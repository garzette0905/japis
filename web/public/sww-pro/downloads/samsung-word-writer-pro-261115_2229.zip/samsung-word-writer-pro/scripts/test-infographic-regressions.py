"""Exercise actual DOCX rendering and appendix ordering with a tall test image."""
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

from docx import Document
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'qa_render' / 'infographic'


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    Image.new('RGB', (1600, 2200), '#dceaff').save(OUT / 'comic.png')
    comic = {'mode': 'infographic', 'image': {'path': 'comic.png'}}
    body = {'title': '검증 보고서', 'sections': [{'heading': '핵심 내용', 'bullets': [{'text': '매출 100에서 120으로 20% 증가'}]}]}
    for name, data, expected in [
        ('standalone', comic, ['#별첨1.']),
        ('combined', {**body, 'appendices': [{'title': '기업개요', 'sections': body['sections']}, comic, {'title': 'CEO Profile', 'sections': body['sections']}]}, ['#별첨1.', '#별첨2. 기업개요', '#별첨3. CEO Profile']),
    ]:
        source = OUT / f'{name}.json'
        target = OUT / f'{name}.docx'
        source.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        subprocess.run([sys.executable, str(ROOT / 'scripts/generate.py'), str(source), str(target)], check=True)
        doc = Document(target)
        text = '\n'.join(p.text for p in doc.paragraphs)
        assert [text.index(label) for label in expected] == sorted(text.index(label) for label in expected)
        assert len(doc.inline_shapes) == 1
        if name == 'standalone':
            assert not doc.element.xpath('.//w:br[@w:type="page"]')
            assert '이 상' not in text
        assert doc.inline_shapes[0].height > 0
    spec = importlib.util.spec_from_file_location('sww', ROOT / 'scripts/generate.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    try:
        module.ordered_appendices([comic, comic])
        raise AssertionError('duplicate summaries accepted')
    except ValueError:
        pass
    try:
        module.render_infographic(Document(), {'image': {}})
        raise AssertionError('missing image accepted')
    except ValueError:
        pass
    import generate_ceo_weekly as weekly
    buf, _ = weekly.build_document({'infographicAppendix': comic}, str(OUT))
    (OUT / 'weekly.docx').write_bytes(buf)
    assert len(Document(OUT / 'weekly.docx').inline_shapes) == 1
    print('[infographic] PASS: standalone, appendix order, required image, duplicates, CEO weekly')


if __name__ == '__main__':
    main()
