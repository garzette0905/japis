# Prompt Builder mode


Use this reference only when the user asks for `Prompt Builder`, `프롬프트 빌더`, `문서작성 프롬프트 생성`, `스킬용 프롬프트`, or asks to open/export the prompt-builder screen.


## Two supported forms


1. **Screen form (번들 HTML 우선)**: Prompt Builder 실행 화면은 번들된 `assets/prompt-builder.html` 파일로 제공한다. 소스 저장소는 **https://github.com/garzette0905/samsung-word-writer-pro** 이며 저장소 페이지 자체는 빌더 실행 화면이 아니다. 사용자는 빌더에서 옵션 선택 → **`ChatGPT 열기`(Web/App)/`Claude 열기`(Web/App) 버튼으로 새 대화를 열고(Web 은 클립보드 복사 후 붙여 넣기, App 은 입력창 자동 채움)**, `Prompt복사` 후 **이 채팅에 붙여넣기** → (수정/오탈자면) 원본 파일 첨부 → 전송. HTML 미리보기를 지원하지 않는 환경에서는 파일을 다운로드/첨부 형태로 제공한다.
2. **Conversational in-builder (게이트형)**: 맨몸으로 스킬만 호출된 경우의 진입 게이트 — 절차는 아래 참조.


번들 HTML은 헬퍼 UI이며, ChatGPT에서 스킬 호출 시 자동으로 열리지는 않는다. **파일 업로드는 채팅에서 이뤄지므로 수정/보완·오탈자 등 원본 파일이 필요한 작업에도 문제없이 동작한다.**


## 오른쪽 카드 버튼 (260915 개편 · 260929 Web 링크化)


버튼 순서와 동작. "열기" 4종은 클릭 시 프롬프트를 **클립보드에 복사**한 뒤 서비스를 연다. **Web 2종은 새 대화 페이지만 열고** 사용자가 입력창에 붙여 넣는다(Ctrl+V) — 260915~260928 에는 chatgpt.com `prompt`·claude.ai `q` 파라미터로 프롬프트를 실어 보냈으나, **사내 웹 프록시(Somansa WebProxy)가 요청 URL 약 8KB 초과를 `414 URI Too Long` 으로 거부**한다(260929 실측 — 한글 1자가 9자로 인코딩되어 옵션을 비운 기본 프롬프트만도 URL 약 13K). 특수문자·내용 문제가 아니라 길이 상한이라 Web 의 URL 전달은 폐지했다. **App 2종(데스크톱 앱 딥링크)은 HTTP 프록시를 거치지 않으므로 종전대로 프롬프트를 파라미터로 실어 입력창을 자동으로 채운다**(Claude `q` 는 디코딩 기준 약 14,000자 상한 — 컴팩트化된 프롬프트는 3~5K). 클립보드 API 가 막히면 textarea 선택 + `execCommand("copy")` 로 폴백하고, 그래도 안 되면 상태 문구로 `Prompt복사` 버튼을 안내한다. 버튼명은 260929 부터 다시 `(App)`(260923~260928 은 `(Work)`/`(Cowork)`).


| 버튼 | 동작 | 첫 줄 호출문 |
|---|---|---|
| `ChatGPT 열기 (Web)` | 클립보드 복사 + `https://chatgpt.com/` 새 탭 | `@samsung-word-writer-pro …` |
| `ChatGPT 열기 (App)` (260929, 260923~28 은 `(Work)`) | 클립보드 복사 + `codex://new?prompt=<encoded>` — ChatGPT 데스크톱 앱 딥링크, 입력창 자동 채움(learn.chatgpt.com Commands › Deep links) | `@samsung-word-writer-pro …` |
| `Claude 열기 (Web)` | 클립보드 복사 + `https://claude.ai/new` 새 탭 | `/samsung-word-writer-pro …` |
| `Claude 열기 (App)` (260929, 260923~28 은 `(Cowork)`) | 클립보드 복사 + `claude://claude.ai/new?q=<encoded>` — Claude 데스크톱 앱 딥링크, 입력창 자동 채움(support.claude.com "Open Claude Desktop with a link") | `/samsung-word-writer-pro …` |
| `Prompt복사(Claude Code, AI Pro, Antigravity)` (260929 부터 Codex 앞) | 클립보드 복사 | `/…` |
| `Prompt복사(Codex)` (260923, 종전 `(ChatGPT)`) | 클립보드 복사 | `@…` |
| `.txt 다운로드` | 프롬프트 텍스트 파일 저장 | 현재 표시 양식 |
| `Skill 다운로드(zip)` | 배포 ZIP(`assets/downloads/…`) | — |
| `GitHub 저장소 열기` (맨 마지막) | https://github.com/garzette0905/samsung-word-writer-pro 새 탭 — 소스 저장소 | — |


앱 딥링크는 앱 미설치 시 브라우저가 아무 동작도 하지 않으므로, 클릭 후 약 1.8초 안에 창 포커스가 바뀌지 않으면 "앱이 설치되어 있지 않거나 실행 확인이 필요" 상태 메시지를 띄우고 Web 버튼을 안내한다.


## 대화형 인빌더 게이트 (맨몸 호출 시)


이 게이트는 스킬 Procedure의 맨 앞(Step -1)에서 **완성형 지시 없이 스킬만 맨몸으로 호출된 경우에만** 트리거된다. 사용자가 Prompt Builder 화면을 명시적으로 열기·표시·내보내기 요청하면 질문 없이 위 Screen form(번들 HTML 우선)을 바로 안내한다.


**먼저 아래 "완성 프롬프트 가드"를 확인한다.** 가드에 걸리면 인빌더를 **작동시키지 않고** 곧바로 Step 0(작성 절차)로 진행한다.


**완성 프롬프트 가드 — 다음 중 하나라도 해당하면 인빌더 실행 금지:**
- 메시지에 `document_type` JSON 블록이 있거나, `"builder_generated": true` 마커가 있음 (= Prompt Builder에서 복사·붙여넣기 한 완성 프롬프트).
- 이미 완성형 지시문(작업 지시·유형·work_mode 등이 갖춰진 프롬프트)을 붙여넣고 실행한 경우.
- 첨부파일이 있거나, 작성 대상·주제가 명확한 작성 요청이 있는 경우.


**가드에 걸리지 않는 "맨몸 호출"**(스킬만 부르고 명확한 작성 태스크가 없음, 예: "스킬 쓸게", "보고서 만들고 싶어")일 때만 아래 게이트를 실행한다:


1. 사용자에게 **한 가지만** 묻는다 — **"화면형 빌더를 사용하시겠습니까?"**, 선택지는 정확히 두 개:
   - **예**
   - **아니오 (현재 Prompt 내용으로 실행)**
2. **"예"** → 번들된 `assets/prompt-builder.html`을 화면에 제공하고, GitHub 저장소 https://github.com/garzette0905/samsung-word-writer-pro 는 소스 링크로 안내한다. *"빌더에서 옵션을 선택 → 생성된 프롬프트 복사 → 이 채팅에 붙여넣기 + (수정/오탈자 작업이면) 원본 파일 첨부 → 전송"* 을 안내한다. HTML 미리보기를 지원하지 않으면 파일을 다운로드/첨부 형태로 제공한다. 파일 업로드는 채팅에서 이뤄진다.
3. **"아니오 (현재 Prompt 내용으로 실행)"** → 화면 빌더를 띄우지 않고, **사용자가 화면(대화)에 입력한 현재 내용을 바탕으로** Step 0부터 바로 실행한다.
4. 이 게이트는 **딱 이 한 번의 예/아니오 질문**까지다 — 그 외 필드를 채팅으로 하나하나 묻지 않는다 (그 외 옵션은 화면형 빌더가 담당).


## Conversational collection fields


Ask only for missing essentials. If the user already supplied enough context, generate the prompt immediately.


### 1. Document type


Primary document type (단일 선택): 01~06, 09 중 하나. 화면에서는 **01~06 과 07~10 사이에 점선**(`.doc-divider`, 260923)이 있어 주 유형과 추가 선택·보완중 유형이 살짝 구분된다.


- `01_언론 기사, 기술·제품개요`
- `02_시장동향·산업분석`
- `03_주간 보고`
- `04_현안 보고`
- `05_개별 사업 전략`
- `06_기존 문서 수정 (업데이트, 오탈자, 문서비교)` — **문서 첨부 필수**. 작업 방식(work_mode)에 따라 세 갈래: `new`(=업데이트, 목차 참고용 표준문서 첨부) / `typo_only`(오탈자만 수정, Word 첨부) / `compare`(문서비교, Word 2개 첨부). 생성 JSON 의 `document_type.primary.sub_mode` 가 `update` / `typo_only` / `compare` 로 실린다.


  **06 선택 시 화면 동작 (260917, 260918 개선)** — ① `더보기` 가 **천천히(0.55초) 펼쳐지고**, 펼침이 끝난 뒤 ② `작업 방식` 이 임시 리스트 박스(size=N)로 바뀌어 높이·투명도가 천천히(0.45초) 늘어나며 나타난다(급작스러운 네이티브 드롭다운 `showPicker()` 는 사용하지 않음. 항목을 고르거나 포커스를 벗어나면 드롭다운으로 복귀). ③ 작업 방식 첫 항목 라벨이 **`문서 작업 선택`**(미선택 안내) 으로 바뀐다 — 미선택(`new`)·`(문서 업로드) 문서 수정/보완`(`rewrite`) 은 06 에서 모두 **업데이트**(`sub_mode: update`) 로 생성되고, `typo_only` / `compare` 는 각각 오탈자 / 문서비교. ④ 작업 방식에 따라 `Prompt 입력` 기본 문구와 첨부 자동 체크(업데이트 → 참고용 표준문서, 오탈자·문서비교 → Word 초안/docx)가 바뀐다. ⑤ 프롬프트 카드 버튼 아래에 **`문서 업로드 필요` 안내**(필요 문서 수: 오탈자 Word 1개 / 문서비교 Word 2개 / 수정·보완·업데이트 1개 이상)가 뜨고, "열기"·"복사" 상태 문구에도 "ChatGPT·Claude 입력창에서 문서를 직접 업로드한 뒤 전송" 안내가 붙는다 — Prompt Builder 는 정적 HTML 이라 파일을 ChatGPT·Claude 로 전달할 수 없다(프롬프트 텍스트도 클립보드로만 전달). 다른 주 유형을 고르면 리스트 박스가 닫히고 `더보기` 가 모두 접히며 자동 입력·자동 체크가 원래대로 돌아간다(사용자가 직접 쓴 내용·체크는 유지).
- `09_전사 레벨 전략 보고 (보완중)` — **화면형 빌더에서는 현재 선택 비활성(disabled)**


**`03_주간 보고` 옆 `CEO 현안보고` 체크박스 (03 하위 옵션, 260911 추가)** — 체크하면 ① 주 유형이 03 으로 고정되고(다른 주 유형을 고르면 자동 해제), ② `보고 목적` 드롭다운이 `경영진 보고 (임원·결재용)` 하나만 보이도록 잠기며, ③ `Prompt 입력` 란이 아래 입력 양식으로 자동 채워진다(사용자가 이미 쓴 내용이 있으면 덮어쓰지 않음). 생성 JSON 에 `ceo_weekly_report` 블록이 실리고 유형별 지시가 CEO 현안보고 전용 지시(전용 생성기 `scripts/generate_ceo_weekly.py`, 존칭 서술형 문체, `To Be Determined`, 표·이미지는 사용자 제공분만)로 바뀐다. 규칙 전문은 `references/ceo-weekly-report.md`.


```text
* 보고 주차(예, 8월 4주차) :
* 조직명 :
* 보고자 :
* 연간 주요업무 :
* 주간 업무 스토리 (첨부 파일 가능) :
※ 항목이 없을 경우 보고서 만들때, 'To Be Determined' 라고 기재해주세요
```


대화형 수집에서도 사용자가 "CEO 현안보고 / 팀 주간 현안보고" 를 요청하면 위 5개 항목만 확인하고(없는 항목은 `To Be Determined`), 나머지 필드는 묻지 않는다.


Additional options: 07, 08, 10 may be selected **in addition to** one primary type. 07과 08은 서로도 중복 선택 가능하다.


**07·08 단독 선택 (260929)** — 화면형 빌더에서 07 또는 08 이 체크된 상태로 **주 유형(01~06) 체크를 해제**하면 주 유형 없는 단독 모드가 된다(07·08 태그 `단독·추가 선택 가능`, 문서 종류 아래 안내 문구). 07/08 이 하나도 없으면 주 유형 해제는 무시되고, 단독 모드에서 마지막 07/08 을 해제하면 01 로 되돌아간다(문서 종류는 항상 1개 이상). 생성 JSON 은 `document_type.primary` 가 07(있으면) 또는 08 이 되고 `mode`(`companyinfo`/`ceoinfo`)·`standalone: true`·`apply_report_logic: false` 가 실리며, 둘 다 골랐으면 08 이 `additional` 로 따라간다(`role: "… 기업개요와 별도 섹션 또는 별첨으로 작성"`). `apply_audience_depth` 는 `false`. 유형별 지시는 "07_기업개요 단독 문서 / 08_CEO Profile 단독 문서(사진 필수) / 07·08 함께 단독 선택(기업개요 본 문서 + CEO Profile 별첨)" 으로 바뀌고 report-logic 라우팅 지시는 빠진다. 스킬은 이 JSON 을 받으면 §기업개요 (companyinfo) mode / §CEO Profile (ceoinfo) mode 로 바로 간다.


- `07_기업개요` → `companyinfo` 모드 고정 구조
- `08_CEO Profile` → `ceoinfo` 모드 고정 구조 (단독 문서일 때 인물 이미지 필수, 별첨이면 권장). 렌더 엔진은 보고서·기업개요와 동일한 `scripts/generate.py`
- `10_지참자료, 색인 (보완중)` — **화면형 빌더에서는 현재 선택 비활성(disabled)**


> 07/08은 원래 하나의 유형(`기업개요·CEO Profile 분석`)이었으나, 사용자가 기업개요와 CEO Profile을 **분리해서 요청**할 수 있도록 별도 항목으로 나눴다. 둘 다 체크하면 각각 별도 별첨(또는 별도 섹션)으로 구분해 작성한다.
> 09·10은 화면에는 보이되 체크박스가 disabled 상태다(둘 다 보완중 유형). 사용자가 대화로 전사 레벨 전략 보고·지참자료를 요청하면 유형 규칙은 그대로 적용한다 — 비활성은 빌더 UI 한정이다.


### 2. Sub-type (하위 유형) — 수집하지 않는다


**`subtype` 필드는 폐지되었다.** 화면형 빌더의 `세부 옵션 선택` 드롭다운도 제거했으므로 프롬프트/JSON에 하위 유형을 싣지 않는다. 하위 유형(장애·이슈형 / 의사결정·대응형 / 진행현황형 / 거래처·Account Status형 / 정책·산업 참고자료형 등)은 **첨부·입력 내용을 보고 스킬이 직접 판단**한다.


- 판단 기준 원천: `references/report-logic.md`의 유형별 "하위 유형" 절(04·05), `references/report-evaluator.md`의 유형별 "Sub 업무" 표.
- 빌더 생성 프롬프트의 작업 지시 3번에 "하위 유형은 프롬프트에서 지정하지 않으므로 직접 판단" 문장이 포함된다.
- 대화형 수집에서도 하위 유형을 사용자에게 묻지 않는다.


### 3. Work mode


Default: `신규 작성`. (06 선택 시 첫 항목 라벨은 `문서 작업 선택` 으로 바뀌며, 값은 그대로 `new` — 06 에서는 업데이트로 해석.)


- `신규 작성`
- `(문서 업로드) 문서 수정/보완` (`rewrite`)
- `(문서 업로드) 오탈자만 수정` (`typo_only`)
- `(문서 업로드) 문서비교` (`compare`, 260917 추가, 260929 라벨에서 `(Word 2개)` 제거) — Word 파일 2개(이전·최신)를 비교해 **최신 버전 파일의 복사본**에 바뀐 부분만 노란 하이라이트. Word 2개가 업로드되지 않았으면 "비교할 Word 파일 2개가 업로드되어 있지 않아 문서비교 작업을 진행할 수 없습니다" 안내 후 중지, 변경 비율(문자 기준) **20% 이상**이면 "많이 바뀌어 문서비교가 어렵습니다" 안내 후 중지. 로컬 환경은 `scripts/compare_docx.py` 가 비교·판정·하이라이트·저장을 한 번에 처리한다. 생성 JSON 에 `document_compare` 블록이 실린다:
  ```json
  "document_compare": {
    "required_documents": 2,
    "stop_if_not_two_docs": true,
    "highlight_target": "later_version",
    "change_ratio_limit": 0.2,
    "stop_if_over_limit": true,
    "script": "scripts/compare_docx.py"
  }
  ```
- `별첨 중심 정리`


> `(문서 업로드) …` 3개 모드와 `별첨 중심 정리`는 업로드 문서를 전제로 한다. `문서 수정/보완`·`오탈자만 수정`·`문서비교` 선택 시 "수정 표시"의 노란색 하이라이트가 자동 체크된다. 기존 `template_reformat` 프롬프트는 하위 호환을 위해 스킬에서 계속 처리하지만 Prompt Builder의 신규 선택 목록에서는 제외한다. 목차를 유지하고 내용만 바꾸는 작업은 `06_기존 문서 업데이트`를 사용한다.


### 4. Attachment types


Allow multiple selections.


- Word 초안/docx
- PDF/보고서
- PPT/슬라이드
- Excel/수치자료
- 기사/URL
- 메모/메일/메신저
- 이미지/캡처
- 참고용 표준문서


### 5. Other options


- `toc`: true only when the user wants a 목차 page.
- `highlight_policy`: `modified_content_yellow_highlight` only when the user asks for modified contents to be highlighted in yellow.
- `title_hint`: optional.
- `audience`: **3값 중 하나** (화면형 빌더의 `보고 목적` 드롭다운, 기본값 `manager`). 값에 따라 깊이·`□` 섹션 수·구조·별첨 정책을 보정한다. 상세 기준표와 가드는 `references/report-depth.md` §"독자별 깊이 보정 (audience)"이 원천이며, 생성 프롬프트에는 `보고 목적(독자) 기준 지시` 블록으로 실린다.


  | 값 | 라벨 | 요약 |
  |---|---|---|
  | `executive` | 경영진 보고 (임원·결재용) | 유형 목표 깊이 +1(상한 L4), `□` 3~5개·1페이지, 두괄식 → 리스크·대응 → 실행 권고 Top N → `※ 최종 판단`, 기업개요·CEO·상세표는 전부 별첨 |
  | `manager` | 팀장 보고 (관리자) — **기본값** | 유형 목표 깊이 유지(L2~L3), `□` 5~7개, 현황 → 이슈 → 대응 균형, 별첨 1~2개 |
  | `working` | 실무 검토 (상세 내용 포함) | 유형 최소 깊이 유지·해석 최소화, `□` 7개 이상 허용(번호 챕터 그룹핑 금지), 사실·맥락 우선, 상세표·원문 발췌 별첨 적극 |


  적용 유형은 **01·02·04·05·09뿐**이다 — 03(시사점 강제 금지)·06(표준문서 목차 고정)·07·08(고정 구조)·10은 유형 고유 규칙이 우선한다. 보고 목적과 무관하게 **이동글틀은 페이지당 최소 3개 이상**, **`·` 레벨 상세는 필요하면 추가**한다. **`CEO 현안보고` 체크 시** `audience` 는 `executive` 로 고정 표시되지만 `apply_audience_depth` 는 `false` — 보정표 대신 전용 양식 규칙을 따르고 이동글틀도 쓰지 않는다.
- `extra_request`: optional. 화면형 빌더의 **"Prompt 입력"(#extra)** 값이며, 생성 프롬프트 최상단 `★ 최우선 사용자 지시` 블록으로 배치된다. 문서 종류로 **06을 선택하면 이 입력란이 06 전용 기본 문구로 자동 채워지고**(사용자가 이미 입력한 내용이 있으면 덮어쓰지 않음), 06 외 유형으로 바꾸면 원래 안내 문구(placeholder)로 되돌아간다. 06 기본 문구:
  ```text
  첨부 문서의 제목 및 상위레벨(1., 2. 등 번호숫자 또는 □ 레벨) 목차는 유지하고 하위 내용을 지침에 맞게 변경해주세요.
  예) 첨부한 표준 문서의 목차를 참고하여 문서를 만들어주세요
  ```
- `include_diagrams`: optional boolean. 화면형 빌더에서 `Prompt 입력 (최우선 반영)` 오른쪽의 **보고서내 도식포함** 체크박스 값이다. `true`이면 본문에 내용과 직접 연결된 간단한 편집 가능 Word 도식을 반드시 1~2개 포함한다. 도형 테두리와 연결 화살표 선은 검은색 1.0pt이며, 연결선은 단일 화살표 선으로 작성한다. 도식은 표준 템플릿 13종(`horizontal_flow`/`vertical_flow`/`chevron_flow`/`2x2_cycle`/`cycle`/`comparison`/`hub_spoke`/`hierarchy`/`layers`/`matrix_2x2`/`timeline`/`funnel`/`pyramid`) 중 내용 구조에 맞는 것을 고르고, 노드 제목 8자·항목 14자 이내로 쓴다 (`references/content-schema.md` §Diagram).
- `save_path`: optional. **로컬 환경(Codex·Claude Code·Antigravity·AI Pro) 전용** — 사용자가 Word 저장 폴더를 지정하면 그 경로를 최우선으로 사용. 미지정 시 로컬에 `D:\Secure Folder`가 있으면 거기, 없으면 기본 경로. **`D:\Secure Folder`에 저장이 불가한 환경이면 실제로 저장한 다른 경로를 사용자에게 표시**한다(JSON 경로는 불필요). 화면형 빌더 하단 "Word 파일 저장경로" 입력란이 이 값을 만든다.


## Prompt output format


Generate a complete prompt in Korean. It must include:


- skill trigger: `@samsung-word-writer-pro`
- `document_type` JSON
- `output_format: docx`
- attachment analysis instructions
- type-specific instructions for 01~05 when relevant
- instructions for 07/08/10 when selected as additional options
- `보고 목적(독자) 기준 지시` block derived from `audience`


## document_type JSON shape


```json
{
  "document_type": {
    "primary": {
      "code": "01",
      "name": "01_언론 기사, 기술·제품개요",
      "display_name": "01_언론 기사, 기술·제품개요",
      "logic_source": "references/report-logic.md v0.3",
      "apply_report_logic": true,
      "outline_policy": "핵심/개요 → 구조화된 사실 블록 → 사례/비교/리스크 → 의미 → SDS 시사점"
    },
    "additional": [
      {
        "code": "07",
        "name": "07_기업개요",
        "display_name": "07_기업개요",
        "mode": "companyinfo",
        "role": "기업개요(companyinfo 모드 고정 구조)를 별첨 또는 본문 보조자료로 활용"
      }
    ]
  },
  "work_mode": "신규 작성",
  "output_format": "docx",
  "toc": false,
  "highlight_policy": "none",
  "attachments": ["Word 초안/docx"],
  "audience": "manager",
  "audience_label": "팀장 보고 (중간관리)",
  "apply_audience_depth": true,
  "title_hint": ""
}
```


`CEO 현안보고` 체크 시 primary 03 에 다음이 덧붙는다 — `display_name: "03_주간 보고 (CEO 현안보고)"`, `audience: "executive"`, `apply_audience_depth: false`, 그리고 최상위 블록:


```json
"ceo_weekly_report": {
  "enabled": true,
  "template": "ceo_weekly_v1",
  "reference": "references/ceo-weekly-report.md",
  "generator": "scripts/generate_ceo_weekly.py",
  "filename_pattern": "[X월 X주차 현안보고] 조직명_YYMMDD_HHMM.docx",
  "missing_field_text": "To Be Determined",
  "input_fields": ["보고 주차", "조직명", "보고자", "연간 주요업무", "주간 업무 스토리"],
  "user_supplied_only": ["표", "이미지", "설명주석(※)"]
}
```


For primary 09 or additional 10, set `display_name` with `(보완중)`. Primary 05 is analyzed and should not be marked 보완중. 추가 항목에는 `mode` 필드도 함께 싣는다 — 07 → `companyinfo`, 08 → `ceoinfo`, 10 → `reference`. `apply_audience_depth`는 primary code가 01·02·04·05·09일 때만 `true`다.


## Standard prompt template (260929 컴팩트化)


프롬프트 기본형이 3,600자에 달해(URL 인코딩 18K) 표준 지시를 **요지 + 참조 위치**로 줄였다(기본형 약 2,800자). 상세 규칙은 프롬프트에 되풀이하지 않고 SKILL.md·`references/*.md` 를 가리킨다 — 톤·서식(`tone.md`), 이동글틀 앵커·강조 열(SKILL.md Cross-mode invariants), 독자 보정(`report-depth.md`), 업데이트(`template-apply.md`), 오탈자·문서비교(`evaluate-revise.md`), CEO 현안보고(`ceo-weekly-report.md`), 기업개요·CEO Profile(`companyinfo.md`·`ceoinfo.md`). 블록 사이 빈 줄은 1줄로 통일한다.


```text
@samsung-word-writer-pro 스킬을 활용하여 아래 조건에 맞는 삼성형 Word 보고서를 작성해주세요.


※ 위 스킬이 호출되지 않거나 찾을 수 없으면 "samsung-word-writer-pro 스킬을 추가(설치)한 후 다시 실행해주세요" 라고 안내하고 작업을 진행하지 마세요.
※ 이 프롬프트는 Prompt Builder 완성형 프롬프트(builder_generated: true)입니다. 대화형 인빌더를 작동시키지 말고 아래 지침으로 바로 실행해주세요.
{★ 최우선 사용자 지시 블록 — Prompt 입력이 있을 때}


아래 document_type JSON 을 우선 적용해주세요.


```json
{JSON}
```


작업 지시:
1. 산출물은 Word(.docx). toolName·llmVersion 은 확인된 이름 그대로(추정 금지), 파일명은 생성기가 `제목(Tool, LLM)_YYMMDD_HHMM.docx` 로 자동 생성.
2. `references/report-logic.md` 로 문서유형·목차 흐름 결정, 01~05 는 v0.3 우선, 하위 유형은 직접 판단. (07·08 단독이면 "고정 구조라 라우팅 미적용" 한 줄)
3. 단순 재포맷 금지, 빠진 논리·SDS 관점 보완.
4. 삼성형 톤·서식은 SKILL.md·`references/tone.md` 그대로 — □/-/·/※/→ 구조, 압축 명사형, 한자 미사용, 표 행 0.8cm, `__…__`/`**…**` 부분 강조, `예)`, 국내 서비스 여부 `※`.
5. 파란 9pt 이동글틀 — 출처는 줄 끝 날짜·괄호 토큰(예: `(9/8)`), 모델명은 이름 앵커, 비교표 강조 열 `"highlightColumn"`.
6. 별첨은 본문 보조자료로만.
{기존 문서 평가/보완 · 오탈자만 수정 · 문서비교 · 수정 표시 · 도식 포함 지시 — 해당 시}


보고 목적(독자) 기준 지시 (`references/report-depth.md` §독자별 깊이 보정):
- 보고 목적 : {라벨}
{독자별 3줄}
- 적용 유형 01·02·04·05·09, 이동글틀 페이지당 3개 이상, 번호 챕터 신규 그룹핑 금지.


유형별 추가 지시:
{TYPE_SPECIFIC_INSTRUCTIONS}


첨부파일 분석 지시:
{ATTACHMENT_INSTRUCTIONS}
{문서 제목/주제 : … — 있을 때}


작업파일 저장 지시 (로컬 환경만):
- 저장 우선순위 ① 지정 경로 → ② D:\Secure Folder → ③ 기본 경로. 완료 후 Word 파일 경로 안내.


최종 산출물:
- Word 파일(.docx)
- 적용한 문서유형과 목차 흐름 한 줄 요약
- 저장된 Word 파일 경로 안내 (로컬 환경)
```


## Type-specific instructions


- 01: `핵심/개요 → 구조화된 사실 블록 → 사례/비교/리스크 → 의미 → SDS 시사점` 흐름을 우선 적용. 배경과 경쟁사 비교는 내용이 있을 때만 선택 적용.
- 02: 시장/경쟁사 현황과 구조화된 분석 후 반드시 SDS 연결 또는 자사 비교 포함. 데이터·표는 의미 해석과 `→/⇒` 시사점으로 연결.
- 03: 사실 공유형 정기보고. SDS 시사점, 장문 해석, 별첨을 억지로 넣지 않음. 고객명, 금액, 기간, 일자, 수행범위를 보존하고 `- 이 상 -`으로 마무리.
- 03 + CEO 현안보고: `references/ceo-weekly-report.md` 를 읽고 `scripts/generate_ceo_weekly.py` 로 생성. 입력 5항목 → `week/org/reporter/annualTasks/sections`, 빈 항목 `To Be Determined`. 존칭 서술형(`~하였습니다/~예정입니다/~하겠습니다`), □ 2~4개·`-` 2~4개·2~3줄, □ 헤딩 Bold + 중요 어구 `**…**`. 표·이미지·※ 는 사용자 제공분만. SDS 시사점·별첨·이동글틀 금지. 파일명 `[X월 X주차 현안보고] 조직명_YYMMDD_HHMM.docx`.
- 04: 장애·이슈형 / 의사결정·대응형 / 진행현황형 / 거래처·Account Status형 중 먼저 판단. 마지막은 SDS 입장, 대응방향, 의견, 재발 방지대책 중 문서 성격에 맞게 처리.
- 06 (업데이트, `sub_mode: update`): 표준문서(목차 참고용 업로드 문서)의 제목·상위레벨 목차를 유지하고 하위 내용만 재구성. 표준문서 미첨부 시 `참고할 문서를 알려주세요` 안내 후 중지. 상세 규칙은 SKILL.md §"06_기존 문서 수정 — 업데이트 (template_apply) 모드". 업데이트일 때만 JSON에 `template_apply` 블록이 함께 실린다:
  ```json
  "template_apply": {
    "standard_document_required": true,
    "keep_title": true,
    "keep_top_level_outline": true,
    "rewrite_scope": "sub_level_only",
    "no_extra_sections": true
  }
  ```
- 06 + 오탈자만 수정 (`sub_mode: typo_only`): 유형별 지시가 "내용·목차·서식 불변, 오탈자만 수정" 으로 바뀌고 `오탈자만 수정 지시` 블록이 실린다. Word 미첨부 시 `오탈자를 수정할 Word 문서를 첨부해주세요` 안내 후 중지. 규칙: `references/evaluate-revise.md` §오탈자만 수정.
- 06 + 문서비교 (`sub_mode: compare`): `문서비교 지시` 블록(Word 2개 필수 → 20% 판정 → 최신본 하이라이트 → 경로·비율·대비표 보고)이 실리고 업데이트·평가 지시는 적용하지 않는다. 규칙: `references/evaluate-revise.md` §문서비교.
- 07 additional: 기업개요는 `companyinfo` 모드 고정 목차(설립/본사 → 경영진 → 인력 → 시가총액 → 주주 → 주요사업 → 경영실적)로 작성. 본문에 과도하게 넣지 말고 별첨 또는 보조 섹션으로 분리. 사용자가 기업개요 자체를 산출물로 요청한 경우에만 단독 문서로 작성.
- 08 additional: CEO/인물 프로필은 `ceoinfo` 모드 고정 목차(이름 → 국적/출생 → 학력 → 주요 이력 → 참고사항)로 작성하고 **인물 이미지 확보**(없으면 사용자에게 요청 — 단독 CEO Profile 문서는 사진 없이 생성이 막힌다). 본문 과다 서술 금지, 별첨 또는 보조 섹션으로 분리하며 별첨에는 `appendices[].profileImage` 로 사진을 붙인다. **인물이 여러 명이면 인물별 □ 섹션의 `sections[].profileImage`** 로 □ 헤딩 우측 "텍스트 앞" 그림(260923) — 인라인 사진 단락·`※ 사진` 캡션 줄 금지, 사진 옆 줄 겹침은 생성기 줄폭 예약 + `verify_docx.py` 로 확인.
- 07 + 08 동시 선택: 기업개요와 CEO Profile을 한 섹션에 섞지 말고 각각 별도 별첨(또는 별도 섹션)으로 구분.
- 07 단독 (`primary.code: "07"`, `standalone: true`): SKILL.md §기업개요 (companyinfo) mode · `references/companyinfo.md` 고정 목차로 단독 문서. 보고서 본문·시사점·목차 페이지·번호 목차 없음.
- 08 단독 (`primary.code: "08"`, `standalone: true`): SKILL.md §CEO Profile (ceoinfo) mode · `references/ceoinfo.md` 고정 목차로 단독 문서, **인물 사진 필수**(없으면 사용자에게 요청 후 진행), 여러 명이면 인물별 □ 섹션 `sections[].profileImage`.
- 07 + 08 단독: 기업개요를 본 문서로, CEO Profile 을 별첨(또는 별도 섹션)으로 각각 고정 구조.
- 09: 입력자료 성격에 맞게 구조를 제안하고 무리한 섹션은 만들지 않음.
- 10 additional: 지참자료·색인 성격의 첨부는 본문 작성의 참고자료 또는 별첨 source로 활용.


## Attachment instructions


Include only applicable lines.


- Word 초안/docx: 기존 논리를 우선 파악하고, 필요한 경우 목차·문장·표를 삼성형 보고서 양식으로 재구성.
- PDF/보고서: 본문뿐 아니라 표·도표·이미지 내 텍스트까지 확인해 핵심 근거 반영.
- PPT/슬라이드: 장표 제목, 메시지, 표/도식 논리를 추출해 Word 보고서 구조로 변환.
- Excel/수치자료: 수치·표·시계열을 확인해 본문 요약표 또는 별첨 표로 반영.
- 기사/URL: 핵심 사실, 발표 주체, 날짜, 전략적 의미를 확인하고 중복 출처 주석 회피.
- 메모/메일/메신저: 의사결정 사항, 지시사항, 일정, 담당조직 우선 추출.
- 이미지/캡처: 표·도식·스크린샷 내용을 읽어 본문 또는 별첨에 반영.
- 참고용 표준문서: 그대로 복사하지 말고 목차 흐름, 표현 톤, 표 구성 패턴만 참고. **문서 종류 06 선택 시 이 항목이 자동 체크**된다 (06은 목차 참고용 표준문서 첨부가 전제). 사용자가 직접 체크/해제한 상태는 유지된다.
