# SDS 임원 보고서 문체 규칙 (Tone rules)


The single thing that distinguishes this style from ordinary Korean prose is
**information density per line**. Every line is a standalone fact. Padding,
hedging, and narrative connective tissue all go away. Think: "a staff officer
briefing an executive in 3 minutes."


Read all of this before you start rewriting. These are the rules that give
the output its characteristic look.


---


## 1. Sentence ending — 명사형 / 축약형 우선


Rewrite verb endings to noun or compressed forms. This is the #1 signal.


| Avoid | Prefer |
|---|---|
| ~입니다 / ~습니다 | (삭제) |
| ~한다 / ~된다 | ~함 / ~됨 / (명사로 마침) |
| ~할 예정입니다 | ~예정 |
| ~진행 중입니다 | ~중 / ~진행 중 |
| ~필요합니다 | ~필요 |
| ~있습니다 | ~있음 / (명사로 마침) |
| ~가능합니다 | ~가능 |
| ~전망됩니다 | ~전망 |
| ~검토 중 | ~검토 중 |


**Before:** Microsoft가 M365 Copilot에 OpenClaw와 유사한 에이전트를 통합해서 개발하고 있는 것으로 알려졌습니다.
**After:**  Microsoft, M365 Copilot에 OpenClaw 유사 Agent 통합 개발 중


---


## 2. One information per line — 한 줄 = 한 정보


Each bullet carries exactly one fact. If a sentence naturally has two facts
("A이면서 동시에 B도 있음"), split into two bullets. If two facts are tightly
linked, use a `·` detail line under the parent bullet.


**Before:** 기업고객을 대상으로 하며 강화된 보안 기능과 접근 통제 기능이 탑재될 예정이고, 로컬 PC에서 실행되며 사용자 대신 작업을 수행하는 에이전트입니다.


**After:**
```
  - 기업고객 대상, 강화된 보안·접근 통제 기능 탑재 예정
  - Claw : 로컬 PC에서 실행되며 사용자 대신 작업 수행하는 Agent
```


---


## 3. Line length — 30~55 characters


Aim for 30~55 Korean characters per line. If a line runs over, break at a
clause boundary and wrap with **6-space indent** so the wrapped text aligns
with the content column (not with the bullet character).


**Example (line too long, wrapped):**
```
  - 핵심 기능은 'always-on' 상태로 장기간 다단계 작업을
    지속 수행하는 것
```


**Single-character widow rule**: if a bullet wraps with only 1–2 orphan characters
on the last line, first try to tighten the wording. If the text is already as
tight as it gets, set `"scale": 92` (or 93) on that bullet to condense the
letter-spacing just enough to pull the widow back up. Do **not** force every
line onto a single row — use `scale` surgically only for awkward widows.


---


## 4. Bullet hierarchy — 수동 들여쓰기


The hierarchy is **not** Word's list feature. It is literal spaces + symbols
in the text. The generator preserves them verbatim.


**Canonical order (top → bottom).** The top two tiers (`Ⅰ` / `1.`) are
**optional** and should be used only when the report is large enough to
need them — default briefs start at `□`.


| Level | Prefix | Size | Required? | When |
|---|---|---|---|---|
| Roman chapter | `Ⅰ. ` / `Ⅱ. ` / `Ⅲ. ` | 16pt bold | **Optional** — 매우 큰 범위의 보고서 | Top-level grouping in very large or TOC-backed reports |
| Number chapter | `1. ` / `2. ` / `3. ` | 15pt bold | **Optional** | Sub-chapter under a Roman-numeral chapter, or mid-tier grouping in a long report |
| Section | `□ ` | 14pt bold | Always | Each main section (default starting point for ordinary briefs) |
| L1 bullet | `  - ` (2sp + hyphen + space) | 14pt | Always | Facts under a section |
| L2 bullet | `    ·` (4sp + middle-dot) | 14pt | Always | Detail under L1 |
| Wrap | 6 spaces | 14pt | — | Continuation of previous line |
| Note | `  ※ ` | 14pt | — | Supplementary note at end of section |
| Implication | `  → ` (2sp + arrow + space) | 14pt | — | "What this means" / follow-on |
| Subhead | `< … >` | 14pt bold | — | Inline mini-heading for a chart/table block |
| Bracket tag | `[위협]` / `[기회]` at section heading start | — | — | Threat/opportunity framing |


Visualized (only the two bottom tiers are mandatory):


```
Ⅰ. 대분류                 ← Optional — 매우 큰 범위의 보고서
   1. 중분류              ← Optional
      □ 소분류            ← default starting point
         - 본문
            · 세부
```


Set `"numeral": "Ⅰ"` or `"number": 1` on a section in the content JSON. The
generator drops the `□` prefix automatically for those levels — never combine
`Ⅰ`/`1.` with `□`, the markers are redundant.


### Circled numbers (`①②③`) — dash/dot 수준의 옵션 기호


`①②③` 번호는 **별도의 계층이 아니라 `-` (대시) / `·` (도트) 레벨에서 순서를
표시할 때 사용하는 선택적 기호**다. 전략 항목, 단계별 절차, 순위 있는 발견사항
처럼 순서 자체가 의미를 지닐 때만 사용하고, 나머지는 일반 `-` / `·`을 유지한다.
`Ⅰ`·`1.`·`□` 자리에는 절대 사용하지 않는다. (content JSON: `"kind": "circled"`)


**안티패턴 — `dash`/`dot` 불릿의 `text` 안에 `①②③`을 리터럴로 넣지 말 것.** `- ① …` 처럼 대시 마커와 원문자 마커가 중복 출력된다. 순서 있는 항목은 반드시 `{ "kind": "circled", "index": N, "text": "…" }` 로 승격해 원문자를 **유일한 마커**로 쓴다. `arrow` / `note` 도 동일 — 텍스트 앞에 `①②③`을 붙이지 않는다.


**같은 이유로 `text` 를 불릿 자신의 마커로 시작하지 말 것.** `{ "kind": "arrow", "text": "→ 성사 시 …" }` 는 `  → → 성사 시 …` 로 화살표가 두 번 찍힌다. `note`(`※`), `dash`(`-`), `dot`(`·`) 모두 동일하며, 마커는 언제나 생성기가 붙인다. 함의 문장은 화살표 없이 내용만 쓴다 — `{ "kind": "arrow", "text": "성사 시 …" }`. (유일한 예외는 `wrap`: 접기 줄에서 `→ …` 로 시작하는 것은 정상 용법.)


**Bold is reserved for key takeaways and action items.** The primary visual
hierarchy comes from size (title 20pt vs body 14pt), the `□` symbol, and
indentation. However, in the SDS 시사점 section or equivalent, critical
implication lines (`→`) and action-item summaries may use `"bold": true` for
emphasis. Limit to 1–3 bold bullets per section to maintain contrast.


The `·` is **U+00B7 middle dot**, not a hyphen or bullet.


### 하위레벨·개조식 변형 규칙 (실무 교정 반영)


임원 교정에서 반복 확인된 위계 판단 규칙. 렌더러는 `-`/`·`/`→`/`※`를 모두 지원하므로, **어떤 상황에 어떤 기호를 쓸지**가 핵심이다.


- **`-`(L1) 항목의 세부·부연은 `·`(L2)로 내린다.** 특히 `-` 문장 안의 괄호 수치·부연은 본문에 붙이지 말고 별도 `·` 하위 항목으로 분리한다.
  - (예) `- …인식 격차 존재 (부모 27% Vs 자녀 38%)` → `- …인식 격차 존재` + `  ·부모 인지 27% vs. 자녀 실사용 38%`
- **여러 실행/제언 항목은 상위 `-`로 묶고 하위를 `·(라벨)`로 편다.** 병렬 `→`를 여러 줄 나열하지 않는다.
  - (예) `→ 확보 : …` / `→ 육성 : …` (독립 2줄) → `- 대응 방안` + `  ·(확보) …` + `  ·(육성) …`
- **단기·중장기 제언은 `→` 하나로 시작해, 단기 문장 끝에 쉼표를 찍고 중장기는 다음 줄에 들여써 잇는다.** `→`를 두 번 쓰지 않는다.
  - (예) `→ 단기적으로는 …,` + `   중장기적으로는 …`  (❌ `→ 단기적으로는 …` / `→ 중장기적으로는 …` 처럼 화살표 2개로 나누지 않는다)
- **사실과 결론이 두 줄로 나뉘면 한 줄 `→`로 통합한다.** `※사실` + `→결론`을 각각 두지 말고 `→ …작용, …부상`처럼 하나의 귀결 문장으로 합친다.
- **`→`는 섹션당 종합 결론 1줄, `※`는 보충 사실·제언**으로 역할을 구분한다.
- **`·` 레벨 예시는 `예)` 로 시작한다 (260923).** `·예시 : 이메일 발송·여행 예약` (❌) → `·예) 이메일 발송·여행 예약` (✅). 생성기가 `예시 :`/`예 :` 선행 라벨을 자동으로 `예) ` 로 바꾼다.
- **□ 하위 내용의 핵심은 밑줄·Bold 로 강조한다 (260923 손수정본).** 정의 문장의 핵심 어구는 `__…__`(부분 밑줄), 실행 항목의 핵심은 `**…**`(부분 Bold), 구조·결론 줄 전체는 `"bold": true`. 예: `- 정의 : 목표를 실행 계획으로 바꿔 __앱 종료 후에도 일하는 상시 Agent__` / `- 구조 : 사용자별 전용 클라우드 VM + 격리 브라우저 + 자격증명 금고` (`bold`) / `→ Muse는 OpenClaw(통제·투명성)·Grok Bot(팀용)과 달리 소비자 편의성에 집중` (`bold`). 섹션당 1~2곳만 — 모두 강조하면 아무것도 강조되지 않는다.
- **서비스·제품 소개에는 국내 서비스 여부를 `※` 로 명시한다 (260923).** 독자가 반드시 묻는 질문이므로 `※ 미국 한정 서비스 개시, 한국 내 서비스 일정 미정 (meta.ai의 경우 1년 소요)` 처럼 출시 지역·국내 일정(미정이면 미정)·유사 서비스의 국내 도입 소요 기간을 한 줄로 적는다.


---


## 5. Symbols and shorthand


| Symbol | Meaning | Example |
|---|---|---|
| `→` | 시사점 / 귀결 / 파생 | `→ SDS 등 M365 기반 고객 대상 AI Agent 채택 가속화 예상` |
| `※` | 단락 끝의 보충·강조 | `※ 로컬 실행·보안 통제·상시 작동이 3대 키워드` |
| `↑` `↓` | 증가 / 감소 | `채택률 78%→88% ↑` |
| `∼` (U+223C) | 범위 | `10∼20%`, `3∼5명` |
| `·` (U+00B7) | 인라인 나열·하위 bullet | `보안·접근 통제` |
| `$` `B$` `₩` | 금액 | `258B$`, `100억원+` |
| `+` suffix | 초과 | `100+ 고객`, `연간 8%+` |


### 표현 정규화 (실무 교정 반영)


- **전환·이동은 화살표로.** "A에서 B로" 서술 대신 `A → B`로 압축한다. (예) `청년 개인에서 가족 전 세대로 이동` → `청년개인 → 가족 전세대로 이동`
- **영문 약어 `vs.`** 는 소문자 + 마침표로 통일한다 (`Vs`/`VS` 금지).
- **에이전트 → Agent (전 보고서 공통).** 본문의 '에이전트'는 모든 보고서에서 영문 `Agent`로 표기한다. 생성기(`normalize_body`)가 자동 치환한다.
- **영어권(라틴문자) 인물명은 원어(영문) 표기.** 한글 음차 대신 영문으로 쓴다 — 나델라 → Nadella, 알트만 → Altman, 아모데이 → Amodei. (한국·중국·일본 등 비영어권 인물명은 통용 표기·로마자 병기 관례를 따른다.)
- **완곡·모호한 서술 대신 고유명사를 직접 쓴다.** (예) `안전 지향 연구소도 …` → `Anthropic도 …`
- **전망성 결론은 양태를 명시한다.** 문미에 `… 전망`, `… 예상` 등을 붙여 사실과 구분한다.
- **불필요한 수식·부연은 덜어낸다.** (예) `(부모 27% Vs 자녀 38%, 주간 기준)` → `·부모 인지 27% vs. 자녀 실사용 38%`


---


## 6. Hanja — 사용하지 않음 (전면 한글)


**보고서 본문에 한자(漢字)를 쓰지 않는다.** 요일·연·월·일·시 단위, 정도/등급,
회사 표기, 국가명 비교 등 과거에 한자로 적던 자리도 **모두 한글**로 적는다.
한자가 한 글자라도 남으면 안 된다.


| ❌ Don't (한자) | ✅ Write (한글) |
|---|---|
| `'26年`, `3月`, `5日`, `週 1회`, `12時` | `'26년`, `3월`, `5일`, `주 1회`, `12시` |
| 요일: `(月)`·`(火)`·`(水)`·`(木)`·`(金)`·`(土)`·`(日)` | `(월)`·`(화)`·`(수)`·`(목)`·`(금)`·`(토)`·`(일)` |
| `비중高`, `ROI中`, `규모大` | `비중 높음`, `ROI 중간`, `대규모` |
| `有`·`無`·`未정`·`內`·`外`·`前`·`後` | `있음`·`없음`·`미정`·`내부`·`외부`·`이전`·`이후` |
| `Anthropic社`, `美`·`韓`·`中`·`日`, `等` | `Anthropic`, `미국`·`한국`·`중국`·`일본`, `등` |
| `業務`, `使用`, `時間`, `構築`, `導入`, `創出`, `生產性` | `업무`, `사용`, `시간`, `구축`, `도입`, `창출`, `생산성` |


생성기(`scripts/generate.py`)가 렌더 직전에 관용 단자 한자를 한글로 자동
치환하는 안전망을 두지만(`normalize_hanja`), **작성 단계에서부터 한글로 쓰는
것이 원칙**이다. 자동 치환에 의존해 한자를 남기지 말 것.


상단 보고서 일자의 요일도 한글로 — 예: `'26. 6. 25 (목)` (`(木)` 아님).


---


## 6-9. 인라인 날짜 표기 — 본문 이벤트 날짜는 `M/D`


본문 괄호 안 이벤트 날짜는 `M/D` 형식으로 짧게 적는다 (연도·한자 없음).


| ❌ Don't | ✅ Write |
|---|---|
| `('26.6.24)` | `(6/24)` |
| `(2026년 6월 24일)` | `(6/24)` |


연도가 의미상 꼭 필요할 때(과거 연도 비교 등)만 `'25.10` 처럼 연도를 병기한다.
우상단 보고서 `date`(요일 포함)는 종전대로 `'26. 6. 25 (목)` 형식을 유지한다.


---


## 6-10. 영어 단어 — 1~2개 단독 사용 시 첫 글자 대문자


보통명사 영어 단어를 1~2개만 단독으로 쓸 때는 첫 글자를 대문자로 적는다.
생성기(`normalize_body`)가 **전체 소문자** 단독 영어 단어를 자동 대문자화하므로,
작성 단계에서 소문자로 써도 산출물에는 대문자로 나온다.


| ❌ Don't | ✅ Write |
|---|---|
| `frontier 모델` | `Frontier 모델` |
| `full-stack 수직통합` | `Full-stack 수직통합` |
| `inference 전용` | `Inference 전용` |
| `scale-up은 서버 내 칩 연결` | `Scale-up은 서버 내 칩 연결` |
| `scale-out은 서버 간 클러스터 연결` | `Scale-out은 서버 간 클러스터 연결` |


이미 대문자 약어(AI, GPU, DC, TPU)·고유명사(OpenAI, Nvidia, Broadcom)·
이미 대문자가 섞인 단어(Full-stack으로 이미 쓴 경우)는 변경 없음.


---


## 6-11. 연도 표기 — 항상 `'YY년` (아포스트로피 + 뒤 2자리)


본문·제목·헤딩 어디서든 연도를 4자리 그대로(`2026년`, `2030년`) 쓰지 않는다.
**아포스트로피 + 뒤 2자리 + 년**으로 축약한다.


| ❌ Don't | ✅ Write |
|---|---|
| `2026년` | `'26년` |
| `2030년까지` | `'30년까지` |
| `2024년도 상반기 보고` | `'24년도 상반기 보고` |
| `1976년 설립` | `'76년 설립` |


생성기(`scripts/generate.py`의 `normalize_body`)가 렌더 직전 `(19|20)XX년` 패턴을 `'XX년`으로 자동 치환하는
안전망을 두지만, 한자 규칙과 마찬가지로 **작성 단계에서부터 축약 표기로 쓰는
것이 원칙**이다.


예외: 본문 인라인 이벤트 날짜(`M/D`, §6-9)는 연도를 아예 쓰지 않으므로 이
규칙과 무관하다.


## 6-12. 제목 1줄 고정 — 넘치면 축약


문서 제목(`title` / `reportTitle` / CEO Profile 제목 등)은 20pt bold로
**한 줄 안에 들어가야 한다.** 초안이 페이지 폭을 넘어 2줄로 줄바꿈될 것 같으면
핵심어만 남기고 축약한다.


| ❌ Don't (2줄로 줄바꿈됨) | ✅ Write (1줄) |
|---|---|
| `MS 개발도구 AI 모델 전환 계기로 본 AI 활용·투자전략` | `MS 개발도구 AI 모델 전환 현황 및 향후계획` |


- 대략적 기준(20pt, 여백 포함 A4 폭 기준): 한글 위주 제목은 **약 24~25자
  이내**. 영문 단어가 섞이면(절반 폭) 더 길게 가능.
- 정확한 판정은 `scripts/generate.py`가 생성 시
  자동으로 한다 — 제목이 한 줄 폭을 넘으면 `[WARN] 제목이 한 줄 폭을 초과해
  Word에서 2줄로 줄바꿈됩니다` 를 stderr에 출력한다. 이 경고가 뜨면 제목을
  더 축약해 재생성한다.
- 부제·수식어를 덜어내고 핵심 키워드만 남기는 방향으로 축약한다 — 문장
  구조를 바꾸는 것이 아니라 길이를 줄이는 것이 목적.
- **장식용 괄호·인용부호부터 뺀다** — `「 」`·`『 』`·따옴표 등은 정보를
  더하지 않고 폭만 늘린다. 제목이 1줄을 넘길 것 같으면 핵심어를 줄이기 전에
  먼저 이런 괄호/인용부호를 제거해본다. (예: `Nvidia, Wall Street와 「5,000억
  달러 AI 파이낸싱」 추진` → `Nvidia, Wall Street와 5,000억 달러 AI
  파이낸싱 추진`). 낫표 자체는 §6 "「 」(낫표)"에서 본문·제목에 선택적으로
  허용하지만, 제목에서는 **1줄 고정이 낫표 사용보다 항상 우선**한다.


---


## 7. 주석 (Annotations) — 파란 9pt 텍스트 상자, 단어 아래 배치


주석은 본문 한 줄을 읽다가 막히는 지점을 그 자리에서 짧게 풀어주는 장치.
실제 SDS 보고서에서 주석은 **세 가지 용도**로 쓰이며, 빈도 순은 다음과 같다:


1. **단문 맥락 보강** — 조건·범위·전제·비공개 사실을 한두 구절로 부연
2. **약어·도메인 용어 풀이** — 낯선 약어·기술·제품명의 정의
3. **출처 인용** — 출처 자체가 신호일 때만 (선택적)


출처 인용은 세 용도 중 가장 드문 쪽이며 **기본 동작이 아니다**. 모든
숫자에 기계적으로 출처를 다는 것은 오히려 정보 밀도를 떨어뜨린다.


### 이동글틀 작성 기준 (필수 5원칙)


이동글틀을 만들 때 아래 5가지를 기준으로 삼는다.


1. **출처 언급** — 인용한 매체·기관·1차 소스 URL은 `* 출처 : {매체 또는 URL}` 형식으로 부착한다.
2. **발생시점(일자) 표시** — 기사·발표·이벤트의 시점을 이동글틀로 부착한다: `* {M/D}일 발표`, `* '{YY}.{M}월 발표`, `* '26.5월 기준` 등 (01·02·04 유형에서 특히 중요).
3. **어려운 용어·약어 설명** — 낯선 용어·약어에 정의를 부착한다. **약어(약칭)가 앵커이면 `* {풀네임} ({정의})` 형식**으로 푼다.
   - (예) anchor `GDC` → `* Google Distributed Cloud (구글 On-Prem이나 Edge 환경에서 제공하는 하이브리드·멀티클라우드 솔루션)`
   - 앵커가 이미 완전한 용어(약어가 아님)면 풀네임을 반복하지 말고 정의만 쓴다 (`* 정의`) — 아래 "정의만" 규칙 참조.
4. **문서 레벨과 무관하게 배치** — 이동글틀은 `□`·`-`·`·` 등 문서 계층과 상관없이, 설명이 필요한 단어라면 어느 레벨에든 붙인다.
5. **페이지당 최소 3개 이상** — 한 페이지에 이동글틀이 3개 미만이면 대개 출처·발생시점·용어 주석 기회를 놓친 것이다. 단, 숫자를 맞추려 억지 주석을 만들지 말 것 — 실제 해설이 필요한 자리에 채우고, 동일 출처 반복 금지(아래) 원칙은 그대로 지킨다.


**용도별 예시:**


| 용도 | 주석 내용 예시 | 앵커 |
|---|---|---|
| ① 단문 맥락 보강 (조건·범위·비공개) | `지분율 비공개` / `거래 종결시` / `규모 미공개` / `연결 기준, 비경상 항목 제외` | 해당 수치·명사 |
| ① 구체 예시·나열 | `예) Dose ID GPT` / `스페인, 이탈리아, 프랑스, 노르웨이` / `인사, 콜센터, 재무관리 등` | 상위 개념 |
| ② 도메인 약어 / 용어 | `월간 활성 사용자 수` (anchor: `MAU`) / `Wafer-Scale Engine` | 약어·용어 |
| ② 낯선 기술 / 제품명 | `로컬 PC에서 사용자 대신 작업하는 Agent` (anchor: `Claw`) | 제품 토큰 |
| ② 숫자가 의미하는 맥락 | `전년 동기 대비` / `전 세계 누적 기준` | 숫자 자체 |
| ② 인물·조직 1회 소개 | `Moderna CEO` / `공동창업자 겸 사장` | 인물명 |
| ③ 출처 인용 (선택) | `출처: Reuters ('25.11)` / `McKinsey 2025` | 수치 또는 핵심 명사 |
| ③ 1차 소스 URL | `https://openai.com/index/stargate-community/` | 핵심 명사 |
| 특례: 인터뷰 질문 원문 | `(Q) AI 스케일링 법칙이 여전히 유효한가?` | 답변 요약 문장 |


**관용 prefix — 내용이 실제로 해당할 때만 사용:**


- `출처:` — 기관·매체 인용
- `예)` — 구체 사례·상품명 나열
- `(참고)` — 본문에서 생략한 부연 정보
- `(추가)` — 뒤늦게 확인된 사실
- `(Q)` — 인터뷰 질문 원문 보존 (답변 요약 문장에 앵커)


prefix는 필수가 아니며, 기계적으로 붙이지 말 것. 단문 맥락 보강은 대개
prefix 없이 구절만 쓴다 (`지분율 비공개`).


**동일 출처의 반복 금지 — 한 섹션·보고서 내에서 같은 출처를 여러 주석에
중복 표기하지 않는다.** 섹션의 불릿이 모두 같은 보고서에서 왔다면:


- 섹션 헤딩에 `headingAnnotation`으로 한 번만 붙이거나,
- 그 섹션에서 가장 대표성 있는 단 한 줄에만 붙이고 나머지는 비워둔다.


같은 `* McKinsey 2025`가 한 장표에 4~5번 반복되는 순간, 주석은 해설
기능을 잃고 배경 소음이 된다. **반복되는 출처는 한 번만, 진짜 해설이
필요한 자리에만 주석을 남긴다**는 원칙을 지킨다.


---


렌더링 측면에서, 주석은 본문 흐름에서 분리된 **파란 9pt 떠 있는 텍스트
상자**로, 설명 대상 단어 **바로 아래**에 배치된다. 본문을 아래로 밀어내지
않으며(텍스트 앞 wrap), 별도 host 단락을 만들지 않아 불릿 사이에 빈 줄(과거의
1pt 줄)이 생기지 않는다.


- **짧은 주석(여백에 들어가는 경우)**: 대상 단어 첫 글자 아래에 `* ` prefix로
  좌측 정렬된다.
- **긴 주석(좌측 정렬 시 우측 여백을 넘는 경우)**: `* ` 대신 끝에 ` ┘`를 붙이고
  텍스트가 **왼쪽으로 흐르며, ┘ 글자가 대상 단어(앵커) 첫 글자 바로 아래**에
  오도록 배치된다. (종전의 우측 여백 정렬 → 앵커 정렬로 변경.)


`*`/`┘` 모드 전환과 위치 계산은 생성기가 14pt 바탕체 장체 95% 문자폭을
기준으로 자동 처리한다. 작성자는 모드를 신경 쓸 필요 없이 `anchor`만 정확히
지정하면 된다.


**설명 대상 용어명을 주석 본문에 반복하지 않는다 — 정의만 적는다.** 즉
`* 용어 : 정의` 가 아니라 `* 정의` 로 쓴다.


| ❌ Don't (용어 라벨 반복) | ✅ Write (정의만) |
|---|---|
| `{anchor:"추론", text:"추론 : 학습 완료된 AI 모델을 실행하는 과정"}` | `{anchor:"추론", text:"학습 완료된 AI 모델을 실행하는 과정"}` |
| `{anchor:"워런트", text:"워런트 : 정해진 가격에 매입할 권리"}` | `{anchor:"워런트", text:"정해진 가격에 매입할 권리"}` |


생성기가 선행 `앵커 :` 라벨을 자동 제거하는 안전망을 두지만, 작성 시에도
라벨 없이 정의만 쓰는 것이 원칙이다. **단, 한 주석이 둘 이상의 용어를 함께
풀이할 때 두 번째 이후 용어의 라벨은 유지한다** — 예:
`{anchor:"TPU", text:"Google 설계 AI 전용 칩 / Trainium : Amazon 자체 AI 칩"}`
(앵커 `TPU :` 만 제거되고 `Trainium :` 는 그대로 둔다.)


**약어(약칭)를 푸는 경우는 예외** — 앵커가 약어(GDC, MAU, MoE 등)이면
주석은 그 약어의 **풀네임을 먼저 쓰고 괄호로 정의**를 붙이는 `* {풀네임} ({정의})`
형식을 쓸 수 있다. 풀네임은 앵커(약어)와 다른 문자열이므로 "용어명 반복"에
해당하지 않으며, 콜론(`:`)이 아닌 괄호를 쓰므로 자동 라벨 제거와도 무관하다.


| ✅ 약어 풀이 (풀네임 + 괄호 정의) | 앵커 |
|---|---|
| `{anchor:"GDC", text:"Google Distributed Cloud (구글 On-Prem이나 Edge 환경에서 제공하는 하이브리드·멀티클라우드 솔루션)"}` | `GDC` |
| `{anchor:"MoE", text:"Mixture of Experts (일부 전문가만 선택 구동해 연산비를 낮추는 구조)"}` | `MoE` |


Annotations render only as the textbox form — omit any `style` field; other annotation styles are not supported.


Annotations **must be anchored to a specific word** whenever possible. A
whole-line note (no anchor) is acceptable only when the citation is a
genuinely umbrella one — e.g., "기사 전체의 출처".


**Never cite raw filenames** (e.g., `report.pdf`, `2024년_상반기.xlsx`,
`meeting_notes.docx`). A filename is a local artifact, not a citable source —
in the final document the reader has no idea which file that was. Cite the
actual **document title, publisher, organization, or source URL** instead.


| ❌ Don't | ✅ Do |
|---|---|
| `* 2024년_상반기_실적.xlsx` | `* 경영관리팀` |
| `* CES2026_keynote.pdf` | `* CES Keynote` |
| `* mckinsey_report.docx` | `* McKinsey Global Institute` |


**URLs are allowed as annotation text** when citing a 1차 소스 — 기사·
공식 발표·영상 등. 긴 URL을 서술로 바꿔 쓰지 말고, URL 자체 또는
`URL (매체명, 발행월)` 형태로 기재한다. 예:


- `https://openai.com/index/stargate-community/`
- `https://biz.heraldcorp.com/article/10650555 (헤럴드경제, 1/7일 기사)`
- `https://www.youtube.com/watch?v=xRh2sVcNXQ8 (1h 20m)`


**Dates are conditionally allowed — 사실적 의미를 지닐 때만.** 날짜가
사건의 시점, 기준 시점, 출처 발행월처럼 본문 해석에 필요한 정보일 때는
그대로 둔다. 반면 우상단 `date`와 중복되는 **장식적 꼬리표 날짜**는
제거한다.


| ✅ 허용 (사실적 의미) | ❌ 금지 (장식적 꼬리표) |
|---|---|
| 이벤트 시점: `'25.12.10, 아마존 정상회의` | 기관명 뒤 발행월만: `* Gartner, 2026.3` |
| 기준·관측 시점: `'26.1 기준`, `'25 착공` | 본문 최신성만 암시: `* 78% (2025)` |
| 출처 발행월: `출처: Reuters ('25.11)` | 우상단 `date`와 같은 달을 반복 표기 |
| 비교 시점: `전년 동기 대비` | 모든 출처에 기계적으로 붙인 발행일 |


판단 기준: **그 날짜를 지우면 독자가 사실을 오독할 가능성이 있는가?**
그렇다면 유지, 아니라면 제거.


If no meaningful citation is available, omit the annotation entirely —
better no annotation than a filename.


The textbox renderer emits a DrawingML shape (`w:drawing` +
`wps:wsp`) with no fill, no border, and `wp:wrapNone` + `behindDoc="0"`
(줄 바꿈 = 텍스트 앞) — the box floats in front of text and does **not**
push body content. Because it doesn't reserve space, it can overlap the
next body line when the anchor sits in the middle of a multi-line bullet;
avoid that by anchoring on the bullet's last wrapped line, or by omitting
the annotation.


**Rendering target:**
```
  - 기업의 AI 채택률은 증가(78%→88%) 했으나, 이익 창출 기업은 6%에 불과
                          * McKinsey 2025
```
(the `*` lines up under the `7` of `78%→88%`)


**In content JSON — use the object form with `anchor`:**
```json
{
  "text": "기업의 AI 채택률은 증가(78%→88%) 했으나, 이익 창출 기업은 6%에 불과",
  "annotation": { "text": "McKinsey 2025", "anchor": "78%→88%" }
}
```


**The `anchor` must be an exact substring of `text`** — the first occurrence
is used to compute indent. If the anchor isn't found, the generator falls
back to a whole-line note (no indent) instead of failing.


**Whole-line (legacy) form — still allowed, use sparingly:**
```json
{
  "text": "…",
  "annotation": "TechCrunch 전체 기사 참고"
}
```


### Picking the anchor


Choose the shortest, most specific substring that the note is really about:


| Note content | Pick anchor on… |
|---|---|
| 약어 / 도메인 용어 해설 | 약어/용어 그 자체 (`MAU`, `TCO`, `SMR`) |
| 제품·기능 개념 설명 | 제품 토큰 (`Claw`, `Copilot Cowork`) |
| 숫자의 맥락·기준 | 해당 수치 (`78%→88%`, `7,440억 달러`) |
| 인물·조직 부연 | 인명·조직명 (`스테판 반셀`, `Global Atlantic`) |
| (선택) 출처 인용 | 인용 대상이 되는 숫자 또는 핵심 명사 |
| **출처·출시 정보** (`출처 : Meta Newsroom (…)`, `9/8일 출시`) | **그 줄 맨 오른쪽의 날짜·괄호 토큰** (`(9/8)`, `'26.9월`) — 긴 출처 주석이 ┘ 모드로 갈 때 ┘ 가 줄 끝에 오고 상자가 윗줄 왼쪽으로 나가지 않는다 (260923) |
| **모델명·서비스명 소개** (`'26.4월 공개, Llama 대체 …`) | 이름 자체 (`Muse Spark`) — 생성기가 `*` 를 이름 바로 아래에 두고, 우측 여백이 모자라면 ┘ 로 바꾸기 전에 장평(95→85%)을 먼저 줄인다. 무엇을 설명하는지 한눈에 보이게 하는 것이 목적 |


Do **not** anchor on very short tokens that appear multiple times in the
bullet (`AI`, `M365`) — pick a longer substring that is unique within `text`.


**┘ 모드 배치 규칙 (260923 손수정본 — 생성기 자동, 작성자는 앵커만 고른다):**


- ┘ 상자의 왼쪽 끝은 **앵커가 놓인 본문 줄의 글자 시작점(`- `/`·` 뒤)보다 왼쪽으로 나가지 않는다.** 종전에는 긴 주석이 x=0(본문 왼쪽 끝)까지 밀려 ┘ 가 허공을 가리켰다.
- 안 맞으면 ┘ 를 **오른쪽으로 옮겨** 상자를 글자 시작선에 붙인다(┘ 는 줄 끝까지). 그래도 안 맞으면 **장평 95 → 85%** 까지만 줄인다(가독성 하한). 그것도 안 되면 `*` 모드로 돌아가 줄 시작선에 붙이고 `[WARN]` — 주석을 줄이라는 신호다.
- 앵커가 줄바꿈으로 갈라진 2줄 문장(`… 자체 / 평가 필요` 에 anchor `자체 평가`)은 **앵커가 시작되는 줄**에 붙는다. 이동글틀이 아래 줄로 밀리며 무엇을 설명하는지 알 수 없게 되는 일을 막는다.
- 한 페이지의 ┘ 상자들이 같은 x(본문 글자 시작선)에서 시작하는 모양이 정상이다.


**주석을 달 자리 — 해설이 실제로 필요한 곳에만:**


- 본문 한 줄에 조건·범위·비공개 사실을 짧게 덧붙일 필요 → 해당 수치·명사에 앵커, 한두 구절로 부연 (`지분율 비공개`)
- 낯선 약어·용어가 본문에 처음 등장 → 해당 토큰에 앵커, 짧은 풀이
- 숫자가 맥락 없이는 오독될 위험 → 그 숫자에 앵커, 기준·범위 보충
- 제품/기능명이 독자에게 생소 → 1회에 한해 개념 한 줄 해설
- 출처가 **그 자체로 신호**이고 섹션에 아직 표기 안 됨 → 대표 1줄에만
- 1차 소스(기사·발표·영상) URL이 인용 근거 → 해당 URL을 주석 본문으로 기재
- 인터뷰 아키타입에서 질문 원문을 보존 → 답변 요약 문장에 `(Q) …` 주석


**주석을 달지 말아야 할 자리:**


- 이미 같은 출처를 다른 주석·헤딩에서 표기함 (중복 금지)
- 숫자·사실이 본문만으로 충분히 이해됨 (불필요한 소음)
- 파일명밖에 댈 것이 없음 (§7 서두 규칙)
- 출처 기관명에 의미 없는 발행월만 꼬리표로 붙임 (장식 날짜 금지)


If the user explicitly asks for an annotation ("여기에 McKinsey 출처 넣어줘"),
honor it verbatim — anchor to the most natural term if you can infer it,
otherwise use the whole-line form.


---


## 8. Section heading framing


Each `□` section heading states a **topic**, not a sentence. Typical patterns:


- Descriptive: `□ 기사 개요`, `□ OpenClaw 개요`, `□ 신규 Claw 차별점 및 핵심 기능`
- Tagged: `□ [위협] Agentic IT 개발 도구의 급속한 확산`, `□ [기회] AI 시장확대`
- Action-oriented: `□ 향후 일정 및 SDS 시사점`, `□ 실행방안`


Keep them short. 5~25 characters is typical.


### Higher-level headings (Ⅰ·Ⅱ·Ⅲ, 1·2·3) — Optional tiers above `□`


For reports big enough that `□` sections alone can't carry the structure, promote headings with:


- `"numeral": "Ⅰ"` → renders as `Ⅰ. 제목` (16pt bold, no `□`) — Roman-numeral top-level chapter, typically in TOC-backed reports.
- `"number": 1` → renders as `1. 제목` (15pt bold, no `□`) — numeric sub-chapter, one level under a Roman-numeral chapter or as a mid-tier grouping in long reports.


Both are **optional**. The hierarchy is: Ⅰ → 1. → □ → - → ·. Use only as many top tiers as the content actually needs; for ordinary briefs, start at `□`.


Never combine the markers (`□ Ⅰ. …`, `Ⅰ. □ …`, `1. □ …` are all wrong) — the generator drops `□` automatically whenever `numeral` or `number` is set.


---


## 9. Document opening and closing


- **Opening**: `Title (centered, 20pt, bold + underline)` → `Date (right-aligned)`. Full spacing/margin defaults: `references/generator-defaults.md`.
- **Closing (main body only)**: `- 이  상 -` **right-aligned** at the bottom of
  the block. Note the **two spaces** between `이` and `상` (Korean public-document
  convention). The generator inserts this automatically — don't include it in
  the content JSON. Appendices do **not** render a closing marker.


---


## 9-1. No meta / self-referential content — 주제로 바로 진입


보고서의 독자는 **주제에 대한 사실·시사점**을 보러 온다. "이 보고서가
어떻게 작성되었는가"는 독자 관심사가 아니다. 따라서 보고서 작성자·
조사자 관점의 메타 서술은 전부 빼고, 첫 섹션부터 주제 본문으로 바로
진입한다.


**금지 — 섹션 자체**


| 금지 헤딩 예시 | 대체 |
|---|---|
| `□ 검토 범위` | 삭제. 바로 `□ 개요` / `□ 주요 변화` / `□ 현황` 등으로 시작 |
| `□ 작성 기준` | 삭제 |
| `□ 조사 범위` / `□ 분석 방법` | 삭제 |
| `□ 본 보고서 개요` | `□ 개요`로 축약 (주제 개요이지 보고서 소개가 아님) |


**금지 — 메타 문장**


| Don't | Do |
|---|---|
| "본 보고서는 OpenAI 공개자료 기준으로 Images 2.0을 비교 정리" | (삭제) — 내용 자체로 바로 진입 |
| "핵심 관찰 포인트는 품질 향상보다 실무형 산출물에 있음" | "실무형 산출물 제작 범위 전면 확대"처럼 사실로 전환 |
| "~ 관점에서 해석" / "~ 기준으로 정리" | 해석·기준 프레이밍 삭제, 결론만 남김 |
| "이번 리뷰에서는 ~를 다룸" | (삭제) |


**예외 — 굳이 공개해야 하는 scope 단서**


공개 자료 한정, 특정 기간 한정 등 독자 판단에 실제로 영향을 주는 제약은
별도 섹션이 아니라 관련 섹션 하단에 **`※` 주 한 줄로** 붙인다.


예:
```
  ※ OpenAI 공개 자료 기준, 내부 수치는 비공개
```


**Rule of thumb** — 문장 앞에 "본 보고서는", "이번 분석은", "작성자는"을
붙일 수 있으면 그 문장은 메타 서술이다. 전부 삭제하거나 주제 사실로
전환한다.


---


## 10. 표 (Tables) — 폰트 크기와 정렬


표의 기본 폰트는 **12pt**다. 컬럼이 많거나 셀 텍스트가 길어서 한 줄에 담기
어려우면 `fontSize`로 9~14pt 범위 내에서 조정한다 (권장 범위).


| 상황 | 폰트 크기 |
|---|---|
| 기본 | 12pt |
| 컬럼 4개 이하, 텍스트 짧음 | 12~13pt |
| 컬럼 5개 이상 또는 셀 텍스트가 긺 | 10~11pt |
| 컬럼이 매우 많거나 페이지 폭 꽉 차는 긴 텍스트 | 9pt |
| 요약표·핵심 KPI 한 줄 | 13~14pt |


**셀 정렬 규칙:**


| 셀 종류 | 정렬 |
|---|---|
| **헤더(타이틀)** | 가운데 — 항상 |
| 일반 텍스트 (설명·명칭) | 좌측 (default) |
| **금액·소수점·천단위 구분자** (1,200억, 258B$, 45.0%) | 우측 — 자릿수·소수점을 맞춰 읽어야 함 |
| **동일 기준의 짧은 비교 숫자** (81%, 28%, 8%, 순위 1·2·10 등 ≤5자) | 가운데 — 비교 사다리처럼 읽힘 |
| **고정 길이 데이터** (코드·등급·기호 — 모든 셀 같은 길이, ≤8자) | 가운데 |


Rule of thumb: **"돈·소수점·쉼표가 보이면 우측, 순위·퍼센트처럼 짧은 비교 숫자면 가운데, 글은 좌측."**


생성기는 자동으로 판정한다. 직접 지정이 필요하면 `alignments: ["left","right","center"]`처럼 컬럼별 배열을 준다. (상세: `references/content-schema.md`)


**컬럼 너비:** 이제 기본이 **내용 기반 자동 산정**이다. 짧은 숫자·짧은 문자열 컬럼은 자신의 자연 폭을 유지하고, 긴 텍스트 컬럼이 나머지 페이지 폭을 흡수한다. `[긴 라벨, C-Suite, IC, Gap]` 같은 표에서 과거 `25% × 4`로 라벨이 2줄로 접히던 문제가 해소된다. 특정 비율을 강제하려면 `columnWidths: [3,1,1,1]` 같은 상대 가중치 배열로 override 할 수 있다.


---


## 11. 별첨 (Appendices)


Each 별첨 is a self-contained mini-document. It has:
- its own title
- its own date
- `□` sections like the main body
- its own `- 이  상 -`


Use 별첨 when the supporting material is substantive enough to deserve its
own title and would distract from the main topic if inlined. Rule of thumb:
if the material has its own headline, its own source, or its own date, it's
probably a 별첨.


Label: `별첨 1`, `별첨 2`, … (the generator handles the label).


---


## Quick self-check before generating


- [ ] Every bullet starts with `- ` or `·` or `□ ` (no freeform sentences)
- [ ] No `-습니다` / `-합니다` endings left
- [ ] No line over 55 Korean characters without a 6-space wrap
- [ ] 주석은 세 용도(**① 단문 맥락 보강 / ② 약어·용어 풀이 / ③ 출처 인용**) 중 하나에 해당하며, 같은 출처가 여러 주석에 반복 표기되지 않음 (중복 출처는 섹션 헤딩 1회 또는 대표 불릿 1회로 통합). 주석 속 날짜는 **이벤트·기준·발행 시점** 등 사실적 의미가 있을 때만 유지, 장식적 꼬리표 날짜(`* Gartner, 2026.3` 류)는 제거
- [ ] **주석 본문에 설명 대상 용어명을 반복하지 않음** — `* 정의`만 적고 `* 용어 : 정의`로 쓰지 않음 (한 주석이 둘 이상 용어를 풀 때 두 번째 이후 용어 라벨만 유지)
- [ ] Each section heading is a topic, not a sentence
- [ ] **한자 미사용 — 요일·연·월·일 포함 모든 글자가 한글** (`(목)` not `(木)`, `'26년` not `'26年`, `미국`·`등` not `美`·`等`). 한자가 한 글자도 남지 않음
- [ ] **본문 인라인 이벤트 날짜는 `M/D`** (`(6/24)`, not `('26.6.24)`); 우상단 보고서 `date`만 `'26. 6. 25 (목)` 형식 유지
- [ ] **단독 영어 단어 1~2개는 첫 글자 대문자** (`Frontier`, `Full-stack`); 약어·고유명사는 원표기
- [ ] 범위 표시는 2byte 물결표 `∼`(U+223C) 사용 (ASCII `~` 아님)
- [ ] `→` 화살표 불릿은 2칸 들여쓰기(`  → `)로 통일
- [ ] 별첨 have been separated from main body where appropriate
- [ ] **No meta / self-referential content** — 검토 범위 / 작성 기준 등의 섹션 없음, "본 보고서는 ~" / "핵심 관찰 포인트는 ~" 같은 문장 없음, 첫 섹션부터 주제 본문으로 진입
