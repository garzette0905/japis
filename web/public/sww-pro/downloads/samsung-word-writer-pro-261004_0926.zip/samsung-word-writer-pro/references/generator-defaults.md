# Generator rendering defaults (자동 렌더링 규칙)


This is what `scripts/generate.py` renders **automatically** — you don't set most of these in the content JSON. Read this when you need to reason about exact spacing/positioning, or when **visually verifying a rendered .docx/PNG** (page-fit checks, overlap/clipping checks, spacing audits).


## Page and base typography


- A4, 2cm margins.
- Body 14pt, title 20pt, annotations 9pt.
- `autoSpaceDE="0"` / `autoSpaceDN="0"` on every paragraph (prevents CJK/Latin auto-spacing).
- Body line spacing 240 auto; wrapped lines within the **same** bullet use after=180 (9pt) between rows.
- Annotation line spacing 200 exact (9pt).
- Title: bold + underline, after=240 (12pt). Date: right-aligned, after=360 (**18pt**).
- Section heading (`□ …`): bold; everything else regular weight unless `bold: true` / `underline: true`.
- **문서 전체 스타일 초기화 + □ Bold 고정**: Word 문단 스타일(제목1·제목2 등 Heading Style)을 적용하지 않고 **Normal 기반 직접 서식(direct formatting)만** 사용한다. `□` 레벨 헤딩 텍스트는 **반드시 Bold**로 렌더. 기존 문서 수정/보완·재생성 시 원본에 남은 Heading Style·잔여 서식은 제거하고 엔진 표준 서식으로 통일한다. (생성기가 빈 문서에서 직접 서식으로 렌더하므로 신규·재생성 산출물은 이 조건을 자동 충족.)


## Position-aware spacing-after


Last line of a bullet uses the spacing dictated by what comes next:


- `□ heading` → first bullet: **16pt** (320 twips)
- `-` (dash) → next `-`: **16pt** ("바-바 16pt")
- `-` (dash) → sub-level (`·`/`→`/`※`/`①`...): **12pt** ("바아래 ·있으면 12pt")
- sub-level → next sub-level: **12pt**
- any bullet → table: **16pt** ("표가 있으면 16pt 이상")
- within a wrapped bullet (continuation lines): **9pt** (`body_wrap`)
- last bullet of a section: **12pt**, and the next `□` heading carries `before=20pt` ("네모-네모 사이 20pt") → the legacy empty separator paragraph is no longer emitted
- section separators are no longer rendered as a blank paragraph; the new `□`'s `before=400` carries the 20pt inter-section gap instead


## Annotation rendering (textbox only)


DrawingML 텍스트 상자 (`w:drawing` + `wps:wsp`) anchored under the target word. 배경 없음 (`a:noFill`), 테두리 없음 (`a:ln/a:noFill`), 줄 바꿈 = 텍스트 앞 (`wp:wrapNone`, `behindDoc="0"`). 바탕체 9pt **#3333FF (파랑)**, 장체 95%. **세로 위치** `ANNOT_DROP_DXA = 324` (앵커 줄 단락 상단에서 16.2pt 아래 — 260909 손수정본 계측, 종전 300). 일반 모드는 텍스트 앞에 `* ` (별표 + 한 칸) 를 붙이고 좌측을 anchor 용어 시작점 + `ANNOT_X_NUDGE_DXA = 24`(1.2pt) 에 정렬. **long 모드** 자동 전환 조건 두 가지: ① 오른쪽 끝이 본문 폭에서 `ANNOT_RIGHT_SAFETY_DXA = 300` 안쪽에 못 들어옴, ② 앵커 줄 글자 끝보다 `ANNOT_MAX_OVERHANG_DXA = 2400`(120pt) 이상 돌출. long 모드는 `* ` prefix 대신 끝에 ` ┘` 를 붙이고 박스를 왼쪽으로 이동해 **`┘`가 anchor 첫 글자 바로 아래**에 오도록 정렬(텍스트는 왼쪽으로 흐름). **배치 계획 `plan_annotation_layout` (260923)**: (1) `* ` 95% 가 두 조건을 다 만족하면 그대로 → (2) 우측 여백만 걸리면 `* ` 유지 + 장평 `ANNOT_SCALE_STEPS = (95, 92, 90, 88, 85)` 순 축소(글자 오른쪽 끝이 본문 우측 끝 `ANNOT_EDGE_SAFETY_DXA = 60` 안쪽) → (3) ┘ 모드: 장평 단계마다 (a) ┘ 를 앵커 아래에 두었을 때 박스 왼쪽 끝 ≥ **앵커 줄 글자 시작점**(`line_start_dxa`, 첫 줄은 prefix 폭·이어지는 줄은 continuation indent)이면 채택, (b) 아니면 박스를 글자 시작선에 붙이고 ┘ 를 오른쪽으로 옮김(┘ 오른쓴 끝 ≤ 줄 끝 + `ANNOT_TAIL_TOLERANCE_DXA = 200`) → (4) 안 되면 `* ` 로 복귀(돌출 허용, 앵커 → 줄 시작점 순) → (5) 주석이 본문 폭보다 길면 줄 시작선에 `* ` 85% 로 붙이고 우측으로 조금 넘치게 둔 뒤 `[WARN]`(박스를 x=0 으로 밀던 종전 동작 폐지). 하한 `ANNOT_MIN_SCALE_PCT = 85`. 앵커가 줄바꿈으로 갈라지면 `_locate_anchor_across_lines` 가 **앵커가 시작되는 줄**을 고른다. `verify_docx.py` 는 이동글틀이 윗줄 글자 시작점보다 3pt 이상 왼쪽에서 시작하면 WARN. 프레임 폭은 주석 길이에 맞춰 자동 계산(바탕체는 고정폭이라 전각 171·반각 86 DXA 추정이 실측과 일치; `┘` 등 박스 문자는 전각). **출처 URL**(`sourceUrl`)은 제목 왼쪽 정렬 → 넘치면 왼쪽 이동 → 본문 폭 초과 시 장평 최소 75% → 2줄 순서로 항상 전체가 보이게 맞춘다. 텍스트 앞 배치라 본문을 밀어내지 않음 — 멀티라인 bullet 중간 앵커가 다음 라인과 겹칠 위험이 있으면 앵커 단어를 조정하거나 주석을 생략한다. 상세 작성 기준은 `references/tone.md` §7.


## Profile image rendering (`profileImage`)


인물 프로필 사진은 **"텍스트 앞"(In Front of Text) floating** — `wp:anchor` + `behindDoc="0"` + `wp:wrapNone` (자식 순서 `extent → effectExtent → wrapNone → docPr → cNvGraphicFramePr → graphic`). 이동글틀과 같이 **별도 host 단락 없이** 제목(별첨이면 별첨 라벨) 단락에 부착되므로 본문 높이를 전혀 차지하지 않는다. 기본 폭 **3.8cm**, x = 본문 폭 우측 끝 정렬, y = 앵커 단락 상단 기준 **300 twips(≈0.53cm) 아래**. `width_cm` / `x_cm` / `y_cm` / `x_emu` / `y_emu` 로 조정. WebP 등 python-docx 미지원 포맷은 Pillow 로 PNG 자동 변환, HTTP(S) URL 은 임시 폴더로 자동 다운로드.


### □ 헤딩 우측 사진 (`sections[].profileImage` / `kind:"image", "float":"right"`, 260923)


여러 인물 별첨의 사진은 각 인물 `□` 헤딩 단락에 같은 "텍스트 앞" 방식으로 붙는다 (`attach_floating_image`, `docPr name="Section photo"`). 손수정본(Jev 260923) 계측 기본값: 폭 **`SECTION_PHOTO_DEFAULT_WIDTH_CM = 4.5`**(1619250 EMU), x = 본문 폭 우측 끝 정렬, y = **헤딩 단락 상단(`SECTION_PHOTO_Y_DXA = 0`)**. 인라인 사진 단락·`※ 사진` 캡션 단락은 만들지 않는다.


**줄폭 예약 (`plan_photo_reserve`)** — "텍스트 앞" 은 본문을 밀어내지 않으므로 옆 줄이 길면 글자가 사진 뒤로 들어간다. 생성기는 헤딩 단락 상단 기준으로 불릿 시작 y 를 누적 추정(줄 높이 `BODY_PT × 1.3 × BODY_LINE/240` = 364dxa, 줄 사이 `body_wrap` 180, 불릿 사이 `_bullet_after_spacing`)해 **사진 아래끝 + `SECTION_PHOTO_BOTTOM_MARGIN_DXA = 120` 안에서 시작하는 불릿**의 pre-wrap 폭을 `RIGHT_RESERVE_DXA = 본문 폭 − 사진 x + SECTION_PHOTO_TEXT_GAP_DXA(170)` 만큼 줄인다(`_wrap_width_dxa()` — 불릿·□ 헤딩 공용). 4.5cm 사진이면 헤딩 + 3줄이 예약 범위(실측: 4번째 줄 시작 2736dxa > 사진 아래 2561dxa). 표·도식·이미지를 만나면 예약을 멈춘다. `verify_docx.py` 가 렌더 결과에서 글자 상자 ∩ 사진 상자(세로 40%↑·가로 2pt↑)를 `WARN 글자가 사진과 겹침` 으로 다시 잡는다.


## Inline emphasis and labels (260923)


- `text` 안의 `**…**` → 부분 Bold, `__…__` → 부분 밑줄 (`parse_inline_emphasis` → `_emphasis_runs`). 마커는 폭 계산·줄바꿈·앵커 탐색 전에 제거되고 줄 오프셋(`_line_offsets`)으로 run 을 나눈다. 표 셀·소제목·이동글틀 본문은 미지원.
- 불릿 본문·이동글틀 본문의 선행 `예시 :` / `예 :` → `예) ` (`normalize_example_label`).


## Text normalization (`normalize_body`)


- 한자 → 한글, ASCII `~` → `∼`, `M.D일` → `M/D일` 은 본문·제목·표 셀에 모두 적용된다.
- **영문 첫 글자 자동 대문자화는 본문에만 적용된다.** 섹션 제목(`heading`)과 소제목(`subhead`)은 제품명·코드명·API 이름이 그대로 오는 자리라 제외한다 (`horizontal_flow`가 `Horizontal_flow`가 되는 것을 막는다).
- 밑줄이 들어간 토큰(`snake_case`)은 본문에서도 대문자화하지 않는다. 소문자 고유명사는 `NO_AUTOCAP` 목록과 JSON 최상위 `noAutoCap: ["..."]` 로 관리한다.
- **영어 구 안의 기능어는 대문자화하지 않는다** (`ENGLISH_FUNCTION_WORDS`: of/and/the/in/on/for/to/with/by/from/vs …). 바로 앞 토큰이 영어 단어일 때만 예외가 걸리므로 `The State of AI in 2026`, `Bank of America` 는 그대로, 한글 문장 사이의 단독 `frontier` 는 여전히 `Frontier` 가 된다. 따라서 영문 제목·구는 **원문 표기대로 소문자 기능어로 써도 안전**하다.


## Inline images (`kind: "image"`)


- 폭: 본문 폭의 92% 상한 (`maxWidthPct`). 높이: **본문 높이의 55% 상한** (`IMAGE_MAX_HEIGHT_PCT`, bullet 의 `maxHeightPct` 로 조정). 둘 다 비율을 유지하며 축소하고, 높이 축소 시 stderr 에 `[INFO] 이미지 높이가 … 축소했습니다` 를 낸다. 세로로 긴 도표가 페이지를 덮는 확대 렌더는 이 상한으로 생성 단계에서 막힌다 — `verify_docx.py` 의 "확대 렌더 의심" 임계값과 같은 55% 다.
- 도식 노드의 `title`/`items` 는 애초에 정규화를 거치지 않는다 — 쓴 그대로 렌더링된다.


## Wrapping and indentation


- Wrapped lines use a hanging indent so continuation starts under the text, not the bullet mark.
- Colon-based hanging indent: when a bullet contains `" : "`, wrapped continuation starts at the character after the colon, aligning the value column (e.g., `설립 : 1976년 미국 뉴욕` wraps under `1976…`).
- **1단어 widow 자동 보정** — 불릿 마지막 줄에 1단어만 남을 경우 생성기가 자동으로 **문자간격 -0.2pt(최대 -0.3pt)** 를 적용해 앞 줄로 당겨온다. 수동 지정 불필요.
- **Auto widow fix (문장 장평 단계 축소)** — 불릿이 2줄 이상으로 wrap되고 **마지막 wrap 줄에 1~2단어만 남을 때**, 생성기가 문장 본문의 장평을 `94 → 93 → 92 → 91 → 90` 순으로 좁혀가며 short tail이 해소되는 첫 값을 적용한다. 불릿 마크(prefix — `-`, `·`, `→`, 원문자 등)는 항상 95%를 유지 — 문장 본문만 압축된다. 90%까지도 해소되지 않으면 생성기는 원래 wrap과 95% 장평으로 되돌린다(부작용 없음). bullet에 수동 `scale` 필드가 있으면 이 자동 보정은 비활성화된다.


## Tables


- Tables are indented to start at the same x-position as the bullet text above them (not flush-left).
- Default 12pt; `fontSize` clamps to 9–14pt for dense or long-text tables.
- Rows default to **minimum 0.8cm height** — the generator applies `w:trHeight` with `hRule=atLeast` and `val=454` to every row (JSON에 별도 `rowHeight` 불필요).
- Column widths: content-aware by default — each column gets `max(header, body) DXA` as its natural width; numeric/short-string columns stay at natural width, long-text columns absorb the remaining page width, 900 DXA floor applies. Override with `columnWidths: [weights]` (relative).
- Cell alignment: header row always centered; body cells auto-inferred — money/decimal/thousands → right, short comparable numeric ≤5 chars → center, fixed-length short strings → center, **첫 열 라벨(≤22 전각) → center, 시점·기간 열 → center, 비서술 헤더의 짧은 값 열(비교표) → center**, 서술·명칭 헤더(`비고/내용/기업…`) → left. 명시 `alignments` 의 `left` 도 첫 열·시점 열은 center 로 보정(`alignmentsStrict: true` 로 해제). 상수: `LABEL_MAX_WEIGHTED_CHARS = 22`, `PERIOD_*_RE`, `DESCRIPTIVE_HEADER_RE`.
- Borders: single black line overall, **header row bottom border only at 1.5pt** — no shading, no separate config needed.
- **Accent column (260923)**: `highlightColumn`(머리글 문자열 / 0-based 정수 / 생략 시 문서 제목에 포함된 머리글 자동, `false` 로 끔) 열의 좌·우 변 + 머리글 위 + 마지막 행 아래를 `TABLE_ACCENT_BORDER_SZ = 12`(1.5pt) `TABLE_ACCENT_BORDER_COLOR = 0000FF` 로 렌더. 이웃 열의 맞닿은 변도 같이 파랗게 써서 Word 의 인접 셀 테두리 충돌에서 파란 선이 이긴다. `columns + rows` 단순 표 전용.
- Cell margins: 좌우 50 DXA, **상하 0**. 세로 여백은 행 최소 높이 0.8cm가 이미 만들어 주므로 값을 주면 행이 규정보다 높아진다. 좌우 50 DXA는 열 너비 계산이 이미 얹어 두는 `CELL_H_PADDING_DXA`(200) 안쪽이라 줄바꿈은 바뀌지 않는다.
- Page-break avoidance is **automatic** for every table — if a table (with its caption/unit) would split across a page boundary, the whole block moves to the next page.


## Diagrams (`kind: "diagram"`)


렌더링 상수 (전부 `scripts/generate.py` 의 `DIAGRAM_*`). **이 표로 판단이 되면 소스를 열 필요가 없다.**


| 항목 | 값 | 비고 |
| --- | --- | --- |
| 노드 제목 | 11pt 진하게, 가운데 정렬 | 1줄에 안 들어가면 도식 전체를 1pt씩 줄여 최소 9pt (`[WARN]` 출력) |
| 노드 items | 10pt, 가운데 정렬 | 항목이 2줄을 넘으면 1pt씩 줄여 최소 8pt (`DIAGRAM_ITEM_MIN_PT`, `[WARN]`); 줄 수·단락 간격(60 DXA)·여유 80 DXA 만큼 박스 높이가 늘어남 |
| 화살표 라벨 | 9pt | 라벨이 길면 박스 사이 간격이 자동으로 벌어짐 |
| 박스 안쪽 여백 | 160 DXA (상하좌우) | |
| 박스 사이 기본 간격 | 가로 500 DXA / 2x2 세로 660 DXA | |
| 테두리·연결선 | 검정 1.0pt (12700 EMU) | |
| 전체 폭 | 본문 폭(9,638 DXA) 고정 | 노드 수로 균등 분할 |
| chevron 겹침 | 520 DXA | 겹친 영역은 다음 도형이 덮으므로 글자가 들어가지 않음 |


레이아웃 13종과 노드 수 (`scripts/diagram_templates.py` `LAYOUTS`): `horizontal_flow` 2~5 · `vertical_flow` 2~5 · `chevron_flow` 3~6 · `2x2_cycle` 4 · `cycle` 3~6 · `comparison` 2 · `hub_spoke` 1+3~6 · `hierarchy` 1+2~5 · `layers` 2~6 · `matrix_2x2` 4 · `timeline` 3~6 · `funnel` 3~5 · `pyramid` 3~5. 앞의 4개는 generate.py 안의 기존 구현, 나머지는 템플릿 모듈이 기하를 계산하고 generate.py 가 그린다. 노드 수가 범위를 벗어나거나 `title` 이 비면 `diagram_templates.validate` 가 원인이 적힌 ValueError 로 즉시 실패한다. 글자 권고: 제목 8자·항목 14자(전각 기준, `TITLE_MAX_CHARS`/`ITEM_MAX_CHARS`) — 넘으면 `[WARN]` 후 자동 축소, 안전 사각형 높이를 넘으면 `[WARN] … 글자가 도형 높이를 넘습니다`.


템플릿별 고정 기하: `vertical_flow` 상자 폭 5400 · 세로 간격 520 / `cycle` 상자 폭 2700(≤4노드)·2300 · 타원 링 / `hub_spoke` 중심 2800(타원) · 주변 2500/2200 / `hierarchy` 하위 상자 = 본문 폭 균등 분할(간격 300) · 세로 간격 700 · 꺾인 선 / `layers` 라벨 폭 2200 · 구성요소 상자 간격 120 / `matrix_2x2` 축 라벨 영역 왼쪽 1000 / `timeline` 점 지름 260 / `funnel` 최소 폭 42% / `pyramid` 최소 폭 38%.


**형상별 안전 사각형** — preset 도형은 바운딩 박스와 별개로 내부 텍스트 영역을 갖는다. 생성기는 도형 외곽과 텍스트를 **별도 도형 2개**로 그리고, 텍스트는 아래 영역에 가운데 정렬로 얹는다.


| 형상 | 좌우 잠식 | 상하 잠식 | 같은 글자를 담는 데 필요한 박스 높이 |
| --- | --- | --- | --- |
| `rect` | 없음 | 없음 | ×1.00 |
| `chevron` | 좌 `min(w,h)×0.15`, 우 520 DXA | 없음 | ×1.00 |
| `hexagon` | 좌우 `min(w,h)×0.15` | 없음 | ×1.00 |
| `ellipse`(`circle`) | 좌우 `w×0.147` | 상하 `h×0.147` | ×1.41 |
| `cylinder`(`can`) | 없음 | 상하 `h×0.22` | ×1.79 |


실사용 가용 폭(A4 본문 기준): `chevron_flow` 5노드 ≈ 1,300 DXA(한글 11pt 6자), `horizontal_flow` 4노드 ≈ 1,700 DXA(8자). **제목은 6자 이내, items는 10자 이내**로 쓰는 것이 안전하다.


지켜야 할 XML 불변식 (어기면 Word에서만 깨진다):
- 글자가 없는 도형에는 `wps:txbx` 를 **넣지 않는다.** 빈 `w:txbxContent` 가 하나라도 있으면 Word가 그 뒤 모든 텍스트를 한 도형씩 밀어서 그린다(화살표 라벨이 노드 박스 안으로 들어가고 마지막 노드 글자가 사라진다). LibreOffice는 정상 렌더하므로 **Word로 확인해야 잡힌다.**
- `hexagon` 은 `adj` 만 덮어쓰면 안 된다. `vf` 를 함께 지정하지 않으면 Word가 문서를 아예 열지 못한다.


## Document furniture


- `- 이 상 -` is right-aligned with after=180; inserted automatically in the main body only.
- Appendices have **no** centered title block, **no** date, and **no** `- 이 상 -` closing — only the main body has those. Appendix label renders as `#별첨N. <title>` at the top-left of a new page, then the sections follow directly.
- Page numbers render as `- N -` centered in the footer (12pt 바탕체, 바닥글 0.9cm).


## Verification checklist (`scripts/verify_docx.py` 가 자동 판정)


After generating, run `python scripts/generate.py <json> <docx> --verify --png` (or `python scripts/verify_docx.py <docx> --content <json> --png`) **once** and read the text summary. Do **not** open page PNGs one by one to judge these — the script already checks them and prints a knob hint per issue (SKILL.md §Step 5 has the 2-round loop rule):


| 자동 판정 (요약에 나옴) | 힌트로 붙는 knob |
| --- | --- |
| `□` heading orphaned with 0~2 lines at the bottom of a page (ERROR when alone, WARN when 1~2 lines follow) | `"pageBreakBefore": true` — 이동 후 앞 페이지 공백이 1/4를 넘으면 `compact` 로 대체 |
| Section spilling 1~2 lines onto the next page / last page holding only `- 이 상 -` | `"compact": true` 또는 문장 축약 |
| Page starting with `□` while the previous page is >25% blank | `pageBreakBefore` 취소 검토 |
| Previous page >25% blank without a heading start (table/image pushed whole) | 표 분할·이미지 축소 |
| 1~2 word widow lines (14pt body only) — INFO | 문장 2~4자 축약 또는 `"scale"` |
| Annotation box overlapping a body line or another annotation; annotation past the right margin | anchor 이동·주석 축약·bullet 분리 |
| Image taller than 55% of the content height (확대 렌더), image/shape outside the content area | `width` / `maxWidthPct` 축소, 도식 노드 축소 |
| Title rendered in 2 lines, footer page-number mismatch, blank page, page-count cap (`--max-pages`) | 제목 축약 / 재생성 |
| Annotations per page < 3 — INFO | 근거 있는 출처·시점·용어 풀이만 추가 |
| docx: Heading styles, non-bold `□`, non-바탕체 fonts, 한자, English function-word capitalisation (`Of/And/In`), ASCII `~`, table cell margins / row height, `- 이 상 -` count | 원문 JSON 수정 (`noAutoCap` 포함) |


What still needs **one** visual pass (all `page-*.png` read in a single turn, or `contact-sheet-*.png` when >8 pages):


- Text clipped inside diagram nodes (Word-only rendering differences — see §Diagrams).
- Table column widths that look awkward even though borders/row heights are correct — check the installed `scripts/generate.py` version before overriding `fontSize`/`rowHeight` manually.
- Whether an inserted image actually shows the intended chart/figure.
- Leftover Heading-style formatting that survived a rewrite is caught by the script; visual sanity of the highlighted (yellow) revisions in evaluate/revise workflows is not (see `references/evaluate-revise.md`).
