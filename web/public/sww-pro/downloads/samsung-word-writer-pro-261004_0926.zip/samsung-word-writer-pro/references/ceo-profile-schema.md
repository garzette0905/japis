# CEO profile content JSON schema


CEO Profile(문서유형 08)은 **일반 보고서·기업개요와 같은 JSON 스키마**를 쓰고 같은 엔진(`scripts/generate.py`)이 렌더한다. 즉 이 문서는 `references/content-schema.md` 의 **CEO 전용 추가분**만 정의한다 — 섹션/불릿/주석/표 필드는 전부 `content-schema.md` 를 그대로 따른다.


절차·고정 섹션 순서·작성 기준은 `references/ceoinfo.md` 를 먼저 읽는다.


## Standard shape (신규 작성은 이 형태로)


```json
{
  "mode": "ceoinfo",
  "title": "Anthropic사 CEO Profile",
  "profileImage": {
    "path": "assets/example_ceo_image.jpeg",
    "alt": "profile image for Dario Amodei",
    "width_cm": 3.8
  },
  "termAnnotations": {
    "MoE": "Mixture of Experts (전문가 혼합 구조)"
  },
  "sections": [
    { "heading": "이    름 : Dario Amodei ('83년생)", "bullets": [] },
    { "heading": "국    적 : 미국", "bullets": [] },
    {
      "heading": "주요 이력",
      "bullets": [
        { "kind": "dash", "text": "'21.2월 ~ 현재, Anthropic 공동 창업자 겸 CEO" },
        {
          "kind": "dash",
          "text": "'25년, 보험사 대상 UBI 플랫폼 관련 전략 검토",
          "annotation": { "anchor": "UBI", "text": "Usage-Based Insurance (운전 행태 기반 보험)" }
        }
      ]
    }
  ]
}
```


## CEO 전용 top-level 필드


| Field | Type | Required | Notes |
|---|---:|---:|---|
| `mode` | string | no | `"ceoinfo"` 로 두면 **단독 CEO Profile 문서**로 취급하고 `profileImage` 누락 시 생성이 실패한다. 별첨으로만 들어가는 CEO Profile 에는 지정하지 않는다. |
| `profileImage` | object 또는 string | 조건부 | 인물 사진. 객체(`path` / `url` / `alt` / `width_cm` / `x_cm` / `y_cm` / `x_emu` / `y_emu`) 또는 경로·URL 문자열. `mode: "ceoinfo"` 일 때 필수. **`appendices[]` 안에서도 동일하게 쓸 수 있다.** |
| `profileImagePath` | string | no | `profileImage.path` 의 top-level alias. |
| `profileImageUrl` | string | no | `profileImage.url` 의 top-level alias. 생성기가 내려받아 삽입한다. |
| `termAnnotations` | object 또는 array | no | 용어집. 각 용어의 **첫 등장 지점**에 이동글틀을 자동 배분한다. alias: `term_annotations`. |


`title` / `date` / `sections` / `appendices` 등 나머지 필드는 `references/content-schema.md` 와 동일하다.


### `profileImage` 세부


```json
"profileImage": { "path": "/mnt/data/attached_ceo_photo.png", "alt": "profile image for Jane Doe" }
```
```json
"profileImage": { "url": "https://example.com/jane-doe.jpg", "width_cm": 4.0 }
```
```json
"profileImage": "https://example.com/jane-doe.jpg"
```
```json
"profileImagePath": "C:/photos/jane-doe.png"
```


| Key | Default | Notes |
|---|---|---|
| `path` | — | 로컬 파일 경로. 절대경로, 또는 JSON 파일 기준 / 현재 디렉터리 / 스킬 루트 기준 상대경로. |
| `url` | — | HTTP(S) 이미지 URL. 임시 폴더로 내려받아 삽입. |
| `alt` | `profile image` | 대체 텍스트 — 의미 있게 쓴다. |
| `width_cm` | `3.8` | 가로 폭(cm). 세로는 비율 유지 자동. |
| `x_cm` / `x_emu` | 본문 우측 끝 정렬 | 앵커 단락 기준 가로 오프셋. |
| `y_cm` / `y_emu` | 300 twips (≈0.53cm) | 앵커 단락 상단 기준 세로 오프셋(아래 방향). |


렌더 결과는 항상 **"텍스트 앞"(In Front of Text) floating** — `wp:anchor` + `behindDoc="0"` + `wp:wrapNone`. 별도 host 단락을 만들지 않으므로 본문 높이를 차지하지 않는다. WebP 등 python-docx 가 못 읽는 포맷은 Pillow 로 PNG 변환 후 삽입한다(Pillow 없으면 명확한 에러).


### `termAnnotations` 세부


```json
"termAnnotations": {
  "MoE": "Mixture of Experts (전문가 혼합 구조)",
  "RAG": "Retrieval-Augmented Generation (검색 증강 생성)"
}
```
```json
"termAnnotations": [
  { "anchor": "MoE", "text": "Mixture of Experts (전문가 혼합 구조)" }
]
```


배분 규칙: 문서 순서대로 훑으며 **이미 `annotation` / `headingAnnotation` 이 있는 라인은 건너뛰고**, 용어가 처음 등장하는 라인 하나에만 붙인다. 한 라인에는 이동글틀 1개. 표·이미지·도식·소제목 불릿은 대상에서 제외된다. 긴 용어를 먼저 매칭하므로 `AI` 가 `AI Agent` 를 가로채지 않는다.


## 레거시 CEO JSON (하위 호환)


예전 `scripts/generate_ceo.py` 용 평면 구조도 계속 동작한다. `generate.py` 의 `expand_ceo_profile()` 이 로드 직후 표준 `sections` 로 펼친다 — 렌더 결과는 신규 형태와 동일하다. **신규 작성에는 쓰지 않는다.**


| 레거시 필드 | 변환 결과 |
|---|---|
| `name` (+ `name_annotation`) | `□ 이    름 : {값}` 섹션 (+ `headingAnnotation`) |
| `nationality` (+ `nationality_annotation`) | `□ 국    적 : {값}` 섹션 |
| `birthplace` (+ `birthplace_annotation`) | `□ 출    생 : {값}` 섹션 |
| `education[]` | `□ 학    력` 섹션 + `dash` 불릿 |
| `career[]` | `□ 주요 이력` 섹션 + `dash` 불릿 |
| `notes[]` | `□ 참고사항` 섹션 + `dash`(`text`) / `dot`(`children`) / `note`(`note`) 불릿 |
| `image` / `image_path` / `image_url` / `ceo_image` | `profileImage` |
| `term_annotations` | `termAnnotations` |


`career[]` 항목은 문자열, `{ "period", "organization", "role" }`, `{ "text", "annotation" }` 세 형태를 모두 받는다. `period` + `organization`/`role` 조합은 `'21.2 ~ 현재, Anthropic Co-Founder & CEO` 처럼 한 줄로 합쳐진다.


레거시 진입점 `python scripts/generate_ceo.py content.json out.docx` 도 아직 동작하지만 deprecation 경고를 출력하고 `generate.py` 로 위임한다. `--template` 옵션은 무시된다.


## Hanja rule


생성기가 관용 한자를 한글로 자동 치환한다(`normalize_hanja`). 원문 자체를 한글로 쓰는 것이 원칙이며, closing 은 항상 `- 이 상 -`.
