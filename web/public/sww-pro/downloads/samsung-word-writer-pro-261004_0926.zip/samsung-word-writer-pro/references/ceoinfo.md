# CEO Profile (ceoinfo) mode


Use this mode when the user asks for a **CEO / 대표 / 창업자 / founder / 임원 / executive profile / 인물 프로필**. 본문은 아래 **고정 섹션 순서**를 따른다 — general 모드의 archetype 자유도를 적용하지 말고, TOC를 붙이지 말고, `Ⅰ./1.` 계층을 쓰지 말고, `검토 범위 / 분석 방법 / Samsung 제언` 같은 섹션을 만들지 않는다.


## 엔진 통합 (필독 — 260821 변경)


**CEO Profile 은 더 이상 전용 엔진을 쓰지 않는다.** 기업개요(07)·일반 보고서와 **완전히 동일한 렌더 경로**(`scripts/generate.py` + 표준 `sections` JSON)를 탄다.


- **Generator**: `scripts/generate.py` (기업개요·일반 보고서와 동일). `scripts/generate_ceo.py` 는 예전 호출을 깨뜨리지 않기 위한 **deprecated 호환 레이어**일 뿐이며, 내부적으로 `generate.py` 를 호출한다. 새로 만들 때는 `generate.py` 를 직접 쓴다.
- **입력 JSON 형태도 보고서와 동일** — `title` / `date`(선택) / `sections[]` / `appendices[]`. 예전의 `name` / `nationality` / `education` / `career` / `notes` 평면 구조는 `generate.py` 의 `expand_ceo_profile()` 이 표준 `sections` 로 자동 변환하므로 계속 동작하지만, **신규 작성은 `sections` 형태로 쓴다.**
- **이동글틀(주석)·줄간격·표·페이지 맞춤·widow 보정 로직이 하나뿐이다.** CEO Profile 의 주석 규칙은 `references/tone.md` §7 과 `references/content-schema.md`(Annotation forms)를 그대로 따른다 — 별도 CEO 전용 주석 규칙은 없다.
- **Do not set** `toc`, `cover`, `numeral`, `number` in ceoinfo JSON.
- 예시 JSON: `assets/example_ceo.json` (예전 시각 참고용 `assets/template_CEO Profile.docx` 는 260917 에 패키지에서 제외 — 생성에 쓰이지 않았고 DRM 배포 사고의 원인이었다). 필드 명세: `references/ceo-profile-schema.md`.


## Fixed CEO profile section order


순서를 유지한다. 자료가 없어 채울 수 없는 섹션은 빼되, 순서를 뒤집거나 다른 성격의 섹션으로 바꾸지 않는다. 모든 섹션은 `□` 레벨 하나로만 렌더한다(JSON `heading` 에는 `□` 를 직접 쓰지 않는다 — 생성기가 붙인다).


### 0. Title


- Format: `{회사}사 CEO Profile`, 예: `Anthropic사 CEO Profile`, `Stripe사 CEO Patrick Collison Profile`.
- 가운데 정렬 20pt bold + underline (엔진 기본값). **제목에 출처 주석 금지.**
- **제목 1줄 고정** — 상세: `references/tone.md` §6-12. 연도는 `'YY년` 축약.


### 1. 이름


- `"heading": "이    름 : Patrick Collison ('88년생)"` — 라벨은 `이    름`(이·름 사이 4칸)으로 폭을 맞춘다.
- 나이 또는 출생연도를 알면 괄호로 덧붙인다.


### 2. 국적 / 출생


- `"heading": "국    적 : 아일랜드"`, `"heading": "출    생 : 아일랜드 리머릭 (거주 : 미 캘리포니아 샌프란시스코)"`.
- 자료가 뒷받침될 때만, 하나 또는 둘 다.


### 3. 학력


- `"heading": "학    력"` + `dash` bullets. 예: `'06 ~ '11년, Princeton University 생물 물리학 박사`.


### 4. 주요 이력


- `"heading": "주요 이력"` + `dash` bullets. 한 줄에 기간·조직·역할: `'21.2월 ~ 현재, Anthropic 공동 창업자 겸 CEO`.
- 창업·성장 chronology 가 더 적합하면 연도 기반 이벤트 bullet 로 쓴다: `'08년, Auctomatic 공동 창업, Live Current Media에 매각(19세, 백만장자)`.


### 5. 참고사항 (선택)


- `"heading": "참고사항"`. 가족·순자산·커뮤니티 역할·지분 등 의미 있는 특이사항만. 분량 채우기용 금지.
- 하위 상세는 `dot` bullet 으로: `- 형제 : John Collison(Stripe President)` → `· 아일랜드 리머릭 출신, '09년 MIT 입학`.


### 6. Closing marker


- 본문 마지막에 `- 이 상 -` 자동 삽입 (엔진 처리). 별첨으로 붙는 CEO Profile 에는 붙지 않는다(엔진 기본값).


## 인물 사진 (profileImage)


- **단독 CEO Profile 문서는 사진 필수.** `"mode": "ceoinfo"` 를 최상위에 두면 사진이 없을 때 생성기가 실패로 막는다.
- **다른 보고서의 별첨/보조 섹션으로 들어가는 CEO Profile 은 사진 권장(필수 아님)** — 별첨은 `appendices[].profileImage` 로 붙인다.
- 렌더 방식: 본문 폭 기준 **우상단 floating**, Word 줄바꿈 옵션은 항상 **"텍스트 앞"(In Front of Text)**. OOXML 상 `wp:anchor` + `behindDoc="0"` + `wp:wrapNone` (자식 순서 `extent → effectExtent → wrapNone → docPr`). 사용자가 매번 수동으로 바꿀 필요 없이 `generate.py` 가 자동 처리한다.
- **별도 host 단락을 만들지 않는다** — 이동글틀과 동일하게 제목(또는 별첨 라벨) 단락에 부착되어 본문 높이를 전혀 차지하지 않는다.
- 기본값: 폭 `3.8cm`, x = 본문 우측 끝 정렬, y = 앵커 단락 상단에서 300 twips 아래. `width_cm` / `x_cm` / `y_cm` (또는 `x_emu` / `y_emu`) 로 조정.
- alt text 는 의미 있게 (`profile image for Dario Amodei`).
- **여러 인물이 한 별첨에 들어갈 때(창업진·경영진 프로필, 260923 Jev 손수정본)** — 인물마다 `□ 이름 (직책)` 섹션을 두고 사진은 **`sections[].profileImage`** 로 붙인다. □ 헤딩 우측에 폭 4.5cm "텍스트 앞" 그림으로 들어가고, 생성기가 사진 옆 줄(헤딩 + 보통 이름·국적·학력 3줄)의 wrap 폭을 줄여 글자가 사진 뒤로 들어가지 않게 한다. **`kind: "image"` 인라인 사진 단락과 `※ 사진 : 출처` 캡션 줄은 쓰지 않는다**(1인당 약 9줄 낭비 → 3명이 2쪽). 출처는 `headingAnnotation: {"anchor": "<이름>", "text": "사진 : …"}` 로. 스키마 예시는 `references/content-schema.md` §Image.


### Image intake priority


1. 사용자가 파일을 첨부하면 그 로컬 경로를 `profileImage.path` 에 그대로 (`/mnt/data/...`, `C:\...` 등).
2. 사용자가 URL 을 주면 `profileImage.url` 에 그대로 — 생성기가 내려받아 삽입한다.
3. 위 둘 다 없을 때만 공식/회사 이미지를 조사.
4. 다운로드·오픈 실패는 명확히 실패시키고 재요청한다 — 사진 없이 단독 CEO Profile 산출 금지.
5. WebP 등 python-docx 가 못 읽는 포맷은 Pillow 로 PNG 변환 후 삽입(자동).


## Annotation rules (이동글틀) — 보고서와 동일


**CEO 전용 규칙은 없다.** `references/tone.md` §7 "이동글틀 작성 기준"과 `references/content-schema.md`(Annotation forms)을 그대로 따른다. 요약하면:


- 파랑(3333FF) 9pt floating DrawingML 텍스트 박스, `* ` (별표 + 한 칸) prefix. 길어서 우측 여백을 넘으면 `* ` 대신 끝에 ` ┘` 를 붙이고 박스를 왼쪽으로 밀어 `┘` 가 anchor 첫 글자 바로 아래에 오게 자동 전환된다.
- `{"anchor": "...", "text": "..."}` — anchor 단어 **바로 아래**에 배치된다. 여러 줄로 wrap 된 bullet 에서도 anchor 가 있는 줄을 찾아 붙는다.
- 이동글틀 텍스트에 **용어명을 반복하지 않는다**(정의만). `용어 : 정의` 로 써도 생성기가 선행 라벨을 제거한다.
- **제목엔 주석 금지.** 쉬운/일반 용어(CEO, R&D, NASDAQ, AI, PC, 널리 알려진 회사명·통화·거래소)에는 주석 금지.
- 같은 용어는 문서 전체에서 한 번만.
- 섹션 heading 에 붙일 때는 `headingAnnotation` 을 쓴다.


### `termAnnotations` (용어집, 선택)


최상위에 용어집을 두면 생성기가 **각 용어의 첫 등장 지점**에 이동글틀을 자동 배분한다(이미 주석이 있는 라인은 건드리지 않고, 한 라인에 하나만, 같은 용어는 1회만).


```json
"termAnnotations": {
  "MoE": "Mixture of Experts (전문가 혼합 구조)",
  "RAG": "Retrieval-Augmented Generation (검색 증강 생성)"
}
```


레거시 표기 `term_annotations` 도 동일하게 동작한다.


## Hanja absolute ban (ceoinfo)


- 최종 문서에 **한자(漢字) 절대 금지**. `年→년`, `月→월`, `日→일`, `現→현재`, `社→사`, `美→미국`, `兆/億/萬 → 조/억/만`, `博士/碩士/學士 → 박사/석사/학사` 등.
- Closing 은 `- 이 상 -` (절대 `- 以 上 -` 아님).
- `generate.py` 의 `normalize_hanja` 가 관용 한자를 자동 치환하지만, 원문 자체를 한글로 쓰는 것이 원칙이다.


## Spacing (엔진 자동 — 지정 불필요)


보고서 엔진의 위치별 spacing 이 그대로 적용된다. `□` 헤딩 뒤 16pt, `-`↔`-` 16pt, `-`→`·` 12pt, wrap 연속 줄 9pt, 섹션 사이 20pt, 마지막 `- 이 상 -` 9pt. 상세: `references/generator-defaults.md`.


## CEO JSON skeleton (default)


```json
{
  "mode": "ceoinfo",
  "title": "Anthropic사 CEO Profile",
  "profileImage": {
    "path": "assets/example_ceo_image.jpeg",
    "alt": "profile image for Dario Amodei",
    "width_cm": 3.8
  },
  "sections": [
    { "heading": "이    름 : Dario Amodei ('83년생)", "bullets": [] },
    { "heading": "국    적 : 미국", "bullets": [] },
    {
      "heading": "학    력",
      "bullets": [
        { "kind": "dash", "text": "'06 ~ '11년, Princeton University 생물 물리학 박사" }
      ]
    },
    {
      "heading": "주요 이력",
      "bullets": [
        { "kind": "dash", "text": "'21.2월 ~ 현재, Anthropic 공동 창업자 겸 CEO" },
        {
          "kind": "dash",
          "text": "'25년, 보험사 대상 UBI 플랫폼 관련 전략 검토",
          "annotation": { "anchor": "UBI", "text": "Usage-Based Insurance (운전 행태 기반 보험)" }
        }
      ]
    },
    {
      "heading": "참고사항",
      "bullets": [
        { "kind": "dash", "text": "남매 : Daniela Amodei(President, Co-founder)" },
        { "kind": "dot", "text": "'18.10 ~ '20.12월, OpenAI VP of Safety & Policy" }
      ]
    }
  ]
}
```


전체 예시: `assets/example_ceo.json`.


## 다른 보고서의 별첨으로 붙일 때


문서유형 08 이 01~06·09 와 중복 선택된 경우, CEO Profile 은 본문을 대체하지 않고 **별첨**으로 분리한다. 같은 JSON 안에서 처리한다:


```json
"appendices": [
  {
    "title": "Stripe사 CEO Patrick Collison Profile",
    "profileImage": { "path": "C:/photos/collison.jpg" },
    "sections": [
      { "heading": "이    름 : Patrick Collison ('88년생)", "bullets": [] },
      { "heading": "주요 이력", "bullets": [ /* ... */ ] }
    ]
  }
]
```


07(기업개요)과 08(CEO Profile)이 함께 지정되면 한 섹션에 섞지 말고 **각각 별도 별첨**으로 만든다.


## CEO generation command


```bash
python scripts/generate.py <ceo_content.json> <output.docx>
```


`python scripts/generate_ceo.py ...` 도 아직 동작하지만 deprecation 경고를 출력하고 `generate.py` 로 위임한다. 신규 작성엔 쓰지 않는다.


생성 후 시각 검증 (가능하면 PNG 렌더링):


- 제목 가운데 20pt bold+underline, 제목 1줄
- `□` 헤딩·bullet 간격이 보고서 기준과 동일
- 이동글틀 = 파랑(3333FF) 9pt, `* ` prefix (긴 경우 끝에 `┘`), anchor 단어 직하
- 인물 사진 우상단 배치, 본문을 밀어내지 않음("텍스트 앞")
- 한자 잔류 없음, closing `- 이 상 -`
- 페이지 번호 정상


## 회귀 검사


```bash
python scripts/test-ceo-regressions.py
```


이동글틀 색상·floating 여부, 사진의 "텍스트 앞" 배치, 레거시 JSON 변환, 용어집 배분, 별첨 사진, 사진 누락 시 실패, 여러 인물 별첨의 □ 헤딩 사진·줄폭 예약(260923)을 한 번에 확인한다.
