# Content JSON schema


This is the shape `scripts/generate.py` expects.


## Top level


```jsonc
{
  "title": "기업 개요",
  "toolName": "ChatGPT chat",                  // required — 확인된 현재 실행 Tool 이름
  "llmVersion": "GPT-5",                       // required — 확인된 LLM 이름 그대로
  "sourceUrl": "https://example.com/article",  // optional — 기사/1차 소스 URL, 제목 바로 아래 9pt 파랑 한 줄
  "date": "'26. 4. 15 (수)",
  "toc": { /* TOC cover page — optional, only if user asks */ },
  "profileImage": { /* 인물 사진 — optional, ceoinfo 모드용 */ },
  "termAnnotations": { /* 용어집 — optional, 첫 등장 지점에 이동글틀 자동 배분 */ },
  "noAutoCap": ["ebay", "…"],                   // optional — 자동 대문자화에서 제외할 고유명사 추가 등록
  "mode": "ceoinfo",                            // optional — 단독 CEO Profile 문서 표시(사진 필수 검증)
  "sections": [ /* Section */ ],
  "appendices": [ /* Appendix */ ]
}
```


Notes:


- **`toolName` + `llmVersion`** (required; snake_case aliases supported) — 최종 Word 파일명을 `<보고서 제목>(<확인된 Tool이름>, <확인된 LLM이름>)_YYMMDD_HHMM.docx`로 만드는 실행 메타데이터. 실행 환경에서 받은 값을 그대로 사용하고, 확인되지 않은 버전·변형을 추정하거나 기본값으로 채우지 않는다. `GPT-5`까지만 확인되면 그대로 `GPT-5`, `GPT-5.6 Sol`까지 확인되면 그대로 `GPT-5.6 Sol`을 기록한다. Tool이 구분되면 Codex는 `Codex`, ChatGPT 채팅 서비스는 `ChatGPT chat`으로 기록한다. 시각은 KST 기준이며 Windows 금지문자는 `_`로 정규화된다. 자동화 호출은 `SWW_TOOL_NAME`·`SWW_LLM_VERSION` 환경변수로 대체할 수 있다.
- **`sourceUrl`** (top-level, optional; alias `titleSource`) — 보고서가 근거한 기사·공식 발표 등 1차 소스 URL. 제목 **바로 아래에 붙여**(y=471dxa) 좌측 정렬 파랑 9pt `* 출처 : {url}` 한 줄로 렌더된다(날짜 위). 생성기가 `* 출처 : ` prefix를 자동으로 붙이므로 URL만 넣으면 된다. **URL 전체가 항상 보인다** — 제목 왼쪽 끝에서 본문 폭을 넘으면 박스를 왼쪽으로 밀고, 본문 폭보다 길면 장평을 75%까지 좁히고, 그래도 길면 2줄 박스로 감싼다(잘림 없음). URL 을 줄이거나 나눠 쓰지 않는다. 제목 줄 자체에는 출처 주석을 달지 않는다. `titleAnnotation` 은 유효하지 않은 필드로 무시된다.
- **날짜**: 우상단 `date` 는 `'YY. M. D (요일)` 형식, **요일은 한글**(`(수)`), 한자 없음. 본문 인라인 이벤트 날짜는 `M/D`(`(6/24)`).
- **한자 미사용**: 모든 텍스트(제목/날짜/헤딩/불릿/표/주석)에서 한자를 쓰지 않는다. 생성기가 렌더 직전 관용 단자 한자를 한글로 자동 치환(`normalize_hanja`)하고, 본문 텍스트의 ASCII `~` 는 2byte `∼`(U+223C)로 자동 변환한다.
- Title renders bold + underlined; section headings (`□ …`) render bold. Body text stays regular weight.
- **제목 「 」 컨벤션 (선택)**: 강조가 필요한 고유명사(프로젝트명·계약명·법안명·솔루션명 등)는 「 」(낫표)로 감쌀 수 있다. 다만 **강제는 아니다** — 짧은 코드명/영문 고유명사는 낫표 없이 둬도 된다(예: `Jalapeño`). 일반 명사구 제목엔 쓰지 않는다.
- `toc` is **optional** and triggers the formal 목차 cover page. **Include it only when the user explicitly requests** a 목차 / TOC / table of contents / 목차 장표. If omitted, the document starts directly with the title block as before.
- **When `toc` is present, the body's centered title block and right-aligned date are auto-skipped** (the TOC page already carries them). The body begins directly with the first section. Override with `"skipTitleBlock": false` on the top level if you explicitly want the title repeated.
- **`profileImage`** (top-level 또는 `appendices[]` 항목, optional; **`sections[]` 항목에도 허용 — □ 헤딩 우측 사진, §Image 참고**) — 인물 프로필 사진. `{"path": "..."} / {"url": "https://..."}` 또는 경로·URL 문자열. 제목(별첨이면 별첨 라벨) 단락에 **"텍스트 앞"(In Front of Text) floating** 으로 부착되어 본문 높이를 차지하지 않는다. 기본 폭 3.8cm, 본문 우측 끝 정렬. 조정 키: `width_cm` / `x_cm` / `y_cm` / `x_emu` / `y_emu` / `alt`. Alias: `profileImagePath`, `profileImageUrl`. 상세: `references/ceo-profile-schema.md`.
- **`termAnnotations`** (top-level, optional; alias `term_annotations`) — `{"용어": "정의"}` 용어집. 문서 순서대로 훑어 **각 용어가 처음 등장하는 라인 하나**에만 이동글틀을 자동으로 붙인다. 이미 `annotation`/`headingAnnotation` 이 있는 라인은 건너뛴다.
- **`mode`** (top-level, optional) — `"ceoinfo"` 면 단독 CEO Profile 문서로 보고 `profileImage` 누락 시 생성이 실패한다. 다른 값/미지정은 검증 없음.
- **자동 대문자화와 `noAutoCap`** (top-level, optional; alias `no_auto_cap`) — 생성기는 문장 안의 **전체 소문자 영어 단어**의 첫 글자를 대문자로 올린다(`frontier` → `Frontier`, `scale-up` → `Scale-up`). 단, **소문자로 시작하는 회사명·고유명사는 제외**한다 — `eBay`·`iOS`·`xAI` 처럼 대소문자가 섞인 표기는 애초에 건드리지 않고, 소문자로만 쓰인 브랜드(`ebay`, `github`, `naver`, `kakao`, `iphone`, `mrna` 등)는 `NO_AUTOCAP` 목록으로 보호된다(`EBay`·`Github` 같은 오표기 방지). 목록에 없는 고유명사가 있으면 최상위 `"noAutoCap": ["…"]` 로 문서 단위 추가한다.


## `toc` — formal 목차 cover page (optional)


```jsonc
{
  "toc": {
    "reportTitle": "'24년도 영업지원 상반기 보고",
    "items": [
      "미청구 현황",
      "요금조정 및 1회성 청구 현황",
      "매출채권 현황",
      "빌링시스템 구축 현황"
    ],
    "appendix": {
      "label": "[별첨]",
      "items": [
        "1-1) 조직별 미청구 현황",
        "1-2) 장기 미청구 리스트",
        "2-1) 조직별 요금조정 현황",
        "2-2) 금액별 요금조정 현황",
        "3) 1회성 청구 세부내역",
        "4) 법인별 매출채권 회전기일 현황",
        "5) 신규 발생 90일 초과 채권"
      ]
    },
    "date": "2024. 3. 30",
    "author": "XX팀"
  }
}
```


Rendering:


- 상단: 굵은 테두리 안에 `reportTitle` (22pt bold, 중앙정렬)
- 중앙: `- 목    차 -` 라벨 (18pt bold, 중앙정렬, 목·차 사이 4-space)
- 본문 박스: 얇은 테두리 안에 `items[]`가 `1. …`, `2. …` 형식으로 나열 (16pt bold).
  - 각 항목은 문자열 또는 `{ "text": "…", "number": 2 }` 형태. `number`를 주면 자동번호 대신 그대로 사용.
- `appendix` (선택): `[별첨]` 라벨과 함께 `1-1)`, `1-2)` 같은 세부 항목을 14pt로 들여써서 렌더.
- 하단: `date` (18pt, 중앙) → `author` (20pt bold, 중앙, 자간 넓힘)
- 이 장표 뒤에 자동으로 페이지 나눔이 들어가고 본문(제목/일자/섹션/이 상 -)은 다음 페이지에서 시작.


모든 필드는 선택적 — 누락된 필드는 그 슬롯만 비운 채 렌더.


## Section


```jsonc
{
  "heading": "회사 개요",
  "headingAnnotation": {
    "text": "공식 홈페이지 기준",
    "anchor": "회사 개요"
  },
  "pageBreakBefore": false,  // optional — true면 이 섹션 앞에 페이지 나누기(□ 가 새 페이지 상단에서 시작). 첫 섹션엔 무시됨.
  "compact": false,          // optional — true면 이 섹션 본문 줄간격을 223(≈93%)으로 압축
  "line": 240,               // optional — 줄간격을 직접 지정(예: 223). compact보다 우선.
  "bullets": [ /* Bullet */ ]
}
```


`headingAnnotation` is optional and remains allowed.


### Page-fit fields (`pageBreakBefore` / `compact` / `line`)


본문이 페이지 경계에 어정쩡하게 걸칠 때 **렌더 후 시각 검증**으로 판단해 지정한다(본 엔진은 Word 자동 흐름에 의존하므로 자동 분량 계산은 하지 않음).


| Field | Scope | Effect | When |
|---|---|---|---|
| `pageBreakBefore: true` | section | **□ 헤딩 바로 앞 단락 끝**에 `w:br type="page"` run을 삽입해 `□` 가 **다음 페이지 첫째 줄**에서 시작. **제약: 앞 페이지 공백이 전체의 1/4 이상이 되면 사용 금지** (과도한 여백). | □ 헤딩이 페이지 하단에 **1~2줄만** 홀로 남을 것으로 예상될 때 |
| `compact: true` | section / document | 본문 줄간격 223(≈93%)으로 압축 | 한 페이지가 **딱 1~2줄만** 넘칠 때 한 페이지로 끌어올림 |
| `line: <n>` | section / document | 줄간격을 `<n>`(twips, 240=단일행)으로 직접 지정 | 압축 정도를 세밀 조정할 때 (`compact`보다 우선) |


document 최상위에도 `compact` / `line` 을 둘 수 있으며 전체 기본값이 된다(섹션별 지정이 우선).


### Section heading levels (optional extra tiers)


The default section heading is `□ 제목` (14pt bold). For large reports that need extra hierarchy above `□`, you can optionally promote a section with `numeral` or `number`:


| Field | Renders as | Size | When to use |
|---|---|---|---|
| `numeral: "Ⅰ"` | `Ⅰ. 제목` (no `□`) | 16pt bold | Top-level chapter in a **very large** report (typically TOC-backed) |
| `number: 1` | `1. 제목` (no `□`) | 14pt bold | Sub-chapter under a Roman-numeral chapter, or mid-tier grouping in a long report |
| *(neither)* | `□ 제목` | 14pt bold | **Default** — ordinary section |


Full hierarchy (top → bottom), with indentation preserved:


```
Ⅰ. 대분류              ← numeral (optional, 매우 큰 범위의 보고서)
   1. 중분류           ← number  (optional)
      □ 소분류         ← default section
         - 본문        ← dash bullet
            · 세부     ← dot bullet
```


`numeral` and `number` are **both optional** — use them only when the content is voluminous enough that `□` alone can't carry the structure. For ordinary briefs, keep the plain `□` style and do not introduce higher levels.


```jsonc
{
  "numeral": "Ⅰ",
  "heading": "Executive Summary",
  "bullets": [ /* … */ ]
}
```


```jsonc
{
  "number": 1,
  "heading": "시장 개요",
  "bullets": [ /* … */ ]
}
```


Rule: when `numeral` or `number` is set, the `□` prefix is **omitted** — these markers are higher-level than `□`, so never combine them. Use at most one of `numeral` / `number` on a single section.


## Bullet


```jsonc
{
  "kind": "dash",
  "text": "핵심 내용",
  "bold": true,
  "annotation": {
    "text": "출처 또는 보충설명",
    "anchor": "핵심"
  }
}
```


### Annotation forms


```jsonc
"annotation": "McKinsey 2025"
```


or


```jsonc
"annotation": {
  "text": "McKinsey 2025",
  "anchor": "78%"
}
```


#### Annotation rendering


Annotations render as a DrawingML 9pt blue (#3333FF) **텍스트 상자**, 설명 대상 단어(앵커) 바로 아래에 배치된다. 배경 없음 / 테두리 없음 / 줄 바꿈 = 텍스트 앞 (`wp:wrapNone`, `behindDoc="0"`); 폭은 주석 길이에 맞춰 자동 계산.


- **위치** (260909 손수정본 계측값): 박스 상단은 앵커가 놓인 본문 줄의 단락 상단에서 **16.2pt(324 DXA) 아래** — 본문 글자와 붙어 보이지 않을 만큼 띄우고, 다음 줄과는 겹치지 않는 거리. 모든 이동글틀에 같은 값이 적용된다(단락 after 간격과 무관).
- **짧은 주석**: 앵커 첫 글자 위치에서 **1.2pt 오른쪽**에 `* ` (별표 + 한 칸) prefix로 좌측 정렬 — 별표가 앵커 글자 왼쪽으로 튀어나온 듯 보이지 않게.
- **긴 주석** → ` ┘` 모드 자동 전환 (둘 중 하나면): ① `* ` 주석의 오른쪽 끝이 본문 폭 우측 15pt 안쪽에 들어오지 못함, ② **앵커가 놓인 본문 줄의 글자 끝보다 120pt 이상 오른쪽으로 튀어나옴**(짧은 줄 끝 앵커에 긴 주석이 붙어 빈 공간으로 홀로 뻗는 모양 방지). `* ` 대신 끝에 ` ┘` 를 붙이고, **┘ 글자가 앵커 첫 글자 바로 아래**에 오도록 박스를 좌측으로 밀어 배치(텍스트는 왼쪽으로 흐름).
- **배치 계획 (260923, `plan_annotation_layout`)**: ①만 걸리고 ②는 아니면 `* ` 모드를 유지한 채 **장평 92→85%** 로 먼저 맞춘다(모델명·서비스명 소개는 이름 아래 `*` 가 읽기 쉽다). ┘ 모드에서는 **박스 왼쪽 끝이 앵커 줄의 글자 시작점보다 왼쪽으로 나가지 않는다** — 안 맞으면 ┘ 를 오른쪽으로 옮겨 박스를 글자 시작선에 붙이고, 그래도 안 맞으면 장평을 85%까지 줄인다. 앵커가 줄바꿈으로 갈라졌으면 **앵커가 시작되는 줄**에 붙는다. 어떤 경우에도 박스가 x=0 으로 밀리지 않는다(주석이 본문 폭보다 길면 `*` 로 줄 시작선에 붙이고 `[WARN]`). 작성자 규칙: 출처·출시 주석은 줄 끝 날짜·괄호 토큰(`(9/8)`)에 앵커.


**주석 본문에는 설명 대상 용어명을 반복하지 않는다 — 정의만 적는다** (`* 정의`, not `* 용어 : 정의`). 생성기가 선행 `앵커 :` 라벨을 자동 제거한다(둘째 이후 용어 라벨은 유지). 주석은 anchor 라인 단락에 직접 부착되어 별도 host 단락(과거 1pt 빈 줄)을 만들지 않는다. Do not set a `style` field — other annotation styles are not supported.


**`anchor` 는 본문에 실제로 있는 문자열이어야 한다 — 토씨 하나까지 그대로.** 앵커가 해당 불릿/소제목 본문에서 발견되지 않으면 기준점이 없어 이동글틀이 **본문보다 왼쪽(dxa 0)** 에 붙고, 정렬이 깨진 것처럼 보인다. 생성기는 이 경우 `[WARN]` 을 출력하고 본문 텍스트 시작점으로 떨어뜨려 렌더하지만, 원인은 anchor 오타이므로 JSON 을 고쳐야 한다. 흔한 실수: 본문은 `연환산 매출은 7월 말 기준 …` 인데 `anchor` 에 본문에 없는 `650억 달러` 를 넣는 경우. 앵커를 특정하기 어려우면 `anchor` 를 생략한다(불릿 텍스트 시작점에 자동 배치).


**약어(약칭) 앵커는 예외 — `* {풀네임} ({정의})` 형식.** 앵커가 약어(GDC, MAU, MoE 등)이면 풀네임을 먼저 쓰고 괄호로 정의를 붙인다. 풀네임은 앵커와 다른 문자열이므로 "용어명 반복"이 아니다. 예: `{ "anchor": "GDC", "text": "Google Distributed Cloud (구글 On-Prem이나 Edge 환경에서 제공하는 하이브리드·멀티클라우드 솔루션)" }`. 이동글틀 작성 5원칙(출처·발생시점·용어약어·레벨무관·페이지당 최소 3개)은 `references/tone.md` §7 참조.


```jsonc
"annotation": {
  "text": "Bloomberg",
  "anchor": "AUM"
}
```


Rules:


- Prefer anchored annotations when the note explains a specific number, name, or term.
- Use whole-line string annotations only for umbrella citations.
- `anchor` must be an exact substring of the owning text.
- Section-level `headingAnnotation` follows the same rule.
- The textbox uses a DrawingML shape (`w:drawing` + `wps:wsp`) with `a:noFill` + `a:ln/a:noFill` for no background/border, and `wp:wrapNone` with `behindDoc="0"` for 텍스트 앞 wrap. It is attached directly to the anchor line paragraph and floats in the gap just below it (no separate host paragraph, so no 1pt blank line). Because it sits in front of text and reserves no space, it can overlap the following line if the anchor is on a non-last line of a multi-line bullet. Avoid that by choosing an anchor on the last wrapped line, or by omitting the annotation.
- **Never cite raw filenames** (`report.pdf`, `2024년_상반기.xlsx`, `meeting_notes.docx`, etc.) in annotations. The filename is a local artifact, not a citable source. Instead, cite the actual document title, publisher, organization, or source URL (e.g., `* 경영관리팀`, `* McKinsey Global Institute`, 기사 URL). If no meaningful citation is available, omit the annotation entirely.
- **Dates are conditionally allowed** — 사실적 의미를 지닐 때만 (이벤트 시점, 기준·관측 시점, 출처 발행월, 비교 시점). 장식적 꼬리표 날짜(기관명 뒤 발행월만 기계적으로 붙인 형태 `* Gartner, 2026.3` 등)는 우상단 `date`와 중복되므로 제거. 판단 기준: 그 날짜를 지우면 독자가 사실을 오독하는가? 자세한 규칙은 `references/tone.md` §7 참조.
- **URLs are allowed** when citing a 1차 소스 (기사·공식 발표·영상). URL 자체 또는 `URL (매체명, 발행월)` 형태로 기재.


## `kind` reference


| kind | renders as | use for |
|---|---|---|
| `dash` | `  - {text}` | main bullet |
| `dot` | `    ·{text}` | detail under a bullet |
| `wrap` | `      {text}` | continuation line |
| `note` | `  ※ {text}` | supplementary note |
| `arrow` | `  → {text}` | implication |
| `circled` | ` ① {text}` | ordered strategy item |
| `ordered` | ` 1) {text}` | numbered sub-section |
| `subhead` | `< {text} >` | mini-heading |
| `table` | table block | tabular content |
| `image` | picture (+ optional `< 캡션 >` above it) | embedding a pre-made image file |
| `diagram` | native editable Word shapes (+ optional `< 캡션 >` above it) | simple box/arrow schematic (구조도/순환도/비교도) |


**마커는 생성기가 붙인다 — `text` 에 다시 쓰지 말 것.** `{"kind": "arrow", "text": "→ …"}` 처럼 쓰면 `  → → …` 로 두 번 찍힌다. `note`(`※`), `dash`(`-`), `dot`(`·`) 도 동일. 생성기가 선행 중복 마커를 제거하고 `[WARN]` 을 남기지만, 애초에 넣지 않는 것이 원칙이다. 예외는 `wrap` — 접기 줄에서 `→ …` 로 시작하는 것은 정상 용법이다.


**`□` 제목과 `subhead`를 혼용하지 말 것.** `□` 레벨 제목은 반드시 `sections[].heading`에 마커 없이 넣는다. `subhead`는 표·도식 내부 등의 중앙 소제목 전용이며 생성기가 `< ... >`를 붙이므로 `text`에는 `□`나 `< >`를 넣지 않는다. 생성기는 잘못된 `{"kind":"subhead","text":"□ 제목"}` 입력을 발견하면 `[WARN]`을 출력하고 좌측 정렬 `□ 제목`으로 안전 복구한다.


**`text` 안에 줄바꿈(`\n`)을 넣지 말 것.** 줄바꿈 위치는 생성기가 폭을 계산해 결정한다(`split_bullet_text`). 수동 `\n` 은 문단 중간을 끊고 이어지는 줄의 정렬을 깨뜨리므로 공백으로 치환되며 `[WARN]` 이 출력된다.


### `bold` (optional)


Set `"bold": true` on a bullet to render it in bold. Use this for key implications (`→`), summary takeaways, or action items that need emphasis. Do not overuse — limit to 1–3 critical lines per section.


### `underline` (optional, SC 260506)


Set `"underline": true` on a bullet to render the body text with an underline (the prefix mark `-`/`·`/`→` etc. is **not** underlined). 새 SC 양식의 표준 강조 수단으로, `bold`와 별개의 강조 채널이다. 콜론(`:`) 위치와 무관 — 어떤 위치든 강조가 필요한 bullet에 사용. `bold`와 함께 쓰는 것도 가능 (`bold + underline`).


```jsonc
{ "kind": "dot", "text": "강조내용 : 밑줄로 표기되는 본문", "underline": true }
```


### Inline emphasis — `**…**` / `__…__` (부분 강조, 260923)


전체 bullet이 아니라 **일부 어구만** 강조할 때는 `text` 안에 마크업을 쓴다: `**어구**` = 부분 Bold, `__어구__` = 부분 밑줄. 마커는 폭 계산·줄바꿈·앵커 탐색 전에 제거되고 렌더 시 run 이 나뉘어 서식만 입혀진다(줄바꿈으로 갈라진 구간도 이어진다). `bold`/`underline` 플래그와 함께 써도 된다.


```jsonc
{ "kind": "dash", "text": "정의 : 목표를 실행 계획으로 바꿔 __앱 종료 후에도 일하는 상시 Agent__" }
{ "kind": "dash", "text": "(상품 반영) **전용 VM·승인 Agent·자격증명 금고를 FabriX·Brity에 반영**" }
```


- `annotation.anchor` 에는 마커를 넣지 않는다(마커를 뗀 본문과 비교한다).
- 마커 안팎에 공백을 두지 않는다(`** 어구 **` 는 마크업으로 보지 않는다). 표 셀·소제목·이동글틀 본문에서는 지원하지 않는다.
- 섹션당 1~2곳만. 기준과 예시는 `references/tone.md` §4 "하위레벨·개조식 변형 규칙".


### `highlight` (optional)


Set `"highlight": true` on a bullet that was **added or substantively modified** during 기존 문서 수정/보완 mode (`references/evaluate-revise.md`) — renders the sentence body with a yellow highlighter (`w:highlight yellow`).


```jsonc
{ "kind": "dash", "text": "신규로 추가되거나 수정된 문장", "highlight": true }
```


- Never set it on unchanged text or on a purely cosmetic re-render (줄간격·줄바꿈·표 높이·폰트 변경만 있는 경우).
- **단, 텍스트가 실제로 바뀌는 자동 정규화(한자→한글, `~`→`∼` 등)는 변경으로 보아 `highlight: true`를 지정한다.**
- Not used in fresh(신규) 작성 — only in rewrite/revise/template_reformat workflows.
- **Annotations support the same field** — an added or modified 이동글틀은 `annotation: { "anchor": "...", "text": "...", "highlight": true }`로 지정하면 주석 텍스트가 노란 배경으로 렌더된다.
- Table-cell-level highlighting is **not supported** — when a table changes, add a `※` note bullet near the table describing the change and highlight that note instead.


### `scale` (optional)


Per-bullet character-width percentage. Default is 95 (inherited from the global 장체 95% rule). Lower it to 92 or 93 **only** when a long sentence wraps with a 1–2 character widow on the last line — tightening the letter-spacing pulls those characters up onto the previous line. A manual `scale` applies uniformly to **both the bullet prefix and sentence body** and **disables the automatic widow-fix** below.


```jsonc
{ "kind": "dash", "text": "…long sentence that has only one widow character…", "scale": 92 }
```


Do **not** force every bullet onto a single line. Use `scale` surgically; most bullets should keep the default 95.


**Automatic widow fix (no config needed):** when a bullet wraps to ≥2 lines and the last wrapped line has only 1–2 words, the generator itself tries tightening the sentence body's 장평 in steps `94 → 93 → 92 → 91 → 90` and picks the first value that eliminates the short tail. The bullet mark (prefix) always stays at 95% — only the sentence body is compressed. If 90% still can't resolve the widow, the generator reverts to the original wrap at 95% (no side effects). This is disabled whenever the bullet has a manual `scale` field. Full rendering-defaults reference: `references/generator-defaults.md`.


### Circled numbers (`①②③` — use at dash/dot level)


`kind: "circled"` with `index: 1/2/3…` renders `①②③…`. Circled numbers are a **formatting accent at the `-` (dash) or `·` (dot) level**, not a separate hierarchy tier. Use them when the content under a section is genuinely an ordered list — e.g., numbered strategy items, phased steps, ranked findings — and leave plain `dash` / `dot` for regular bullets. Mixing `dash` and `circled` within the same section is fine.


Do **not** use `①②③` to replace the Roman/number chapter levels (`numeral` / `number`) or the `□` section heading — those are structural; circled numbers are inline ordering only.


**Anti-pattern — never inline `①②③` as literal characters inside a `dash`/`dot` bullet's `text`.** This renders the dash marker AND the circled number together (e.g., `  - ① …`), producing duplicate ordering markers. Always promote ordered items to `{ "kind": "circled", "index": N, "text": "…" }` so the generator emits the circled number as the sole marker. Same rule for `arrow` / `note` — do not prefix their text with `①②③`.


## Image (`kind: "image"`)


Embeds a pre-made image file inline. `caption` renders **above** the image as `< 제목 >` (centered, bold) — the same convention as a table's `caption`.


```jsonc
{ "kind": "image", "path": "assets/some_diagram.png", "caption": "구조도 제목", "alignment": "center" }
```


Any explanatory note or source for the image is a **separate bullet placed right after it** (with a normal 이동글틀 `annotation`), not a field on the image bullet itself.


### Floating photo beside a `□` heading (`float: "right"` / `sections[].profileImage`, 260923)


인물 사진처럼 **글자와 나란히 놓여도 되는 작은 그림**은 인라인 단락으로 넣지 않는다 — 사진 단락 + `※ 사진 : 출처` 줄이 1인당 약 9줄을 차지해 창업진 3명이 2쪽으로 늘어난다(Jev 보고서 손수정본에서 사용자가 전부 우측 "텍스트 앞" 그림으로 바꿨다). 두 표기는 같은 결과를 낸다:


```jsonc
// ① 섹션 필드 (권장)
{ "heading": "Diogo Almeida (공동 창업자·CEO)",
  "profileImage": { "path": "photos/almeida.png", "alt": "profile image for Diogo Almeida" },
  "headingAnnotation": { "anchor": "Diogo Almeida", "text": "사진 : TypeSafe AI 공식 Team 페이지" },
  "bullets": [ { "kind": "dash", "text": "이름 : Diogo Almeida" }, … ] }


// ② 섹션 첫 불릿 (같은 뜻)
{ "heading": "…", "bullets": [ { "kind": "image", "path": "photos/almeida.png", "float": "right" }, … ] }
```


- 렌더: □ 헤딩 단락에 **"텍스트 앞"**(`wp:anchor` + `wp:wrapNone` + `behindDoc="0"`, Word 줄바꿈 옵션 "텍스트 앞") 이동 그림. 폭 **4.5cm** 기본, 본문 폭 우측 끝 정렬, 세로 = 헤딩 단락 상단. `width_cm` / `x_cm` / `y_cm` 으로 조정. 별도 host 단락이 없어 **본문 높이를 전혀 차지하지 않는다**.
- **겹침 방지(자동)**: 생성기가 사진 세로 범위(헤딩 + 보통 3줄) 안에서 시작하는 불릿의 wrap 폭을 `본문 폭 − 사진 폭 − 0.3cm` 로 줄여 미리 줄바꿈한다 → 긴 `학력 :` 줄도 사진 왼쓴 끝 앞에서 꺾인다. 사진 아래부터는 본문 폭 전체. `[INFO] … 사진 옆 N개 항목의 줄폭을 … 줄여` 로그로 확인. `verify_docx.py` 는 렌더 결과에서 글자 상자가 사진 상자와 겹치면 `WARN 글자가 사진과 겹침` 을 낸다.
- **캡션 없음**: float 이미지는 `caption` 을 무시한다(`[WARN]`). 사진 출처는 섹션 `headingAnnotation` 으로 적는다. `※ 사진 : …` 불릿을 따로 만들지 않는다.
- 첫 불릿이 아닌 자리의 float 이미지는 **직전 불릿의 마지막 줄**에 붙고, 그 아래 줄들의 폭이 같은 방식으로 예약된다. 사진 아래에 표·도식이 바로 오면 그 앞에서 예약을 멈춘다.


Size: the generator caps width at 92% of the content width (`maxWidthPct`) and **height at 55% of the content height (`maxHeightPct`)**, keeping the aspect ratio — a tall chart never takes over a page. Set `"maxHeightPct": 0.4` for a smaller figure, or `width`/`height` (px) for an exact size below the caps.


## Diagram (`kind: "diagram"`) — native editable Word shapes, 13 standard templates


For a simple schematic (구조도/순환도/비교도/밸류체인/조직도/계층도/매트릭스/타임라인), prefer `kind: "diagram"` over a pre-rendered image — it renders as real DrawingML shapes (rectangles, chevrons, hexagons, circles, cylinders + connector arrows + text), so every node's text and every arrow's label stays **individually editable in Word** after generation. All geometry is computed by `scripts/diagram_templates.py` (pure Python, no Word template file) so **any LLM writing the JSON gets the same result**: boxes are sized from the text, fonts shrink automatically to fit (title 11→9pt, items 10→8pt), and nothing is clipped as long as the char limits below are respected.


Rendering invariants: every node border and connector is black 1.0pt. A connector is one native DrawingML arrow line with an arrowhead (hierarchy/timeline use plain lines). If a diagram/table/image caption or `subhead` immediately below a `□` section repeats the section heading (same text or same meaning), the generator suppresses the repeated `< … >` line.


```jsonc
{
  "kind": "diagram",
  "caption": "3단계 진행 구조도",          // optional, `< 제목 >` above the diagram
  "layout": "horizontal_flow",
  "nodes": [
    { "title": "현황 진단", "items": ["시장·경쟁 분석", "내부 역량 점검"], "color": "blue" },
    { "title": "전략 수립", "items": ["핵심 과제 도출"], "color": "green" },
    { "title": "실행 관리", "items": ["단계별 로드맵"], "color": "purple" }
  ],
  "arrows": [ { "from": 0, "to": 1, "label": "분석" }, { "from": 1, "to": 2, "label": "설계" } ]
}
```


### Templates (`layout`) — pick the one that matches the content's structure


| `layout` | 용도 | 노드 수 | 비고 |
| --- | --- | --- | --- |
| `horizontal_flow` | 좌→우 단계 흐름(절차·프로세스) | 2~5 | 자동 화살표 i→i+1, `arrows[].label` 은 선 아래 |
| `vertical_flow` | 위→아래 단계 흐름 | 2~5 | 상자 폭 5400 DXA 중앙 정렬(`boxWidth` 조정), 라벨은 선 오른쪽 |
| `chevron_flow` | 화살표형 밸류체인 | 3~6 | 노드 자체가 화살표, 연결선 없음 |
| `2x2_cycle` | 4단계 순환(PDCA) | 4 | 좌상→우상→우하→좌하 시계 방향 |
| `cycle` | 원형 순환 | 3~6 | 타원 링 위 배치, 시계 방향 화살표(`defaultShape: "ellipse"` 권장) |
| `comparison` | 좌우 비교(As-Is/To-Be) | 2 | 화살표는 `arrows` 를 줄 때만 |
| `hub_spoke` | 중심-주변(플랫폼·생태계) | 1+3~6 | `nodes[0]` = 중심(기본 타원, `hubShape`), `direction`: `out`(기본)/`in`/`none` |
| `hierarchy` | 조직도·분류 트리 | 1+2~5 | `nodes[0]` = 최상위, 꺾인 연결선(화살촉 없음) |
| `layers` | 계층 구조(아키텍처 스택) | 2~6 | `title` = 계층명(왼쪽 라벨), `items` = 계층 안 구성요소 상자(가로 나열, 1~4개) |
| `matrix_2x2` | 2×2 매트릭스(우선순위·포지셔닝) | 4 | 순서 **좌상→우상→좌하→우하**. `xAxis`/`yAxis` 축 제목, `xLabels`/`yLabels` (기본 `낮음/높음`) |
| `timeline` | 일정·마일스톤 | 3~6 | `title` = 시점(`'26.6월`), `items` = 내용(선 아래), 점으로 표시 |
| `funnel` | 퍼널(단계별 축소) | 3~5 | 위에서 아래로 폭 축소 |
| `pyramid` | 피라미드(계층·비중) | 3~5 | 위에서 아래로 폭 확대 |


모든 템플릿의 실제 렌더 예시는 `assets/example_diagram_templates.json` (한 문서에 13종) — 새 도식은 그 섹션을 복사해 시작하는 것이 가장 안전하다.


### Fields


- `caption` (optional): same `< 제목 >` convention as Image/Table — renders above the diagram, not inside it.
- `nodes[].title` (required): **8자 이내(전각 기준, 영문·숫자는 0.5자)**. `nodes[].items` (optional): 각 항목 **14자 이내**, 노드당 1~3개. 넘으면 생성기가 글자를 줄이고 `[WARN]` 을 내며, 그래도 안 들어가면 `[WARN] … 글자가 도형 높이를 넘습니다` 를 낸다 — 그 경고가 뜨면 글자를 줄이는 쪽이 맞다.
- `defaultShape` (optional): `"rect"`(기본) / `"chevron"` / `"hexagon"` / `"ellipse"`(alias `"circle"`) / `"cylinder"`. `chevron_flow` 의 기본은 `chevron`, `hub_spoke` 의 중심은 `ellipse`.
- `nodes[].shape` (optional): overrides `defaultShape` for one node. Use mixed shapes only when the visual semantics are clear — `cylinder` for data storage, `ellipse` for an event or endpoint.
- `nodes[].color` (optional): `blue` / `green` / `purple` / `orange` / `teal` / `red` / `gray`. Omit to auto-assign in that order by node index.
- `arrows` (optional): `{ "from": <index>, "to": <index>, "label": "..." }`. `from`/`to` are node indices (or exact node `title` strings). If omitted, nodes auto-connect (`horizontal_flow`/`vertical_flow` sequential, `2x2_cycle`/`cycle` around the ring, `hub_spoke` hub→spokes); `chevron_flow` always suppresses connectors; `comparison`/`hierarchy`/`layers`/`matrix_2x2`/`timeline`/`funnel`/`pyramid` draw no arrows unless given. Connectors are always black 1.0pt; a legacy `color` on an arrow is accepted but ignored.
- Layout-specific: `boxWidth` (vertical_flow), `hubWidth` / `hubShape` / `direction` (hub_spoke), `labelWidth` (layers), `xAxis` / `yAxis` / `xLabels` / `yLabels` (matrix_2x2).
- Box sizes, gaps and font sizes are computed automatically from node count and text length — do not try to control positions. Connectors are drawn at fixed positions (not live-bound), so regenerate from JSON instead of dragging boxes in Word.
- Any explanatory note belongs in a **separate bullet right after the diagram** (with a normal 이동글틀 `annotation`) — never add a `footer`/note field to the diagram spec itself.
- 형상별 실제 가용 폭·높이 배수는 `references/generator-defaults.md` §Diagrams.


## Table


```jsonc
{
  "kind": "table",
  "columns": ["구분", "금액", "비중"],
  "rows": [
    ["A사업", "1,200억", "35%"],
    ["B사업", "800억",   "24%"]
  ],
  "fontSize": 12,
  "alignments": ["left", "right", "right"],
  "columnWidths": [3, 1, 1]
}
```


**테두리**: 표 전체 테두리는 검정 0.5pt, **헤더(첫 행) 아래줄만 1.5pt** 로 자동 렌더된다(별도 지정 불필요). 셀 여백(`tblCellMar`)은 0.


**강조 열 `highlightColumn` (optional, 260923)**: 비교표에서 **문서가 설명하는 서비스·제품의 열**을 파란(`0000FF`) 1.5pt 테두리로 감싼다 — 열의 좌·우 변 전체 + 머리글 위 + 마지막 행 아래(헤더 아래줄은 검정 1.5pt 유지). 값은 열 머리글 문자열(`"highlightColumn": "Meta Muse"`) 또는 0-based 정수. **생략하면 자동**: 첫 열을 제외한 머리글(3자 이상)이 문서 `title` 에 들어 있으면 그 열을 골라 `[INFO]` 를 낸다. `"highlightColumn": false` 로 끈다. `columns + rows` 단순 표 전용(`cells` 병합표는 무시 + `[WARN]`).


**행 높이**: 모든 표 행은 **최소 높이 0.8cm**로 자동 렌더된다. 생성기가 각 `w:tr`에 `w:trHeight w:hRule="atLeast" w:val="454"`를 삽입하므로 JSON에서 별도 지정할 필요가 없다. `atLeast` 방식이라 한 줄 행은 0.8cm 미만으로 줄어들지 않고, 긴 텍스트 행은 잘리지 않고 확장된다.


### `fontSize` (optional)


- **Default 12pt.** Accepts 9–14pt; values outside this range are clamped.
- Shrink (9–11pt) when the table has many columns or long text that would otherwise overflow.
- Grow (13–14pt) only for very short, visually prominent summary tables.


### `alignments` (optional)


Per-column array of `"left"` / `"right"` / `"center"`. Must have the same length as `columns`. When omitted, the generator auto-infers:


| Column content | Inferred alignment |
|---|---|
| Money / decimal / thousands-separator — 금액, 소수점, 자릿수 구분자 (e.g. `1,200억`, `258B$`, `45.0%`) | **right** (comma/decimal column alignment matters) |
| Short comparable numeric — 동일 기준 퍼센트·순위·소수량 (e.g. `81%`, `28%`, `8%`, `1`, `2`, `10`) | **center** |
| Fixed-length short strings — 모든 셀이 같은 길이, ≤8 chars (코드·등급·기호 등 `A`/`B`/`C`, `상`/`중`/`하`) | **center** |
| **첫 열** — `구분`·항목·제목 성격의 소개 라벨 (`추진(전망)`, `기록 1위`, `Google`, `상장신청(비공개)`), 전각 기준 ≤22자 | **center** (260909) |
| **시점·기간** — `'26.10∼11월`, `'19.12월`, `6/1일`, `2026년`, `Q3`, 또는 헤더가 `시점/일자/기간/일정/연도…` | **center** (260909) |
| **비교표의 짧은 값 열** — 헤더가 비교 대상(`Anthropic`, `OpenAI`, `국가`…)이고 모든 값이 ≤22자 | **center** (260909) |
| 서술·명칭 열 — 헤더가 `비고/내용/설명/특징/기업/회사/제품/서비스/담당…` 또는 긴 글 | **left** |


Header row is **always centered**, regardless of body alignment. 별첨 표에도 같은 규칙이 적용된다.


Rule of thumb: **"돈·소수점·천단위 구분자가 보이면 오른쪽, 라벨·시점·짧은 비교값은 가운데, 서술·명칭은 왼쪽."** Omit `alignments` and let the generator infer. If you set `alignments` anyway, `left` on the **first column or a period column is normalised to `center`** (with an `[INFO]`), because those must look the same whichever LLM wrote the JSON — set `"alignmentsStrict": true` on the table only when you truly need left there.


### `columnWidths` (optional)


Array of **relative weights** (same length as `columns`). `[3, 1, 1, 1]` gives the first column 3× the width of each of the other three; `[3000, 1000, 1000, 1000]` produces the same ratio — the numbers are rescaled to fit the page. Use this when the auto layout (see below) doesn't produce the proportions you want.


**Default (auto) behavior:** the generator no longer forces equal-width columns. It measures the natural content width of each column (max of header and body cells, in DXA, scaled by the table font size) and allocates width as follows:


- **Numeric or short-string columns** (≤6 chars) stay at their natural width — they don't need extra room and shouldn't wrap.
- **Long-text columns** absorb the remaining page width, proportional to their natural width. This is why a table like `[긴 설명 라벨, C-Suite, IC, Gap]` gives the label column ~65% of the row and the numeric columns ~10–12% each, instead of the old 25% × 4 where the label wrapped to two lines while numeric columns sat half-empty.
- Every column has a **minimum width floor** (~1.6 cm / 900 DXA) so even a 1-character numeric column isn't crushed.


Use `columnWidths` to override auto layout when you want a specific look — e.g., forcing equal width for a symmetric comparison table, or giving a mid-length column extra breathing room.


### `caption` (optional)


A short label rendered as a centered 14pt bold line **above** the table, wrapped in `< … >`. Use this for titled figure-style tables (e.g. `"장기간 대형 PJT 현황"` → `< 장기간 대형 PJT 현황 >`). The caption paragraph always has **12pt spacing-after**, including when a `unit` line follows. Omit for unlabeled tables — most inline tables need no caption.


**`□` 제목 바로 아래의 표에는 제목과 겹치는 캡션을 달지 않는다** (⑦, 260909). 섹션이 그 표 하나로 이뤄져 있거나 캡션이 □ 제목과 같은 뜻(`□ 주요 지표 대비` + `< 상장 추진 현황 비교 >`)이면 **캡션을 빼고 더 구체적인 문구를 □ 제목으로** 쓴다(`□ 상장 추진 현황 비교`). 생성기도 같은 판정(문자열 일치·포함·끝말 동의어 `비교≈대비`, `현황≈추이≈이력`)으로 캡션을 지우고, 캡션이 더 구체적이면 □ 제목을 캡션 문구로 바꾼 뒤 `[INFO]` 를 낸다. 캡션은 □ 제목과 다른 대상을 가리킬 때만 남긴다(`□ 주요 투자사·투자금액·투자시점` + `< Anthropic 주요 투자 유치 이력 >` 은 유지).


### `unit` (optional)


A unit label rendered as a right-aligned 10pt line between the caption (or directly above the table if no caption). The generator wraps it in parentheses automatically — pass `"건, 백만원"` and it renders `(건, 백만원)`. Use this **only when every numeric column shares the same unit(s)**; if columns have different units, omit `unit` and put the unit inside the header text instead (`금액(억원)`).


Both `caption` and `unit` are optional — a plain numeric table should not carry either.


### Complex merged tables — `cells` (optional)


For tables that need merged cells (stacked period headers, hierarchical row labels), use `cells` instead of `columns + rows`. `cells` mode also receives the same 0.8cm minimum row height. This is an escape hatch — **do not reach for `cells` for ordinary tables**. Most tables are flat grids; `columns + rows` is the right default and results in cleaner JSON.


```jsonc
{
  "kind": "table",
  "caption": "분기 실적",
  "unit": "건, 억원",
  "headerRowCount": 2,
  "cells": [
    [ {"text":"구분","rowspan":2,"colspan":2}, {"text":"'25.1Q","colspan":2}, {"text":"'25.2Q","colspan":2} ],
    [ null, null, "건수", "금액", "건수", "금액" ],
    [ {"text":"합계","colspan":2}, "24", "62", "109", "392", null, null ],
    [ "국내", "A사업", "7", "14", "28", "226" ],
    [ null,   "B사업", "2", "3",  "16", "10"  ]
  ],
  "columnWidths": [1, 1, 1, 1, 1, 1]
}
```


Cell item forms (each slot in a row):


- **string** — single 1×1 cell (text only). Equivalent to `{"text": "…"}`.
- **object** `{ "text", "rowspan", "colspan", "align", "bold" }` — explicit descriptor.
  - `rowspan` / `colspan` default to 1. Use them to merge down/right.
  - `align` (optional): `"left" | "center" | "right"` — overrides per-cell inference.
  - `bold` (optional): force bold on a body cell (headers are already bold).
- **`null`** — marker for a slot **already covered** by a prior merge (rowspan from above, or colspan from the left). You must include `null` for every covered slot so the row still has the right column count; `cells` is a full 2D grid, not a sparse list.


### `headerRowCount` (optional, cells-mode only)


Number of top rows that should render as header (bold + centered). Default `1`. For stacked headers (period group + sub-label like 건수/금액), set `2` or `3` so all header tiers get header styling.


### `columnWidths` in cells-mode


With `cells` the generator cannot auto-infer column widths the way it does for flat tables (merges blur the natural-width signal). If you want specific proportions, pass `columnWidths` as an array of relative weights matching the full logical column count (same length as the longest row after expanding merges). If omitted, columns are split equally.


### Per-cell alignment in cells-mode


Header rows (top `headerRowCount` rows): centered, bold. Body cells: alignment is inferred **per cell** — numeric cells right- or center-align, text cells left-align. Override any cell with `"align": "..."`.


### Page-break behavior


Every table is rendered with two protections so the whole table stays on one page when it fits:


- `w:cantSplit` on every row — prevents a single row from splitting mid-cell across pages.
- `w:keepNext` on every paragraph in every row **except the last row** — forces Word to keep each row attached to the next one, so the entire table moves to the next page together rather than breaking between rows.


Caption/unit paragraphs also carry `w:keepNext` so they stay attached to the start of the table. Tables taller than a single page will still have to split between rows — there is no way around that.


This applies automatically; you do not need to configure anything.


Side effect: because `keepNext` is set on cell paragraphs, Word's editing view draws a ■ indicator in the left gutter next to every non-last row. This is visual only — it does not print, export to PDF, or otherwise affect the document. It is the cost of guaranteeing the table does not split mid-way across a page boundary.


Layout: the table is auto-indented so the first column starts at the same x-position as the surrounding `  - ` bullet text (not flush-left). Do not add manual indent — the generator handles it.


## Appendix


```jsonc
{
  "title": "별첨 제목",
  "sections": [ /* Section */ ]
}
```


Rendered as `#별첨N. <title>` at the top-left of a new page, then sections follow directly. Appendices do **not** render a centered title, a date, or `- 이 상 -`.


**`title` 에 `별첨 N.` 라벨을 다시 쓰지 말 것.** 번호와 라벨은 생성기가 붙인다 — `"title": "별첨 1. 주요 투자자 현황"` 은 `#별첨1. 별첨 1. 주요 투자자 현황` 으로 겹쳐 나온다. 제목만 넣는다(`"title": "주요 투자자 현황"`). 생성기가 선행 `별첨 N` 라벨을 제거하고 `[WARN]` 을 남기지만, 번호 없는 `별첨 자료 목록` 같은 정상 제목은 그대로 둔다.


별첨이 CEO Profile 인 경우 `"profileImage": { "path": "..." }` 를 같은 객체에 두면 별첨 라벨 단락에 우상단 floating 사진이 붙는다.


## Notes for authors


- Keep lines within roughly 30 to 55 Korean characters.
- Put citations in `annotation`, not in `text`.
- Keep section notes / implications after the main bullets in that section.
- The closing `- 이 상 -` is automatic.




## v0.7 layout notes


- `sourceUrl` renders as a floating textbox directly below the title and is aligned to the title text left edge, not the page left edge.
- Section headings with body bullets are kept with the following block to prevent a lone `□` heading at the bottom of a page.
- Add first-occurrence annotations for uncommon services/vendors such as DownDetector.
