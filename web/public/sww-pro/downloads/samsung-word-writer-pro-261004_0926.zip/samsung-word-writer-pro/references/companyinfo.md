# 기업개요 (companyinfo) mode


Use this mode when the user asks for **기업개요 / 회사개요 / company overview / company profile** of a single company. Body uses the **fixed section order** below — do **not** apply general-mode archetype freedom, do **not** add TOC, do **not** use `Ⅰ./1.` tiers, do **not** invent sections like `검토 범위 / 분석 방법 / Samsung 제언`.


## Primary reference format (필독)


- **포맷 기준(ground truth)**: 아래에 글로 정리한 SoftBank Corp. 기업개요 예시의 핵심 포맷. 기업개요 요청이 들어오면 이 기준을 재현하도록 `scripts/generate.py`용 JSON을 구성한다. (예전 `assets/template_company info.docx` 는 260917 에 패키지에서 제외 — 사내 PC 에서 DRM 이 걸린 채 배포되어 Claude Desktop 스킬 설치를 막았기 때문. 생성기는 이 파일을 로드하지 않았으므로 동작 차이는 없다.)
- generate.py는 docx 를 베이스로 열지 않는다(JSON→코드 렌더링). 아래 fixed order와 충돌하면 **이 기준 포맷을 우선**한다.
- 기준 예시(SoftBank Corp. 개요)가 정의하는 핵심 포맷:
  1. **□ 헤더 라벨 정렬** — `□ 설    립`, `□ 경 영 진`, `□ 인    력`, `□ 시가총액`, `□ 주    주`, `□ 주요사업`, `□ 경영현황`. (라벨은 회사에 맞게: `경 영 진`↔`대표`, `경영현황`↔`경영실적` 등 자연스러운 변형 허용.)
  2. **이동글틀(파란 9pt 주석) 적극 사용** — 본문 수치·고유명사를 보조. 예: 경영진 영문 원문명(`* Ken Miyauchi`), 단위·환산(`* 한화 약 132조 (1엔 = 9.45원, 매매기준율)`), 사업별 비중 %(`* 50.7%`, `* 12.6%`), 각주(`* Non-consolidated 19,045명`, `※ 환율 적용`). anchor 라인 직하에 배치.
  3. **주요사업** — `dash`로 사업라인, 각 라인에 비중/순위 등 이동글틀. 특이사항은 `※`/브래킷 note.
  4. **경영현황(경영실적)** — 인트로 주석(`* 매출 …/영업이익 …`) + 단위 표기(`(십억엔)`) + 3개년 재무표. 표는 `구분 | '21년 | '22년 | '23년 | 전년比`, 매출·영업이익·(영업이익률 %) 행, 증감은 **전년比(YoY)**(`+172.0`, `-184.1`, `-3.5p`)로 — CAGR 대신 사용 가능. 표는 우측 정렬 floating, 셀 여백 0, 헤더 굵게.
- **한자 지양** — 기준 문서에 남아있는 `等·向·用`류 한자는 산출 시 한글로 대체(`등`, `대상/향`, `용`)한다.


## What companyinfo mode owns


1. **Research and compose** — actively fill obvious fact gaps (대표 이력, 인력, 주요사업, 시가총액, 주주현황, 재무). Do not just reformat thin input.
2. **Body outline is fixed** — see "Fixed company overview section order" below.
3. **All body sections render at the `□` level only.** In JSON, omit the visible `□` prefix from `heading`; the generator adds it. Bullet `kind` is limited to `dash` / `dot` / `note` / `table`.
4. **Do not set** `toc`, `cover`, `numeral`, or `number` in companyinfo JSON.
5. **Generator**: use `scripts/generate.py` (same as general mode).
6. **Appendices** — optional; promote 자회사·사업부문 상세 등 분리 자료를 `#별첨1. <제목>` 등으로. 단순 기업개요는 본문 한 페이지로 끝나는 것이 기본.
7. **밑줄 강조**는 절제 — 진정한 강조 포인트(예: M&A 후 핵심 변화 라인)에만.


## Fixed company overview section order


Preserve this order; drop any section the input genuinely does not support, but never reorder or rename to a fundamentally different shape.


### 0. Title


- Format: `{기업명} 개요`, 예: `Accenture 개요`. 고유명사 강조 시 Samsung 컨벤션 「 」 사용 가능 — 예: `「KKR」 기업 개요`.
- Render centered, 20pt, bold, underlined (engine default). Title은 **출처 주석 금지**.
- **제목 1줄 고정** — 제목은 한 줄에 들어가도록 축약한다. 상세 기준·예시: `references/tone.md` §6-12.


### 1. 설립연도 및 본사 소재지


- Heading example: `설립 : '87년(본사 : 서울시 강서구 마곡동)` 또는 longer: `설립 연도 및 본사소재지 : '76년 (본사 : 미국 뉴욕주 뉴욕시)`. 연도는 `'YY년` 축약 표기(`references/tone.md` §6-11).


### 1-1. One-line company introduction


- 설립 라인 바로 아래에 정확히 1개의 `dash` bullet — 한 줄 회사 소개. 예: `Accenture는 글로벌 고객 대상으로 컨설팅, SI, SM를 제공하는 기업`.


### 2. 대표자 성명 및 주요 이력


- Heading example: `대표 : 홍길동 (대표이사 사장)`.
- 학력·경력 milestones는 `dash` 위주, 세부 history는 필요 시 `dot`.
- 예: `1996 ~ 2000, 서울대학교 전자공학과 졸업`.


### 3. 인력현황


- Heading example: `인력 : 6,990명 ('25년 3월 기준)`. 기준일·기준연도 포함(연도는 `'YY년` 축약 표기).


### 4. 주요사업


- Heading: `주요사업`. `dash`로 사업라인, `dot`로 sub-items.
- 최근 주요 변화 (M&A·파트너십·신사업·구조조정) 는 `kind: "note"` 라인으로 `※` 렌더.


### 5. 시가총액


- 국내 상장: `시가총액 : KRW 5조 478억 (5.26일 KOSPI 종가 52,100원)`.
- 해외 상장: `시가총액 : USD 5조 478억 (5.26일 NASDAQ 종가 52.10달러)`.
- 비상장사: `※ 비상장사로 시가총액 미공개` 한 줄 note.


### 6. 주주현황


- Heading example: `주주현황 : IBM 44.96%, HPE 21.5%, 소액주주 12.59% 등`. `등`은 비망라 시에만.


### 7. 경영실적


- Heading: `경영 실적` / `경영실적`.
- 먼저 매출/이익 추이·성장 동인·일회성 약점에 대한 요약 bullet 2~3개.
- 이후 최근 3개년 표 (`매출`, `영업이익`, `영업이익률`, 일반적으로 `구분 | '22년 | '23년 | '24년 | CAGR`).
- 증감 컬럼은 **CAGR** 또는 **전년比(YoY)** 중 자료에 맞는 방식 — 기준 예시(SoftBank Corp.)처럼 전년比(`+172.0`, `-184.1`, `-3.5p`)를 쓸 수 있다. CAGR은 `((latest/earliest) ** (1/2) - 1)` (3개년 기준). 의미 없으면 `-`.
- 표 위 `unit` 필드로 단위 명시 (`단위 : 억원`, `단위 : 억 USD` 등). 재무 3개년 표는 `alignments`를 모두 `center` 권장.


### 8. Closing marker


- 본문 마지막에 `- 이 상 -` 자동 삽입 (엔진 처리).


## Companyinfo annotation guard


- Easy/common terms (R&D, NASDAQ, NYSE, KOSPI, CEO, CFO, AI, cloud, SI, SM, ERP, CRM, API, SaaS, 데이터센터, 보안, 매출, 영업이익 등)에는 주석 금지.
- 같은 문서에서 같은 용어는 한 번만 주석.
- 사용 가치가 있는 대상: 최신/니치 IT 용어 (agentic AI, RAG, MoE, sovereign cloud, vector database 등), 금융/M&A 용어 (AUM, FRE, LBO, mezzanine, dry powder, GP/LP, EV/EBITDA 등), 사명·약어 중 첫 등장 시 의미가 자명하지 않은 것.


## Companyinfo JSON skeleton (default)


```json
{
  "title": "KKR(Kohlberg Kravis Roberts) 기업 개요",
  "date": "'26. 5. 11 (월)",
  "sections": [
    {
      "heading": "설립 연도 및 본사소재지 : '76년 (본사 : 미국 뉴욕주 뉴욕시)",
      "bullets": [
        {
          "kind": "dash",
          "text": "KKR은 전 세계 기관투자자·연금·보험사 대상 사모펀드, 크레딧, 인프라, 부동산, 보험 솔루션을 제공하는 대체자산운용 기업",
          "annotation": { "anchor": "대체자산운용", "text": "대체자산운용 : 주식·채권 외 사모펀드·인프라·부동산 등을 운용하는 사업" }
        }
      ]
    },
    {
      "heading": "대표 : Joseph Bae (Co-CEO)",
      "bullets": [
        { "kind": "dash", "text": "Harvard 졸업, Goldman Sachs Principal Investments 근무 후 KKR 입사" },
        { "kind": "dot", "text": "1996 ~ 2017, KKR 아시아 사업 총괄 및 아시아 PE 플랫폼 구축 주도" },
        { "kind": "dot", "text": "2021 ~ 현재, KKR Co-CEO" }
      ]
    },
    { "heading": "인력 : 5,043명 ('25년 연말 기준)", "bullets": [] },
    {
      "heading": "주요사업",
      "bullets": [
        { "kind": "dash", "text": "Asset Management : PE, 인프라, 부동산, 크레딧, 자본시장 운용",
          "annotation": { "anchor": "PE", "text": "PE : 비상장기업 지분투자 중심의 사모펀드" } },
        { "kind": "dot", "text": "PE : 대형 LBO, 성장형 투자",
          "annotation": { "anchor": "LBO", "text": "LBO : 차입금을 활용해 기업을 인수하는 방식" } },
        { "kind": "dash", "text": "Insurance : Global Atlantic 기반 은퇴·연금, 생명보험, 재보험 상품" },
        { "kind": "note", "text": "Global Atlantic 인수 이후 보험·대체투자 결합 모델 확장" }
      ]
    },
    { "heading": "시가총액 : USD 약 1,048억 (NYSE : KKR, '26.4 기준)", "bullets": [] },
    { "heading": "주주현황 : Vanguard Group 6.6%, BlackRock 5.5% 등", "bullets": [] },
    {
      "heading": "경영 실적",
      "bullets": [
        { "kind": "dash", "text": "총매출은 Asset Management와 Insurance 동시 확대에 따라 최근 3개년 고성장" },
        { "kind": "dash", "text": "Fee Related Earnings는 운용보수 기반 수익성 확대를 견인",
          "annotation": { "anchor": "Fee Related Earnings", "text": "FRE : 운용보수 등 반복성 수익에서 비용을 차감한 이익" } },
        {
          "kind": "table",
          "unit": "단위 : 억 USD, 12월 결산",
          "columns": ["구분", "'22년", "'23년", "'24년", "CAGR"],
          "rows": [
            ["매출", "94.0", "145.0", "218.8", "52.6%"],
            ["영업이익", "23.8", "30.7", "32.7", "17.2%"],
            ["영업이익률", "25.3%", "21.2%", "14.9%", "-"]
          ],
          "alignments": ["center", "center", "center", "center", "center"]
        }
      ]
    }
  ],
  "appendices": []
}
```


A working example lives at `assets/example_companyinfo.json`.
