---
name: samsung-word-writer-pro
description: Convert raw materials into a Word (.docx) document written in Samsung report style, or build a ready-to-paste prompt for that workflow. Supports 10 document types — 01_언론 기사·기술/제품개요 = 데일리 기사/뉴스 분석, 02_시장동향·산업분석 = 업계 동향, 시장분석 (예. AI Agent 동향 보고), 03_주간 보고 = 주간단위 정기 보고 (예. CEO 주간동향 보고; 하위 옵션 CEO 현안보고 = 팀장→CEO 주간 업무현안, 전용 양식), 04_현안 보고 = 사내 개별 안건 이슈보고서 (예. 사업 현안 보고, 장애보고, 거래현황 보고), 05_개별 사업 전략 = 개별 사업전략 수립 (예. MSP 사업 전략, 보안사업 추진방안), 06_기존 문서 수정 = 업데이트(표준문서 제목·상위 목차 유지, 하위 내용만 재구성)·오탈자 수정·문서비교(Word 2개 비교, 변경부분 노란 하이라이트) (문서 첨부 필수), 07_기업개요 = 회사개요/company overview (예. OpenAI 회사개요), 08_CEO Profile = CEO/인물 프로필 (예. Sam Altman 프로파일), 09_전사 레벨 전략 보고 = 간담회 등 전사 사업전략 방향 도출, 10_지참자료·색인 = 각종 정보를 모아 참고자료로 정리 (예. 회의 참고자료). 07·08·10은 01~06, 09와 중복 선택 가능. Use for Samsung-style 보고서/브리프/제언/주간보고/현안보고/시장분석/기술개요/사업전략, 기업개요/company overview, CEO/대표 프로필, formal Korean Word documents, and requests for a 프롬프트 빌더/Prompt Builder screen or prompt. Includes report-logic routing for 01~05 and a Prompt Builder asset.
---


# samsung-word-writer-pro (Python edition)


Turns rough input into a report in **Samsung in-house Word style**, with optional appendices and an optional formal **목차 (TOC) cover page**.


## Three modes (mode-routing)


This skill ships **three writing modes** that share the same Samsung visual engine and **the same rendering script (`scripts/generate.py`)**, differing only in **body outline**. Decide the mode from the user request before composing.


| Mode | Trigger keywords | Body outline | Script |
|---|---|---|---|
| **general** (default) | 보고서 / 브리프 / 제언 / 주간보고 / 현안보고 / 시장분석 / 이벤트요약 / 기술개요 등 — *or* any Samsung-style document not matching the two specialized modes | Free archetype ideation (see `references/report-archetypes.md`). Supports `Ⅰ./1.` higher tiers, optional 목차 TOC cover, appendices. | `scripts/generate.py` |
| **companyinfo** | 기업개요 / 회사개요 / company overview / company profile / 단일 기업 정리 (대표/인력/주요사업/시가총액/주주현황/경영실적) | **Fixed company overview section order** — see §"기업개요 (companyinfo) mode" below. No TOC, no `Ⅰ./1.`, `□` headings only. 시각·구조 기준은 `references/companyinfo.md` §Primary reference format. | `scripts/generate.py` |
| **ceoinfo** | CEO / 대표 / 창업자 / founder / 임원 / chairperson / executive **profile / biography / 인물 프로필 / 인물 개요** (이미지 첨부 또는 URL 포함 시 강한 신호) | **Fixed CEO profile structure** — 이름 / 국적·출생 / 학력 / 주요 이력 / (참고사항), `□` 헤딩만. 단독 문서는 인물 사진 필수. See §"CEO Profile (ceoinfo) mode" below. | `scripts/generate.py` (companyinfo·general 과 **동일 엔진**. 사진은 `profileImage`) |
| **ceo_weekly** (03 하위 옵션) | Prompt Builder `03_주간 보고` 옆 **`CEO 현안보고`** 체크(JSON `ceo_weekly_report.enabled: true`) / "CEO 현안보고", "팀 주간 현안보고", "대표님께 드리는 주간 업무현안" | **팀장 → CEO 주간 업무현안 고정 양식** — 인사말 → `{조직} 현안 보고` 제목 → 보고자 → `[연간 주요 업무]` 박스 → `□` 현안 2~4개(`-` 존칭 서술형 항목) → `- 이 상 -`. 11pt 바탕체, 이동글틀·장평 축소·우상단 날짜 없음. See §"CEO 현안보고 (ceo_weekly) mode" below. | **`scripts/generate_ceo_weekly.py`** (전용 생성기 — 일반 엔진을 쓰지 않는다) |


Conflict-resolution: when a mode-specific rule (companyinfo / ceoinfo) conflicts with general Samsung guidance (free ideation, optional TOC, Roman tiers), the mode-specific rule wins. The Samsung visual engine — spacing, fonts, **이동글틀(주석) 렌더링**, table styling — applies to all three modes, and since 260821 all three run through the **single** generator `scripts/generate.py` (CEO 전용 엔진 폐지).


**예외 — `ceo_weekly`(CEO 현안보고)는 Samsung 시각 엔진을 쓰지 않는다.** 기준 문서(박광현 팀장 「[8월 4주차 현안보고] 경영지원담당 AX팀PI팀.docx」)를 계측해 만든 전용 생성기 `scripts/generate_ceo_weekly.py` 가 11pt 서술형 양식을 1:1 로 재현하며, 아래 Cross-mode invariants(이동글틀 5원칙·14pt·장평 95%·표 12pt)와 `tone.md` §1 명사형 어미는 이 모드에 적용하지 않는다. 규칙 전문과 기존 규칙 대비표는 `references/ceo-weekly-report.md`.


### Cross-mode invariants (모든 모드 공통)


- **Uncommon terms/vendor annotation** — add a first-occurrence floating textbox annotation for uncommon services/vendors such as DownDetector, niche products, small vendors, or unfamiliar monitoring platforms. Do this once per term, with definition-only text. Example: DownDetector -> real-time outage monitoring service that aggregates user reports.
- **이동글틀(주석) 작성 기준 (필수 5원칙)** — 이동글틀은 다음을 기준으로 만든다: ① **출처** (`* 출처 : {매체/URL}`), ② **발생시점/일자** (`* 7/16일 발표`, `* '26.5월 기준`), ③ **어려운 용어·약어 정의** — 약어가 앵커이면 `* {풀네임} ({정의})` 형식으로 푼다 (예: anchor `GDC` → `* Google Distributed Cloud (구글 On-Prem이나 Edge 환경에서 제공하는 하이브리드·멀티클라우드 솔루션)`). ④ 이동글틀은 **문서 계층(`□`/`-`/`·`)과 무관**하게 설명이 필요한 단어 아래 어디든 붙인다. ⑤ **한 페이지에 최소 3개 이상** 배치를 목표로 하되, 숫자 맞추기용 억지 주석은 금지(동일 출처 반복 금지 원칙 유지). 상세 기준·예시는 `references/tone.md` §7 "이동글틀 작성 기준".
- **이동글틀 배치 규칙 (260923 손수정본 반영, 생성기 자동)** — ① ┘ 모드 상자는 **앵커가 놓인 본문 줄의 글자 시작점(`- ` 뒤)보다 왼쪽으로 나가지 않는다**. 안 맞으면 ┘ 를 오른쪽으로 옮겨(상자를 글자 시작선에 붙여) 배치하고, 그래도 안 되면 장평을 95→85% 까지만 줄인다(가독성 하한). ② `* ` 모드가 우측 여백에 조금 못 들어오면 ┘ 로 바꾸기 전에 같은 장평 단계로 먼저 맞춘다 — 모델명·서비스명 소개는 이름 바로 아래 `*` 가 읽기 쉽다. ③ 앵커가 줄바꿈으로 갈라지면 **앵커가 시작되는 줄**에 붙는다(2줄 문장에서 이동글틀이 아래로 밀리며 ┘ 가 허공을 가리키던 사고 방지). 작성자 규칙: **출처·출시 정보 이동글틀은 그 줄 맨 오른쪽의 날짜·괄호 토큰(예: `(9/8)`)에 앵커**하고, 모델명·서비스명 설명은 이름 자체를 앵커로 삼는다. 상세: `references/tone.md` §7 "Picking the anchor", `references/generator-defaults.md`.
- **표(table) 폰트 디폴트 = 12pt** — 모든 모드에서 표 안의 텍스트는 기본 12pt로 렌더. 칼럼이 많거나 텍스트가 길어 줄바꿈이 잦을 때만 `fontSize`를 9–14pt 범위에서 명시적으로 조정. 사유 없이 14pt 등으로 키우지 말 것. (`scripts/generate.py`의 `b.get('fontSize', 12)` 기본값.) CEO 모드는 표 미사용.
- **표 행 최소 높이 = 0.8cm** — `scripts/generate.py`가 모든 표 행에 `w:trHeight w:hRule="atLeast" w:val="454"`를 자동 삽입한다. `exact`가 아니라 `atLeast`이므로 한 줄 행은 0.8cm 미만으로 줄어들지 않고, 긴 텍스트 행은 잘리지 않고 확장된다.
- 본문 14pt, 제목 20pt, 주석 9pt 파랑(3333FF), 표 셀 여백 0 DXA는 Samsung 엔진 고정값.
- **제목 1줄 고정 + 연도 축약(`'YY년`)** — 제목은 20pt 기준 한 줄에 들어가도록 축약(넘치면 생성기가 `[WARN]`로 경고)하고, 연도는 항상 `2026년`이 아닌 `'26년`처럼 쓴다(생성기가 렌더 시 자동 치환하는 안전망 있음). 상세·예시: `references/tone.md` §6-11, §6-12.


The Samsung style is characterized by three rules:


1. **위치별 줄간격(spacing-after) 분기** — 단일 12pt가 아니라 계층 전이에 따라 9pt / 12pt / 16pt / 18pt / 20pt로 나뉨.
2. **강조 표기에 밑줄(underline) 추가** — 기존 `bold` 외에, 부분 강조용 표준으로 `underline` 도입.
3. **표 셀 여백 0** — `tblCellMar` top/bottom/left/right 모두 0 DXA.
4. **표 행 최소 높이 0.8cm** — 모든 데이터 표·병합표·목차 박스 표의 행 높이를 최소 454 twips로 고정(`atLeast`).


또한, 제목의 고유명사는 **「 」(낫표)** 안에 적을 수 있으나(예: `보고서「프로젝트명」`), **제목 1줄 고정이 항상 우선**한다 — 낫표를 넣어 폭이 초과되면 낫표를 빼고 축약한다. 상세: `references/tone.md` §6-12.


## What this skill owns end-to-end


1. **Research and compose**
   Read the source material, fill obvious fact gaps, infer the right section structure, and write the report itself. Do not just reformat thin input.
2. **Rewrite in Samsung tone**
   Use compressed noun-ending phrasing, one fact per line, and **blue 9pt annotations (`* ` prefix — 별표 + 한 칸)** for citations or side-notes attached to the line they explain. 주석이 길어 우측 여백을 넘거나 **앵커가 놓인 본문 줄 끝보다 120pt 이상 튀어나오면** `* ` 대신 끝에 ` ┘` 를 붙여 자동 처리(스크립트 담당). 위치(본문 줄 아래 16.2pt, 앵커 첫 글자 +1.2pt)와 출처 URL 전체 표시(왼쪽 이동 → 장평 축소 → 2줄)는 생성기가 보장하므로 작성자는 앵커만 정확히 고른다.
3. **Prompt Builder mode (+ 대화형 인빌더 게이트)**
   If the user asks for `Prompt Builder`, `프롬프트 빌더`, `문서작성 프롬프트 생성`, or asks to open/export the builder screen — or the request is a "맨몸 호출" (완성 프롬프트·첨부·명확한 작성 태스크가 없을 때) — **read `references/prompt-builder.md` first**; it has the link/fallback and the full 대화형 게이트 절차.
4. **Evaluate and revise existing documents (기존 문서 수정/보완)**
   When the user uploads an existing report and asks to 수정/보완/평가, **read `references/evaluate-revise.md` first** (procedure) and `references/report-evaluator.md` (scoring criteria). See §"기존 문서 수정/보완 (Evaluate & Revise) 모드" below.
5. **Rewrite examples and depth control**
   When drafting or rewriting a report, read `references/rewrite-examples.md` and `references/report-depth.md` after `references/tone.md` when the task involves improving sentence quality, deepening a shallow draft, or producing a polished Samsung-style report. Use `rewrite-examples.md` to choose reusable sentence patterns by report type, and use `report-depth.md` to raise sentences from fact listing to structured facts, implication, and SDS action/strategy.
6. **Report logic routing**
   For **general** mode document-writing requests, read `references/report-logic.md` before drafting. If the requested document matches **01_언론 기사·기술/제품개요**, **02_시장동향·산업분석**, **03_주간 보고**, **04_현안 보고**, or **05_개별 사업 전략**, apply the corresponding section logic from `report-logic.md`. For these five analyzed types, `report-logic.md` takes precedence over the broader archetype palette in `references/report-archetypes.md`. Use `report-archetypes.md` only as a supplementary ideation source or for types not yet covered by `report-logic.md`.
7. **Structure**
   Use the canonical layout: centered **bold + underlined** title, right-aligned date, **bold** `□` section headings, `-` bullets, `·` detail lines, `※` notes, `→` implications, and right-aligned `- 이 상 -`.
   - Full heading hierarchy (top → bottom): **Ⅰ. (Optional, 매우 큰 범위 보고서) → 1. (Optional) → □ → - (dash) → · (dot)**. Promote a section with `"numeral": "Ⅰ"` (16pt bold) or `"number": 1` (14pt bold); the generator drops the `□` prefix automatically for those levels.
   - **번호 챕터(`1./2./…`) 그룹핑 기준**: `□` 섹션이 **8개 이상**이면 목차가 복잡해지므로, 의미 단위로 묶어 상위 번호 챕터(`"number": 1`, `2`, …)를 추가해 정리한다. `□` 섹션이 7개 이하면 번호 챕터 없이 `□`만으로 두는 것이 기본. **TOC(목차 페이지) 없이도 번호 챕터를 쓸 수 있다** (실무 문서 관행). 이때 `Ⅰ.` Roman tier는 TOC 있는 대형 보고서로 남겨두고, 그룹핑에는 `1./2.` 아라비아 번호를 쓴다.
   - `①②③` are an **optional accent at the dash/dot level**, not a separate hierarchy tier — use only when the content is genuinely an ordered list.
   - Key implication lines (`→`) and action items may use `"bold": true` for emphasis.
   - **밑줄 강조**: 강조하려는 bullet에 `"underline": true` (전체 본문 텍스트가 밑줄). 콜론 위치와 무관 — 강조하고 싶은 어구에서 자유롭게 사용. `bold`와 함께 쓸 수 있음.
   - **부분 강조 (260923)**: 본문 `text` 안에서 `__어구__` = 부분 밑줄, `**어구**` = 부분 Bold. `□` 하위 내용 중 정의의 핵심 어구(예: `정의 : 목표를 실행 계획으로 바꿔 __앱 종료 후에도 일하는 상시 Agent__`)나 실행 항목의 핵심(`(상품 반영) **전용 VM·승인 Agent·자격증명 금고를 FabriX·Brity에 반영**`)에 쓰고, 구조·결론 줄 전체는 `"bold": true` 로 강조한다. **섹션당 1~2곳**, 과용 금지. 마커는 폭 계산·줄바꿈·앵커 탐색 전에 제거되므로 anchor 에는 마커를 넣지 않는다.
   - **`·` 레벨 예시 라벨은 `예)`** — `·예시 : 이메일 발송…` 이 아니라 `·예) 이메일 발송…`. 생성기가 `예시 :`/`예 :` 선행 라벨을 `예) ` 로 자동 치환한다.
   - **제목 「 」 컨벤션 (선택, 1줄 고정이 우선)**: 보고서 제목에서 고유명사(프로젝트·계약·법안 명 등)는 「 」(낫표) 안에 넣을 수 있음 — 예: `보고서「프로젝트명」`. 단, 낫표는 폭만 늘리고 정보를 더하지 않으므로 **제목이 한 줄을 넘길 것 같으면 낫표부터 뺀다.** 일반 명사구는 애초에 낫표 없이 그대로 쓴다.
   - 섹션 사이 간격(□-□ 사이 20pt)은 새 `□` 헤딩의 **`before=20pt`** 로 자동 처리하므로 작성자가 별도로 지정할 필요 없다.
8. **Format**
   Drive `scripts/generate.py` with content JSON. Never open Word directly.
9. **Attach appendices**
   If the user gives clearly separate supporting material, promote it to `#별첨1. <제목>`, `#별첨2. <제목>`, etc. — the label appears top-left on its own page and the appendix body continues directly (no centered title, no date, no `- 이 상 -`).
10. **(Optional) 목차 cover page**
   Only when the user **explicitly asks** for a 목차 / TOC / table of contents / 목차 장표, prepend a formal cover page in front of the body: boxed report title at top, centered `- 목    차 -` heading, a bordered box listing the main sections (and optional `[별첨]` sub-entries), then 발행일과 작성자/부서. If the user does not ask for one, do **not** add a TOC page — keep the current default layout.
   - **When `toc` is present, the body automatically skips the centered title block and the right-aligned date** — the TOC page already carries them, so the body starts directly with the first section. (This is the generator default; you don't need to set anything.)
   - **Roman-numeral chapter headings (Ⅰ, Ⅱ, Ⅲ …) are reserved for formal reports that include a TOC**. In the body JSON, set `"numeral": "Ⅰ"` on a section to render it as `Ⅰ. 제목` at 16pt bold. The generator will **omit the `□` prefix** for numeral-marked sections, because the Roman numeral is a higher-level marker than `□` — **never combine both**. For ordinary reports (no TOC), keep the plain `□ 제목` style; do not introduce Roman numerals.
11. **페이지 맞춤 (page-fit)** — 본문이 페이지 경계에 어정쩡하게 걸치지 않도록 아래 knob으로 한 페이지 단위로 정리한다. 본 엔진은 Word의 자동 흐름에 의존하므로 페이지 분량은 작성자(Claude)가 판단·지정해야 하지만, **판정은 육안이 아니라 `scripts/verify_docx.py`의 텍스트 요약으로 한다** — 변환 → 페이지 수 → □ 헤딩 고립 / 1~2줄 넘침 / 하단 공백 1/4 → 이동글틀 겹침을 **1회 실행**으로 판정하고 이슈마다 아래 knob 힌트(`sections[i]에 "pageBreakBefore": true` 등)를 붙여 준다. 절차·종료 조건은 §Step 5, 생성기 기준값은 `references/generator-defaults.md`.
   - The generator also applies keepNext to section headings that have body bullets, so a single `□` heading is not left alone at the bottom of a page when its content starts on the next page.
   - **`pageBreakBefore`** (section 단위, `"pageBreakBefore": true`) — **□ 헤딩이 페이지 하단에 1~2줄만 홀로 남을 때** 지정한다. 생성기가 **□ 헤딩 바로 앞 단락 끝**에 `w:br type="page"` run을 삽입해 □ 가 **다음 페이지 첫째 줄**에 나오도록 한다.
     - ⚠️ **중요 제약**: `pageBreakBefore`를 지정했을 때 앞 페이지가 **전체 높이의 1/4 이상 공백**이 생기면 지정을 취소한다 (과도한 여백). 1/4 이하로 비는 경우에만 사용.
     - 판단 기준: □ 헤딩이 앞 페이지에 **1~2줄만** 남을 것으로 예상될 때 → `pageBreakBefore: true`. 앞 페이지 빈 줄이 4~5줄 이상 → `pageBreakBefore` 대신 `compact`로 1~2줄을 끌어올린다.
     - (첫 섹션에는 적용 안 됨.)
   - **`compact` / `line`** (section 또는 document 단위) — 한 `□` 섹션(또는 그 섹션이 놓인 페이지)이 **1~2줄만 다음 페이지로 넘칠 때**, 해당 섹션에 `"compact": true` (→ 줄간격 223 ≈ 93%) 또는 `"line": <값>` 을 지정해 줄간격을 줄여 한 페이지에 끌어올린다. document 최상위에 두면 전체 기본 줄간격이 된다.
   - **1단어/1~2단어 widow 자동 보정** — 생성기가 자동으로 처리한다 (수동 지정 불필요). 알고리즘 상세: `references/generator-defaults.md`.
   - 판단 기준 요약: **□ 1~2줄만 남음 → `pageBreakBefore`(단, 앞 페이지 1/4 이상 공백 시 취소). 1~2줄만 넘침 → `compact`. 1단어 widow → 자동 처리.** 모두 `verify_docx.py` 요약의 힌트를 따라 조정한다 (PNG를 페이지마다 열어 판단하지 않는다).


## Non-negotiable rules


- **주석(이동글틀) 작성 규칙 전체** — 3가지 용도(맥락 보강/용어 풀이/출처 인용), 필수 5원칙, 허용 prefix, 출처 표기(`* 출처 : `), 날짜 허용 기준, 동일 출처 반복 금지, 파일명 인용 금지, URL 허용, `┘` 자동 배치 등은 `references/tone.md` §7과 `references/content-schema.md`(Annotation forms)에 전부 있다 — **주석을 붙일 때마다 반드시 확인한다.**
- **`sourceUrl`** (top-level, optional): 제목이 근거한 1차 소스 URL. 제목 바로 아래 파랑 9pt `* 출처 : {url}` 로 자동 렌더되며, 제목 줄 자체에는 출처 주석을 달지 않는다. 상세: `references/content-schema.md`.
- Titles render bold + underlined; section headings (`□ …`) render bold. Body bullets and details stay regular weight.
- **문서 전체 스타일 초기화 + □ Bold 고정**: Word 문단 스타일(제목1·제목2 등 Heading Style)을 적용하지 않고 **Normal 기반 직접 서식(direct formatting)만** 사용한다. `□` 레벨 헤딩 텍스트는 **반드시 Bold**로 렌더. 기존 문서 수정/보완·재생성 시 원본에 남은 Heading Style·잔여 서식은 제거하고 엔진 표준 서식으로 통일한다.
- Appendices have **no** centered title block, **no** date, and **no** `- 이 상 -` closing. Only the main body has those.
- **출처 전용 별첨 금지**: 인용 매체·기사 출처를 모아 별첨 `주요 근거` / `출처 목록` 섹션으로 만들지 않는다. 출처·발표시점은 **본문 해당 사실 옆 이동글틀**로 부착하고, 별첨은 용어 정리·상세 표 등 본문 보조자료로만 사용한다.
- **한자·영어 표기·기호 규칙** — 한자 미사용(전면 한글), 단독 영어 단어 첫 글자 대문자, 에이전트→Agent, 영어권 인물명 원어 표기, `∼`(범위), `→` 2칸 들여쓰기 등은 `references/tone.md` §5, §6, §6-9, §6-10에 전부 있다 — **작성 전 확인한다.**
- **표 렌더링 규칙** — 테두리, 행 최소 높이 0.8cm, 정렬, 컬럼 폭 등 자동 렌더링 규칙은 `references/content-schema.md`(Table)와 `references/generator-defaults.md`(Tables)에 있다.
- **`「 」`(낫표)는 선택 사항** — 강조가 필요한 고유명사·작품·인용엔 써도 되나 짧은 코드명/영문 고유명사엔 생략 가능 (예: `Jalapeño`).
- **No meta / self-referential content.** 첫 섹션은 항상 주제 본문으로 바로 진입한다 — `검토 범위` / `작성 기준` / `분석 방법` 같은 섹션이나 "본 보고서는 …" 같은 메타 서술 금지. 상세 규칙과 예시: `references/tone.md` §9-1.
- **No source-disclaimer tail line at the bottom of a profile / appendix.** 보고서/별첨/CEO Profile 마지막에 `※ ~ 정보는 공개 프로필 및 주요 외신 기사 기준으로 정리` 같은 작성 출처·기준 안내 문구를 절대 추가하지 말 것. 이는 작성자(=Claude) 내부 메모일 뿐 독자에게는 불필요한 잡음. 출처가 정말 필요하면 해당 사실 옆 9pt 주석으로 anchor.
- **Heading hierarchy order is fixed**: `Ⅰ. → 1. → □ → - → ·` (see "Structure" above, and `references/tone.md` §8). Never reverse the order or combine `Ⅰ.`/`1.` with `□` on the same heading.


## When to use


Use this skill when the user:


- asks for a report / 보고서 / 브리프 / 제언 / Word 문서 / docx
- asks for Samsung style or a Korean business brief
- gives raw material and expects a polished Korean corporate document
- asks to rewrite existing content into Samsung in-house report tone
- asks to see the **user manual / 사용 설명서 / 사용 가이드 / 매뉴얼** for this skill, or asks how to use it and wants the guide shown → see §"사용 설명서 (User Manual) 요청 처리"


## Procedure


### Step -1. Prompt Builder requests + 대화형 인빌더 게이트


Before drafting anything, check: is this a **Prompt Builder** request (`프롬프트 빌더`, `HTML`, "열어줘" 등), or a **"맨몸 호출"** (스킬만 호출되고 완성 프롬프트·첨부·명확한 작성 태스크가 없는 경우)? If so, **read `references/prompt-builder.md` first and follow it exactly** — it has the hosted-link/HTML-fallback guidance and the full "완성 프롬프트 가드 → 예/아니오 게이트" procedure. Do not start drafting a Word report until the gate resolves (or its guard confirms this isn't a bare call).


### Step 0. Plan the structure (logic routing + ideation)


Before writing in **general** mode, read `references/report-logic.md` first and classify the request against the analyzed report types below.


| Type | Apply when the input is mainly about | Rule source |
|---|---|---|
| `01_언론 기사, 기술·제품개요` | 시의성 있는 기사·발표·외부 이벤트·기술/제품 개요 | `report-logic.md` |
| `02_시장동향·산업분석` | 시장·산업·경쟁사·Player·기술경쟁력 분석 | `report-logic.md` |
| `03_주간 보고` | 주간동향·정기 공유·계약/현안/언론 일정 모음 | `report-logic.md` |
| `04_현안 보고` | 장애·사고·계약/협력·정부사업·진행현황·의사결정 이슈 | `report-logic.md` |
| `05_개별 사업 전략` | 특정 사업의 성장전략·추진방안·계약방안·사업모델·R&R·밸류체인 역량 진단 | `report-logic.md` |


**03 + CEO 현안보고를 먼저 확인한다** — Prompt Builder JSON에 `ceo_weekly_report.enabled: true` 가 있거나(03_주간 보고 옆 `CEO 현안보고` 체크), 사용자가 "CEO 현안보고 / 팀 주간 현안보고 / 대표님께 드리는 업무현안" 을 요청하면 아래 01~05 로직 라우팅·archetype ideation·audience 보정을 **모두 건너뛰고** §"CEO 현안보고 (ceo_weekly) mode" 로 간다. 양식이 고정이라 ideation 이 필요 없다.


**먼저 06을 확인한다** — 요청이 `06_기존 문서 수정`이면 위 01~05 로직 라우팅을 **적용하지 않는다**. 작업 방식이 `compare`(문서비교, Word 2개 → 최신본 변경부분 노란 하이라이트) 또는 `typo_only`(오탈자만 수정)이면 §"기존 문서 수정/보완 (Evaluate & Revise) 모드"의 해당 절로, 그 외(업데이트 — 사용자가 표준문서를 올리고 "이 목차 그대로 새 자료로 써줘", 예: 월별 실적보고)는 §"06_기존 문서 수정 — 업데이트 (template_apply) 모드"로 간다. 표준문서의 목차가 곧 구조이므로 별도 ideation이 필요 없다.


**추가 유형 07·08·10은 01~06, 09와 중복 선택된다** — `07_기업개요`(→ companyinfo 모드), `08_CEO Profile`(→ ceoinfo 모드), `10_지참자료, 색인`은 primary 유형 하나와 함께 지정될 수 있다. 이때 기업개요·CEO Profile은 본문을 대체하지 않고 별첨 또는 보조 섹션으로 분리하며, 07과 08이 함께 지정되면 두 개요를 한 섹션에 섞지 않고 각각 별도 별첨으로 만든다. 사용자가 기업개요/CEO Profile **자체**를 산출물로 요청한 경우에만 해당 모드로 단독 문서를 만든다. **Prompt Builder 에서 주 유형을 해제하고 07·08 만 고른 경우(260929)** JSON 의 `document_type.primary.code` 가 `07`/`08` 이고 `mode`·`standalone: true` 가 실린다 — 이때는 report-logic 라우팅 없이 바로 §기업개요 (companyinfo) mode / §CEO Profile (ceoinfo) mode 로 가서 단독 문서를 만들고, 07+08 이 함께면 기업개요 본 문서 + CEO Profile 별첨(`appendices[].profileImage`)으로 만든다.


**보고 목적(독자)에 따라 깊이·섹션 수를 보정한다** — Prompt Builder JSON의 `audience`(`executive` / `manager`(기본) / `working`) 또는 사용자가 말한 보고 대상에 맞춰 목표 깊이, `□` 섹션 수, 구조, 별첨 정책을 조정한다. 기준표와 필수 가드(적용 유형은 **01·02·04·05·09만**, 이동글틀 페이지당 최소 3개 유지, `1./2.` 번호 챕터 신규 그룹핑 금지)는 `references/report-depth.md` §"독자별 깊이 보정 (audience)" 참조. 값은 `executive`(경영진 보고) / `manager`(팀장 보고, 기본) / `working`(실무 검토) 3개다.


**하위 유형은 프롬프트로 지정되지 않는다** — Prompt Builder의 `세부 옵션 선택`(`subtype`)은 폐지됐다. 장애·이슈형 / 의사결정·대응형 / 진행현황형 / 거래처·Account Status형 등 하위 유형은 `references/report-logic.md`의 하위 유형 절과 `references/report-evaluator.md`의 Sub 업무 표를 기준으로 **입력·첨부 내용을 보고 직접 판단**한다.


If a request matches 01~05, use the corresponding section flow and exceptions in `report-logic.md` as the primary structure. In particular, do **not** force `SDS 시사점` into `03_주간 보고`, and do **not** treat `04_현안 보고` as a generic market-analysis report. For `05_개별 사업 전략`, anchor the structure in 사업 개요/현황, 밸류체인·시장·경쟁 진단, 전략 방향/추진 방안, 실행계획, and SDS 검토의견.


Then read `references/report-archetypes.md` as a supplementary ideation palette. The catalog lists 8 recurring archetypes
(기업개요 / 이벤트요약 / 시장분석 / 기술개요 / Samsung 제언 / 주간보고 /
업무계획 / 현안보고) and one common-DNA set shared across all of them.


The archetype catalog is an **ideation palette, not a template**:


- Real reports are almost always **hybrids** — e.g., an investment-impact
  analysis that ends with a company-overview trailer, or a weekly status
  that folds a mini-issue report inside. Draw blocks from multiple
  archetypes as needed.
- **Drop any section the input doesn't actually support.** If the raw
  material has no revenue data, do not invent a `경영실적` section. If
  there's no clear Samsung action item, do not tack on a fake `제언` block.
  An empty or invented section is worse than no section.
- Reorder, merge, rename, or omit freely so the **reader** can scan the
  brief quickly. Comprehension is the goal; conformance to a pattern
  never is.


Once you have a skeleton composed from *what the input actually supports*
(not from a template), move to Step 1.


### Step 1. Read, classify, and research


Figure out:


- **Main topic**: the subject of the one-page body
- **Date**: use `'YY. M.D (요일)` with the weekday **in Hangul** (월·화·수·목·금·토·일) in Asia/Seoul unless the user provides a date. 본문 인라인 이벤트 날짜는 `M/D` 형식
- **Appendices**: separate material that deserves its own mini-document
- **Sources / citations**: URLs, publication names, dates, or quote attributions to place in **blue 9pt annotations (`* ` prefix)**


Fill gaps actively. If the user gives only a few facts, research adjacent facts and produce a complete brief.


**중간 산출물은 파일로, 컨텍스트에는 요약만 (필수)** — 원문 PDF·HTML·긴 기사의 추출 텍스트, 셸 로그, 렌더 이미지를 대화 컨텍스트에 통째로 올리지 않는다. 컨텍스트에 실린 것은 이후 모든 턴이 다시 읽으므로 턴 수만큼 비용이 곱해진다.
- 원문은 **파일로 저장**하고(예: `work_<주제>/source.txt`, PDF는 `pymupdf`/`pdftotext`로 텍스트 추출) 필요한 절만 `grep`·`sed -n`으로 잘라 읽는다. 30쪽 PDF를 페이지 이미지로 넘겨 읽지 않는다. 도표가 필요하면 해당 페이지만 PNG로 잘라 `kind: "image"`에 쓴다.
- 여러 파일·URL 조사는 각 소스를 **요약 10줄 이내로 압축한 뒤 원문은 폐기**한다. 웹 조사 결과도 파일에 적고 요약만 남긴다.
- 셸 명령 출력은 `| tail -n 20`, `| grep` 으로 필요한 줄만 받는다. 검증은 §Step 5의 스크립트 요약만 읽는다.
- 목표: **본문 작성 시작 시점 컨텍스트 ≤ 85K 토큰** (참조 문서 로드 포함). 초과가 예상되면 자료 수집을 멈추고 먼저 초안을 쓴다.


### Step 2. Rewrite in Samsung tone


Read `references/tone.md` before writing. For report improvement, rewriting, or any polished Samsung-style report, also read `references/rewrite-examples.md` and `references/report-depth.md` before drafting final sentences.


Key rules:


- strip narrative padding
- one fact per line
- target 30 to 55 Korean characters per line
- prefer noun endings / compressed endings over conversational prose
- **한자 미사용 (전면 한글)** — 요일·연·월·일 포함 모든 글자를 한글로 (`(목)`·`'26년`·`3월`·`미국`·`등`). 한자를 한 글자도 남기지 않는다. See `references/tone.md` §6.
- 단독 영어 단어 1~2개는 첫 글자 대문자 (`Frontier`·`Full-stack`); 약어·고유명사·관용 기술어는 원표기. 범위 표시는 2byte `∼`. `→` 불릿은 2칸 들여쓰기.
- keep citations and tangential context in **blue 9pt annotations**, anchored to the exact word/number they explain, with the **definition only** (no `용어 :` label)
- use `rewrite-examples.md` by report type: 공통 examples first, then 01~05 type-specific examples when the document type is known
- use `report-depth.md` to target the right depth: 03 mostly L1~L2, 01/02 L2~L3, 04/05 L3~L4
- for 04/05, do not stop at facts; end with SDS 입장, 검토의견, 대응방향, 실행계획, or 재발방지대책 when supported by input
- for 04 incident/outage reports, the incident overview must include occurrence date and time, cause/status, and impact scope. If the exact time is unavailable, write `time unknown` or `under confirmation` rather than omitting it

### Step 3. Build the content JSON


Write JSON matching `references/content-schema.md`.


Minimum shape:


```json
{
  "title": "기업 개요",
  "date": "'26. 4. 15 (수)",
  "sections": [
    {
      "heading": "회사 개요",
      "bullets": [
        {
          "kind": "dash",
          "text": "핵심 내용",
          "annotation": { "text": "출처", "anchor": "핵심" }
        }
      ]
    }
  ],
  "appendices": []
}
```


Notes:


- Do **not** add any source/citation field above the title. `titleAnnotation` is no longer supported — use the top-level `"sourceUrl"` field instead.
- `annotation`, `headingAnnotation`, `bold`, `highlight`, `scale`: full field semantics and auto-behaviors (auto widow-fix, highlight rules) are in `references/content-schema.md`; annotation writing/anchoring rules are in `references/tone.md` §7.
- `numeral` / `number` on a section: optional higher-level heading (`Ⅰ.` 16pt / `1.` 14pt). Use only when the report needs a tier above `□`; the generator drops the `□` prefix automatically. Never combine with `□`.
- **`□` 제목과 `subhead` 구분** — `□` 레벨 제목은 `sections[].heading`에 제목 문자열만 넣고 `□`를 직접 쓰지 않는다. `subhead`는 `< 소제목 >` 중앙정렬 전용이므로 `text`에 `□` 또는 `< >`를 넣지 않는다. 생성기는 잘못된 `subhead + □` 입력을 경고하고 좌측 `□` 헤딩으로 복구하지만, 작성 단계에서 올바른 계층을 사용한다.
- Circled numbers (`kind: "circled"`): optional dash/dot-level accent for genuinely ordered lists. Not a hierarchy tier — do not use in place of `numeral` / `number` / `□`.
- **Tables — default = 단순 표.** Keep `columns + rows` as the default; only reach for `caption` / `unit` / `cells` when the content actually requires them — do not bolt them onto every table. Full field reference (including auto column-width/alignment behavior): `references/content-schema.md` (Table) and `references/generator-defaults.md` (Tables).
- **표 강조 열 (260923)** — 비교표에서 **문서가 설명하는 서비스·제품의 열**은 파란 1.5pt 테두리(좌·우 + 머리글 위·마지막 행 아래)로 감싸 강조한다. 표에 `"highlightColumn": "Meta Muse"`(열 머리글) 또는 0-based 정수로 지정하고, 생략하면 **문서 제목에 들어 있는 열 머리글**을 생성기가 자동으로 골라 `[INFO]` 를 낸다(`"highlightColumn": false` 로 끔). `columns + rows` 단순 표 전용.
- **표 정렬 정책 (260909)** — `alignments` 는 생략하고 생성기 추론에 맡긴다: **첫 열(구분·항목 라벨)은 가운데**, **시점·기간 열(`'26.6월`, `6/1일`, `2026년`)은 가운데**, 비교표(`구분 | Anthropic | OpenAI`)처럼 값이 짧은 열도 가운데, `비고·내용·기업명` 같은 서술·명칭 열은 왼쪽, 금액·소수는 오른쪽. `alignments` 로 `left` 를 줘도 첫 열·시점 열은 가운데로 보정된다(`"alignmentsStrict": true` 로만 해제). 별첨 표도 동일.
- **Simple schematic (구조도/순환도/비교도/Value Chain/조직도/타임라인) → `"kind": "diagram"`, not a pre-rendered image.** Renders as editable native Word shapes from **13 standard templates** (`scripts/diagram_templates.py`): `horizontal_flow`(2~5) · `vertical_flow`(2~5) · `chevron_flow`(3~6, 밸류체인) · `2x2_cycle`(4) · `cycle`(3~6) · `comparison`(2) · `hub_spoke`(중심 1+주변 3~6) · `hierarchy`(상위 1+하위 2~5) · `layers`(2~6, items=계층 안 구성요소) · `matrix_2x2`(4, `xAxis`/`yAxis`) · `timeline`(3~6, title=시점) · `funnel`(3~5) · `pyramid`(3~5). 내용 구조에 맞는 템플릿을 고르고 **노드 제목 8자·항목 14자 이내(전각 기준)** 로 쓴다 — 넘으면 생성기가 글자를 자동 축소(제목 11→9pt, 항목 10→8pt)하고 `[WARN]` 을 낸다. Node shapes: rectangle, chevron, hexagon, circle, cylinder via `defaultShape` / `nodes[].shape`. Field reference and examples: `references/content-schema.md` §Diagram, `assets/example_diagram_templates.json` (13종 전부), `assets/example_diagram_shapes.json`.
- **도식 선 규격** — 상자 테두리와 연결 화살표 선은 모두 검은색 1.0pt. 연결선은 사각형+삼각형 조합이 아닌 단일 Word 화살표 선으로 렌더한다.
- **중복 소제목 금지** — `□ 제목` 바로 아래의 `< 소제목 >` 또는 표·이미지·도식 캡션이 제목과 **같거나 같은 뜻**(포함 관계, 또는 끝말이 `비교≈대비`·`현황≈추이≈이력`처럼 동의어)이면 `< >` 줄을 생략한다. 작성 단계에서 애초에 캡션을 빼고 **더 구체적인 문구를 `□` 제목에** 쓴다(예: `□ 주요 지표 대비` + `< 상장 추진 현황 비교 >` → `□ 상장 추진 현황 비교` 하나만). 생성기도 같은 규칙으로 캡션을 지우고, 캡션이 더 구체적이면 □ 제목을 캡션 문구로 바꾼 뒤 `[INFO]` 를 낸다.
- **Prompt Builder의 `보고서내 도식포함`** — 체크된 프롬프트(`include_diagrams: true`)는 본문에 내용과 직접 연결된 간단한 편집 가능 도식을 반드시 1~2개 포함한다.
- Appendix entries in `appendices[]` only need `title` and `sections`; `date` is ignored.
- **Optional** top-level `toc` triggers the formal 목차 cover page (see `references/content-schema.md`). Add it **only when the user explicitly requests** a 목차/TOC; otherwise omit the field and fall back to the default layout.


### Step 4. Generate the .docx


```bash
python scripts/generate.py <content.json> <output.docx> --verify --png
```


**`--verify`를 항상 붙인다** — 생성 직후 `scripts/verify_docx.py`가 같은 명령 안에서 실행되어 변환·페이지 수·페이지 경계·겹침 판정의 **텍스트 요약**이 함께 돌아온다(검증을 위한 추가 턴 없음). `--verify` 뒤의 인수는 모두 `verify_docx.py`로 전달된다(`--png` 페이지 PNG, `--sheet` 6쪽 합성 시트, `--max-pages N` 분량 상한, `--json 경로`). 요약을 읽는 방법과 종료 조건은 §Step 5.


**Word 파일명 (필수):** content JSON 최상위에 **현재 실행 환경에서 확인된 값을 그대로** `toolName`과 `llmVersion`에 넣는다. 모델명이 `GPT-5`까지만 확인되면 `GPT-5`, `GPT-5.6 Sol`까지 확인되면 `GPT-5.6 Sol`을 사용한다. 확인되지 않은 마이너 버전·변형을 추정하거나 기본값으로 보완하지 않는다. Tool도 구분 가능한 가장 구체적인 이름을 쓴다: Codex 환경은 `Codex`, ChatGPT 채팅 서비스는 `ChatGPT chat`; 구분 정보가 없으면 확인된 이름만 그대로 쓴다. 생성기는 KST 기준 생성 시각을 붙여 `<보고서 제목>(<확인된 Tool이름>, <확인된 LLM이름>)_YYMMDD_HHMM.docx`로 저장한다. Windows 금지문자는 `_`로 바뀐다. 자동화 환경에서는 `SWW_TOOL_NAME`·`SWW_LLM_VERSION` 환경변수로 대체 가능하다.


If `python-docx` is not yet installed, the script auto-installs it on first run (via `pip install -r requirements.txt`). Python 3.9+ recommended.


**출력 저장 경로 (로컬: Claude Code·Codex·Antigravity·AI Pro):** 생성기가 `<output.docx>` 경로를 다음 우선순위로 결정한다 — ① 호출 시 **디렉터리를 포함한 경로**를 주면 그 경로(사용자 지정 최우선), ② **파일명만** 주면 `D:\Secure Folder`가 있으면 거기, ③ 없으면 현재 작업 디렉터리(기본값). 사용자가 경로를 지정하지 않았고 로컬에 `D:\Secure Folder`가 있으면 **파일명만 넘겨** 자동으로 그 폴더에 저장되게 한다. **생성 후 저장된 Word 파일의 실제 경로를 사용자에게 안내**한다(JSON 경로는 안내 불필요). `generate.py` 단일 규칙 (`generate_ceo.py` 는 이 파일로 위임하는 deprecated 호환 레이어).


**Generator behavior (자동 렌더링)**: spacing-after 수치(16/12/9/20pt 등), A4 여백, 폰트 크기, 주석 DrawingML 박스, 표 테두리/행높이/폭/정렬, 부록 라벨·페이지번호 렌더링 등 생성기가 자동으로 처리하는 모든 규칙은 `references/generator-defaults.md`에 있다. `verify_docx.py` 요약의 이슈를 해석할 때 이 파일을 기준으로 삼는다.


### Step 5. Verify and return — 검증 루프는 최대 2라운드


**육안 검증 루프를 돌리지 않는다.** 렌더 검증이 세션 비용의 50~70%를 차지한 원인은 "PNG 생성 → 페이지마다 Read → 판단 → 수정"의 반복이었다. 판정은 스크립트가, 육안은 마지막 1회만.


1. **1라운드** — Step 4의 `--verify --png` 명령 1회. 돌아온 요약만 읽는다: `[verify]` 페이지 수, `[docx]` 구조 검사, `[pages]` 페이지별 1줄(본문 줄 수·주석 수·채움%·섹션), `[issues]` 이슈+힌트, `[result]`. **이 단계에서 PNG를 열지 않는다.**
2. **수정** — `[issues]` 힌트대로 **content JSON만** 고친다(`pageBreakBefore` / `compact` / 문장 2~4자 축약 / 이미지 `width`·`maxWidthPct` / 주석 anchor 이동 / 한자·대문자화 원문 수정). ERROR는 필수, WARN은 힌트가 타당하면 반영, INFO는 선택. 별첨 직전 공백처럼 의도된 WARN은 그대로 둔다.
3. **2라운드** — 같은 명령을 다시 1회. `[result]`가 PASS이거나 남은 WARN이 의도된 것이면 종료. **3라운드는 돌리지 않는다** — 남은 항목은 최종 보고에 "미해결"로 적는다.
4. **육안 확인은 마지막 1회** — `qa_render/<파일명>/page-*.png`를 **한 턴에 전부 병렬 Read**한다(8쪽 초과 문서는 `--sheet`가 만든 `contact-sheet-*.png`만 읽는다). 볼 것은 스크립트가 못 보는 것만: 도식 안 글자 잘림, 표 열 폭의 어색함, 이미지 내용 적합성. 페이지마다 한 턴씩 열기, 확대(zoom) 재촬영, 수정 후 재촬영은 하지 않는다.
5. **변환기가 없을 때** — `[env]`에 Word COM·soffice가 모두 없으면 `[docx]` 구조 검사만 유효하다. 그 사실을 최종 보고에 적고 4번(PNG)은 생략한다. PyMuPDF·pywin32는 스크립트가 첫 실행 시 자동 설치를 시도한다.


**최종 보고 서식 (필수, 5~8줄)** — ① 저장된 Word 파일의 **실제 경로** ② 페이지 수 ③ 검증 결과(`[result]` 한 줄) ④ 반영한 수정 1~3개 ⑤ 미해결 항목(없으면 "없음") ⑥ 문서 한 줄 요약. JSON 경로·중간 산출물·검증 로그 전문은 넣지 않는다.


## Edge cases


- English input: translate to Korean, then apply Samsung tone
- Existing doc input: extract text first, then rewrite
- Very long input: split into body + appendices
- Tables: use `"kind": "table"` when the content is inherently tabular
- No date given: default to today in Asia/Seoul


## 기존 문서 수정/보완 (Evaluate & Revise) 모드


Use this mode when the user **uploads an existing report** (docx/PDF/텍스트) and asks to 수정, 보완, 개선, 평가, or when the Prompt Builder JSON has `work_mode: "rewrite"` / `"typo_only"` / `"compare"` / `"template_reformat"`.


**Before doing anything, read `references/evaluate-revise.md`** — it has the full DRM-intake procedure, the evaluation/scoring/highlight workflow, its relationship to fresh (신규) drafting, and the two narrower sub-modes (오탈자만 수정, 표준 템플릿 중심 변경).


- **Evaluation criteria source**: `references/report-evaluator.md` (문서유형별 표준 목차·필수 슬롯·점수표).
- **`work_mode: "compare"` (문서비교, 260917)** — 평가·보완을 하지 않는다. Word 2개(이전·최신)가 첨부됐는지 확인(아니면 "비교할 Word 파일 2개가 업로드되어 있지 않아 문서비교 작업을 진행할 수 없습니다" 안내 후 **중지**) → `python scripts/compare_docx.py <이전.docx> <최신.docx>` → 변경 비율 **20% 이상이면 "많이 바뀌어 문서비교가 어렵습니다" 안내 후 중지**(`exit 2`, 파일 미생성) → 미만이면 **최신본 복사본**의 바뀐 글자·추가 단락만 노란 하이라이트 → 경로·변경 비율·`이전 → 최신` 대비표 보고. 절차 전문: `references/evaluate-revise.md` §문서비교.
- 문서유형 06이 지정된 경우: 작업 방식이 `typo_only` 면 §오탈자만 수정, `compare` 면 §문서비교(둘 다 `references/evaluate-revise.md`), 그 외(업데이트)는 §"06_기존 문서 수정 — 업데이트 (template_apply) 모드"를 따른다.


## 06_기존 문서 수정 — 업데이트 (template_apply) 모드


문서유형 **06**(Prompt Builder `06_기존 문서 수정 (업데이트, 오탈자, 문서비교)`)은 작업 방식에 따라 **업데이트 / 오탈자만 수정 / 문서비교** 세 갈래다(JSON `document_type.primary.sub_mode`). 오탈자·문서비교는 위 §기존 문서 수정/보완 모드의 하위 절을 따르고, 이 절은 **업데이트**(예: 월별 실적보고 — 전월 보고서 양식에 이번 달 데이터 반영) 또는 사용자가 "이 문서 양식(목차) 그대로 이번 자료로 다시 써줘"라고 요청할 때 적용한다. **목차를 참고할 표준문서 첨부가 필수**다. 목적은 **사용자가 올린 문서의 제목·상위레벨 목차 틀을 그대로 재사용**하고, 그 틀 안의 내용만 새 자료 기준으로 다시 쓰는 것이다.


**Before doing anything, read `references/template-apply.md`** — it has the 표준문서/참고문서 정의, 필수 작성 지침, and how this mode differs from `rewrite` / `template_reformat`.


## 기업개요 (companyinfo) mode — 문서유형 07


Use this mode when the user asks for **기업개요 / 회사개요 / company overview / company profile** of a single company (Prompt Builder 문서 종류 `07_기업개요`, 01~06·09와 중복 선택 가능). Body uses a **fixed section order**, not general-mode archetype freedom — do **not** add TOC, do **not** use `Ⅰ./1.` tiers, do **not** invent sections like `검토 범위 / 분석 방법 / Samsung 제언`.


**Before drafting, read `references/companyinfo.md`** — it holds the primary reference format (SoftBank Corp. 개요 예시를 글로 정리한 기준), the fixed 0~8 section order, the annotation guard, and the JSON skeleton (also see `assets/example_companyinfo.json`).


- **Generator**: `scripts/generate.py` (same as general mode).
- **Do not set** `toc`, `cover`, `numeral`, or `number` in companyinfo JSON.


## CEO Profile (ceoinfo) mode — 문서유형 08


Use this mode when the user asks for a **CEO / 대표 / 창업자 / founder / 임원 / executive profile / 인물 프로필** (Prompt Builder 문서 종류 `08_CEO Profile`, 01~06·09와 중복 선택 가능). Body uses a **fixed section order** with `□` headings only — do **not** add TOC, do **not** use `Ⅰ./1.` tiers.


**Before drafting, read `references/ceoinfo.md`** — it holds the fixed section order, the `profileImage` rules, the hanja ban list, image intake priority, and the JSON skeleton (also see `assets/example_ceo.json` and the field spec in `references/ceo-profile-schema.md`).


- **Generator**: `scripts/generate.py` (기업개요·general 과 **동일**). CEO 전용 엔진은 260821에 폐지됐고 `scripts/generate_ceo.py` 는 deprecated 호환 레이어로만 남아 `generate.py` 에 위임한다.
- **입력 JSON 도 보고서와 동일** — `title` / `sections[]` / `appendices[]`. 이동글틀(주석)·줄간격·widow 보정·페이지 맞춤 로직이 보고서와 완전히 같다. 레거시 평면 JSON(`name`/`career`/`notes`)은 `expand_ceo_profile()` 이 자동 변환.
- **인물 사진** — 최상위(또는 별첨) `profileImage` 로 지정하면 우상단 "텍스트 앞" floating 으로 삽입된다. `"mode": "ceoinfo"` 인 **단독 문서는 사진 필수**(없으면 생성 실패). 다른 보고서의 **별첨**으로 붙는 CEO Profile 은 사진 권장·필수 아님.
- **여러 인물이 한 별첨에 들어갈 때(창업진·경영진 프로필) 사진은 인물별 `□` 섹션의 `sections[].profileImage` 로 붙인다 (260923 손수정본).** 각 인물의 □ 헤딩 우측에 "텍스트 앞"(글자와 겹치는 배치) 이동 그림(폭 4.5cm)으로 들어가 본문 높이를 차지하지 않고, 생성기가 사진 세로 범위의 줄 wrap 폭을 자동으로 줄여 **글자가 사진 뒤로 들어가지 않게** 한다(`verify_docx.py` 가 렌더 결과로 겹침을 다시 검사). **`kind: "image"` 인라인 사진 단락 + `※ 사진 : 출처` 캡션 줄은 쓰지 않는다** — 1인당 약 9줄을 잡아먹어 3명이 2쪽으로 늘어난다. 사진 출처는 `headingAnnotation`(이동글틀)으로. 같은 뜻의 대안 표기 `{"kind": "image", "path": …, "float": "right"}` (섹션 첫 불릿) 도 동일하게 렌더된다.
- **Do not set** `toc`, `cover`, `numeral`, or `number` in ceoinfo JSON.


## CEO 현안보고 (ceo_weekly) mode — 03_주간 보고 하위 옵션


Prompt Builder에서 `03_주간 보고` 옆 **`CEO 현안보고`** 체크박스를 켠 프롬프트(JSON `ceo_weekly_report.enabled: true`, `audience: "executive"` 고정) 또는 그에 준하는 대화 요청에 적용한다. 팀장이 CEO에게 매주 올리는 **1페이지 업무현안 보고**로, 양식·글자 길이·줄바꿈·줄간격은 박광현 팀장 문서를 표준으로, 문서 구조(□·-··)·어투·깊이는 기획팀 종합판(87주차)의 평균 수준으로 학습해 고정했다.


**Before drafting, read `references/ceo-weekly-report.md`** — 입력 5항목(보고 주차/조직명/보고자/연간 주요업무/주간 업무 스토리)과 `To Be Determined` 규칙, 계측 양식표, 문체표(존칭 서술형), Bold 기준, 표·이미지·※ 는 사용자 제공분만 반영하는 원칙, JSON 스키마, 기존 규칙 대비표가 전부 거기 있다.


- **Generator**: `python scripts/generate_ceo_weekly.py <content.json> [폴더] --verify --png` — 파일명은 **`[X월 X주차 현안보고] 조직명_YYMMDD_HHMM.docx`** 로 자동 생성(요청 서식의 `HH:MM` 은 Windows 파일명 제약으로 `HHMM`). 저장 경로 우선순위는 일반 엔진과 같다(지정 폴더 → `D:\Secure Folder` → 현재 폴더).
- **입력 항목이 비면 추측하지 않고 `To Be Determined`** — 생성기가 자동 기재하고 `[WARN]` 을 낸다. 최종 보고에 어떤 항목이 TBD 로 남았는지 적는다.
- **문체**: `-` 항목은 CEO께 보고드리는 존칭 서술형(`~하였습니다 / ~진행 중입니다 / ~예정입니다 / ~하겠습니다 / ~판단됩니다`), `·` 하위는 명사형 축약 허용. □ 마지막 항목은 계획·다짐으로 닫는다. `tone.md` §1(명사형)은 적용하지 않는다.
- **구조**: □ 2~4개 / 1페이지, □ 당 `-` 2~4개, `-` 하나 = 2~3줄(한 줄 약 45~50자, 줄바꿈은 생성기가 계측). □ 헤딩은 `명사구 (기간)` Bold. 중요 수치·기한·결론은 `**…**` 부분 Bold.
- **넣지 않는 것**: SDS 시사점·별첨·떠 있는 이동글틀(텍스트 상자)·목차·번호 챕터·우상단 날짜. 표·이미지·※ 설명주석은 **사용자가 입력·첨부·요청한 것만** — 직접 만들지 않는다.
- **주석은 꼭 필요할 때만, 문장 아래 파란 줄로**: 항목에 `"annotation": "…"` 을 주면 생성기가 문장 바로 아래 줄에 파란(3333FF) 9pt `* ` 주석을 넣고 앞 문장 간격을 0pt 로 붙인다. 일반 엔진의 이동글틀 5원칙(페이지당 3개)은 적용하지 않는다.
- **Do not** route through `scripts/generate.py`, `report-logic.md` 03 골격(경영 일정/주요 사업), archetype ideation, audience 깊이 보정. `verify_docx.py` 요약의 "이동글틀 3개 미만" INFO 는 이 양식에서 정상이다.
- 예시 입력: `assets/example_ceo_weekly.json`. 회귀 검사: `scripts/test-ceo-weekly-regressions.py`.


## 사용 설명서 (User Manual) 요청 처리


사용자가 이 스킬의 **사용 설명서 / 사용자 매뉴얼 / 사용 가이드 / 매뉴얼 / 설명서 보여줘 / how to use (문서로) 보여줘** 등을 요청하면, 대화로 기능을 나열하는 대신 번들된 HTML 매뉴얼 `assets/user-manual.html` 을 **직접 열어서 보여준다.**


- 파일 위치: `assets/user-manual.html` (9개 기능 안내: 스킬 정의 → 접속 방법 → 문서 생성/오탈자/개선 Demo → 사진→문서 → 사용법 질문 → Prompt Builder → 로드맵).
- **표시 방법 (환경별)**:
  - 로컬/데스크톱 환경(Claude Code·Cowork 등): 브라우저 미리보기로 `assets/user-manual.html` 을 연다(예: preview/navigate로 `file://` 경로 열기). 파일 경로도 함께 안내.
  - 클라우드/채팅 환경(ChatGPT·claude.ai 등, 로컬 파일 열기 불가): 매뉴얼 HTML 파일을 사용자에게 **다운로드/첨부 형태로 제공**하거나, GitHub 저장소(https://github.com/garzette0905/samsung-word-writer-pro)와 함께 매뉴얼 내용을 요약 안내. GitHub 저장소 페이지는 빌더 실행 화면이 아니며, 실행 화면은 번들 HTML 파일이다.
- **원칙**: "사용법을 물어보는" 대화형 안내(§Step -1 / 매뉴얼 STEP 7)와 별개로, **매뉴얼을 "보여달라"는 요청에는 이 HTML 파일 자체를 제시**하는 것을 우선한다. HTML 원문을 코드블록으로 통째로 붙여넣지 말 것.


## Files in this skill


- `SKILL.md`
- `references/tone.md`
- `references/content-schema.md`
- `references/report-archetypes.md`
- `references/report-logic.md`
- `references/prompt-builder.md` (Prompt Builder link/fallback + 대화형 게이트 절차 전문 + 필드 수집)
- `references/companyinfo.md` (companyinfo mode — fixed section order, JSON skeleton)
- `references/ceoinfo.md` (ceoinfo mode — output structure, spacing/annotation/hanja rules, JSON shape)
- `references/ceo-profile-schema.md` (ceoinfo mode — full field spec)
- `references/evaluate-revise.md` (기존 문서 수정/보완 모드 전체 절차 — rewrite + typo_only + compare(문서비교) + template_reformat 서브모드)
- `references/template-apply.md` (06_기존 문서 수정 — 업데이트 모드 전체 절차)
- `scripts/compare_docx.py` (**문서비교** — 06 작업 방식 `compare`. Word 2개를 단락→글자 단위로 비교해 최신본 복사본에 변경부분만 노란 하이라이트. 변경 비율 20% 이상이면 `exit 2` 로 중지·파일 미생성, 파일 2개가 아니면 `exit 3`. 일반 docx 는 python-docx, NASCA DRM 은 Word COM 자동 처리)
- `scripts/test-compare-regressions.py` (문서비교 회귀 검사 — 소폭 수정 하이라이트·표 셀·서식 보존·20% 중지·입력 오류 + Prompt Builder 06/문서비교 배선 + check-skill assets 검증)
- `references/ceo-weekly-report.md` (CEO 현안보고 — 03 하위 옵션. 입력 5항목·TBD 규칙, 기준 문서 계측 양식표, 존칭 서술형 문체표, Bold 기준, JSON 스키마, 기존 규칙 대비표)
- `references/generator-defaults.md` (생성기 자동 렌더링 기준값 — spacing/여백/주석/표/부록 등, 시각 검증 시 참조)
- `scripts/generate.py` (**모든 모드 단일 엔진** — general + companyinfo + ceoinfo. `--verify [옵션]`으로 생성 직후 검증까지 1턴)
- `scripts/verify_docx.py` (**산출물 통합 검증** — docx→PDF 변환(Word COM→LibreOffice 순), 페이지 수, □ 헤딩 고립·1~2줄 넘침·하단 공백 1/4·widow, 이동글틀 겹침·우측 초과, 이미지 과점·도형 이탈, 한자·대문자화·폰트·Heading 스타일 검사를 1회 실행으로 판정하고 knob 힌트가 붙은 **텍스트 요약**을 돌려준다. `--png`/`--sheet`로 마지막 육안 확인용 PNG·contact sheet 생성. 검증 루프 규칙은 §Step 5)
- `scripts/generate_ceo.py` (**deprecated** — generate.py 로 위임하는 호환 레이어. 신규 호출 금지)
- `scripts/generate_ceo_weekly.py` (**CEO 현안보고 전용 생성기** — 박광현 팀장 기준 문서를 계측한 11pt 서술형 양식을 1:1 재현. 표준 파일명 `[X월 X주차 현안보고] 조직명_YYMMDD_HHMM.docx` 자동 생성, `--verify` 지원. general 엔진과 별개)
- `scripts/test-ceo-weekly-regressions.py` (CEO 현안보고 회귀 검사 — 기준 문서 줄바꿈 1:1 재현·서식 계측값·TBD 대체·파일명·Prompt Builder 배선)
- `scripts/test-ceo-regressions.py` (ceoinfo 통합 회귀 검사 — 이동글틀·사진 배치·레거시 변환·용어집·별첨·사진 누락 실패)
- `scripts/diagram_templates.py` (표준 도식 템플릿 13종 — 레이아웃 기하 계산, generate.py 가 로드)
- `scripts/test-diagram-regressions.py` (도식 템플릿 13종·표 정렬 정책·캡션 중복·이동글틀 위치·Prompt Builder 배선 회귀 검사)
- `scripts/test-verify-regressions.py` (verify_docx.py 회귀 검사 — 판정 규칙 12건 + 생성→검증 파이프라인)
- `assets/prompt-builder.html` (screen-style Prompt Builder helper)
- `assets/user-manual.html` (사용자 매뉴얼 — 사용법/설명서 요청 시 열어서 보여주는 HTML 가이드)
- `assets/example.json` (general 입력 JSON 예시)
- `assets/example_diagram_shapes.json` (diagram 레이아웃·기본 도형 선택 예시)
- `assets/example_diagram_templates.json` (도식 템플릿 13종을 한 문서에 모두 담은 예시 — 새 도식을 쓸 때 해당 섹션을 복사해 시작)
- `assets/user-manual.html` (사용 설명서 — shadcn 스타일, 도식 템플릿 13종 안내 포함)
- `assets/example_companyinfo.json` (companyinfo 입력 JSON 예시)
- `assets/example_ceo_weekly.json` (CEO 현안보고 입력 JSON 예시 — 수치는 가상)
- `assets/example_ceo.json`, `assets/example_ceo_image.jpeg` (ceoinfo 예시)
- **배포 패키지에 Office 바이너리(docx/xlsx/pptx)를 넣지 않는다 (260917)** — 예전 `assets/example.docx`·`template_company info.docx`·`template_CEO Profile.docx` 는 참고용이었으나 사내 PC에서 NASCA DRM이 걸린 채 패키징되면 Claude Desktop 스킬 설치 시 임시 폴더 삭제가 차단돼 응답 지연을 일으켰다. 포맷 기준은 `references/companyinfo.md`·`references/ceoinfo.md` 의 글 설명으로 대체했고, `scripts/check-skill.py` 가 assets 의 DRM/손상 파일과 Office 바이너리를 검사한다.
- `requirements.txt` (runtime deps: `python-docx`, `Pillow` — auto-installed on first run if missing)


- `references/rewrite-examples.md` — good sentence examples by report type with reason, rule, function, and depth.
- `references/report-depth.md` — depth levels, rewrite rules for shallow vs. deep reports, and §"독자별 깊이 보정 (audience)" (보고 목적 3값별 깊이·섹션 수·구조·별첨 기준).
- `references/report-evaluator.md` — 평가 기준 (유형별 표준 목차·필수 슬롯·점수표·재작성 규칙). 기존 문서 수정/보완 모드의 평가 원천이며, 신규 작성 시 자가 점검에도 사용.
- `agents/openai.yaml` (ChatGPT·Codex·API·Atlas 노출용 인터페이스/정책 메타)
- `assets/icon.svg` (스킬 아이콘 — `agents/openai.yaml`에서 참조)
- `docs/changelog.md` (전체 변경 이력 통합 파일 — 새 변경은 개별 파일을 만들지 말고 이 파일 하단에 append. **배포 ZIP 에는 포함되지 않는다** — 저장소 문서이지 스킬 실행 리소스가 아니므로 `scripts/package-skill.py`가 `docs/`를 제외한다)
- `docs/roadmap.md` (미착수 개선 과제 — 토큰 절감·Word 품질·문서 깊이. 배포 ZIP 미포함)
- `scripts/sync-gh-pages.sh` (호스팅 페이지 동기화 — `assets/prompt-builder.html`→`index.html`, `assets/user-manual.html`→`user-manual.html`, `assets/downloads/*.zip`→gh-pages `downloads/`. **main이 단일 원본**이며 gh-pages에서 직접 고치면 다음 동기화 때 덮어써진다)
- `scripts/install-hooks.sh` (Git 자동화 훅 설치 — clone마다 1회 `sh scripts/install-hooks.sh`. `pre-commit`이 최신 timestamp ZIP 생성·다운로드 링크 갱신·스테이징, `pre-push`가 main 커밋의 호스팅 페이지·ZIP을 gh-pages에 게시. ZIP과 커밋 내용의 일치를 위해 unstaged 추적 파일이 있으면 commit을 중단)
- `scripts/check-skill.py` (SKILL.md front matter 검증 — `description`은 **1024자 이내**여야 스킬 업로드가 통과한다 — 그리고 **assets 검증**: NASCA DRM(`<## NASC`) 헤더·ZIP 으로 열리지 않는 docx/xlsx/pptx 는 오류, 정상 Office 바이너리도 경고. pre-push 훅과 `package-skill.py` 가 자동 실행하며 수동 실행은 `python scripts/check-skill.py`)
- `scripts/package-skill.py` (ChatGPT 등록·배포용 zip 생성 — **Windows `Compress-Archive`를 쓰지 말 것.** `python scripts/package-skill.py`는 이전 timestamp ZIP을 최신 `assets/downloads/samsung-word-writer-pro-YYMMDD_HHMM.zip`으로 교체하고 Prompt Builder 다운로드 링크도 같은 이름으로 갱신한다. 경로 구분자 `/`와 front matter를 함께 검증)
- `scripts/run-python.sh` (Git 훅용 Python 탐색기 — `SWW_PYTHON` → `python`/`python3` → `py -3` → Codex 번들 Python 순서)
