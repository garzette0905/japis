#!/usr/bin/env python3
"""
generate_ceo_weekly.py — CEO 현안보고(팀 주간 현안보고) 전용 .docx 생성기


Usage:
    python scripts/generate_ceo_weekly.py <content.json> [<output.docx | output_dir>] [--verify [verify 옵션]]


    - 출력 인수를 생략하거나 디렉터리를 주면 표준 파일명을 자동 생성한다.
        [{보고 주차} 현안보고] {조직명}_YYMMDD_HHMM.docx
      (Windows 파일명에 `:` 를 쓸 수 없어 `HH:MM` 은 `HHMM` 으로 기록한다.)
    - 파일명만 주면 D:\\Secure Folder 가 있을 때 그 폴더에, 없으면 현재 폴더에 저장한다.
    - `--verify` 뒤 인수는 scripts/verify_docx.py 로 그대로 전달된다.


기준 문서: 「[8월 4주차 현안보고] 경영지원담당 AX팀PI팀.docx」 (박광현 팀장, 260828)
    Word COM 으로 열어 SaveAs(plain docx) 한 뒤 document.xml 을 계측한 값을 그대로 상수로 옮겼다.
    이 스크립트는 samsung-word-writer-pro 의 일반 엔진(generate.py, 14pt·장평 95%·이동글틀)과
    **다른 양식**을 낸다 — CEO 현안보고는 11pt 서술형 문서이며 이동글틀·장평 축소를 쓰지 않는다.


Layout invariants (기준 문서 계측값, twips = 1/20pt):
    - A4, 여백 상/하 1418(2.5cm) · 좌/우 1134(2cm) · 머리글 851 · 바닥글 992
    - 글꼴 바탕체(ascii/eastAsia/hAnsi/cs), 색 000000, 장평 100%, 줄간격 1줄(line=240 auto)
    - autoSpaceDE/DN = 0 (한글·영문/숫자 사이 자동 간격 없음)
    - 인사말 2줄  : 12pt, 왼쪽, after 12pt  →  빈 줄(11pt, after 12pt)
    - 제목        : 20pt Bold+밑줄, 가운데, after 16pt
    - 보고자      : 12pt, 오른쪽, after 9pt  ("{조직명} {보고자}")
    - [연간 주요 업무] 박스 : 1×1 표, 폭 9954, 행 높이 1362(atLeast), 테두리 0.5pt(sz 4),
                  라벨 12pt Bold(before/after 6pt) + 항목 11pt "  1. …"(after 6pt), 세로 가운데
                  → 빈 줄(11pt, after 9pt)
    - □ 헤딩      : 11pt Bold, 양쪽 맞춤, after 9pt
    - `-` 항목    : " - " + 본문, 이어지는 줄은 "   "(공백 3) 들여쓰기, 11pt, 양쪽 맞춤
                  줄 사이 after 9pt / 항목 마지막 줄 after 12pt / 섹션 마지막 항목 after 9pt
    - 섹션 사이   : 빈 줄(11pt Bold, after 9pt)
    - 종결        : 빈 줄(12pt Bold, after 8pt, line 259) → "- 이  상 -" 12pt 오른쪽(after 8pt, line 259)
    - 줄바꿈은 작성자가 아니라 이 스크립트가 글자 폭을 계측해 단어 경계에서 나눈다(11pt 전각 220dxa).
"""


from __future__ import annotations


import io
import json
import os
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path


for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding='utf-8', errors='replace')
    except (AttributeError, ValueError):
        pass


SKILL_ROOT = Path(__file__).resolve().parent.parent




def _ensure_deps():
    try:
        import docx  # noqa: F401
        return
    except ImportError:
        pass
    req = SKILL_ROOT / 'requirements.txt'
    sys.stderr.write('[ceo-weekly] installing python dependencies (python-docx)...\n')
    cmd = [sys.executable, '-m', 'pip', 'install', '--quiet', '--disable-pip-version-check']
    cmd += ['-r', str(req)] if req.exists() else ['python-docx']
    subprocess.check_call(cmd)




_ensure_deps()


from docx import Document  # noqa: E402
from docx.shared import Emu, Twips  # noqa: E402
from docx.oxml import OxmlElement  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402


# ---------- 기준 문서 계측 상수 --------------------------------------------
FONT = '바탕체'
BLACK = '000000'
TBD = 'To Be Determined'


PAGE = {'width': 11906, 'height': 16838, 'top': 1418, 'bottom': 1418,
        'left': 1134, 'right': 1134, 'header': 851, 'footer': 992}
CONTENT_WIDTH = PAGE['width'] - PAGE['left'] - PAGE['right']      # 9638
CONTENT_HEIGHT = PAGE['height'] - PAGE['top'] - PAGE['bottom']    # 14002


# half-points
SZ_GREETING = 24   # 12pt
SZ_TITLE = 40      # 20pt
SZ_REPORTER = 24   # 12pt
SZ_BOX_LABEL = 24  # 12pt
SZ_BOX_ITEM = 22   # 11pt
SZ_BODY = 22       # 11pt — □ 헤딩·- 항목·※ 주석
SZ_CLOSING = 24    # 12pt
SZ_TABLE = 20      # 10pt — 본문 안 데이터 표
SZ_CAPTION = 22    # 11pt
SZ_NOTE = 20       # 10pt — ※ 출처·기준 / * 참석자·용어 (기획팀 종합판 관행)
SZ_ANNOT = 18      # 9pt — 문장 아래 파란 주석 줄 (이동글틀 대체, 꼭 필요할 때만)
ANNOT_BLUE = '3333FF'


# twips
AFTER_GREETING = 240
AFTER_BLANK_AFTER_GREETING = 240
AFTER_TITLE = 320
AFTER_REPORTER = 180
BOX_LABEL_BEFORE = 120
BOX_LABEL_AFTER = 120
BOX_ITEM_AFTER = 120
AFTER_BLANK_AFTER_BOX = 180
AFTER_HEADING = 180
AFTER_LINE = 180            # 항목 안 줄 사이 / 섹션 마지막 항목
AFTER_ITEM_GAP = 240        # 항목 → 다음 항목
AFTER_SECTION_BLANK = 180
AFTER_CLOSING_BLANK = 160
LINE_CLOSING = 259
AFTER_CLOSING = 160
AFTER_TABLE_SPACER = 120


BOX_WIDTH = 9954
BOX_ROW_HEIGHT = 1362
BORDER_SZ = 4


# 11pt 바탕체 글자 폭 (장평 100%)
BODY_PT = 11
FULL_DXA = BODY_PT * 20          # 220
HALF_DXA = BODY_PT * 10          # 110
# 기준 문서의 실제 줄(최장 ≈ 9,480dxa)이 모두 들어오고, 그보다 긴 줄은 나뉘도록 잡은 폭.
WRAP_CAPACITY = CONTENT_WIDTH - 60


PREFIX = {
    'dash': (' - ', '   '),        # 1차 항목 — 존칭 서술형 문장
    'dot': ('  · ', '    '),       # 하위 항목 — 명사형 축약 허용
    'arrow': ('  → ', '    '),     # 결론·판단 (필요할 때만)
    'note': ('   ※ ', '      '),   # 출처·기준·부연 (10pt)
    'star': ('   * ', '     '),    # 참석자·용어 정의 (10pt)
}
SMALL_KINDS = {'note', 'star'}


_INVALID_FILENAME_CHARS_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
KST = timezone(timedelta(hours=9))
SECURE_FOLDER = r"D:\Secure Folder"


_WARNINGS: list[str] = []




def warn(msg: str) -> None:
    _WARNINGS.append(msg)
    print(f'[WARN] {msg}', file=sys.stderr)




# ---------- 문자 폭 계측 ----------------------------------------------------
def is_fullwidth(code: int) -> bool:
    return (
        (0x1100 <= code <= 0x115F) or (0x2E80 <= code <= 0x303E) or
        (0x3041 <= code <= 0x33FF) or (0x3400 <= code <= 0x4DBF) or
        (0x4E00 <= code <= 0x9FFF) or (0xA000 <= code <= 0xA4CF) or
        (0xAC00 <= code <= 0xD7A3) or (0xF900 <= code <= 0xFAFF) or
        (0xFE30 <= code <= 0xFE4F) or (0xFF00 <= code <= 0xFF60) or
        (0xFFE0 <= code <= 0xFFE6) or code == 0x00B7 or code == 0x203B or
        (0x2500 <= code <= 0x257F) or code == 0x223C or
        (0x2014 <= code <= 0x2015) or (0x2190 <= code <= 0x21FF) or
        (0x25A0 <= code <= 0x25FF) or (0x2460 <= code <= 0x24FF)
    )




def measure_dxa(s: str) -> int:
    return sum(FULL_DXA if is_fullwidth(ord(ch)) else HALF_DXA for ch in (s or ''))




# ---------- 인라인 서식 (**굵게**) ------------------------------------------
_BOLD_RE = re.compile(r'\*\*(.+?)\*\*')




def parse_inline(text: str, base_bold: bool = False) -> list[tuple[str, bool]]:
    """`**중요**` 표기를 (텍스트, bold) 세그먼트 목록으로 바꾼다."""
    segs: list[tuple[str, bool]] = []
    pos = 0
    for m in _BOLD_RE.finditer(text or ''):
        if m.start() > pos:
            segs.append((text[pos:m.start()], base_bold))
        segs.append((m.group(1), True))
        pos = m.end()
    if pos < len(text or ''):
        segs.append((text[pos:], base_bold))
    return segs or [('', base_bold)]




def plain_text(text: str) -> str:
    return _BOLD_RE.sub(r'\1', text or '')




def wrap_segments(segs: list[tuple[str, bool]], first_cap: int, cont_cap: int) -> list[list[tuple[str, bool]]]:
    """세그먼트(서식 포함) 문장을 단어 경계에서 폭 기준으로 나눈다.


    반환: 줄 목록. 각 줄은 (텍스트, bold) 세그먼트 목록.
    """
    # 토큰화: 공백 단위 단어를 세그먼트 경계를 유지하며 만든다.
    tokens: list[list[tuple[str, bool]]] = []   # 단어 = 세그먼트 조각 목록
    cur: list[tuple[str, bool]] = []
    for text, bold in segs:
        parts = re.split(r'( +)', text)
        for part in parts:
            if not part:
                continue
            if part.isspace():
                if cur:
                    tokens.append(cur)
                    cur = []
            else:
                cur.append((part, bold))
    if cur:
        tokens.append(cur)
    if not tokens:
        return [[('', False)]]


    def tok_dxa(tok):
        return sum(measure_dxa(t) for t, _ in tok)


    lines: list[list[tuple[str, bool]]] = []
    line: list[tuple[str, bool]] = []
    line_dxa = 0
    cap = first_cap
    for tok in tokens:
        w = tok_dxa(tok)
        delta = (HALF_DXA + w) if line else w
        if line and line_dxa + delta > cap:
            lines.append(line)
            line = list(tok)
            line_dxa = w
            cap = cont_cap
        else:
            if line:
                # 공백은 앞 세그먼트의 서식을 따른다
                line.append((' ', line[-1][1]))
            line.extend(tok)
            line_dxa += delta
    if line:
        lines.append(line)
    # 인접한 같은 서식 세그먼트 병합
    merged_lines = []
    for ln in lines:
        merged: list[tuple[str, bool]] = []
        for t, b in ln:
            if merged and merged[-1][1] == b:
                merged[-1] = (merged[-1][0] + t, b)
            else:
                merged.append((t, b))
        merged_lines.append(merged)
    return merged_lines




# ---------- OOXML helpers ---------------------------------------------------
def _make(tag: str, **attrs) -> OxmlElement:
    el = OxmlElement(f'w:{tag}')
    for k, v in attrs.items():
        el.set(qn(f'w:{k}'), str(v))
    return el




def _rpr(*, size: int, bold: bool = False, underline: bool = False, color: str = BLACK) -> OxmlElement:
    rpr = _make('rPr')
    fonts = _make('rFonts', ascii=FONT, eastAsia=FONT, hAnsi=FONT, cs=FONT)
    rpr.append(fonts)
    if bold:
        rpr.append(_make('b'))
        rpr.append(_make('bCs'))
    rpr.append(_make('color', val=color))
    rpr.append(_make('sz', val=size))
    rpr.append(_make('szCs', val=size))
    if underline:
        rpr.append(_make('u', val='single'))
    return rpr




def make_run(text: str, *, size: int, bold: bool = False, underline: bool = False,
             color: str = BLACK) -> OxmlElement:
    r = _make('r')
    r.append(_rpr(size=size, bold=bold, underline=underline, color=color))
    t = _make('t')
    t.set(qn('xml:space'), 'preserve')
    t.text = text or ''
    r.append(t)
    return r




def make_paragraph(runs, *, size: int, align: str | None = None, before: int = 0,
                   after: int = 0, line: int = 240, bold_mark: bool = False,
                   keep_next: bool = False) -> OxmlElement:
    p = _make('p')
    ppr = _make('pPr')
    if keep_next:
        ppr.append(_make('keepNext'))
    ppr.append(_make('autoSpaceDE', val=0))
    ppr.append(_make('autoSpaceDN', val=0))
    ppr.append(_make('spacing', before=before, beforeAutospacing=0,
                     after=after, afterAutospacing=0, line=line, lineRule='auto'))
    if align:
        ppr.append(_make('jc', val=align))
    ppr.append(_make('textAlignment', val='top'))
    # 단락 기호 서식 (빈 줄 높이 결정)
    ppr.append(_rpr(size=size, bold=bold_mark))
    p.append(ppr)
    for r in runs:
        p.append(r)
    return p




def blank_paragraph(*, size: int, after: int, line: int = 240, bold_mark: bool = False) -> OxmlElement:
    return make_paragraph([], size=size, after=after, line=line, bold_mark=bold_mark)




def seg_runs(segs: list[tuple[str, bool]], *, size: int) -> list[OxmlElement]:
    return [make_run(t, size=size, bold=b) for t, b in segs if t != '']




class Body:
    def __init__(self, doc: Document):
        self.doc = doc
        self.body = doc.element.body


    def append(self, el) -> None:
        sect = self.body.find(qn('w:sectPr'))
        if sect is not None:
            sect.addprevious(el)
        else:
            self.body.append(el)




# ---------- 문서 설정 --------------------------------------------------------
def setup_document(doc: Document) -> None:
    sec = doc.sections[0]
    sec.page_width = Twips(PAGE['width'])
    sec.page_height = Twips(PAGE['height'])
    sec.top_margin = Twips(PAGE['top'])
    sec.bottom_margin = Twips(PAGE['bottom'])
    sec.left_margin = Twips(PAGE['left'])
    sec.right_margin = Twips(PAGE['right'])
    sec.header_distance = Twips(PAGE['header'])
    sec.footer_distance = Twips(PAGE['footer'])


    styles_el = doc.styles.element
    defaults = styles_el.find(qn('w:docDefaults'))
    if defaults is not None:
        rpr_default = defaults.find(qn('w:rPrDefault'))
        if rpr_default is not None:
            rpr = rpr_default.find(qn('w:rPr'))
            if rpr is None:
                rpr = _make('rPr')
                rpr_default.append(rpr)
            for tag in ('rFonts', 'sz', 'szCs'):
                for el in rpr.findall(qn(f'w:{tag}')):
                    rpr.remove(el)
            rpr.insert(0, _make('rFonts', ascii=FONT, eastAsia=FONT, hAnsi=FONT, cs=FONT))
            rpr.append(_make('sz', val=SZ_BODY))
            rpr.append(_make('szCs', val=SZ_BODY))
        ppr_default = defaults.find(qn('w:pPrDefault'))
        if ppr_default is not None:
            for el in list(ppr_default):
                ppr_default.remove(el)
            ppr = _make('pPr')
            ppr.append(_make('spacing', after=0, line=240, lineRule='auto'))
            ppr_default.append(ppr)


    # python-docx 기본 빈 단락 제거
    body = doc.element.body
    for p in body.findall(qn('w:p')):
        if not p.findall(qn('w:r')):
            body.remove(p)
            break




# ---------- 입력 정규화 ------------------------------------------------------
def _tbd(value, field: str) -> str:
    if value is None or (isinstance(value, str) and not value.strip()):
        warn(f"'{field}' 항목이 없어 '{TBD}' 로 기재합니다.")
        return TBD
    return str(value).strip()




def _short_org(org: str) -> str:
    """'경영지원담당 AX팀/PI팀' → 'AX팀/PI팀' (마지막 어절). 한 어절이면 그대로."""
    parts = org.split()
    return parts[-1] if len(parts) >= 2 else org




def normalize_items(items) -> list[dict]:
    out: list[dict] = []
    for it in items or []:
        if isinstance(it, str):
            out.append({'kind': 'dash', 'text': it})
        elif isinstance(it, dict):
            kind = str(it.get('kind') or 'dash').lower()
            if kind in ('sub', 'detail'):
                kind = 'dot'
            out.append({**it, 'kind': kind})
    return out




# ---------- 렌더링 -----------------------------------------------------------
def render_header(b: Body, data: dict) -> dict:
    week = _tbd(data.get('week'), 'week(보고 주차)')
    org = _tbd(data.get('org'), 'org(조직명)')
    reporter = _tbd(data.get('reporter'), 'reporter(보고자)')
    title = (data.get('title') or '').strip() or f"{_short_org(org)} 현안 보고"


    greetings = data.get('greeting')
    if not greetings:
        greetings = ['안녕하십니까', f"{week} {org} 업무현안 내용을 보고드립니다."]
    elif isinstance(greetings, str):
        greetings = [greetings]
    for g in greetings:
        b.append(make_paragraph(seg_runs(parse_inline(g), size=SZ_GREETING),
                                size=SZ_GREETING, align='left', after=AFTER_GREETING))
    b.append(blank_paragraph(size=SZ_BODY, after=AFTER_BLANK_AFTER_GREETING))


    if measure_dxa(title) * (20 / BODY_PT) > CONTENT_WIDTH:
        warn(f"제목이 20pt 기준 한 줄 폭을 넘습니다 — 축약 권장: {title!r}")
    b.append(make_paragraph([make_run(title, size=SZ_TITLE, bold=True, underline=True)],
                            size=SZ_BODY, align='center', after=AFTER_TITLE))


    reporter_line = (data.get('reporterLine') or '').strip() or f"{org} {reporter}"
    b.append(make_paragraph([make_run(reporter_line, size=SZ_REPORTER)],
                            size=SZ_BODY, align='right', after=AFTER_REPORTER))
    return {'week': week, 'org': org, 'reporter': reporter, 'title': title}




def render_annual_box(b: Body, data: dict) -> None:
    tasks = data.get('annualTasks') or data.get('annual_tasks')
    if isinstance(tasks, str):
        tasks = [tasks]
    tasks = [str(t).strip() for t in (tasks or []) if str(t).strip()]
    if not tasks:
        warn(f"'annualTasks(연간 주요업무)' 항목이 없어 '{TBD}' 로 기재합니다.")
        tasks = [TBD]
    label = (data.get('annualLabel') or '[연간 주요 업무]').strip()


    tbl = _make('tbl')
    tblPr = _make('tblPr')
    tblPr.append(_make('tblW', w=BOX_WIDTH, type='dxa'))
    mar = _make('tblCellMar')
    mar.append(_make('left', w=0, type='dxa'))
    mar.append(_make('right', w=0, type='dxa'))
    tblPr.append(mar)
    tblPr.append(_make('tblLook', val='04A0', firstRow=1, lastRow=0, firstColumn=1,
                       lastColumn=0, noHBand=0, noVBand=1))
    tbl.append(tblPr)
    grid = _make('tblGrid')
    grid.append(_make('gridCol', w=BOX_WIDTH))
    tbl.append(grid)


    tr = _make('tr')
    trPr = _make('trPr')
    trPr.append(_make('trHeight', val=BOX_ROW_HEIGHT))
    tr.append(trPr)
    tc = _make('tc')
    tcPr = _make('tcPr')
    tcPr.append(_make('tcW', w=0, type='auto'))
    borders = _make('tcBorders')
    for side in ('top', 'left', 'bottom', 'right'):
        borders.append(_make(side, val='single', sz=BORDER_SZ, space=0, color=BLACK))
    tcPr.append(borders)
    tcPr.append(_make('vAlign', val='center'))
    tc.append(tcPr)


    tc.append(make_paragraph([make_run('\u00a0' + label, size=SZ_BOX_LABEL, bold=True)],
                             size=SZ_BOX_ITEM, before=BOX_LABEL_BEFORE, after=BOX_LABEL_AFTER))
    for i, task in enumerate(tasks, 1):
        text = f"{i}. {task}" if len(tasks) > 1 or task != TBD else task
        # 기준 문서: 항목 앞 공백 2칸("  1. …"). 이어지는 줄은 번호 뒤 글자 위치(공백 5칸)에 맞춘다.
        first_prefix, cont_prefix = '  ', '     '
        cap = BOX_WIDTH - 200
        lines = wrap_segments(parse_inline(text), cap - measure_dxa(first_prefix), cap - measure_dxa(cont_prefix))
        if len(lines) > 1:
            # 박스 항목은 한 줄이 기준 — 넘치면 경고만 하고 2줄로 이어 쓴다
            warn(f"연간 주요 업무 {i}번이 한 줄을 넘어 2줄로 나뉩니다: {plain_text(task)[:30]!r}")
        for li, segs in enumerate(lines):
            segs = [(first_prefix if li == 0 else cont_prefix, False)] + segs
            tc.append(make_paragraph(seg_runs(segs, size=SZ_BOX_ITEM), size=SZ_BOX_ITEM,
                                     after=BOX_ITEM_AFTER))
    tr.append(tc)
    tbl.append(tr)
    b.append(tbl)
    b.append(blank_paragraph(size=SZ_BODY, after=AFTER_BLANK_AFTER_BOX))




def render_heading(b: Body, heading: str) -> None:
    segs = [('□ ', True)] + [(t, True) for t, _ in parse_inline(heading)]
    b.append(make_paragraph(seg_runs(segs, size=SZ_BODY), size=SZ_BODY, align='both',
                            after=AFTER_HEADING, bold_mark=True, keep_next=True))




def render_text_item(b: Body, item: dict, *, is_last_in_section: bool) -> None:
    kind = item['kind']
    first_prefix, cont_prefix = PREFIX.get(kind, PREFIX['dash'])
    text = str(item.get('text') or '').strip()
    # 작성자가 마커를 본문에 같이 적어도 중복되지 않게 벗겨 낸다
    for mark in ('-', '·', '※', '*', '→'):
        if kind == {'-': 'dash', '·': 'dot', '※': 'note', '*': 'star', '→': 'arrow'}[mark] and text.startswith(mark):
            text = text[1:].strip()
    size = SZ_NOTE if kind in SMALL_KINDS else SZ_BODY
    base_bold = bool(item.get('bold'))
    segs = parse_inline(text, base_bold)
    # 10pt 줄은 같은 폭에 글자가 더 들어간다 (폭 비례)
    scale = size / SZ_BODY
    first_cap = int((WRAP_CAPACITY - measure_dxa(first_prefix) * scale) / scale)
    cont_cap = int((WRAP_CAPACITY - measure_dxa(cont_prefix) * scale) / scale)
    lines = wrap_segments(segs, first_cap, cont_cap)
    annots = item.get('annotation') or item.get('annotations')
    if isinstance(annots, str):
        annots = [annots]
    annots = [str(a).strip() for a in (annots or []) if str(a).strip()]
    for li, line in enumerate(lines):
        prefix = first_prefix if li == 0 else cont_prefix
        last = (li == len(lines) - 1)
        if last:
            after = AFTER_LINE if is_last_in_section else AFTER_ITEM_GAP
            if annots:
                after = 0          # 주석 줄이 문장 바로 아래 붙도록 문장 간격 0pt
        else:
            after = AFTER_LINE
        runs = seg_runs([(prefix, False)] + line, size=size)
        b.append(make_paragraph(runs, size=size, align='both', after=after))
    if annots:
        render_annotation_lines(b, annots, indent_prefix=cont_prefix,
                                after=(AFTER_LINE if is_last_in_section else AFTER_ITEM_GAP))




def render_annotation_lines(b: Body, annots: list[str], *, indent_prefix: str, after: int) -> None:
    """이동글틀 대체 — 문장 바로 아래 줄에 파란색(3333FF) 9pt `* ` 주석을 넣는다.


    떠 있는 텍스트 상자(이동글틀)를 쓰지 않고 일반 단락으로 넣어 Word 에서 그대로 편집할 수 있다.
    앞 문장 단락의 after 는 0pt(호출 측), 주석 줄이 원래 항목 간격(after)을 이어받는다.
    """
    scale = SZ_ANNOT / SZ_BODY
    # 본문 11pt 기준 들여쓰기 폭을 9pt 공백 수로 환산해 문장 첫 글자 위치에 맞춘다
    indent_dxa = measure_dxa(indent_prefix)
    pad = ' ' * max(1, round(indent_dxa / (HALF_DXA * scale)))
    cap = int((WRAP_CAPACITY - indent_dxa) / scale)
    for ai, text in enumerate(annots):
        text = text.lstrip('* ').strip()
        lines = wrap_segments(parse_inline('* ' + text), cap, cap - 2 * HALF_DXA)
        for li, line in enumerate(lines):
            prefix = pad if li == 0 else pad + '  '
            runs = [make_run(prefix + ''.join(t for t, _ in line), size=SZ_ANNOT, color=ANNOT_BLUE)]
            last = (ai == len(annots) - 1 and li == len(lines) - 1)
            b.append(make_paragraph(runs, size=SZ_ANNOT, align='left', after=(after if last else 0)))




def _table_cell(text: str, *, width: int, header: bool, align: str, size: int) -> OxmlElement:
    tc = _make('tc')
    tcPr = _make('tcPr')
    tcPr.append(_make('tcW', w=width, type='dxa'))
    borders = _make('tcBorders')
    for side in ('top', 'left', 'bottom', 'right'):
        borders.append(_make(side, val='single', sz=BORDER_SZ, space=0, color=BLACK))
    tcPr.append(borders)
    tcPr.append(_make('vAlign', val='center'))
    tc.append(tcPr)
    segs = parse_inline(str(text if text is not None else ''), header)
    tc.append(make_paragraph(seg_runs(segs, size=size), size=size,
                             align=('center' if header else align), after=0))
    return tc




_NUM_RE = re.compile(r'^[\s+\-−△▲▽▼]*[\d,]+(\.\d+)?\s*(%|명|억|만|건|개|원|천|백만|시간|일|주|월|년|pt|p)?\s*$')




def _col_align(values: list[str], idx: int) -> str:
    if idx == 0:
        return 'center'
    vals = [v for v in values if str(v or '').strip()]
    if vals and all(_NUM_RE.match(str(v)) for v in vals):
        return 'right'
    if vals and all(measure_dxa(plain_text(str(v))) <= 8 * FULL_DXA for v in vals):
        return 'center'
    return 'left'




def render_table_item(b: Body, item: dict, *, is_last_in_section: bool) -> None:
    cols = [str(c) for c in (item.get('columns') or [])]
    rows = [[str(c) if c is not None else '' for c in r] for r in (item.get('rows') or [])]
    if not cols and rows:
        cols = rows[0]
        rows = rows[1:]
    if not cols:
        warn('표에 columns/rows 가 없어 건너뜁니다.')
        return
    size = int(round(float(item.get('fontSize', 10)) * 2))
    size = max(16, min(size, SZ_BODY))
    indent = measure_dxa(PREFIX['dash'][0])
    total = CONTENT_WIDTH - indent


    caption = (item.get('caption') or '').strip()
    if caption:
        b.append(make_paragraph([make_run(f"< {caption} >", size=SZ_CAPTION, bold=True)],
                                size=SZ_CAPTION, align='center', after=AFTER_LINE, keep_next=True))


    # 열 폭 — 내용 폭 비례, 최소 폭 보장
    n = len(cols)
    widths_in = item.get('columnWidths')
    if isinstance(widths_in, list) and len(widths_in) == n and all(isinstance(w, (int, float)) for w in widths_in):
        s = float(sum(widths_in)) or 1.0
        widths = [int(total * (w / s)) for w in widths_in]
    else:
        need = []
        for i in range(n):
            vals = [cols[i]] + [r[i] if i < len(r) else '' for r in rows]
            need.append(max(measure_dxa(plain_text(v)) for v in vals) * (size / SZ_BODY) + 240)
        s = sum(need) or 1.0
        widths = [max(int(total * (w / s)), 900) for w in need]
        over = sum(widths) - total
        if over > 0:
            widths[widths.index(max(widths))] -= over
    aligns = [_col_align([r[i] if i < len(r) else '' for r in rows], i) for i in range(n)]


    tbl = _make('tbl')
    tblPr = _make('tblPr')
    tblPr.append(_make('tblW', w=total, type='dxa'))
    tblPr.append(_make('tblInd', w=indent, type='dxa'))
    tb = _make('tblBorders')
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        tb.append(_make(side, val='single', sz=BORDER_SZ, space=0, color=BLACK))
    tblPr.append(tb)
    tblPr.append(_make('tblLayout', type='fixed'))
    mar = _make('tblCellMar')
    mar.append(_make('top', w=0, type='dxa'))
    mar.append(_make('left', w=60, type='dxa'))
    mar.append(_make('bottom', w=0, type='dxa'))
    mar.append(_make('right', w=60, type='dxa'))
    tblPr.append(mar)
    tbl.append(tblPr)
    grid = _make('tblGrid')
    for w in widths:
        grid.append(_make('gridCol', w=w))
    tbl.append(grid)


    def row(cells, header):
        tr = _make('tr')
        trPr = _make('trPr')
        trPr.append(_make('trHeight', val=454, hRule='atLeast'))
        tr.append(trPr)
        for i in range(n):
            tr.append(_table_cell(cells[i] if i < len(cells) else '', width=widths[i],
                                  header=header, align=aligns[i], size=size))
        return tr


    tbl.append(row(cols, True))
    for r in rows:
        tbl.append(row(r, False))
    b.append(tbl)


    note = (item.get('note') or '').strip()
    if note:
        b.append(make_paragraph(seg_runs([(' ※ ', False)] + parse_inline(note.lstrip('※').strip()), size=SZ_BODY),
                                size=SZ_BODY, align='both', before=60,
                                after=(AFTER_LINE if is_last_in_section else AFTER_ITEM_GAP)))
    else:
        b.append(blank_paragraph(size=12, after=(AFTER_TABLE_SPACER if is_last_in_section else AFTER_ITEM_GAP),
                                 line=240))




def _resolve_path(p: str, json_dir: str | None) -> str:
    if os.path.isabs(p) or not json_dir:
        return p
    cand = os.path.join(json_dir, p)
    return cand if os.path.exists(cand) else p




def render_image_item(b: Body, doc: Document, item: dict, *, json_dir: str | None,
                      is_last_in_section: bool) -> None:
    path = _resolve_path(str(item.get('path') or ''), json_dir)
    if not path or not os.path.exists(path):
        warn(f"이미지 파일을 찾을 수 없어 건너뜁니다: {path!r}")
        return
    caption = (item.get('caption') or '').strip()
    if caption:
        b.append(make_paragraph([make_run(f"< {caption} >", size=SZ_CAPTION, bold=True)],
                                size=SZ_CAPTION, align='center', after=AFTER_LINE, keep_next=True))
    pct = float(item.get('widthPct') or item.get('width_pct') or 70)
    pct = max(20.0, min(pct, 100.0))
    width_emu = int(CONTENT_WIDTH * 635 * pct / 100)
    max_h_emu = int(CONTENT_HEIGHT * 635 * float(item.get('maxHeightPct') or 0.45))
    para = doc.add_paragraph()
    run = para.add_run()
    pic = run.add_picture(path, width=Emu(width_emu))
    if pic.height > max_h_emu:
        ratio = max_h_emu / pic.height
        pic.height = Emu(max_h_emu)
        pic.width = Emu(int(pic.width * ratio))
    p = para._p
    ppr = p.find(qn('w:pPr'))
    if ppr is None:
        ppr = _make('pPr')
        p.insert(0, ppr)
    for el in list(ppr):
        ppr.remove(el)
    ppr.append(_make('autoSpaceDE', val=0))
    ppr.append(_make('autoSpaceDN', val=0))
    ppr.append(_make('spacing', before=0, after=(AFTER_LINE if is_last_in_section else AFTER_ITEM_GAP),
                     line=240, lineRule='auto'))
    ppr.append(_make('jc', val='left' if item.get('alignment') == 'left' else 'center'))
    note = (item.get('note') or '').strip()
    if note:
        b.append(make_paragraph(seg_runs([(' ※ ', False)] + parse_inline(note.lstrip('※').strip()), size=SZ_BODY),
                                size=SZ_BODY, align='both',
                                after=(AFTER_LINE if is_last_in_section else AFTER_ITEM_GAP)))




def render_sections(b: Body, doc: Document, data: dict, json_dir: str | None) -> int:
    sections = data.get('sections') or []
    if not sections:
        warn(f"'sections(주간 업무 스토리)' 가 없어 '{TBD}' 섹션 1개로 채웁니다.")
        sections = [{'heading': TBD, 'items': [TBD]}]
    count = 0
    for si, sec in enumerate(sections):
        if isinstance(sec, str):
            sec = {'heading': sec, 'items': []}
        heading = (sec.get('heading') or '').strip() or TBD
        items = normalize_items(sec.get('items') or sec.get('bullets'))
        if not items:
            items = [{'kind': 'dash', 'text': TBD}]
        if si > 0:
            b.append(blank_paragraph(size=SZ_BODY, after=AFTER_SECTION_BLANK, bold_mark=True))
        render_heading(b, heading)
        for ii, item in enumerate(items):
            last = (ii == len(items) - 1)
            kind = item['kind']
            if kind == 'table':
                render_table_item(b, item, is_last_in_section=last)
            elif kind == 'image':
                render_image_item(b, doc, item, json_dir=json_dir, is_last_in_section=last)
            else:
                if not str(item.get('text') or '').strip():
                    item['text'] = TBD
                render_text_item(b, item, is_last_in_section=last)
        count += 1
    return count




def render_closing(b: Body) -> None:
    b.append(blank_paragraph(size=SZ_CLOSING, after=AFTER_CLOSING_BLANK, line=LINE_CLOSING, bold_mark=True))
    b.append(make_paragraph([make_run('- 이  상 -', size=SZ_CLOSING)], size=SZ_BODY,
                            align='right', after=AFTER_CLOSING, line=LINE_CLOSING))




# ---------- 파일명 / 경로 ----------------------------------------------------
def _safe_part(value: str) -> str:
    text = str(value or '').replace('/', '').replace('\\', '')
    text = _INVALID_FILENAME_CHARS_RE.sub('_', text)
    return re.sub(r'\s+', ' ', text).strip(' ._')




def standard_filename(meta: dict, now: datetime | None = None) -> str:
    stamp = (now or datetime.now(KST)).astimezone(KST).strftime('%y%m%d_%H%M')
    week = _safe_part(meta.get('week') or TBD)
    org = _safe_part(meta.get('org') or TBD)
    return f"[{week} 현안보고] {org}_{stamp}.docx"




def resolve_output_path(raw_out: str | None, meta: dict) -> str:
    """① 디렉터리(또는 생략) → 표준 파일명 자동, ② .docx 경로 → 그대로.
    파일명만 주면 D:\\Secure Folder 가 있을 때 거기에 저장."""
    fname = standard_filename(meta)
    if not raw_out:
        base = SECURE_FOLDER if os.path.isdir(SECURE_FOLDER) else os.getcwd()
        return os.path.join(base, fname)
    raw = str(raw_out)
    if os.path.isdir(raw) or raw.endswith(('/', '\\')) or not raw.lower().endswith('.docx'):
        return os.path.join(os.path.abspath(raw), fname)
    if os.path.dirname(raw):
        return os.path.abspath(raw)
    if os.path.isdir(SECURE_FOLDER):
        return os.path.join(SECURE_FOLDER, os.path.basename(raw))
    return os.path.abspath(raw)




# ---------- main --------------------------------------------------------------
def build_document(data: dict, json_dir: str | None = None) -> tuple[bytes, dict]:
    doc = Document()
    setup_document(doc)
    b = Body(doc)
    meta = render_header(b, data)
    render_annual_box(b, data)
    meta['sections'] = render_sections(b, doc, data, json_dir)
    if data.get('closing', True):
        render_closing(b)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue(), meta




def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    verify_args = None
    if '--verify' in argv:
        i = argv.index('--verify')
        verify_args = argv[i + 1:]
        argv = argv[:i]
    if not argv:
        sys.stderr.write('Usage: python generate_ceo_weekly.py <content.json> [<output.docx|dir>] [--verify [옵션]]\n')
        return 1
    content_path = argv[0]
    raw_out = argv[1] if len(argv) > 1 else None
    with open(content_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    json_dir = os.path.dirname(os.path.abspath(content_path))


    buf, meta = build_document(data, json_dir)
    out_path = resolve_output_path(raw_out, meta)
    os.makedirs(os.path.dirname(out_path) or '.', exist_ok=True)
    with open(out_path, 'wb') as f:
        f.write(buf)
    print(f"Wrote {out_path.replace(os.sep, '/')} ({len(buf)} bytes) — 제목 {meta['title']!r}, "
          f"□ 섹션 {meta['sections']}개, 경고 {len(_WARNINGS)}건", flush=True)


    if verify_args is not None:
        verifier = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'verify_docx.py')
        cmd = [sys.executable, verifier, out_path, '--content', content_path] + verify_args
        return subprocess.call(cmd)
    return 0




if __name__ == '__main__':
    sys.exit(main())
