#!/usr/bin/env python3
"""문서비교(compare_docx.py) 회귀 검사 + Prompt Builder 06/문서비교 배선 검사.


    python scripts/test-compare-regressions.py


검사 항목
  1. 소폭 수정(글자 몇 개·단락 추가) → exit 0, 하이라이트 파일 생성, 바뀐 글자만 노란색, 원본 서식(굵게) 보존
  2. 표 셀 수정도 하이라이트된다
  3. 대폭 수정(20% 이상) → exit 2, 파일 미생성 / --force 면 생성
  4. 파일 1개 → exit 3
  5. Prompt Builder: 라벨 변경, compare 옵션, document_compare 블록, 06 자동 펼침 코드, Gemini 제거
  6. check-skill.py: NASCA 헤더 / 비 ZIP Office 파일을 오류로 잡는다
"""
from __future__ import annotations


import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "scripts" / "compare_docx.py"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"




def require(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)




def run(*args: str) -> subprocess.CompletedProcess:
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    return subprocess.run([sys.executable, str(SCRIPT), *args], capture_output=True, text=True,
                          encoding="utf-8", errors="replace", env=env)




def build_doc(path: Path, paragraphs: list[str], table: list[list[str]] | None = None,
              bold_first: bool = False) -> None:
    import docx  # type: ignore
    d = docx.Document()
    for i, text in enumerate(paragraphs):
        p = d.add_paragraph()
        r = p.add_run(text)
        if bold_first and i == 0:
            r.bold = True
    if table:
        t = d.add_table(rows=len(table), cols=len(table[0]))
        for ri, row in enumerate(table):
            for ci, val in enumerate(row):
                t.cell(ri, ci).text = val
    d.save(str(path))




def highlighted_texts(path: Path) -> list[str]:
    """노란 하이라이트가 걸린 run 텍스트 목록."""
    import docx  # type: ignore
    from docx.oxml.ns import qn  # type: ignore
    d = docx.Document(str(path))
    out = []
    for r in d.element.body.iter(qn("w:r")):
        rpr = r.find(qn("w:rPr"))
        if rpr is None:
            continue
        hl = rpr.find(qn("w:highlight"))
        if hl is not None and hl.get(qn("w:val")) == "yellow":
            out.append("".join(t.text or "" for t in r.iter(qn("w:t"))))
    return out




def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        tdir = Path(td)
        base = [
            "AX 현장 대응체계 구축 현황 보고",
            "□ 추진 배경 — 현장 장애 대응 지연으로 고객 불만 증가",
            "- '26년 상반기 장애 건수 128건, 평균 복구 4.2시간",
            "- 대응 조직 분산으로 초기 판단 지연",
            "□ 추진 방안",
            "- 통합 상황실 신설 및 24시간 운영",
            "- 장애 등급별 대응 매뉴얼 정비",
            "※ 세부 일정은 별첨 참조",
        ]
        table = [["구분", "'25년", "'26년"], ["장애 건수", "142", "128"], ["평균 복구", "5.1h", "4.2h"]]


        # 1) 소폭 수정 -------------------------------------------------------------
        old = tdir / "report_v1.docx"
        new = tdir / "report_v2.docx"
        build_doc(old, base, table, bold_first=True)
        changed = list(base)
        changed[2] = "- '26년 상반기 장애 건수 121건, 평균 복구 3.8시간"      # 숫자 두 곳 수정
        changed.insert(7, "- 현장 담당자 교육 월 1회 실시")                  # 단락 추가
        table2 = [row[:] for row in table]
        table2[1][2] = "121"                                              # 표 셀 수정
        build_doc(new, changed, table2, bold_first=True)


        out = tdir / "result.docx"
        r = run(str(old), str(new), "--out", str(out), "--json", str(tdir / "r.json"))
        require(r.returncode == 0, f"소폭 수정 exit {r.returncode}: {r.stderr}")
        require(out.is_file(), "하이라이트 파일이 생성되지 않음")
        require("변경 비율" in r.stdout, "요약에 변경 비율이 없음")
        hl = highlighted_texts(out)
        joined = "".join(hl)
        require("121" in joined and "3.8" in joined, f"수정 글자가 하이라이트되지 않음: {hl}")
        require(any("현장 담당자 교육" in h for h in hl), f"추가 단락이 하이라이트되지 않음: {hl}")
        require(not any("장애 건수 1" in h and "128" in h for h in hl), "원문 글자까지 하이라이트됨")
        require(not any("추진 배경" in h for h in hl), f"바뀌지 않은 단락이 하이라이트됨: {hl}")
        require(len(joined) < 60, f"하이라이트 범위가 과도함 ({len(joined)}자): {hl}")
        # 원본 서식 보존 — 제목 run 굵게 유지, 표 존재
        import docx  # type: ignore
        d = docx.Document(str(out))
        require(d.paragraphs[0].runs[0].bold is True, "제목 굵게 서식이 사라짐")
        require(len(d.tables) == 1 and d.tables[0].cell(1, 2).text == "121", "표가 보존되지 않음")
        with zipfile.ZipFile(out) as zf:
            require(zf.testzip() is None, "출력 docx ZIP 손상")


        # 2) 대폭 수정 → 중지 -----------------------------------------------------
        big = tdir / "report_v3.docx"
        build_doc(big, ["완전히 다른 문서 제목", "□ 새 목차 1", "- 전부 새로 쓴 내용 A", "- 전부 새로 쓴 내용 B",
                        "□ 새 목차 2", "- 전부 새로 쓴 내용 C"], None)
        out2 = tdir / "result_big.docx"
        r = run(str(old), str(big), "--out", str(out2))
        require(r.returncode == 2, f"대폭 수정인데 exit {r.returncode}")
        require(not out2.exists(), "20% 초과인데 파일이 생성됨")
        require("20.0% 이상" in r.stderr or "이상입니다" in r.stderr, f"중지 안내 문구 없음: {r.stderr}")
        r = run(str(old), str(big), "--out", str(out2), "--force")
        require(r.returncode == 0 and out2.is_file(), "--force 가 동작하지 않음")


        # 3) 파일 1개 → 입력 오류 --------------------------------------------------
        r = run(str(old))
        require(r.returncode == 3 and "2개" in r.stderr, f"파일 1개 처리 오류: {r.returncode} {r.stderr}")
        r = run(str(old), str(old))
        require(r.returncode == 3, "같은 파일 2개가 통과됨")


        # 4) check-skill assets 검증 ----------------------------------------------
        neg = tdir / "neg"
        (neg / "assets").mkdir(parents=True)
        (neg / "SKILL.md").write_text("---\nname: x-skill\ndescription: d\n---\n", encoding="utf-8")
        (neg / "assets" / "drm.docx").write_bytes(b"<## NASC" + b"\x00" * 32)
        (neg / "assets" / "bad.pptx").write_bytes(b"not a zip")
        env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
        r = subprocess.run([sys.executable, str(ROOT / "scripts" / "check-skill.py"), str(neg / "SKILL.md")],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
        require(r.returncode == 1, "check-skill 이 DRM/손상 assets 를 통과시킴")
        require("NASCA" in r.stderr and "bad.pptx" in r.stderr, f"check-skill 오류 메시지 누락: {r.stderr}")
        r = subprocess.run([sys.executable, str(ROOT / "scripts" / "check-skill.py")],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
        require(r.returncode == 0, f"현재 저장소 check-skill 실패: {r.stderr}")
        require(not list((ROOT / "assets").glob("*.docx")), "assets 에 docx 가 남아 있음")


    # 5) Prompt Builder 배선 -------------------------------------------------------
    builder = (ROOT / "assets" / "prompt-builder.html").read_text(encoding="utf-8")
    require("Prompt복사(Claude Code, AI Pro, Antigravity)" in builder, "복사 버튼 라벨 미변경")
    require("Prompt복사(Codex)" in builder, "Codex 복사 버튼 라벨 미변경 (260923)")
    require(builder.index('id="copyBtnClaude"') < builder.index('id="copyBtnGPT"'),
            "복사 버튼 순서(Claude Code 먼저) 미반영 (260929)")
    require("https://chatgpt.com/?prompt=" not in builder and "https://claude.ai/new?q=" not in builder and "URL_HARD_LIMIT" not in builder,
            "Web 열기 버튼이 여전히 프롬프트를 URL 파라미터로 전달 (260929 폐지 — 사내 프록시 414 URI Too Long)")
    require('url:() => "https://chatgpt.com/"' in builder and 'url:() => "https://claude.ai/new"' in builder,
            "Web 열기 버튼 고정 링크(새 대화 페이지) 없음")
    require('"codex://new?prompt=" + encodeURIComponent(t)' in builder and '"claude://claude.ai/new?q=" + encodeURIComponent(t)' in builder,
            "App 열기 버튼 딥링크 프롬프트 자동 채움 없음 (260929 — 앱은 프록시를 거치지 않음)")
    require('<option value="compare">(문서 업로드) 문서비교</option>' in builder, "문서비교 작업 방식 라벨 미변경 (260929)")
    require("저장경로는 기본 D:\\Secure Folder에 저장됩니다." in builder and "저장경로를 별도로 알려드립니다." in builder,
            "저장경로 안내 문구 미변경 (260929)")
    require("function copyTextToClipboard(" in builder and "const copied = await copyTextToClipboard(text);" in builder,
            "열기 시 클립보드 복사 배선 없음")
    require('STANDALONE_CODES = ["07","08"]' in builder and "primary.standalone = true" in builder
            and "07_기업개요 단독 문서" in builder and "08_CEO Profile 단독 문서" in builder,
            "07/08 단독 선택 배선 없음 (260929)")
    require('placeholder="예: OpenAI, GPT-6 Astra 서비스 개요 및 동향"' in builder, "문서 타이틀 예시 미변경 (260929)")
    require('\\"문서비교\\" 선택시 비교할 Word 파일 2개를 업로드해주세요' in builder, "06 작업 방식 미선택 힌트 문구 미변경 (260929)")
    require("Prompt복사(ChatGPT)" not in builder and "Prompt복사(Claude, AI Pro" not in builder,
            "복사 버튼 옛 라벨(ChatGPT / Claude)이 남아 있음")
    require("ChatGPT 열기 (App)" in builder and "Claude 열기 (App)" in builder,
            "열기 버튼 라벨 (App) 미반영 (260929)")
    require("열기 (Work)" not in builder and "열기 (Cowork)" not in builder, "열기 버튼 옛 라벨 (Work)/(Cowork) 이 남아 있음")
    require('value="appendix"' not in builder, "작업 방식에 별첨문서 작성 항목이 남아 있음 (260923 제거)")
    require("Prompt복사(Claude, AI Pro, Gemini, Antigravity)" not in builder, "복사 버튼 라벨에 Gemini 표기가 남아 있음")
    require('id="repositoryLink"' in builder
            and "https://github.com/garzette0905/samsung-word-writer-pro" in builder
            and builder.rfind('id="repositoryLink"') > builder.rfind('id="skillZipLink"'),
            "GitHub 저장소 버튼이 버튼 목록 마지막에 없음")
    require('divider.className = "doc-divider"' in builder and '.doc-divider {' in builder and 'if (code === "06") {' in builder,
            "01~06 | 07~10 점선 구분 배선 없음")
    require("06_기존 문서 수정 (업데이트, 오탈자, 문서비교)" in builder, "06 라벨 미변경")
    require("06_기존 문서 업데이트 (목차유지, 내용만 변경)" not in builder, "옛 06 라벨이 남아 있음")
    require('<option value="compare">' in builder, "문서비교 작업 방식 옵션 없음")
    require("json.document_compare = {" in builder and "change_ratio_limit: 0.2" in builder,
            "document_compare JSON 블록 없음")
    require("문서비교 지시" in builder and "20% 이상이면" in builder and "2개 업로드되어 있지 않으면" in builder,
            "문서비교 프롬프트 지시 누락")
    require("scripts/compare_docx.py" in builder, "compare 스크립트 안내 누락")
    require("function setAdvanced(" in builder and "function openWorkModePicker(" in builder,
            "더보기 자동 펼침/작업 방식 펼침 함수 없음")
    require("setAdvanced(true" in builder and "setAdvanced(false);" in builder, "06 펼침·타 유형 접힘 배선 없음")
    require('WORK_MODE_NEW_LABEL_06 = "문서 작업 선택"' in builder, "06 작업 방식 첫 항목 라벨(문서 작업 선택) 없음")
    require("select.listbox" in builder and "#advanced.unfolding" in builder and "workModeSelect.showPicker" not in builder,
            "06 천천히 펼침(리스트 박스 애니메이션) 배선 없음")
    require("function refreshUploadNotice(" in builder and 'id="uploadNotice"' in builder, "문서 업로드 필요 안내 배선 없음")
    require("수정내용 하이라이트(노란색)" in builder and "check-inline" in builder, "하이라이트 체크 라벨/한 줄 정렬 미반영")
    require('v === "compare"' in builder, "문서비교 선택 시 노란 하이라이트 자동 체크 배선 없음")
    for ref in ("references/prompt-builder.md", "references/template-apply.md", "references/evaluate-revise.md",
                "SKILL.md"):
        text = (ROOT / ref).read_text(encoding="utf-8")
        require("문서비교" in text, f"{ref} 에 문서비교 설명 없음")
    require("compare_docx.py" in (ROOT / "SKILL.md").read_text(encoding="utf-8"), "SKILL.md 파일 목록에 compare 스크립트 없음")
    print("[compare-test] OK")
    return 0




if __name__ == "__main__":
    raise SystemExit(main())
