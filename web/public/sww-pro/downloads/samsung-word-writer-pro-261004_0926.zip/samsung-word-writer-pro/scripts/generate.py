#!/usr/bin/env python3
"""
sds-word-writer — SDS 보고서 양식 .docx generator


Usage:
    python generate.py <content.json> <output.docx>


Content JSON schema: see references/content-schema.md
Layout invariants (must stay 1:1 with the Node/JS implementation):
    - Font 바탕체 everywhere (ASCII, EastAsia, hAnsi all 바탕체)
    - Width-scale 95% on every run (장체); per-bullet override via "scale"
    - autoSpaceDE="0" / autoSpaceDN="0" on every paragraph
    - Bold: title, section headings, and explicitly marked bullets
    - Body 14pt (sz=28) black; annotations 9pt (sz=18) black (SC 260506)
    - Single line spacing (line=240)
    - Paragraph spacing.after = 240 (12pt) uniformly for body bullets.
    - Long body bullets are pre-wrapped at word boundaries into multiple
      paragraphs (split_bullet_text) so the 12pt after-spacing applies
      between wrapped lines too.
    - Annotations render as a floating 9pt blue (#3333FF) DrawingML text box with a `* ` prefix; long ones auto-switch to a trailing ` ┘`
      anchored under the first character of the anchor word. No background,
      no border, wrap = in front of text.
    - Colon-based hanging indent: when a bullet contains " : ", wrapped text
      starts at the character after the colon for structural readability.
    - Tables are indented to start at the same x-position as bullet text.
    - Table header row renders bold + centered (benchmark style).
    - Every table row has a minimum height of 0.8cm (w:trHeight atLeast 454 twips).
    - Closing "- 이  상 -" is RIGHT-aligned, after=180
"""


from __future__ import annotations


import json
import os
import struct
import subprocess
import sys
import zipfile
from datetime import datetime, timedelta, timezone
import io
import re
from pathlib import Path


# Windows 콘솔(cp949)에서 한글 경고·에러 메시지가 깨지거나 UnicodeEncodeError 로
# 죽는 것을 막는다 (check-skill.py / package-skill.py 와 동일한 처리).
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding='utf-8', errors='replace')
    except (AttributeError, ValueError):
        pass


# ---------- Runtime dependency bootstrap ----------------------
SKILL_ROOT = Path(__file__).resolve().parent.parent




def _ensure_deps():
    """Install python-docx if missing (first-run bootstrap for ChatGPT sandbox)."""
    try:
        import docx  # noqa: F401
        return
    except ImportError:
        pass
    req = SKILL_ROOT / 'requirements.txt'
    sys.stderr.write('[sds-word-writer] installing python dependencies (python-docx)...\n')
    cmd = [sys.executable, '-m', 'pip', 'install', '--quiet', '--disable-pip-version-check']
    if req.exists():
        cmd += ['-r', str(req)]
    else:
        cmd += ['python-docx']
    subprocess.check_call(cmd)




_ensure_deps()


from docx import Document  # noqa: E402
from docx.shared import Twips, Pt, Emu, RGBColor  # noqa: E402
from docx.oxml import OxmlElement  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.enum.text import WD_ALIGN_PARAGRAPH  # noqa: E402
from lxml import etree  # noqa: E402




# ---------- Style constants -----------------------------------
FONT_NAMES = {'ascii': '바탕체', 'eastAsia': '바탕체', 'hAnsi': '바탕체'}
WIDTH_PCT = 95
BLUE = '0000FF'
ANNOT_BLUE = '3333FF'   # 이동글틀(주석) 색상 — 첨부 양식 기준 파랑(3333FF)
BLACK = '000000'
SIZE_TITLE = 40   # 20pt (half-points)
SIZE_BODY = 28    # 14pt
SIZE_ANNOT = 18   # 9pt
SIZE_TABLE = 24   # 12pt
TABLE_MIN_ROW_HEIGHT_TWIPS = 454  # 0.8cm minimum row height (atLeast)
SIZE_APPEND = 28  # 14pt


# Character-width presets (DXA = 1/20 pt). Body 14pt 바탕체 + 장체 95%.
BODY_PT = 14
TITLE_PT = 20
FULLWIDTH_DXA = round(BODY_PT * 20 * 1.00 * (WIDTH_PCT / 100))  # ~266
HALFWIDTH_DXA = round(BODY_PT * 20 * 0.50 * (WIDTH_PCT / 100))  # ~133


# Annotation 9pt 바탕체 + 장체 95%
ANNOT_PT = 9
ANNOT_FULLWIDTH_DXA = round(ANNOT_PT * 20 * 1.00 * (WIDTH_PCT / 100))  # ~171
ANNOT_HALFWIDTH_DXA = round(ANNOT_PT * 20 * 0.50 * (WIDTH_PCT / 100))  # ~86


AFTER = {
    'title': 240,
    'date': 360,            # 18pt — new SC template (was 240/12pt)
    'section_heading': 320, # 16pt — "□-바 16pt" (was 240/12pt)
    'body': 240,            # 12pt — default sub-level → sub-level / dash → sub-level
    'body_wrap': 180,       # 9pt — within wrapped bullet
    'last_in_section': 240, # 12pt — last bullet of section (heading carries before=20pt)
    'section_separator': 0, # disabled — heading's `before` carries the 20pt gap
    'annotation': 240,
    'closing': 180,
    'append_label': 240,
}


# Transition-aware spacing (new SC template)
SPACING_DASH_TO_DASH = 320     # 16pt — `- … - …`
SPACING_DASH_TO_SUB = 240      # 12pt — `- …` followed by `· / →` etc.
SPACING_SUB_TO_DASH = 320      # 16pt — sub returning to a top-level dash
SPACING_SUB_TO_SUB = 240       # 12pt — `· …` followed by `·`
SPACING_BEFORE_TABLE = 320     # 16pt — bullet immediately before a table
SPACING_BEFORE_NEXT_SECTION = 400  # 20pt — section heading's `before` (네모-네모 사이)




def _bullet_after_spacing(kind: str, next_kind: str | None) -> int:
    """Compute the trailing `after` (twips) for the *last* line of a bullet,
    based on the kind of bullet that follows. End-of-section uses
    `last_in_section`; the next section heading carries `before=400`."""
    if next_kind is None:
        return AFTER['last_in_section']
    if next_kind == 'table' or next_kind == 'subhead':
        return SPACING_BEFORE_TABLE
    is_top = (kind == 'dash')
    next_is_top = (next_kind == 'dash')
    if is_top and next_is_top:
        return SPACING_DASH_TO_DASH
    if is_top and not next_is_top:
        return SPACING_DASH_TO_SUB
    if not is_top and next_is_top:
        return SPACING_SUB_TO_DASH
    return SPACING_SUB_TO_SUB


PAGE = {
    'width': 11906, 'height': 16838,
    'top': 1134, 'right': 1134, 'bottom': 1134, 'left': 1134,
    'header': 851, 'footer': 510,
}
PAGE_CONTENT_WIDTH = PAGE['width'] - PAGE['left'] - PAGE['right']
PAGE_CONTENT_HEIGHT = PAGE['height'] - PAGE['top'] - PAGE['bottom']
# 인라인 이미지(kind: "image") 높이 상한 — 본문 높이 대비 비율. verify_docx.py 의
# "확대 렌더 의심" 임계값(55%)과 같은 값이라, 생성 단계에서 막으면 검증에서 다시 걸리지 않는다.
IMAGE_MAX_HEIGHT_PCT = 0.55
TWIPS_PER_INCH = 1440
PX_PER_INCH = 96


FLOAT_ANNOT_Y = -240
WRAP_SAFETY_MARGIN = 0.99


# Vertical drop (twips) of an annotation text box below the top of the bullet
# line it is anchored to. The drawing is attached directly to the anchor line
# paragraph (no separate 1pt host paragraph), so this offset places the blue
# 9pt note in the gap just below the anchored line.
# 260909: 300 → 324 (+1.2pt). 사용자가 Word에서 손으로 고친 문서를 계측한 결과,
# `*` 주석·`┘` 주석 모두 본문 글자와 너무 붙어 보여 일관되게 약 1.2pt 내렸다
# (본문 줄과 겹치거나 가려 보이는 현상 방지). 모든 이동글틀에 동일 값을 쓴다 —
# 단락 after 간격과 무관하게 본문 줄 바로 아래 같은 거리에 놓인다.
ANNOT_DROP_DXA = 324
# `* ` 주석의 x 시작점을 앵커 첫 글자보다 살짝(1.2pt) 오른쪽에 둔다. 손수정본에서
# `*` 주석 대부분이 +1.2~+3pt 이동돼 있었다 — 별표가 앵커 글자 왼쪽으로 튀어
# 나온 듯 보이는 것을 막는다.
ANNOT_X_NUDGE_DXA = 24
# `* ` 좌측 정렬 주석이 우측 본문 여백 끝에서 이만큼 안쪽에 끝나지 못하면 `┘` 모드.
ANNOT_RIGHT_SAFETY_DXA = 300
# `* ` 주석이 앵커가 놓인 본문 줄의 글자 끝보다 이만큼(120pt) 이상 오른쪽으로
# 길게 튀어나오면 `┘` 모드로 전환한다 — 짧은 본문 줄 끝의 앵커에 긴 주석이 붙어
# 본문 밖 빈 공간으로 홀로 뻗어 나가는 모양(손수정본에서 모두 `┘`로 바꿈)을 막는다.
ANNOT_MAX_OVERHANG_DXA = 2400
# 260923 손수정본(Meta Muse 서비스 개요) 반영 — 이동글틀 배치 규칙 확장.
# ┘ 모드 박스의 왼쪽 끝은 앵커가 놓인 본문 줄의 글자 시작점(`- ` 뒤)보다 왼쪽으로
# 나가지 않는다. 안 맞으면 ┘ 를 오른쪽으로 옮기고(박스를 본문 글자 시작선에 맞춤),
# 그래도 안 되면 장평을 95 → 85% 까지만 줄인다(가독성 하한). 종전에는 박스가
# x=0(본문 왼쪽 끝)까지 밀려 ┘ 가 아무것도 가리키지 않는 자리에 찍혔다.
# `* ` 모드도 우측 여백에 조금 못 들어올 때는 ┘ 로 바꾸기 전에 같은 장평 단계로
# 먼저 맞춘다 — 모델명·서비스명 소개처럼 앵커 바로 아래 `*` 가 붙는 쪽이 읽기 쉽다.
ANNOT_SCALE_STEPS = (95, 92, 90, 88, 85)
ANNOT_MIN_SCALE_PCT = 85
# 장평을 줄여 맞출 때 주석 글자의 오른쪽 끝이 본문 우측 끝에서 이만큼(3pt) 안쪽이면 통과.
ANNOT_EDGE_SAFETY_DXA = 60
# ┘ 를 오른쪽으로 옮길 때 ┘ 글자 오른쪽 끝이 본문 줄 끝보다 이만큼(10pt)까지는 넘어도 된다.
ANNOT_TAIL_TOLERANCE_DXA = 200
# 표에서 설명 대상(문서 주제) 열을 강조하는 테두리 — 1.5pt(sz=12) 파랑.
TABLE_ACCENT_BORDER_SZ = 12
TABLE_ACCENT_BORDER_COLOR = '0000FF'
# 문서 제목 — 표의 강조 열 자동 판정(제목에 들어 있는 열 머리글)에 쓴다. render_body 가 설정.
DOC_TITLE = [None]


# 입력 JSON 이 있는 디렉터리 — 상대 경로 이미지 해석에 사용 (main 에서 설정).
CONTENT_JSON_DIR = [None]


# ---------- Hanja / symbol normalization ----------------------
# 보고서 본문에는 한자를 사용하지 않는다(요일 포함 모두 한글). 작성 단계에서
# 한자가 섞여 들어와도 최종 산출물에서 제거되도록 렌더 직전에 한글로 치환한다.
_HANJA_TO_HANGUL = {
    # 연/월/일/시 및 요일 (月/日 는 월·요일 모두 한글로 동일 매핑)
    '年': '년', '月': '월', '日': '일', '時': '시', '分': '분', '秒': '초', '週': '주',
    '火': '화', '水': '수', '木': '목', '金': '금', '土': '토',
    # 시점/상태/위치
    '現': '현', '前': '전', '後': '후', '新': '신', '舊': '구', '初': '초', '末': '말', '先': '선',
    '內': '내', '外': '외', '間': '간', '中': '중', '上': '상', '下': '하', '左': '좌', '右': '우',
    '東': '동', '西': '서', '南': '남', '北': '북',
    '有': '유', '無': '무', '非': '비', '未': '미', '可': '가', '不': '불',
    # 정도/규모
    '高': '고', '低': '저', '大': '대', '小': '소', '長': '장', '短': '단', '最': '최',
    '重': '중', '要': '요', '全': '전', '約': '약', '余': '여',
    # 서수/단위/수
    '第': '제', '次': '차', '回': '회', '個': '개', '件': '건', '名': '명', '人': '인',
    '計': '계', '總': '총', '兆': '조', '億': '억', '萬': '만', '千': '천', '百': '백', '十': '십',
    '元': '원', '圓': '원',
    # 회사/조직/지명
    '社': '사', '會': '회', '院': '원', '團': '단', '組': '조', '課': '과', '部': '부',
    '室': '실', '局': '국', '廳': '청', '府': '부', '署': '서', '黨': '당', '店': '점',
    '館': '관', '校': '교', '本': '본', '市': '시', '道': '도', '區': '구', '里': '리',
    '邑': '읍', '面': '면', '村': '촌', '向': '향',
    # 국가 (비교표용 단자 — 한글 한 글자)
    '美': '미', '韓': '한', '中': '중', '英': '영', '印': '인', '獨': '독', '佛': '불',
    # 사업/경영/학술 상용자
    '創': '창', '共': '공', '同': '동', '代': '대', '表': '표', '業': '업', '務': '무',
    '經': '경', '歷': '력', '事': '사', '職': '직', '勤': '근', '工': '공', '場': '장',
    '公': '공', '私': '사', '商': '상', '設': '설', '立': '립', '投': '투', '資': '자',
    '技': '기', '術': '술', '産': '산', '産業': '산업', '研': '연', '究': '구', '開': '개',
    '發': '발', '活': '활', '動': '동', '成': '성', '功': '공', '失': '실', '敗': '패',
    '達': '달', '規': '규', '模': '모', '位': '위', '命': '명', '者': '자', '國': '국',
    '濟': '제', '情': '정', '報': '보', '電': '전', '法': '법', '論': '논', '文': '문',
    '學': '학', '士': '사', '博': '박', '碩': '석', '物': '물', '理': '리', '化': '화',
    '生': '생', '父': '부', '等': '등', '對': '대', '比': '비', '率': '율',
}
_HANJA_TRANS = {ord(k): v for k, v in _HANJA_TO_HANGUL.items() if len(k) == 1}




def normalize_hanja(s):
    """Replace conventional single-character Hanja with Hangul. Width is
    unchanged (both are full-width), so layout/measurement are unaffected."""
    if not s:
        return s
    return s.translate(_HANJA_TRANS)




# 4자리 서기 연도 + '년' → 'YY년 (아포스트로피 + 뒤 2자리). 작성 단계에서 전체
# 연도(2026년, 2030년 등)가 섞여 들어와도 산출물에서는 축약 표기로 통일한다.
_YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?=년)")




def normalize_year(s):
    if not s:
        return s
    return _YEAR_RE.sub(lambda m: "'" + m.group(1)[-2:], s)




# 줄바꿈·탭 등 "하드 브레이크" 제거. 줄바꿈은 생성기가 폭 계산으로 직접
# 수행하므로(split_bullet_text), 작성 단계에서 텍스트 안에 \n 을 넣으면
# 문단 중간이 끊기고 이어지는 줄의 정렬이 깨진다. 일반 공백은 보존한다.
_HARD_BREAK_RE = re.compile('[ \xa0]*[\r\n\t\x0b\x0c\x85\u2028\u2029]+[ \xa0]*')




def collapse_hard_breaks(s, *, where: str | None = None):
    if not s or not _HARD_BREAK_RE.search(s):
        return s
    if where:
        print(f"[WARN] {where} 텍스트에 줄바꿈(\\n)이 들어 있어 공백으로 대체했습니다 — "
              f"줄바꿈은 생성기가 폭 기준으로 자동 처리합니다: {s[:50]!r}", file=sys.stderr)
    return _HARD_BREAK_RE.sub(' ', s).strip()




# 소문자로 시작하는 회사명·고유명사(eBay, iPhone, github 등)는 자동 대문자화
# 대상에서 제외한다 — 첫 글자를 올리면 EBay·Github 처럼 오히려 틀린 표기가
# 된다. 소문자 형태(하이픈 제거 기준)로 비교하며, 문서별 추가는 최상위
# JSON 의 "noAutoCap": ["..."] 로 확장한다(main 에서 주입).
NO_AUTOCAP = {
    # Apple / 기기·OS
    'ebay', 'iphone', 'ipad', 'ipod', 'imac', 'ios', 'ipados', 'macos', 'watchos',
    'tvos', 'airpods', 'airtag', 'macbook',
    # AI·테크 기업/제품
    'xai', 'openai', 'deepseek', 'llama', 'pytorch', 'tensorflow', 'huggingface',
    'github', 'gitlab', 'npm', 'pnpm', 'nvidia', 'arm', 'asml', 'tsmc',
    # 국내 서비스·기업
    'kakao', 'naver', 'coupang', 'toss', 'krafton', 'nexon', 'ncsoft',
    # 바이오·기타 소문자 고유표기
    'mrna', 'dna', 'rna', 'ph',
}
NO_AUTOCAP_EXTRA: set[str] = set()


# 영어 구(句) 안의 기능어는 대문자화하지 않는다 — `The State of AI in 2026` 이
# `The State Of AI In 2026` 으로 바뀌는 것을 막는다. 앞 토큰이 영어 단어일 때만
# 적용하므로, 한글 문장 사이에 단독으로 쓰인 `in`·`to` 같은 단어는 기존 규칙대로
# 첫 글자를 올린다(그런 용례는 사실상 없다).
ENGLISH_FUNCTION_WORDS = {
    'a', 'an', 'the', 'of', 'and', 'or', 'nor', 'but', 'in', 'on', 'at', 'to', 'for',
    'by', 'from', 'with', 'into', 'onto', 'over', 'under', 'per', 'via', 'vs', 'as',
    'is', 'are', 'be', 'up', 'out', 'off', 'than', 'that', 'this', 'not', 'no',
}
_PREV_ENGLISH_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9.'’\-]*[,:;]?\s*$")




def _is_no_autocap(word: str) -> bool:
    key = (word or '').replace('-', '').lower()
    return key in NO_AUTOCAP or key in NO_AUTOCAP_EXTRA




def _is_english_function_word(word: str, before: str) -> bool:
    """`word` 가 영어 기능어이고 바로 앞 토큰도 영어 단어이면 True (구 중간의 of/and/in)."""
    return word.lower() in ENGLISH_FUNCTION_WORDS and bool(_PREV_ENGLISH_TOKEN_RE.search(before))




def normalize_body(s, *, where: str = '본문', autocap: bool = True):
    """Body-text normalization:
    0. 줄바꿈(\\n)·탭 → 공백 (collapse_hard_breaks)
    1. 한자 → 한글 (normalize_hanja)
    2. ASCII ~ → fullwidth ∼ (U+223C)
    3. M.D일 / M.DD일 → M/D일  (예: 7.6일 → 7/6일)
    4. 문장 내 전체-소문자 단독 영어 단어(하이픈 포함)의 첫 글자를 대문자로
       (예: scale-up → Scale-up, frontier → Frontier)
       이미 대문자 혼합인 단어(Inference, GPU, OpenAI)와 NO_AUTOCAP 에 등록된
       소문자 고유명사(eBay, iPhone, github …)는 건드리지 않음.
       `autocap=False` 면 4번만 건너뛴다 — 섹션 제목·소제목은 제품명/코드명/API
       이름이 그대로 오는 자리라 `horizontal_flow → Horizontal_flow` 처럼 잘못
       고쳐 쓰는 쪽이 손해다. 한자 변환 등 나머지 규칙은 제목에도 그대로 적용된다.
    Applied only to body / heading / cell / title text — never to annotation URLs."""
    if not s:
        return s
    s = collapse_hard_breaks(s, where=where)
    result = normalize_year(normalize_hanja(s)).replace('~', '\u223C').replace('\uC5D0\uC774\uC804\uD2B8', 'Agent')
    # M.D일 / M.DD일 → M/D일
    import re as _re
    result = _re.sub(r'\b(\d{1,2})\.(\d{1,2})일', r'\1/\2일', result)
    # 단독 소문자 영어 단어 첫 글자 대문자화
    # 앞이 공백·※·(··,|문장 시작에 오는 전체소문자 영어 단어 (하이픈 포함)
    def _cap(m):
        word = m.group(2)
        # 회사명·고유명사(eBay, iPhone, github, xAI …)는 대문자화 대상에서 제외 —
        # 첫 글자만 올리면 EBay·Github 처럼 오히려 틀린 표기가 된다.
        if _is_no_autocap(word):
            return m.group(0)
        # 영어 구 안의 기능어(of/and/in/the …)는 앞 토큰이 영어일 때 그대로 둔다.
        if _is_english_function_word(word, m.string[:m.start()]):
            return m.group(0)
        letters = word.replace('-', '')
        if letters and letters == letters.lower() and letters.isalpha():
            return m.group(1) + word[0].upper() + word[1:]
        return m.group(0)
    # 뒤에 영숫자가 이어지면(= 단어가 아직 안 끝났으면) 건드리지 않는다 —
    # eBay·iOS·xAI·mRNA 처럼 소문자로 시작하는 혼합 대소문자 고유명사가
    # EBay·IOS·XAI·MRNA 로 망가지는 것을 막는다.
    # 밑줄이 붙은 토큰(snake_case)은 코드·API·설정 이름이므로 제외한다.
    # `horizontal_flow` 의 `horizontal` 만 잘라 대문자로 만드는 일을 막는다.
    if autocap:
        result = _re.sub(r'((?:^|(?<=[\s※(·,])))((?:[a-z][a-z0-9]*(?:-[a-z][a-z0-9]*)*))(?![A-Za-z0-9_])',
                         _cap, result)
    return result


# Current body line value (240 = single). render_section may temporarily lower
# this (e.g. 223 ≈ 93%) to compress a page so a 1~2-line overflow fits — see
# the "page-fit" guidance in SKILL.md. Restored after each section.
BODY_LINE = [240]
LINE_COMPRESSED = 223   # ≈ 93% — 첨부 양식의 페이지 압축 줄간격 기준값


# EMU / DXA conversion for DrawingML (1 inch = 914400 EMU = 1440 DXA)
EMU_PER_DXA = 635
ANNOT_TEXTBOX_HEIGHT_DXA = 260      # single-line 9pt text box height (a bit > line=200)
ANNOT_TEXTBOX_Y_OFFSET_DXA = -240   # pull the frame up so it overlays the anchor bullet line


_DRAWING_ID_COUNTER = [1000]




def _next_drawing_id() -> int:
    _DRAWING_ID_COUNTER[0] += 1
    return _DRAWING_ID_COUNTER[0]




def _emu_from_dxa(dxa: int) -> int:
    return int(round(dxa * EMU_PER_DXA))


PREFIX = {
    'dash':  '  - ',
    'dot':   '    \u00B7',
    'wrap':  '      ',
    'note':  '  \u203B ',
    'arrow': '  \u2192 ',
}
CIRCLED = ['\u2460', '\u2461', '\u2462', '\u2463', '\u2464',
           '\u2465', '\u2466', '\u2467', '\u2468', '\u2469']


# \ubd88\ub9bf \uc885\ub958\uac00 \uc790\ub3d9\uc73c\ub85c \ubd99\uc774\ub294 \ub9c8\ucee4\ub97c \uc791\uc131 \ub2e8\uacc4\uc5d0\uc11c \ud14d\uc2a4\ud2b8 \uc55e\uc5d0 \ud55c \ubc88 \ub354 \uc4f0\uba74
# `  \u2192 \u2192 \u2026` / `  \u203b \u203b \u2026` \ucc98\ub7fc \ub9c8\ucee4\uac00 \ub450 \ubc88 \ucc0d\ud78c\ub2e4. \ub80c\ub354 \uc9c1\uc804\uc5d0 \uc120\ud589
# \uc911\ubcf5 \ub9c8\ucee4\ub97c \uc81c\uac70\ud55c\ub2e4.
#   arrow / note : \ubb38\uc7a5\uc774 \uc774 \uae30\ud638\ub85c \uc2dc\uc791\ud560 \uc774\uc720\uac00 \uc5c6\uc73c\ubbc0\ub85c \ubb34\uc870\uac74 \uc81c\uac70
#   dash  / dot  : \ub4a4\uc5d0 \uacf5\ubc31\uc774 \ub530\ub77c\uc62c \ub54c\ub9cc \uc81c\uac70 (`-5%` \uac19\uc740 \uac12 \ud45c\uae30\ub294 \ubcf4\uc874)
# `wrap` \uc740 \uc81c\uc678 \u2014 \uc811\uae30 \uc904\uc5d0\uc11c `\u2192 \u2026` \ub85c \uc2dc\uc791\ud558\ub294 \uac83\uc774 \uc815\uc0c1 \uc6a9\ubc95\uc774\ub2e4.
_DUP_MARKERS = {
    'arrow': ('\u2192', '=>', '->'),
    'note':  ('\u203b',),
    'dash':  ('-', '\u2013', '\u2014'),
    'dot':   ('\u00b7', '\u2022'),
}
_DUP_MARKERS_NEED_SPACE = {'dash', 'dot'}




def strip_duplicate_marker(kind, text):
    markers = _DUP_MARKERS.get(kind or '')
    if not markers or not text:
        return text
    out, changed = text.lstrip(), False
    while True:
        for mk in markers:
            if not out.startswith(mk):
                continue
            rest = out[len(mk):]
            if kind in _DUP_MARKERS_NEED_SPACE and rest[:1] not in (' ', '\u00a0'):
                continue
            out, changed = rest.lstrip(), True
            break
        else:
            break
    if changed:
        print(f"[WARN] '{kind}' \ubd88\ub9bf \ud14d\uc2a4\ud2b8\uac00 \ub9c8\ucee4\ub85c \uc2dc\uc791\ud574 \ub9c8\ucee4\uac00 \uc911\ubcf5 \ucd9c\ub825\ub429\ub2c8\ub2e4 \u2014 "
              f"\uc120\ud589 \ub9c8\ucee4\ub97c \uc81c\uac70\ud588\uc2b5\ub2c8\ub2e4(\ub9c8\ucee4\ub294 \uc0dd\uc131\uae30\uac00 \uc790\ub3d9\uc73c\ub85c \ubd99\uc785\ub2c8\ub2e4): {text[:50]!r}",
              file=sys.stderr)
    return out




# ---------- Low-level XML helpers -----------------------------
def _qn(name: str) -> str:
    """Qualified name helper: '_qn("val")' => w:val."""
    return qn('w:' + name) if ':' not in name else qn(name)




def _make(tag: str, **attrs) -> OxmlElement:
    """Create an OxmlElement with the given attrs. Keys default to w:<key>.


    Tag accepts either 'rFonts' (auto-prefixed to 'w:rFonts') or 'w:rFonts'.
    """
    if ':' not in tag:
        tag = 'w:' + tag
    el = OxmlElement(tag)
    for k, v in attrs.items():
        el.set(_qn(k), str(v))
    return el




def _set_attr(el, name: str, value) -> None:
    el.set(_qn(name), str(value))




# ---------- Unicode / measurement -----------------------------
def is_fullwidth(code: int) -> bool:
    """Matches the JS isFullwidth() — CJK / Hangul / wide punctuation set."""
    return (
        (0x1100 <= code <= 0x115F) or
        (0x2E80 <= code <= 0x303E) or
        (0x3041 <= code <= 0x33FF) or
        (0x3400 <= code <= 0x4DBF) or
        (0x4E00 <= code <= 0x9FFF) or
        (0xA000 <= code <= 0xA4CF) or
        (0xAC00 <= code <= 0xD7A3) or
        (0xF900 <= code <= 0xFAFF) or
        (0xFE30 <= code <= 0xFE4F) or
        (0xFF00 <= code <= 0xFF60) or
        (0xFFE0 <= code <= 0xFFE6) or
        code == 0x00B7 or
        code == 0x203B or
        (0x2500 <= code <= 0x257F) or   # 박스 문자(┘ 등) — 바탕체에서 전각


        code == 0x223C or
        (0x2014 <= code <= 0x2015) or
        (0x2190 <= code <= 0x21FF) or
        (0x25A0 <= code <= 0x25FF) or
        (0x2460 <= code <= 0x24FF)
    )




def measure_dxa(s: str, scale: int = WIDTH_PCT) -> int:
    """Measure string width in DXA. `scale` is character-width percent (장평).


    Fast path when scale == WIDTH_PCT uses precomputed constants; otherwise
    recomputes per-char widths for the requested scale.
    """
    if scale == WIDTH_PCT:
        dxa = 0
        for ch in s or '':
            dxa += FULLWIDTH_DXA if is_fullwidth(ord(ch)) else HALFWIDTH_DXA
        return dxa
    full = round(BODY_PT * 20 * 1.00 * (scale / 100))
    half = round(BODY_PT * 20 * 0.50 * (scale / 100))
    dxa = 0
    for ch in s or '':
        dxa += full if is_fullwidth(ord(ch)) else half
    return dxa




def measure_annot_dxa(s: str, scale: int = WIDTH_PCT) -> int:
    """이동글틀(9pt) 글자 폭(DXA). `scale` 은 장평(%) — 기본 95, 배치 계획이 줄일 때 85까지."""
    if scale == WIDTH_PCT:
        full, half = ANNOT_FULLWIDTH_DXA, ANNOT_HALFWIDTH_DXA
    else:
        full = round(ANNOT_PT * 20 * 1.00 * (scale / 100))
        half = round(ANNOT_PT * 20 * 0.50 * (scale / 100))
    dxa = 0
    for ch in s or '':
        dxa += full if is_fullwidth(ord(ch)) else half
    return dxa


def measure_title_dxa(s: str, scale: int = WIDTH_PCT) -> int:
    full = round(TITLE_PT * 20 * 1.00 * (scale / 100))
    half = round(TITLE_PT * 20 * 0.50 * (scale / 100))
    dxa = 0
    for ch in s or '':
        dxa += full if is_fullwidth(ord(ch)) else half
    return dxa




def compute_anchor_indent_dxa(prefix: str, text: str, anchor: str | None) -> int:
    if not anchor:
        return 0
    idx = (text or '').find(anchor)
    if idx < 0:
        return 0
    return measure_dxa((prefix or '') + (text or '')[:idx])




def anchor_indent_or_warn(prefix: str, text: str, anchor: str | None, *,
                          where: str, fallback_dxa: int) -> int:
    """`anchor` 가 본문에 실제로 없으면 경고하고 `fallback_dxa`(본문 텍스트
    시작점)로 떨어뜨린다. 그대로 두면 dxa 0 — 즉 본문보다 왼쪽으로 튀어나온
    위치 — 에 이동글틀이 붙어 정렬이 깨진 것처럼 보인다."""
    if anchor and anchor not in (text or ''):
        print(f"[WARN] 이동글틀 anchor {anchor!r} 를 {where}에서 찾지 못했습니다 — "
              f"본문 시작점에 배치합니다. 본문: {(text or '')[:45]!r}", file=sys.stderr)
        return fallback_dxa
    return compute_anchor_indent_dxa(prefix, text, anchor)




def hanging_indent_for(prefix: str, text: str):
    """Returns dict {'left': DXA, 'hanging': DXA} or None.


    Colon-based indent: when text contains ' : ', hang at character-after-colon
    (only if that point lies within 55% of page content width).
    """
    if text:
        idx = text.find(' : ')
        if idx >= 0:
            colon_end = idx + 3
            full_prefix = prefix + text[:colon_end]
            dxa = measure_dxa(full_prefix)
            if dxa < PAGE_CONTENT_WIDTH * 0.55:
                return {'left': dxa, 'hanging': dxa}
    dxa = measure_dxa(prefix)
    if dxa <= 0:
        return None
    return {'left': dxa, 'hanging': dxa}




def _strip_anchor_label(text, anchor):
    """If an annotation begins with the explained term followed by a colon
    (e.g. '추론 : 학습 …' with anchor '추론'), drop that leading label so the
    box shows the definition only ('학습 …'). Secondary terms inside the note
    (e.g. '… / Trainium : …') are left untouched."""
    if not text:
        return text
    t = text.strip()
    if anchor:
        a = str(anchor).strip()
        if a and t.startswith(a):
            rest = t[len(a):].lstrip()
            if rest.startswith(':'):
                return rest[1:].lstrip()
    return t




def normalize_annotation(annotation):
    if not annotation:
        return None
    if isinstance(annotation, str):
        return {'text': collapse_hard_breaks(annotation, where='이동글틀'), 'anchor': None}
    if isinstance(annotation, dict):
        anchor = annotation.get('anchor') or None
        return {
            'text': collapse_hard_breaks(annotation.get('text', ''), where='이동글틀'),
            # anchor 는 본문 문자열과 일치해야 하므로 본문과 동일하게 정리한다.
            'anchor': collapse_hard_breaks(anchor) if anchor else None,
            'highlight': annotation.get('highlight') is True,
        }
    return None




def split_bullet_text(prefix: str, text: str, first_line_capacity: int, continuation_capacity: int,
                      prefix_scale: int = WIDTH_PCT, text_scale: int = WIDTH_PCT,
                      char_spacing_twips: int = 0):
    """Pre-wrap text at word boundaries (see JS splitBulletText).


    Returns list of line strings; each line becomes its own paragraph so the
    12pt after-spacing applies between wrapped lines.


    `prefix_scale` / `text_scale` let the caller measure prefix (bullet mark)
    and sentence body at different character-width percents — used by the
    auto widow-fix pass which shrinks only the body's 장평.


    `char_spacing_twips`: character spacing in 1/20pt units (negative = tighter).
    When non-zero, each character occupies (char_dxa + char_spacing_twips) width,
    effectively widening/narrowing the line capacity for wrapping purposes.
    """
    src = text or ''
    prefix_dxa = measure_dxa(prefix or '', prefix_scale)


    def _measure_with_spacing(s: str, scale: int) -> int:
        """Measure text width accounting for char_spacing_twips."""
        if not char_spacing_twips:
            return measure_dxa(s, scale)
        base = measure_dxa(s, scale)
        # char_spacing applies between characters (n chars → n inter-char gaps
        # actually n-1 gaps, but Word applies it per-character including last)
        n = len(s or '')
        return base + n * char_spacing_twips


    if prefix_dxa + _measure_with_spacing(src, text_scale) <= first_line_capacity:
        return [src]
    words = [w for w in re.split(r' +', src) if w]
    if len(words) <= 1:
        return [src]


    lines = []
    cur: list[str] = []
    cur_dxa = 0
    cap = first_line_capacity - prefix_dxa


    def flush():
        nonlocal cur, cur_dxa, cap
        lines.append(' '.join(cur))
        cur = []
        cur_dxa = 0
        cap = continuation_capacity


    space_dxa = round(BODY_PT * 20 * 0.50 * (text_scale / 100))
    if char_spacing_twips:
        space_dxa += char_spacing_twips  # space character also gets spacing
    for word in words:
        w_dxa = _measure_with_spacing(word, text_scale)
        delta = (space_dxa + w_dxa) if cur else w_dxa
        if cur and cur_dxa + delta > cap:
            flush()
            cur.append(word)
            cur_dxa = w_dxa
        else:
            cur.append(word)
            cur_dxa += delta
    if cur:
        flush()
    return lines




def _last_line_is_widow(lines) -> bool:
    """Return True if the bullet wrapped to ≥2 lines and the final line has
    only 1–2 whitespace-separated words (typical widow pattern).
    """
    if not lines or len(lines) < 2:
        return False
    last = (lines[-1] or '').strip()
    if not last:
        return False
    words = [w for w in last.split() if w]
    return len(words) <= 2




def _last_line_is_single_word_widow(lines) -> bool:
    """Return True only when the last line has exactly 1 word — tighter criterion
    used for character-spacing fix (요청: 1개 단어만 다음 줄로 밀릴 경우)."""
    if not lines or len(lines) < 2:
        return False
    last = (lines[-1] or '').strip()
    if not last:
        return False
    words = [w for w in last.split() if w]
    return len(words) == 1




# ---------- Image header parsing (no Pillow needed) -----------
def read_png_size(buf: bytes):
    if len(buf) < 24 or buf[1:4] != b'PNG':
        return None
    width = struct.unpack('>I', buf[16:20])[0]
    height = struct.unpack('>I', buf[20:24])[0]
    return {'width': width, 'height': height}




def read_jpeg_size(buf: bytes):
    if len(buf) < 4 or buf[0] != 0xFF or buf[1] != 0xD8:
        return None
    offset = 2
    n = len(buf)
    while offset + 9 < n:
        if buf[offset] != 0xFF:
            offset += 1
            continue
        marker = buf[offset + 1]
        if marker in (0xD8, 0xD9):
            offset += 2
            continue
        length = struct.unpack('>H', buf[offset + 2:offset + 4])[0]
        if length < 2 or offset + 2 + length > n:
            return None
        is_sof = (
            0xC0 <= marker <= 0xC3 or
            0xC5 <= marker <= 0xC7 or
            0xC9 <= marker <= 0xCB or
            0xCD <= marker <= 0xCF
        )
        if is_sof:
            height = struct.unpack('>H', buf[offset + 5:offset + 7])[0]
            width = struct.unpack('>H', buf[offset + 7:offset + 9])[0]
            return {'width': width, 'height': height}
        offset += 2 + length
    return None




def read_image_size(path: str, buf: bytes):
    ext = os.path.splitext(path)[1].lower()
    if ext == '.png':
        return read_png_size(buf)
    if ext in ('.jpg', '.jpeg'):
        return read_jpeg_size(buf)
    return None




def twips_to_px(twips: int) -> int:
    return round((twips / TWIPS_PER_INCH) * PX_PER_INCH)




def image_dimensions(bullet: dict, path: str, buf: bytes):
    intrinsic = read_image_size(path, buf)
    width = bullet.get('width') or bullet.get('widthPx') or (intrinsic and intrinsic.get('width'))
    height = bullet.get('height') or bullet.get('heightPx') or (intrinsic and intrinsic.get('height'))
    if width and not height and intrinsic and intrinsic.get('width') and intrinsic.get('height'):
        height = round(width * intrinsic['height'] / intrinsic['width'])
    elif height and not width and intrinsic and intrinsic.get('width') and intrinsic.get('height'):
        width = round(height * intrinsic['width'] / intrinsic['height'])
    elif not width or not height:
        width = (intrinsic and intrinsic.get('width')) or 600
        height = (intrinsic and intrinsic.get('height')) or 300
    max_width = max(120, round(twips_to_px(PAGE_CONTENT_WIDTH) * (bullet.get('maxWidthPct') or 0.92)))
    if width > max_width:
        scale = max_width / width
        width = round(width * scale)
        height = round(height * scale)
    # 세로로 긴 도표가 페이지를 덮는 "확대 렌더"를 생성 단계에서 막는다 — 본문 높이의
    # 55%(IMAGE_MAX_HEIGHT_PCT) 를 넘으면 비율을 유지한 채 줄인다. `maxHeightPct` 로 조정.
    max_height = max(120, round(twips_to_px(PAGE_CONTENT_HEIGHT)
                                * float(bullet.get('maxHeightPct') or IMAGE_MAX_HEIGHT_PCT)))
    if height > max_height:
        scale = max_height / height
        width = round(width * scale)
        height = round(height * scale)
        print(f"[INFO] 이미지 높이가 본문 높이의 {max_height / twips_to_px(PAGE_CONTENT_HEIGHT):.0%} 를 넘어 "
              f"{width}x{height}px 로 축소했습니다: {os.path.basename(path)}", file=sys.stderr)
    return width, height




def resolve_image_path(image_path: str) -> str:
    if not image_path:
        raise ValueError('Image bullet requires "path".')
    return image_path if os.path.isabs(image_path) else os.path.abspath(image_path)




# ---------- Run / paragraph primitives ------------------------
def _set_run_font(rpr, font_names=FONT_NAMES):
    fonts = _make('rFonts',
                  ascii=font_names['ascii'],
                  eastAsia=font_names['eastAsia'],
                  hAnsi=font_names['hAnsi'])
    # also set cs (complex script) to match
    fonts.set(_qn('cs'), font_names['ascii'])
    rpr.append(fonts)




def _set_run_props(r_element, *, size=SIZE_BODY, color=BLACK, bold=False,
                   underline=False, scale=WIDTH_PCT, character_spacing=None,
                   highlight=False):
    """Attach rPr to a w:r element with SDS-standard run properties."""
    rpr = r_element.find(_qn('rPr'))
    if rpr is None:
        rpr = _make('rPr')
        r_element.insert(0, rpr)
    else:
        # clear to avoid duplicates
        for child in list(rpr):
            rpr.remove(child)


    _set_run_font(rpr)
    if bold:
        rpr.append(_make('b'))
        rpr.append(_make('bCs'))
    if underline:
        rpr.append(_make('u', val='single'))
    rpr.append(_make('color', val=color))
    rpr.append(_make('sz', val=size))
    rpr.append(_make('szCs', val=size))
    rpr.append(_make('w', val=scale))
    if character_spacing is not None:
        rpr.append(_make('spacing', val=character_spacing))
    if highlight:
        # 수정/보완 모드: 변경된 본문을 노란색 형광펜으로 표시
        rpr.append(_make('highlight', val='yellow'))




def make_run(text: str, *, size=SIZE_BODY, color=BLACK, bold=False,
             underline=False, scale=WIDTH_PCT, character_spacing=None,
             highlight=False) -> OxmlElement:
    r = _make('r')
    _set_run_props(r, size=size, color=color, bold=bold, underline=underline,
                   scale=scale, character_spacing=character_spacing,
                   highlight=highlight)
    t = _make('t')
    t.set(qn('xml:space'), 'preserve')
    t.text = normalize_hanja(text or '')
    r.append(t)
    return r



def make_annot_run(text: str, prefix_star: bool = True) -> OxmlElement:
    # 첨부 양식: 주석은 파랑(3333FF), '* ' (별표 + 한 칸) prefix.
    t = (text or '').lstrip('* ').strip() if (text or '').startswith('*') else (text or '')
    if prefix_star:
        t = '* ' + t
    return make_run(t, size=SIZE_ANNOT, color=ANNOT_BLUE, scale=WIDTH_PCT)




_ALIGN = {
    'left': 'left',
    'right': 'right',
    'center': 'center',
    'both': 'both',
}




def _apply_p_properties(p_element, *, alignment=None, line=240, line_rule='auto',
                        before=None, after=None, indent=None, frame=None,
                        keep_bold_empty=False):
    """Append a pPr to a w:p element with the given properties."""
    pPr = p_element.find(_qn('pPr'))
    if pPr is None:
        pPr = _make('pPr')
        p_element.insert(0, pPr)
    # We do NOT pre-inject autoSpaceDE/DN here — postProcessAutoSpace adds them.
    # Frame first if present
    if frame is not None:
        pPr.append(frame)
    if alignment in _ALIGN:
        pPr.append(_make('jc', val=_ALIGN[alignment]))
    spacing_attrs = {}
    if line is not None:
        spacing_attrs['line'] = line
        spacing_attrs['lineRule'] = line_rule
    if before is not None:
        spacing_attrs['before'] = before
    if after is not None:
        spacing_attrs['after'] = after
    if spacing_attrs:
        pPr.append(_make('spacing', **spacing_attrs))
    if indent is not None:
        ind_attrs = {}
        if 'left' in indent and indent['left']:
            ind_attrs['left'] = indent['left']
        if 'hanging' in indent and indent['hanging']:
            ind_attrs['hanging'] = indent['hanging']
        if 'firstLine' in indent and indent['firstLine']:
            ind_attrs['firstLine'] = indent['firstLine']
        if ind_attrs:
            pPr.append(_make('ind', **ind_attrs))
    if keep_bold_empty:
        # rPr on pPr affects paragraph mark only — used for bold empty separators.
        rpr = _make('rPr')
        rpr.append(_make('b'))
        pPr.append(rpr)




def make_paragraph(runs, *, alignment=None, line=240, line_rule='auto',
                   before=None, after=None, indent=None, frame=None,
                   keep_bold_empty=False) -> OxmlElement:
    p = _make('p')
    _apply_p_properties(p, alignment=alignment, line=line, line_rule=line_rule,
                        before=before, after=after, indent=indent, frame=frame,
                        keep_bold_empty=keep_bold_empty)
    for r in (runs or []):
        p.append(r)
    return p




def body_paragraph(text: str, *, alignment=None, after=AFTER['body'],
                   before=None, size=SIZE_BODY, color=BLACK, indent=None,
                   bold=False, underline=False, scale=WIDTH_PCT) -> OxmlElement:
    r = make_run(text, size=size, color=color, bold=bold, underline=underline, scale=scale)
    return make_paragraph([r], alignment=alignment, line=BODY_LINE[0], line_rule='auto',
                          before=before, after=after, indent=indent)




# ---------- Annotation paragraphs -----------------------------
_NS_W  = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
_NS_WP = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
_NS_A  = 'http://schemas.openxmlformats.org/drawingml/2006/main'
_NS_WPS = 'http://schemas.microsoft.com/office/word/2010/wordprocessingShape'




def _xml_escape(s: str) -> str:
    return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')




def _build_annotation_drawing(text: str, *, indent_dxa: int, long_mode: bool = False,
                              y_dxa: int = ANNOT_DROP_DXA, highlight: bool = False,
                              line_start_dxa: int | None = None,
                              line_end_dxa: int | None = None):
    """Build a w:drawing element containing a DrawingML text box (텍스트 상자).


    - 배경 없음 (a:noFill), 테두리 없음 (a:ln/a:noFill)
    - 텍스트 줄 바꿈: 텍스트 앞 (wp:wrapNone + behindDoc="0")
    - 9pt 파랑(3333FF), 장체 95%
    - 일반(normal) 모드: 용어 바로 아래에 `* ` (별표 + 한 칸) prefix 로 표기, 좌측을
      anchor 용어 시작점(indent_dxa)에 정렬.
    - long_mode: 주석이 길어 anchor 위치에서 좌측 정렬하면 우측 여백을 넘는 경우.
      `* ` prefix 대신 끝에 ` ┘` 를 붙이고, 박스를 좌측으로 밀어 **┘ 글자가 anchor
      단어 시작점(indent_dxa) 바로 아래**에 오도록 배치한다(텍스트는 좌측으로 흐름).
    - y_dxa: anchor 라인 단락 상단으로부터의 수직 오프셋(아래로). 주석이 anchor 라인
      바로 아래 여백에 놓이도록 한다.
    - line_start_dxa / line_end_dxa: 앵커가 놓인 본문 줄의 글자 시작·끝 x. 주어지면
      `plan_annotation_layout` 이 `*`/┘ 모드·x·장평을 한 번에 정한다 (260923). `long_mode`
      는 이때 힌트일 뿐이며 계획이 우선한다.
    """
    ann_text = (text or '').lstrip('* ').strip() if (text or '').startswith('*') else (text or '')
    # 이동글틀 텍스트에도 한자·영어 대문자·물결표 정규화를 적용한다.
    # 단, URL 은 문자열 내 위치와 무관하게 원문 그대로 보존한다 — `* 출처 : CNBC (https://...)`
    # 처럼 URL이 중간에 오는 표준 출처 형식에서 https → Https 로 대문자화되는 것을 막는다.
    _parts, _last = [], 0
    for _m in re.finditer(r'https?://\S+', ann_text):
        _parts.append(normalize_body(ann_text[_last:_m.start()]))
        _parts.append(normalize_hanja(_m.group(0)))
        _last = _m.end()
    _parts.append(normalize_body(ann_text[_last:]))
    ann_text = ''.join(_parts)
    plan = plan_annotation_layout(ann_text, indent_dxa, line_start_dxa, line_end_dxa,
                                  long_hint=long_mode)
    display_text = plan['display_text']
    x_dxa = plan['x_dxa']
    frame_width_dxa = plan['frame_width_dxa']
    scale_pct = plan['scale_pct']


    width_emu = _emu_from_dxa(frame_width_dxa)
    height_emu = _emu_from_dxa(ANNOT_TEXTBOX_HEIGHT_DXA)
    x_emu = _emu_from_dxa(x_dxa)
    y_emu = _emu_from_dxa(y_dxa)


    drawing_id = _next_drawing_id()
    escaped = _xml_escape(display_text)
    # 수정/보완 모드: 추가·수정된 이동글틀은 노란 형광펜으로 표시
    hl_tag = '<w:highlight w:val="yellow"/>' if highlight else ''


    xml = f'''<w:drawing xmlns:w="{_NS_W}" xmlns:wp="{_NS_WP}" xmlns:a="{_NS_A}" xmlns:wps="{_NS_WPS}">
  <wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0"
             relativeHeight="{251659000 + drawing_id}" behindDoc="0"
             locked="0" layoutInCell="1" allowOverlap="1">
    <wp:simplePos x="0" y="0"/>
    <wp:positionH relativeFrom="column"><wp:posOffset>{x_emu}</wp:posOffset></wp:positionH>
    <wp:positionV relativeFrom="paragraph"><wp:posOffset>{y_emu}</wp:posOffset></wp:positionV>
    <wp:extent cx="{width_emu}" cy="{height_emu}"/>
    <wp:effectExtent l="0" t="0" r="0" b="0"/>
    <wp:wrapNone/>
    <wp:docPr id="{drawing_id}" name="Annotation {drawing_id}"/>
    <wp:cNvGraphicFramePr/>
    <a:graphic>
      <a:graphicData uri="{_NS_WPS}">
        <wps:wsp>
          <wps:cNvSpPr txBox="1"/>
          <wps:spPr>
            <a:xfrm>
              <a:off x="0" y="0"/>
              <a:ext cx="{width_emu}" cy="{height_emu}"/>
            </a:xfrm>
            <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
            <a:noFill/>
            <a:ln><a:noFill/></a:ln>
          </wps:spPr>
          <wps:txbx>
            <w:txbxContent>
              <w:p>
                <w:pPr>
                  <w:spacing before="0" after="0" line="200" lineRule="exact"/>
                  <w:rPr>
                    <w:rFonts w:ascii="바탕체" w:eastAsia="바탕체" w:hAnsi="바탕체" w:cs="바탕체"/>
                    <w:color w:val="{ANNOT_BLUE}"/>
                    <w:sz w:val="{SIZE_ANNOT}"/>
                    <w:szCs w:val="{SIZE_ANNOT}"/>
                    <w:w w:val="{scale_pct}"/>
                  </w:rPr>
                </w:pPr>
                <w:r>
                  <w:rPr>
                    <w:rFonts w:ascii="바탕체" w:eastAsia="바탕체" w:hAnsi="바탕체" w:cs="바탕체"/>
                    <w:color w:val="{ANNOT_BLUE}"/>
                    <w:sz w:val="{SIZE_ANNOT}"/>
                    <w:szCs w:val="{SIZE_ANNOT}"/>
                    <w:w w:val="{scale_pct}"/>
                    {hl_tag}
                  </w:rPr>
                  <w:t xml:space="preserve">{escaped}</w:t>
                </w:r>
              </w:p>
            </w:txbxContent>
          </wps:txbx>
          <wps:bodyPr rot="0" spcFirstLastPara="0" vertOverflow="overflow"
                      horzOverflow="overflow" wrap="square"
                      lIns="0" tIns="0" rIns="0" bIns="0"
                      anchor="t" anchorCtr="0">
            <a:noAutofit/>
          </wps:bodyPr>
        </wps:wsp>
      </a:graphicData>
    </a:graphic>
  </wp:anchor>
</w:drawing>'''
    return etree.fromstring(xml)




def _build_source_url_drawing(text: str, *, y_dxa: int = 471, x_dxa: int = 0, width_dxa: int | None = None):
    """Build a DrawingML text box for the source URL under the title.


    URL is displayed in a floating textbox directly below the title, left edge
    aligned to the title text when it fits. **URL 전체가 항상 보이도록** 폭을 맞춘다:


    1. 필요 폭(`* 출처 : {url}` 실측 + 여백)이 제목 왼쪽 끝에서 본문 폭 안에 들어오면
       그대로 제목 왼쪽에 정렬.
    2. 안 들어오면 박스를 **왼쪽으로 밀어**(x 축소) 본문 폭 안에 넣는다.
    3. 본문 폭보다도 길면 장평(`w:w`)을 95% → 최소 75%까지 줄여 한 줄에 맞춘다.
    4. 그래도 길면 두 줄 박스(높이 2배)로 감싼다 — 잘리는 일은 없다.


    y_dxa: 제목 단락 상단(paragraph 기준)으로부터의 수직 오프셋. 기본값 471 DXA로,
    제목 글자 바로 아래에 붙여 표시한다(제목과 겹치지 않는 최소 간격).
    (wrap=none + behindDoc=0)


    출처 URL은 `* 출처 : {url}` 형식으로 렌더한다. 입력에 선행 '출처 :' 라벨이
    이미 있으면 중복 제거 후 다시 붙인다.
    """
    body = (text or '').strip()
    for _pre in ('출처 : ', '출처: ', '출처 :', '출처:'):
        if body.startswith(_pre):
            body = body[len(_pre):].strip()
            break
    display_text = '* 출처 : ' + body
    escaped = _xml_escape(display_text)
    padding_dxa = 240
    needed_dxa = measure_annot_dxa(display_text) + padding_dxa
    scale_pct = WIDTH_PCT
    lines_n = 1
    x_dxa = max(0, int(x_dxa))
    if needed_dxa <= PAGE_CONTENT_WIDTH - x_dxa:
        frame_width_dxa = needed_dxa                       # 1) 제목 왼쪽 정렬 그대로
    elif needed_dxa <= PAGE_CONTENT_WIDTH:
        frame_width_dxa = needed_dxa                       # 2) 왼쪽으로 밀어 넣기
        x_dxa = PAGE_CONTENT_WIDTH - needed_dxa
    else:
        x_dxa = 0
        frame_width_dxa = PAGE_CONTENT_WIDTH
        # 3) 장평 축소 — 글자 간격을 좁혀서라도 한 줄에 보이게 한다.
        fit = int(WIDTH_PCT * PAGE_CONTENT_WIDTH / needed_dxa)
        if fit >= 75:
            scale_pct = fit
        else:
            scale_pct = 75                                 # 4) 두 줄 박스
            lines_n = 2
        print(f"[INFO] 출처 URL이 본문 폭보다 길어 장평 {scale_pct}%"
              f"{' · 2줄' if lines_n == 2 else ''}로 맞췄습니다: {body[:60]}", file=sys.stderr)
    if width_dxa is not None:
        # 호출자가 준 폭은 하한으로만 쓴다 — 전체 URL이 보이는 폭보다 좁히지 않는다.
        frame_width_dxa = max(frame_width_dxa, min(int(width_dxa), PAGE_CONTENT_WIDTH - x_dxa))
    frame_width_dxa = max(1200, min(frame_width_dxa, PAGE_CONTENT_WIDTH - x_dxa))
    width_emu = _emu_from_dxa(frame_width_dxa)
    height_emu = _emu_from_dxa(ANNOT_TEXTBOX_HEIGHT_DXA * lines_n)
    x_emu = _emu_from_dxa(x_dxa)
    y_emu = _emu_from_dxa(y_dxa)
    drawing_id = _next_drawing_id()


    xml = f'''<w:drawing xmlns:w="{_NS_W}" xmlns:wp="{_NS_WP}" xmlns:a="{_NS_A}" xmlns:wps="{_NS_WPS}">
  <wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0"
             relativeHeight="{251659000 + drawing_id}" behindDoc="0"
             locked="0" layoutInCell="1" allowOverlap="1">
    <wp:simplePos x="0" y="0"/>
    <wp:positionH relativeFrom="column"><wp:posOffset>{x_emu}</wp:posOffset></wp:positionH>
    <wp:positionV relativeFrom="paragraph"><wp:posOffset>{y_emu}</wp:posOffset></wp:positionV>
    <wp:extent cx="{width_emu}" cy="{height_emu}"/>
    <wp:effectExtent l="0" t="0" r="0" b="0"/>
    <wp:wrapNone/>
    <wp:docPr id="{drawing_id}" name="SourceUrl {drawing_id}"/>
    <wp:cNvGraphicFramePr/>
    <a:graphic>
      <a:graphicData uri="{_NS_WPS}">
        <wps:wsp>
          <wps:cNvSpPr txBox="1"/>
          <wps:spPr>
            <a:xfrm>
              <a:off x="0" y="0"/>
              <a:ext cx="{width_emu}" cy="{height_emu}"/>
            </a:xfrm>
            <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
            <a:noFill/>
            <a:ln><a:noFill/></a:ln>
          </wps:spPr>
          <wps:txbx>
            <w:txbxContent>
              <w:p>
                <w:pPr>
                  <w:spacing before="0" after="0" line="200" lineRule="exact"/>
                  <w:rPr>
                    <w:rFonts w:ascii="바탕체" w:eastAsia="바탕체" w:hAnsi="바탕체" w:cs="바탕체"/>
                    <w:color w:val="{ANNOT_BLUE}"/>
                    <w:sz w:val="{SIZE_ANNOT}"/>
                    <w:szCs w:val="{SIZE_ANNOT}"/>
                    <w:w w:val="{scale_pct}"/>
                  </w:rPr>
                </w:pPr>
                <w:r>
                  <w:rPr>
                    <w:rFonts w:ascii="바탕체" w:eastAsia="바탕체" w:hAnsi="바탕체" w:cs="바탕체"/>
                    <w:color w:val="{ANNOT_BLUE}"/>
                    <w:sz w:val="{SIZE_ANNOT}"/>
                    <w:szCs w:val="{SIZE_ANNOT}"/>
                    <w:w w:val="{scale_pct}"/>
                  </w:rPr>
                  <w:t xml:space="preserve">{escaped}</w:t>
                </w:r>
              </w:p>
            </w:txbxContent>
          </wps:txbx>
          <wps:bodyPr rot="0" spcFirstLastPara="0" vertOverflow="overflow"
                      horzOverflow="overflow" wrap="square"
                      lIns="0" tIns="0" rIns="0" bIns="0"
                      anchor="t" anchorCtr="0">
            <a:noAutofit/>
          </wps:bodyPr>
        </wps:wsp>
      </a:graphicData>
    </a:graphic>
  </wp:anchor>
</w:drawing>'''
    return etree.fromstring(xml)




def attach_annotation(p_element, text: str, *, indent_dxa=0, long_mode=False,
                      line_start_dxa: int | None = None, line_end_dxa: int | None = None,
                      highlight=False) -> None:
    """Attach a floating DrawingML annotation text box to an existing paragraph
    (the bullet/heading line it explains) as an extra run.


    No separate host paragraph is emitted, so the annotation reserves **zero**
    vertical space — eliminating the thin 1pt blank line that a dedicated host
    paragraph used to leave between bullets. The text box floats (텍스트 앞 wrap,
    behindDoc=0) in the gap just below the anchored line via ANNOT_DROP_DXA.
    """
    drawing = _build_annotation_drawing(text, indent_dxa=indent_dxa,
                                        long_mode=long_mode, y_dxa=ANNOT_DROP_DXA,
                                        highlight=highlight,
                                        line_start_dxa=line_start_dxa,
                                        line_end_dxa=line_end_dxa)
    r = _make('r')
    r.append(drawing)
    p_element.append(r)




def _annotation_is_long(text: str, indent_dxa: int, line_end_dxa: int | None = None) -> bool:
    """True when a `* …`-prefixed annotation, left-aligned at the anchor term,
    should switch to ` ┘` (long) mode. Two triggers:


    1. 우측 여백 — 박스 오른쪽 끝이 본문 폭에서 ANNOT_RIGHT_SAFETY_DXA 안쪽에
       들어오지 못한다.
    2. 과다 돌출 — `line_end_dxa`(앵커가 놓인 본문 줄의 글자 끝 x)가 주어졌을 때,
       주석 오른쪽 끝이 그 줄 끝보다 ANNOT_MAX_OVERHANG_DXA 이상 오른쪽으로
       튀어나온다. 줄 끝 근처 앵커에 붙은 긴 주석이 본문 밖 빈 공간으로 홀로
       뻗어 나가는 모양을 막는다(손수정본 기준).
    """
    ann_text = (text or '').lstrip('* ').strip() if (text or '').startswith('*') else (text or '')
    needed = measure_annot_dxa('* ' + ann_text) + 200
    right = max(indent_dxa, 0) + ANNOT_X_NUDGE_DXA + needed
    if right > PAGE_CONTENT_WIDTH - ANNOT_RIGHT_SAFETY_DXA:
        return True
    if line_end_dxa is not None and right > line_end_dxa + ANNOT_MAX_OVERHANG_DXA:
        return True
    return False




def plan_annotation_layout(ann_text: str, anchor_dxa: int,
                           line_start_dxa: int | None = None,
                           line_end_dxa: int | None = None, *,
                           long_hint: bool | None = None) -> dict:
    """이동글틀 한 개의 모드(`* `/┘)·x·장평·프레임 폭을 정한다 (260923 손수정본 기준).


    우선순위:
    1. `* ` 모드, 장평 95 — 앵커 첫 글자 +1.2pt 에서 시작. 우측 여백(15pt 안쪽)과
       과다 돌출(앵커 줄 끝 +120pt) 두 조건을 모두 만족하면 그대로.
    2. 우측 여백만 걸리면(돌출은 아님) `* ` 모드를 유지한 채 장평 92→85 로 줄여 맞춘다 —
       모델명·서비스명 소개는 ┘ 보다 앵커 바로 아래 `*` 가 읽기 쉽다(⑤).
    3. ┘ 모드 — 각 장평 단계에서 (a) ┘ 를 앵커 첫 글자 아래에 두었을 때 박스 왼쪽 끝이
       **본문 줄 글자 시작점(line_start_dxa) 이상**이면 채택, (b) 아니면 박스를 글자
       시작선에 붙이고 ┘ 를 오른쪽으로 옮긴다(┘ 오른쪽 끝 ≤ 줄 끝 +10pt). 옮겨도 안 되면
       다음 장평 단계로(②).
    4. 그래도 안 되면 `* ` 모드로 돌아가 앵커(→ 없으면 줄 시작점)에서 우측 여백 안에
       들어오는 장평을 고른다 — 돌출 규칙보다 "박스가 윗줄 왼쪽으로 나가지 않는다" 가 우선.
    5. 최후(주석이 본문 폭보다 김): 줄 글자 시작선에 `* ` 장평 85 로 붙이고 우측 여백으로
       조금 넘치게 둔다 + [WARN] (박스를 x=0 으로 밀어 ┘ 가 허공을 가리키던 종전 동작 폐지).


    `long_hint`(종전 `_annotation_is_long` 결과)는 호환용 인자일 뿐 판정에 쓰지 않는다 —
    같은 기준(우측 여백·돌출)을 이 함수가 직접 계산한다.
    line_start_dxa 가 None 이면 0(본문 왼쪽 끝)으로 본다. 반환 dict:
    long_mode / x_dxa / scale_pct / frame_width_dxa / display_text / shifted / fallback.
    """
    ann = (ann_text or '').lstrip('* ').strip() if (ann_text or '').startswith('*') else (ann_text or '')
    cw = PAGE_CONTENT_WIDTH
    pad = 200
    anchor = max(int(anchor_dxa or 0), 0)
    min_x = max(int(line_start_dxa or 0), 0)
    limit = int(line_end_dxa) if line_end_dxa is not None else cw


    def _star(scale, x, shifted=False, fallback=None):
        w = measure_annot_dxa('* ' + ann, scale)
        return {'long_mode': False, 'x_dxa': int(x), 'scale_pct': scale,
                'frame_width_dxa': w + pad, 'display_text': '* ' + ann,
                'shifted': shifted, 'fallback': fallback}


    def _tail(scale, x, shifted=False, fallback=None):
        w = measure_annot_dxa(ann + ' \u2518', scale)
        return {'long_mode': True, 'x_dxa': int(x), 'scale_pct': scale,
                'frame_width_dxa': w + pad, 'display_text': ann + ' \u2518',
                'shifted': shifted, 'fallback': fallback}


    star_x = anchor + ANNOT_X_NUDGE_DXA
    w95 = measure_annot_dxa('* ' + ann) + pad
    right95 = star_x + w95
    fits_margin = right95 <= cw - ANNOT_RIGHT_SAFETY_DXA
    overhangs = line_end_dxa is not None and right95 > line_end_dxa + ANNOT_MAX_OVERHANG_DXA
    # 1. `* ` 95%
    if fits_margin and not overhangs:
        return _star(WIDTH_PCT, star_x)
    # 2. 우측 여백만 걸림 → `* ` 유지 + 장평 축소
    if not overhangs:
        for sc in ANNOT_SCALE_STEPS[1:]:
            if star_x + measure_annot_dxa('* ' + ann, sc) <= cw - ANNOT_EDGE_SAFETY_DXA:
                return _star(sc, star_x)
    # 3. ┘ 모드 — 장평 단계마다 (a) 앵커 아래, (b) 오른쪽 이동 순으로 시도
    for sc in ANNOT_SCALE_STEPS:
        pre = measure_annot_dxa(ann + ' ', sc)
        wt = measure_annot_dxa(ann + ' \u2518', sc)
        x = anchor - pre
        if x >= min_x:
            return _tail(sc, x)
        if min_x + wt <= limit + ANNOT_TAIL_TOLERANCE_DXA:
            return _tail(sc, min_x, shifted=True)
    # 4. `* ` 복귀 — 돌출 허용, 앵커 → 줄 시작점 순
    for base in (star_x, min_x + ANNOT_X_NUDGE_DXA):
        for sc in ANNOT_SCALE_STEPS:
            if base + measure_annot_dxa('* ' + ann, sc) <= cw - ANNOT_EDGE_SAFETY_DXA:
                return _star(sc, base, shifted=(base != star_x), fallback='star')
    # 5. 최후 — 주석이 본문 폭 자체보다 길다. 박스를 x=0 으로 밀어 ┘ 가 허공을 가리키게
    #    두는 대신, 줄 글자 시작선에 `* ` 로 붙이고(장평 85) 우측 여백으로 조금 넘치게 둔다.
    #    verify_docx 가 '우측 여백 초과' 로 잡으므로 작성자가 주석을 줄이면 된다.
    base = min_x + ANNOT_X_NUDGE_DXA
    over = (base + measure_annot_dxa('* ' + ann, ANNOT_MIN_SCALE_PCT) - cw) / 20
    print(f"[WARN] 이동글틀이 본문 폭보다 길어 장평 {ANNOT_MIN_SCALE_PCT}% 로도 우측 여백을 "
          f"{over:.0f}pt 넘습니다 — 주석을 축약하세요: {ann[:40]!r}", file=sys.stderr)
    return _star(ANNOT_MIN_SCALE_PCT, base, shifted=True, fallback='overflow')




def _locate_anchor_across_lines(lines, text: str, anchor: str):
    """앵커가 줄바꿈으로 갈라져 어느 한 줄에도 통째로 없을 때, 앵커가 **시작되는** 줄과
    그 줄 안의 위치를 찾는다 (260923 — `자체 평가` 가 `…자체 / 평가 필요` 로 갈라지자
    마지막 줄에 붙고 ┘ 가 오른쪽 끝에 찍혔던 사고 방지). 반환 (line_idx, pos_in_line)
    또는 None."""
    if not anchor or not lines:
        return None
    full = text or ''
    a0 = full.find(anchor)
    if a0 < 0:
        return None
    offsets = _line_offsets(full, lines)
    for i, (ln, off) in enumerate(zip(lines, offsets)):
        if off <= a0 < off + len(ln):
            head = anchor[:max(1, min(len(anchor), off + len(ln) - a0))]
            pos = ln.find(head)
            if pos < 0:
                pos = a0 - off
            return i, pos
    return None




def _line_offsets(text: str, lines) -> list:
    """`split_bullet_text` 가 만든 줄들의 원문(`text`) 안 시작 오프셋. 줄은 원문을
    공백 경계에서 자른 것이므로 순차 탐색으로 복원한다(연속 공백이 합쳐진 경우는
    첫 단어 위치로 보정)."""
    offsets = []
    cursor = 0
    full = text or ''
    for ln in lines:
        idx = full.find(ln, cursor) if ln else -1
        if idx < 0:
            words = (ln or '').split()
            idx = full.find(words[0], cursor) if words else cursor
            if idx < 0:
                idx = cursor
        offsets.append(idx)
        cursor = idx + len(ln)
    return offsets




# ---------- Inline emphasis (`**bold**` / `__underline__`) ------
# 260923 손수정본: `□` 하위 내용 중 핵심 어구만 밑줄(`앱 종료 후에도 일하는 상시 Agent`)
# 또는 Bold 로 강조했다. 불릿 전체 `bold`/`underline` 플래그와 별개로 본문 문자열 안에서
# `**…**` = 부분 Bold, `__…__` = 부분 밑줄 마크업을 지원한다. 마커는 폭 계산·줄바꿈·
# 앵커 탐색 전에 제거되고, 렌더 시 run 을 나눠 서식만 입힌다.
_INLINE_EMPH_RE = re.compile(r'\*\*(?=\S)(.+?)(?<=\S)\*\*|__(?=\S)(.+?)(?<=\S)__')




def parse_inline_emphasis(text: str):
    """`**…**` / `__…__` 마커를 벗겨낸 본문과 강조 구간 [(start, end, 'bold'|'underline')] 을
    돌려준다. 구간 오프셋은 마커를 뗀 본문 기준."""
    if not text or ('**' not in text and '__' not in text):
        return text, []
    out = []
    spans = []
    pos = 0
    for m in _INLINE_EMPH_RE.finditer(text):
        out.append(text[pos:m.start()])
        inner = m.group(1) if m.group(1) is not None else m.group(2)
        kind = 'bold' if m.group(1) is not None else 'underline'
        start = sum(len(s) for s in out)
        out.append(inner)
        spans.append((start, start + len(inner), kind))
        pos = m.end()
    out.append(text[pos:])
    return ''.join(out), spans




def strip_inline_emphasis(text: str) -> str:
    return parse_inline_emphasis(text)[0] if text else text




def _emphasis_runs(line_text: str, line_offset: int, spans, *, bold: bool, underline: bool,
                   scale: int, character_spacing=None, highlight: bool = False) -> list:
    """한 줄 본문을 강조 구간 경계에서 run 으로 나눈다. `spans` 는 원문 오프셋 기준."""
    if not spans or not line_text:
        return [make_run(line_text, size=SIZE_BODY, bold=bold, underline=underline,
                         scale=scale, character_spacing=character_spacing, highlight=highlight)]
    n = len(line_text)
    cuts = {0, n}
    for s, e, _k in spans:
        for v in (s - line_offset, e - line_offset):
            if 0 < v < n:
                cuts.add(v)
    runs = []
    pts = sorted(cuts)
    for a, b in zip(pts, pts[1:]):
        seg = line_text[a:b]
        if not seg:
            continue
        abs_a, abs_b = line_offset + a, line_offset + b
        seg_bold = bold or any(s <= abs_a and abs_b <= e and k == 'bold' for s, e, k in spans)
        seg_ul = underline or any(s <= abs_a and abs_b <= e and k == 'underline' for s, e, k in spans)
        runs.append(make_run(seg, size=SIZE_BODY, bold=seg_bold, underline=seg_ul,
                             scale=scale, character_spacing=character_spacing, highlight=highlight))
    return runs




# `·예시 : …` → `·예) …` (260923 손수정본). `예시 :` 라벨은 `예)` 로 짧게 쓴다.
_EXAMPLE_LABEL_RE = re.compile(r'^(\s*)(?:예시|예)\s*[:：]\s*')




def normalize_example_label(text: str) -> str:
    if not text:
        return text
    return _EXAMPLE_LABEL_RE.sub(r'\1예) ', text, count=1)




# ---------- Native diagram shapes (kind: "diagram") ------------
# Renders a simple box/arrow schematic (구조도/순환도/비교도) as *editable*
# native Word shapes — a DrawingML group (wpg:wgp) containing rectangle
# shapes (node text boxes), straight connector shapes (arrows), and plain
# label text boxes — instead of a rasterized picture. Every box/label stays
# individually clickable and editable in Word after generation.
#
# Layout is computed once in DXA (twips), matching the page content width,
# then converted to EMU only when writing the XML. Connectors are placed at
# fixed coordinates (not live-bound to the shapes they connect) — dragging a
# box in Word will not drag its arrow with it. That trade-off keeps the
# generator simple and avoids the notoriously fragile OOXML shape-connection
# machinery; the payoff is directly editable text without a much larger,
# more brittle implementation.
_NS_WPG = 'http://schemas.microsoft.com/office/word/2010/wordprocessingGroup'




def _load_diagram_templates():
    """`scripts/diagram_templates.py` (표준 도식 템플릿 13종) 를 generate.py 위치 기준으로
    로드한다 — 스킬이 어느 폴더에 설치돼 있어도, cwd 가 어디여도 같은 파일을 쓴다."""
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, 'diagram_templates.py')
    if not os.path.isfile(path):
        raise FileNotFoundError(f"scripts/diagram_templates.py 가 없습니다: {path} — "
                                "스킬 패키지를 다시 설치하세요 (도식 템플릿 모듈 누락).")
    spec = importlib.util.spec_from_file_location('sww_diagram_templates', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod




_DIAGRAM_TEMPLATES = [None]




def diagram_templates():
    if _DIAGRAM_TEMPLATES[0] is None:
        _DIAGRAM_TEMPLATES[0] = _load_diagram_templates()
    return _DIAGRAM_TEMPLATES[0]




# 직전 `_diagram_layout` 호출이 정한 항목(items) 글자 크기. `_diagram_layout` 은 회귀
# 검사가 기대하는 5-튜플을 그대로 돌려주므로, 항목 축소값은 여기로 함께 전달한다.
_DIAGRAM_LAST_ITEM_PT = [10]


DIAGRAM_THEMES = {
    'blue':   {'bg': 'EFF6FF', 'border': '000000'},
    'green':  {'bg': 'ECFDF5', 'border': '000000'},
    'purple': {'bg': 'F5F3FF', 'border': '000000'},
    'orange': {'bg': 'FFF7ED', 'border': '000000'},
    'teal':   {'bg': 'ECFEFF', 'border': '000000'},
    'red':    {'bg': 'FEF2F2', 'border': '000000'},
    'gray':   {'bg': 'F8FAFC', 'border': '000000'},
    'white':  {'bg': 'FFFFFF', 'border': '000000'},   # layers 구성요소 상자 등 (자동 배정 제외)
}
DIAGRAM_THEME_ORDER = ['blue', 'green', 'purple', 'orange', 'teal', 'red', 'gray']


DIAGRAM_TITLE_PT = 11
DIAGRAM_ITEM_PT = 10
DIAGRAM_LABEL_PT = 9
DIAGRAM_BOX_PAD_DXA = 160
DIAGRAM_TITLE_GAP_DXA = 100
DIAGRAM_ITEM_GAP_DXA = 60
DIAGRAM_LINE_EXTRA_DXA = 40
DIAGRAM_LINE_EMU = 12700        # 1.0pt (1pt = 12700 EMU): box + arrow line
DIAGRAM_GAP_DEFAULT_DXA = 500
DIAGRAM_ROW_GAP_DXA = 650
DIAGRAM_BOTTOM_MARGIN_DXA = 160
DIAGRAM_TITLE_MIN_PT = 9        # 제목 자동 축소 하한
DIAGRAM_ITEM_MIN_PT = 8         # 항목(items) 자동 축소 하한 — 항목이 2줄을 넘으면 1pt씩 줄인다
DIAGRAM_TEXT_SAFETY_DXA = 80    # Word 실제 줄 높이 오차 대비 상자 높이 여유
DIAGRAM_HEIGHT_SEED_DXA = 1400  # 안전 사각형 1차 추정에 쓰는 임시 높이


# DrawingML preset 도형은 바운딩 박스와 별개로 내부 텍스트 영역(<rect>)을 따로
# 정의한다. chevron/hexagon 의 기본 adj(50000 = ss*0.5)는 좌우를 각각 min(w,h)의
# 절반씩 잠식해 한글 제목이 통째로 잘리므로 명시적으로 낮춘다.
# 값은 avLst 에 그대로 넣을 {guide: value}. `hexagon` 은 `adj` 만 덮어쓰면
# 세로 배율 guide(`vf`)가 정의되지 않아 Word 가 문서를 열지 못하므로 함께 쓴다.
DIAGRAM_ADJ = {
    'chevron': {'adj': 15000},
    'hexagon': {'adj': 15000, 'vf': 115470},
}
# chevron_flow 는 세그먼트를 이만큼 겹쳐 하나의 사슬처럼 보이게 한다. 겹친 영역은
# 다음 도형이 덮어 그리므로 텍스트가 들어가면 안 된다.
DIAGRAM_CHEVRON_OVERLAP_DXA = 520
# 위/아래가 잠식되는 형상은 같은 글자를 담으려면 박스가 그만큼 높아야 한다.
DIAGRAM_HEIGHT_FACTOR = {
    'ellipse': 1 / (1 - 2 * 0.1465),
    'can': 1 / (1 - 2 * 0.22),
}




def _diagram_safe_rect(shape: str, x0: int, y0: int, x1: int, y1: int):
    """도형 내부에서 텍스트가 확실히 보이는 영역을 DXA 로 반환.


    OOXML presetShapeDefinitions 의 <rect> 정의를 그대로 반영한다.
    """
    w, h = x1 - x0, y1 - y0
    ss = min(w, h)                       # OOXML 의 'ss' = min(w, h)
    if shape in DIAGRAM_ADJ:
        ix = int(ss * DIAGRAM_ADJ[shape]['adj'] / 100000)
        # chevron 은 오른쪽이 다음 세그먼트에 덮이므로 겹침 폭만큼 더 물러난다.
        right = max(ix, DIAGRAM_CHEVRON_OVERLAP_DXA) if shape == 'chevron' else ix
        return x0 + ix, y0, x1 - right, y1
    if shape == 'ellipse':               # 내접 사각형 ~ 0.707배
        dx, dy = int(w * 0.1465), int(h * 0.1465)
        return x0 + dx, y0 + dy, x1 - dx, y1 - dy
    if shape == 'can':                   # 상하 타원이 세로를 잠식
        dy = int(h * 0.22)
        return x0, y0 + dy, x1, y1 - dy
    return x0, y0, x1, y1




def _diagram_node_geometry(node: dict) -> str:
    """노드에 확정된 `_shape`(build_diagram_drawing 이 채움)의 preset 이름."""
    return _diagram_shape_geometry(node.get('_shape'))




def _diagram_inner_width_dxa(box_w_dxa: int, shape: str) -> int:
    """패딩까지 뺀, 실제로 글자가 들어가는 폭(DXA)."""
    ix0, _, ix1, _ = _diagram_safe_rect(shape, 0, 0, box_w_dxa, DIAGRAM_HEIGHT_SEED_DXA)
    return max(ix1 - ix0 - 2 * DIAGRAM_BOX_PAD_DXA, 200)




def _diagram_theme(node: dict, index: int) -> dict:
    key = (node.get('color') or '').strip().lower()
    return DIAGRAM_THEMES.get(key) or DIAGRAM_THEMES[DIAGRAM_THEME_ORDER[index % len(DIAGRAM_THEME_ORDER)]]




def _diagram_text_dxa(s: str, pt_size: int, scale: int = WIDTH_PCT) -> int:
    full = round(pt_size * 20 * (scale / 100))
    half = round(pt_size * 20 * 0.5 * (scale / 100))
    dxa = 0
    for ch in s or '':
        dxa += full if is_fullwidth(ord(ch)) else half
    return dxa




def _diagram_line_height_dxa(pt_size: int) -> int:
    return round(pt_size * 20 * 1.35) + DIAGRAM_LINE_EXTRA_DXA




def _diagram_split_long_word(word: str, pt_size: int, max_dxa: int) -> list[str]:
    """공백 없이 한 줄 폭을 넘는 낱말을 글자 단위로 자른다.


    한글은 공백이 없어도 아무 글자 사이에서나 줄이 바뀌므로, 공백만 보고
    줄을 세면 `서버·스토리지` 같은 제목이 항상 1줄로 계산돼 실제로는 잘린다.
    """
    if _diagram_text_dxa(word, pt_size) <= max_dxa:
        return [word]
    chunks, cur, cur_dxa = [], '', 0
    for ch in word:
        ch_dxa = _diagram_text_dxa(ch, pt_size)
        if cur and cur_dxa + ch_dxa > max_dxa:
            chunks.append(cur)
            cur, cur_dxa = ch, ch_dxa
        else:
            cur += ch
            cur_dxa += ch_dxa
    if cur:
        chunks.append(cur)
    return chunks or [word]




def _diagram_wrap(text: str, pt_size: int, max_dxa: int) -> list[str]:
    """Plain word-wrap by DXA budget — used only to *estimate* box/label
    height. Word re-wraps the real text itself inside the shape at render
    time using its own font metrics, so this only needs to be close."""
    words = [w for w in re.split(r' +', (text or '').strip()) if w]
    if not words:
        return ['']
    space_dxa = _diagram_text_dxa(' ', pt_size) or 1
    lines, cur, cur_dxa = [], [], 0
    for word in words:
        for w in _diagram_split_long_word(word, pt_size, max_dxa):
            w_dxa = _diagram_text_dxa(w, pt_size)
            add = w_dxa if not cur else w_dxa + space_dxa
            if cur and cur_dxa + add > max_dxa:
                lines.append(' '.join(cur))
                cur, cur_dxa = [w], w_dxa
            else:
                cur.append(w)
                cur_dxa += add
    if cur:
        lines.append(' '.join(cur))
    return lines or ['']




def _diagram_node_height_dxa(node: dict, box_w_dxa: int, shape: str = 'rect',
                             title_pt: int = DIAGRAM_TITLE_PT,
                             item_pt: int = DIAGRAM_ITEM_PT) -> int:
    """Estimate the box height needed for the node's text.


    The wrap width is the shape's *safe text rect* (`_diagram_safe_rect`), not
    the raw bounding box: chevron/hexagon eat their left and right edges, so
    measuring against the bounding box overestimates the usable width several
    times over and the text is then silently clipped (the box height is fixed
    -- no autofit, see `_diagram_node_shape_xml`).
    """
    inner = _diagram_inner_width_dxa(box_w_dxa, shape)
    title_lines = _diagram_wrap(node.get('title', ''), title_pt, inner)
    h = (DIAGRAM_BOX_PAD_DXA + len(title_lines) * _diagram_line_height_dxa(title_pt)
         + DIAGRAM_TITLE_GAP_DXA)
    # 항목 단락마다 `after=DIAGRAM_ITEM_GAP_DXA` 가 실제로 붙는다 — 이를 빼고 추정하면
    # 항목이 3개 이상일 때 마지막 줄이 상자 아래로 잘린다(260909 comparison 예시에서 확인).
    for item in (node.get('items') or []):
        lines = _diagram_wrap(item, item_pt, inner)
        h += len(lines) * _diagram_line_height_dxa(item_pt) + DIAGRAM_ITEM_GAP_DXA
    h += DIAGRAM_BOX_PAD_DXA + DIAGRAM_TEXT_SAFETY_DXA
    return round(h * DIAGRAM_HEIGHT_FACTOR.get(shape, 1.0))




def _diagram_fit_item_pt(nodes: list, box_w_dxa: int, title_pt: int = DIAGRAM_TITLE_PT) -> int:
    """items 글자 크기: 어떤 항목도 2줄을 넘지 않을 때까지 10pt → 8pt 로 줄인다.
    (제목과 별개로 줄이되, 제목보다 커지지는 않는다.) 8pt 에서도 넘치면 [WARN]."""
    def too_long(node, pt):
        inner = _diagram_inner_width_dxa(box_w_dxa, _diagram_node_geometry(node))
        return any(len(_diagram_wrap(str(item), pt, inner)) > 2
                   for item in (node.get('items') or []))


    pt = min(DIAGRAM_ITEM_PT, title_pt)
    while pt > DIAGRAM_ITEM_MIN_PT and any(too_long(node, pt) for node in nodes):
        pt -= 1
    long_items = [repr(str(it)) for n in nodes for it in (n.get('items') or [])
                  if too_long({'items': [it], '_shape': n.get('_shape')}, DIAGRAM_ITEM_PT)]
    if pt < DIAGRAM_ITEM_PT and long_items:
        print(f"[WARN] 도식 항목(items)이 길어 {DIAGRAM_ITEM_PT}pt -> {pt}pt 로 줄였습니다: "
              f"{', '.join(long_items[:4])} — 항목은 14자 이내 권장", file=sys.stderr)
    return pt



def _diagram_fit_title_pt(nodes: list, box_w_dxa: int) -> int:
    """제목이 1줄에 들어가는 가장 큰 글자 크기를 도식 단위로 고른다.


    노드마다 크기가 달라지면 보기 나쁘므로 도식 전체에 같은 값을 적용하고,
    축소가 일어났으면 원인이 된 제목을 [WARN] 으로 알려 다듬을 수 있게 한다.
    """
    def wraps(node, pt):
        inner = _diagram_inner_width_dxa(box_w_dxa, _diagram_node_geometry(node))
        return len(_diagram_wrap(node.get('title', ''), pt, inner)) > 1


    pt = DIAGRAM_TITLE_PT
    while pt > DIAGRAM_TITLE_MIN_PT and any(wraps(node, pt) for node in nodes):
        pt -= 1
    if pt < DIAGRAM_TITLE_PT:
        long_titles = [repr(n.get('title', '')) for n in nodes if wraps(n, DIAGRAM_TITLE_PT)]
        print(f"[WARN] 도식 노드 제목이 길어 {DIAGRAM_TITLE_PT}pt -> {pt}pt 로 줄였습니다: "
              f"{', '.join(long_titles)} (제목은 6자 이내 권장)", file=sys.stderr)
    return pt




def _diagram_label_gap_dxa(arrows: list | None, default_gap: int, cap_gap: int) -> int:
    """Widen the gap between boxes when an explicit arrow label needs more
    room than the default gap, so the label never overlaps a neighboring box."""
    if not arrows:
        return default_gap
    needed = default_gap
    for arrow in arrows:
        label = (arrow or {}).get('label')
        if not label:
            continue
        needed = max(needed, min(_diagram_text_dxa(label, DIAGRAM_LABEL_PT) + 300, cap_gap))
    return needed




def _diagram_row_gap_dxa(nodes: list, arrows: list | None, box_w: int, default_gap: int) -> int:
    """2x2_cycle only: the two vertical connectors (TR->BR, BL->TL) place
    their label beside the line, wrapped to ~half the box width. Widen the
    row gap when that wrap needs more than one line, so the label can't
    spill into the box above/below it."""
    if not arrows:
        return default_gap
    vertical_pairs = {(1, 2), (3, 0)}
    cap = min(max(box_w // 2 - 200, 600), 2600)
    needed = default_gap
    for arrow in arrows:
        label = (arrow or {}).get('label')
        if not label:
            continue
        try:
            pair = (_diagram_resolve_index(nodes, arrow['from']), _diagram_resolve_index(nodes, arrow['to']))
        except (KeyError, ValueError):
            continue
        if pair not in vertical_pairs:
            continue
        lines = _diagram_wrap(label, DIAGRAM_LABEL_PT, cap - 100)
        needed = max(needed, len(lines) * _diagram_line_height_dxa(DIAGRAM_LABEL_PT) + 240)
    return needed




def _diagram_layout(layout_name: str, nodes: list, arrows: list | None):
    """Returns (total_w_dxa, total_h_dxa, rects, auto_arrows, title_pt).


    rects: list of (x0, y0, x1, y1) in DXA, aligned with `nodes` order,
    local to the diagram's own top-left origin (0, 0).
    항목(items) 글자 크기는 `_DIAGRAM_LAST_ITEM_PT[0]` 에 남긴다.
    """
    _DIAGRAM_LAST_ITEM_PT[0] = DIAGRAM_ITEM_PT
    n = len(nodes)
    if layout_name == 'horizontal_flow':
        if not (2 <= n <= 5):
            raise ValueError('horizontal_flow layout requires 2~5 nodes')
        gap = _diagram_label_gap_dxa(arrows, DIAGRAM_GAP_DEFAULT_DXA, PAGE_CONTENT_WIDTH // max(n, 2))
        box_w = (PAGE_CONTENT_WIDTH - gap * (n - 1)) // n
        title_pt = _diagram_fit_title_pt(nodes, box_w)
        item_pt = _diagram_fit_item_pt(nodes, box_w, title_pt)
        _DIAGRAM_LAST_ITEM_PT[0] = item_pt
        box_h = max(_diagram_node_height_dxa(node, box_w, _diagram_node_geometry(node), title_pt, item_pt)
                    for node in nodes)
        rects, x = [], 0
        for _ in range(n):
            rects.append((x, 0, x + box_w, box_h))
            x += box_w + gap
        auto_arrows = [{'from': i, 'to': i + 1, 'label': ''} for i in range(n - 1)]
        return PAGE_CONTENT_WIDTH, box_h + DIAGRAM_BOTTOM_MARGIN_DXA, rects, auto_arrows, title_pt


    if layout_name == 'chevron_flow':
        # Value-chain presentation: contiguous chevron segments, each segment
        # is itself an arrow so the flow reads left-to-right without separate
        # connector lines.
        if not (3 <= n <= 6):
            raise ValueError('chevron_flow layout requires 3~6 nodes')
        overlap = DIAGRAM_CHEVRON_OVERLAP_DXA  # 겹침이 이어진 사슬 모양을 만든다
        box_w = (PAGE_CONTENT_WIDTH + overlap * (n - 1)) // n
        # 폭 보정은 `_diagram_safe_rect`(chevron 화살촉 잠식)가 대신한다.
        title_pt = _diagram_fit_title_pt(nodes, box_w)
        item_pt = _diagram_fit_item_pt(nodes, box_w, title_pt)
        _DIAGRAM_LAST_ITEM_PT[0] = item_pt
        box_h = max(_diagram_node_height_dxa(node, box_w, _diagram_node_geometry(node), title_pt, item_pt)
                    for node in nodes)
        rects, x = [], 0
        for i in range(n):
            rects.append((x, 0, x + box_w, box_h))
            x += box_w - overlap
        return PAGE_CONTENT_WIDTH, box_h + DIAGRAM_BOTTOM_MARGIN_DXA, rects, [], title_pt


    if layout_name == '2x2_cycle':
        if n != 4:
            raise ValueError('2x2_cycle layout requires exactly 4 nodes')
        gap_x = _diagram_label_gap_dxa(arrows, DIAGRAM_GAP_DEFAULT_DXA, PAGE_CONTENT_WIDTH // 3)
        box_w = (PAGE_CONTENT_WIDTH - gap_x) // 2
        gap_y = _diagram_row_gap_dxa(nodes, arrows, box_w, DIAGRAM_ROW_GAP_DXA)
        title_pt = _diagram_fit_title_pt(nodes, box_w)
        item_pt = _diagram_fit_item_pt(nodes, box_w, title_pt)
        _DIAGRAM_LAST_ITEM_PT[0] = item_pt
        box_h = max(_diagram_node_height_dxa(node, box_w, _diagram_node_geometry(node), title_pt, item_pt)
                    for node in nodes)
        top_y0, top_y1 = 0, box_h
        bot_y0, bot_y1 = top_y1 + gap_y, top_y1 + gap_y + box_h
        left_x0, left_x1 = 0, box_w
        right_x0, right_x1 = left_x1 + gap_x, left_x1 + gap_x + box_w
        rects = [
            (left_x0, top_y0, left_x1, top_y1),
            (right_x0, top_y0, right_x1, top_y1),
            (right_x0, bot_y0, right_x1, bot_y1),
            (left_x0, bot_y0, left_x1, bot_y1),
        ]
        auto_arrows = [
            {'from': 0, 'to': 1, 'label': ''}, {'from': 1, 'to': 2, 'label': ''},
            {'from': 2, 'to': 3, 'label': ''}, {'from': 3, 'to': 0, 'label': ''},
        ]
        return PAGE_CONTENT_WIDTH, bot_y1 + DIAGRAM_BOTTOM_MARGIN_DXA, rects, auto_arrows, title_pt


    if layout_name == 'comparison':
        if n != 2:
            raise ValueError('comparison layout requires exactly 2 nodes')
        gap_x = _diagram_label_gap_dxa(arrows, DIAGRAM_GAP_DEFAULT_DXA, PAGE_CONTENT_WIDTH // 3)
        box_w = (PAGE_CONTENT_WIDTH - gap_x) // 2
        title_pt = _diagram_fit_title_pt(nodes, box_w)
        item_pt = _diagram_fit_item_pt(nodes, box_w, title_pt)
        _DIAGRAM_LAST_ITEM_PT[0] = item_pt
        box_h = max(_diagram_node_height_dxa(node, box_w, _diagram_node_geometry(node), title_pt, item_pt)
                    for node in nodes)
        rects = [(0, 0, box_w, box_h), (box_w + gap_x, 0, box_w * 2 + gap_x, box_h)]
        return PAGE_CONTENT_WIDTH, box_h + DIAGRAM_BOTTOM_MARGIN_DXA, rects, [], title_pt


    # 그 외 레이아웃(vertical_flow, cycle, hub_spoke, hierarchy, layers, matrix_2x2,
    # timeline, funnel, pyramid)은 scripts/diagram_templates.py 가 계산한다.
    tpl = diagram_templates()
    tpl.validate(layout_name, nodes)
    res = tpl.layout(layout_name, nodes, arrows, {}, sys.modules[__name__])
    _DIAGRAM_LAST_ITEM_PT[0] = res.item_pt
    return res.width, res.height, res.rects, res.auto_arrows, res.title_pt




def _diagram_rect_center(rect):
    x0, y0, x1, y1 = rect
    return (x0 + x1) // 2, (y0 + y1) // 2




def _diagram_arrow_endpoints(rect_a, rect_b):
    """Pick shared-edge points between two boxes, preferring a straight
    horizontal or vertical connector (no diagonals) so labels can be placed
    consistently below (horizontal) or beside (vertical) the line."""
    ax0, ay0, ax1, ay1 = rect_a
    bx0, by0, bx1, by1 = rect_b
    acx, acy = _diagram_rect_center(rect_a)
    bcx, bcy = _diagram_rect_center(rect_b)


    same_row = abs(acy - bcy) < max(ay1 - ay0, by1 - by0) * 0.6
    if same_row:
        y = (max(ay0, by0) + min(ay1, by1)) // 2 if (ay0 < by1 and by0 < ay1) else acy
        return ((ax1, y), (bx0, y)) if acx <= bcx else ((ax0, y), (bx1, y))


    same_col = abs(acx - bcx) < max(ax1 - ax0, bx1 - bx0) * 0.6
    if same_col:
        x = (max(ax0, bx0) + min(ax1, bx1)) // 2 if (ax0 < bx1 and bx0 < ax1) else acx
        return ((x, ay1), (x, by0)) if acy <= bcy else ((x, ay0), (x, by1))


    return (acx, acy), (bcx, bcy)




def _diagram_resolve_index(nodes: list, ref) -> int:
    if isinstance(ref, int):
        return ref
    for i, node in enumerate(nodes):
        if node.get('title') == ref:
            return i
    raise ValueError(f'Diagram arrow reference not found among node titles: {ref!r}')




DIAGRAM_SHAPE_GEOMETRIES = {
    'rect': 'rect',
    'chevron': 'chevron',
    'hexagon': 'hexagon',
    'ellipse': 'ellipse',
    'circle': 'ellipse',
    'cylinder': 'can',
}




def _diagram_shape_geometry(shape_name: str | None) -> str:
    """Return a safe DrawingML preset geometry for a diagram node."""
    key = (shape_name or 'rect').strip().lower()
    try:
        return DIAGRAM_SHAPE_GEOMETRIES[key]
    except KeyError as exc:
        allowed = ', '.join(DIAGRAM_SHAPE_GEOMETRIES)
        raise ValueError(f'Unknown diagram node shape {shape_name!r}. Use one of: {allowed}') from exc




def _diagram_wsp_id_xml(name: str) -> str:
    """Every `wps:wsp` inside a diagram group needs its own `wps:cNvPr`.


    Without it Word renders each `w:txbxContent` into the *previous* text-
    bearing shape (labels land in node 1, node 1's text in node 2, ...), while
    LibreOffice renders correctly -- so a visual check on one renderer alone
    does not catch it.
    """
    shape_id = _next_drawing_id()
    return f'<wps:cNvPr id="{shape_id}" name="{name} {shape_id}"/>'




def _diagram_node_shape_xml(rect, node: dict, index: int,
                            title_pt: int = DIAGRAM_TITLE_PT,
                            item_pt: int = DIAGRAM_ITEM_PT,
                            text_rect=None, suppress_items: bool = False,
                            hide_shape: bool = False) -> str:
    """One diagram node = an outline shape plus a separate text box on top.


    The preset geometry's own text rect is deliberately *not* used: it varies
    per shape (chevron/hexagon/can eat different edges), so hanging the text
    off it makes the layout break whenever the shape changes. Instead the
    outline shape carries geometry + fill + border only, and a borderless text
    box is overlaid on the safe rect (`_diagram_safe_rect`), centered both
    ways. Adding a new shape then only needs a line in `_diagram_safe_rect`.
    """
    theme = _diagram_theme(node, index)
    shape = _diagram_node_geometry(node)
    x0, y0, x1, y1 = rect
    E = _emu_from_dxa
    gds = ''.join(f'<a:gd name="{name}" fmla="val {val}"/>'
                  for name, val in DIAGRAM_ADJ.get(shape, {}).items())
    adj = f'<a:avLst>{gds}</a:avLst>' if gds else '<a:avLst/>'


    # (a) outline: geometry + theme fill (`nodes[].color`) + 1.0pt black border,
    # and deliberately NO `wps:txbx` — see `build_diagram_drawing`.
    shape_xml = f'''<wps:wsp>
      {_diagram_wsp_id_xml('Node')}
      <wps:cNvSpPr/>
      <wps:spPr>
        <a:xfrm><a:off x="{E(x0)}" y="{E(y0)}"/><a:ext cx="{E(x1 - x0)}" cy="{E(y1 - y0)}"/></a:xfrm>
        <a:prstGeom prst="{shape}">{adj}</a:prstGeom>
        <a:solidFill><a:srgbClr val="{theme['bg']}"/></a:solidFill>
        <a:ln w="{DIAGRAM_LINE_EMU}"><a:solidFill><a:srgbClr val="{theme['border']}"/></a:solidFill></a:ln>
      </wps:spPr>
      <wps:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:noAutofit/></wps:bodyPr>
    </wps:wsp>'''


    if hide_shape:
        shape_xml = ''


    # (b) text: borderless overlay on the shape's safe rect, centered.
    if text_rect is not None:
        ix0, iy0, ix1, iy1 = text_rect          # 레이아웃이 글자 영역을 직접 지정 (layers·timeline)
    else:
        ix0, iy0, ix1, iy1 = _diagram_safe_rect(shape, x0, y0, x1, y1)
    ix0 += DIAGRAM_BOX_PAD_DXA
    ix1 -= DIAGRAM_BOX_PAD_DXA
    font = '<w:rFonts w:ascii="바탕체" w:eastAsia="바탕체" w:hAnsi="바탕체" w:cs="바탕체"/>'
    paras = [f'''<w:p><w:pPr><w:jc w:val="center"/>
      <w:spacing before="0" after="{DIAGRAM_TITLE_GAP_DXA}" line="240" lineRule="auto"/></w:pPr>
      <w:r><w:rPr>{font}<w:b/>
      <w:color w:val="0F172A"/><w:sz w:val="{title_pt * 2}"/><w:szCs w:val="{title_pt * 2}"/>
      <w:w w:val="{WIDTH_PCT}"/></w:rPr><w:t xml:space="preserve">{_xml_escape(node.get("title", ""))}</w:t></w:r></w:p>''']
    for item in ([] if suppress_items else (node.get('items') or [])):
        paras.append(f'''<w:p><w:pPr><w:jc w:val="center"/>
          <w:spacing before="0" after="{DIAGRAM_ITEM_GAP_DXA}" line="240" lineRule="auto"/></w:pPr>
          <w:r><w:rPr>{font}
          <w:color w:val="334155"/><w:sz w:val="{item_pt * 2}"/><w:szCs w:val="{item_pt * 2}"/>
          <w:w w:val="{WIDTH_PCT}"/></w:rPr><w:t xml:space="preserve">{_xml_escape(item)}</w:t></w:r></w:p>''')


    text_xml = f'''<wps:wsp>
      {_diagram_wsp_id_xml('NodeText')}
      <wps:cNvSpPr txBox="1"/>
      <wps:spPr>
        <a:xfrm><a:off x="{E(ix0)}" y="{E(iy0)}"/>
        <a:ext cx="{E(max(ix1 - ix0, 200))}" cy="{E(max(iy1 - iy0, 200))}"/></a:xfrm>
        <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
        <a:noFill/><a:ln><a:noFill/></a:ln>
      </wps:spPr>
      <wps:txbx><w:txbxContent>{''.join(paras)}</w:txbxContent></wps:txbx>
      <wps:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:noAutofit/></wps:bodyPr>
    </wps:wsp>'''
    return shape_xml + text_xml




def _diagram_connector_xml(start, end, color_hex: str, arrow: bool = True) -> str:
    """A single native DrawingML arrow line (1.0pt).


    Uses one line shape with ``a:tailEnd`` instead of the former
    rectangle-plus-triangle approximation, so Word exposes it as an editable
    arrow line and the shaft/head cannot drift apart.
    """
    x0, y0 = start
    x1, y1 = end
    dx, dy = x1 - x0, y1 - y0
    x = min(x0, x1)
    y = min(y0, y1)
    # DrawingML requires non-zero extents. One EMU on a horizontal/vertical
    # axis is visually zero while remaining schema-safe.
    cx = max(abs(_emu_from_dxa(dx)), 1)
    cy = max(abs(_emu_from_dxa(dy)), 1)
    flip_h = ' flipH="1"' if dx < 0 else ''
    flip_v = ' flipV="1"' if dy < 0 else ''
    return f'''<wps:wsp>
      {_diagram_wsp_id_xml('Connector')}
      <wps:cNvSpPr/>
      <wps:spPr>
        <a:xfrm{flip_h}{flip_v}><a:off x="{_emu_from_dxa(x)}" y="{_emu_from_dxa(y)}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>
        <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
        <a:noFill/>
        <a:ln w="{DIAGRAM_LINE_EMU}" cap="flat" cmpd="sng" algn="ctr">
          <a:solidFill><a:srgbClr val="{color_hex}"/></a:solidFill>
          <a:prstDash val="solid"/>
          <a:headEnd type="none"/>
          {'<a:tailEnd type="triangle" w="sm" len="sm"/>' if arrow else '<a:tailEnd type="none"/>'}
        </a:ln>
      </wps:spPr>
      <wps:bodyPr/>
    </wps:wsp>'''




def _diagram_dot_xml(cx: int, cy: int, diameter: int, theme_index: int) -> str:
    """타임라인 마일스톤 같은 작은 원 — 글자 없음(빈 txbx 금지 규칙 준수)."""
    theme = DIAGRAM_THEMES[DIAGRAM_THEME_ORDER[theme_index % len(DIAGRAM_THEME_ORDER)]]
    E = _emu_from_dxa
    return f'''<wps:wsp>
      {_diagram_wsp_id_xml('Dot')}
      <wps:cNvSpPr/>
      <wps:spPr>
        <a:xfrm><a:off x="{E(cx - diameter // 2)}" y="{E(cy - diameter // 2)}"/><a:ext cx="{E(diameter)}" cy="{E(diameter)}"/></a:xfrm>
        <a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>
        <a:solidFill><a:srgbClr val="{theme['bg']}"/></a:solidFill>
        <a:ln w="{DIAGRAM_LINE_EMU}"><a:solidFill><a:srgbClr val="{theme['border']}"/></a:solidFill></a:ln>
      </wps:spPr>
      <wps:bodyPr/>
    </wps:wsp>'''




def _diagram_text_box_xml(lab: dict) -> str:
    """테두리·배경 없는 자유 텍스트 상자 (축 라벨·타임라인 설명 등).
    lab: {'x0','y0','w','h','lines'|'text','pt','jc','bold','color'}"""
    pt = int(lab.get('pt') or DIAGRAM_LABEL_PT)
    lines = lab.get('lines') or _diagram_wrap(str(lab.get('text') or ''), pt, max(lab['w'] - 100, 300))
    if not lines:
        return ''
    jc = lab.get('jc') or 'center'
    bold = '<w:b/>' if lab.get('bold') else ''
    color = lab.get('color') or '0F172A'
    font = '<w:rFonts w:ascii="바탕체" w:eastAsia="바탕체" w:hAnsi="바탕체" w:cs="바탕체"/>'
    paras = ''.join(
        f'''<w:p><w:pPr><w:jc w:val="{jc}"/><w:spacing before="0" after="0" line="240" lineRule="auto"/></w:pPr>
        <w:r><w:rPr>{font}{bold}<w:color w:val="{color}"/><w:sz w:val="{pt * 2}"/><w:szCs w:val="{pt * 2}"/>
        <w:w w:val="{WIDTH_PCT}"/></w:rPr><w:t xml:space="preserve">{_xml_escape(ln)}</w:t></w:r></w:p>'''
        for ln in lines)
    E = _emu_from_dxa
    return f'''<wps:wsp>
      {_diagram_wsp_id_xml('Label')}
      <wps:cNvSpPr txBox="1"/>
      <wps:spPr>
        <a:xfrm><a:off x="{E(lab['x0'])}" y="{E(lab['y0'])}"/>
        <a:ext cx="{E(max(lab['w'], 200))}" cy="{E(max(lab['h'], 200))}"/></a:xfrm>
        <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
        <a:noFill/>
        <a:ln><a:noFill/></a:ln>
      </wps:spPr>
      <wps:txbx><w:txbxContent>{paras}</w:txbxContent></wps:txbx>
      <wps:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:noAutofit/></wps:bodyPr>
    </wps:wsp>'''




def _diagram_label_xml(mid, orientation: str, label: str, box_w_dxa: int) -> str:
    """Plain (no fill/border) label text box near a connector — below the
    line for horizontal connectors, beside it for vertical connectors — so
    it never straddles the line into a neighboring box."""
    if not label:
        return ''
    cx, cy = mid
    lh = _diagram_line_height_dxa(DIAGRAM_LABEL_PT)
    if orientation == 'horizontal':
        width_dxa = max(box_w_dxa, 800)
        lines = _diagram_wrap(label, DIAGRAM_LABEL_PT, width_dxa - 100)
        x0, y0 = cx - width_dxa // 2, cy + 60
        jc = 'center'
    else:
        width_dxa = min(max(box_w_dxa // 2 - 200, 600), 2600)
        lines = _diagram_wrap(label, DIAGRAM_LABEL_PT, width_dxa - 100)
        x0, y0 = cx + 60, cy - (len(lines) * lh) // 2
        jc = 'left'
    height_dxa = len(lines) * lh + 80


    paras = []
    for ln in lines:
        paras.append(f'''<w:p><w:pPr><w:jc w:val="{jc}"/><w:spacing before="0" after="0" line="240" lineRule="auto"/></w:pPr>
          <w:r><w:rPr><w:rFonts w:ascii="바탕체" w:eastAsia="바탕체" w:hAnsi="바탕체" w:cs="바탕체"/><w:b/>
          <w:color w:val="0F172A"/><w:sz w:val="{DIAGRAM_LABEL_PT * 2}"/><w:szCs w:val="{DIAGRAM_LABEL_PT * 2}"/>
          <w:w w:val="{WIDTH_PCT}"/></w:rPr><w:t xml:space="preserve">{_xml_escape(ln)}</w:t></w:r></w:p>''')
    body_xml = ''.join(paras)


    return f'''<wps:wsp>
      {_diagram_wsp_id_xml('Label')}
      <wps:cNvSpPr txBox="1"/>
      <wps:spPr>
        <a:xfrm><a:off x="{_emu_from_dxa(x0)}" y="{_emu_from_dxa(y0)}"/>
        <a:ext cx="{_emu_from_dxa(width_dxa)}" cy="{_emu_from_dxa(height_dxa)}"/></a:xfrm>
        <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
        <a:noFill/>
        <a:ln><a:noFill/></a:ln>
      </wps:spPr>
      <wps:txbx><w:txbxContent>{body_xml}</w:txbxContent></wps:txbx>
      <wps:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:noAutofit/></wps:bodyPr>
    </wps:wsp>'''




def _diagram_check_text_fit(nodes, rects, title_pt, item_pt, text_rects=None, suppress_items=frozenset()):
    """추정 글자 높이가 안전 사각형을 넘는 노드에 [WARN] — 넘치면 Word 가 조용히 잘라낸다."""
    for i, (node, rect) in enumerate(zip(nodes, rects)):
        geom = _diagram_node_geometry(node)
        if text_rects and i in text_rects:
            ix0, iy0, ix1, iy1 = text_rects[i]
        else:
            ix0, iy0, ix1, iy1 = _diagram_safe_rect(geom, *rect)
        inner_w = ix1 - ix0 - 2 * DIAGRAM_BOX_PAD_DXA
        need = len(_diagram_wrap(node.get('title', ''), title_pt, inner_w)) * _diagram_line_height_dxa(title_pt)
        if i not in suppress_items:
            for item in (node.get('items') or []):
                need += len(_diagram_wrap(str(item), item_pt, inner_w)) * _diagram_line_height_dxa(item_pt)
            need += DIAGRAM_TITLE_GAP_DXA
        if need > (iy1 - iy0):
            print(f"[WARN] 도식 노드 {node.get('title')!r} 의 글자가 도형 높이를 넘습니다 "
                  f"(필요 {need} > 가용 {iy1 - iy0} DXA) — 제목 8자·항목 14자 이내로 줄이세요.",
                  file=sys.stderr)




def build_diagram_drawing(spec: dict):
    """Build a `w:drawing` (inline DrawingML shape group) for a simple
    box/arrow diagram spec — see references/content-schema.md (Diagram).


    레이아웃 13종: horizontal_flow · chevron_flow · 2x2_cycle · comparison (이 파일) +
    vertical_flow · cycle · hub_spoke · hierarchy · layers · matrix_2x2 · timeline ·
    funnel · pyramid (`scripts/diagram_templates.py`). 노드 수·필수 필드는
    `diagram_templates.validate` 가 먼저 검사해 원인이 분명한 오류를 낸다."""
    tpl = diagram_templates()
    layout_name = spec.get('layout')
    nodes = spec.get('nodes') or []
    arrows_spec = spec.get('arrows')
    tpl.validate(layout_name, nodes)


    # 글자 수 권고 초과는 자동 축소되지만, 작성자가 줄이는 편이 낫다는 것을 알린다.
    for node in nodes:
        if _weighted_len(node.get('title')) > tpl.TITLE_MAX_CHARS:
            print(f"[WARN] 도식 노드 제목이 {tpl.TITLE_MAX_CHARS}자(전각 기준)를 넘습니다: "
                  f"{node.get('title')!r} — 글자가 자동 축소됩니다.", file=sys.stderr)
        for item in (node.get('items') or []):
            if _weighted_len(item) > tpl.ITEM_MAX_CHARS:
                print(f"[WARN] 도식 항목이 {tpl.ITEM_MAX_CHARS}자(전각 기준)를 넘습니다: "
                      f"{str(item)!r} — 글자가 자동 축소됩니다.", file=sys.stderr)


    # Node shape wins, then the diagram default, then the layout's natural
    # default. Existing diagrams stay rectangles unless they opt in. Resolved
    # up front because the layout needs the geometry to size the boxes.
    default_shape = spec.get('defaultShape')
    natural_shape = 'chevron' if layout_name == 'chevron_flow' else 'rect'
    nodes = [dict(node, _shape=(node.get('shape') or default_shape or natural_shape))
             for node in nodes]


    if layout_name in tpl.LEGACY_LAYOUTS:
        total_w, total_h, rects, auto_arrows, title_pt = _diagram_layout(layout_name, nodes, arrows_spec)
        item_pt = _DIAGRAM_LAST_ITEM_PT[0]
        res = tpl.LayoutResult()
        res.width, res.height, res.rects, res.auto_arrows = total_w, total_h, rects, auto_arrows
        res.title_pt, res.item_pt = title_pt, item_pt
    else:
        # 레이아웃이 도형을 정하는 노드(hub 등)는 명시 shape 이 없을 때만 따른다.
        res = tpl.layout(layout_name, nodes, arrows_spec, spec, sys.modules[__name__])
        for i, geom in res.node_shapes.items():
            if not nodes[i].get('shape') and not default_shape:
                nodes[i]['_shape'] = geom
        total_w, total_h, rects, auto_arrows, title_pt, item_pt = (
            res.width, res.height, res.rects, res.auto_arrows, res.title_pt, res.item_pt)


    _diagram_check_text_fit(nodes, rects, title_pt, item_pt, res.text_rects, res.suppress_items)


    # A chevron chain communicates direction through the node geometry itself;
    # separate connectors would overlap the contiguous segments.
    if layout_name == 'chevron_flow':
        arrows = []
    elif res.arrows_xy:
        arrows = []                       # 좌표가 확정된 화살표는 아래에서 직접 그린다
    else:
        arrows = arrows_spec or auto_arrows
    children = []
    # Connectors first so the (very slight) edge overlap sits under the boxes.
    for start, end in res.lines:
        children.append(_diagram_connector_xml(start, end, '000000', arrow=False))
    for start, end, label, orientation in res.arrows_xy:
        children.append(_diagram_connector_xml(start, end, '000000'))
        if label:
            mid = ((start[0] + end[0]) // 2, (start[1] + end[1]) // 2)
            children.append(_diagram_label_xml(mid, orientation, label, 2400))
    for arrow in arrows:
        i_from = _diagram_resolve_index(nodes, arrow['from'])
        i_to = _diagram_resolve_index(nodes, arrow['to'])
        start, end = _diagram_arrow_endpoints(rects[i_from], rects[i_to])
        children.append(_diagram_connector_xml(start, end, '000000'))
        label = arrow.get('label') or ''
        if label:
            orientation = 'horizontal' if abs(start[0] - end[0]) >= abs(start[1] - end[1]) else 'vertical'
            mid = ((start[0] + end[0]) // 2, (start[1] + end[1]) // 2)
            box_w_dxa = rects[i_from][2] - rects[i_from][0]
            children.append(_diagram_label_xml(mid, orientation, label, box_w_dxa))
    for cx_d, cy_d, d, ti in res.dots:
        children.append(_diagram_dot_xml(cx_d, cy_d, d, ti))
    for i, (node, rect) in enumerate(zip(nodes, rects)):
        children.append(_diagram_node_shape_xml(
            rect, node, i, title_pt, item_pt,
            text_rect=res.text_rects.get(i),
            suppress_items=(i in res.suppress_items),
            hide_shape=(i in res.hide_shape)))
    for rect, enode, ti in res.extra_nodes:
        enode = dict(enode, _shape=enode.get('shape') or 'rect')
        children.append(_diagram_node_shape_xml(rect, enode, ti, res.item_pt, res.item_pt))
    for lab in res.labels:
        children.append(_diagram_text_box_xml(lab))


    drawing_id = _next_drawing_id()
    cx, cy = _emu_from_dxa(total_w), _emu_from_dxa(total_h)
    children_xml = ''.join(children)


    # Inline (like a picture), not anchored/floating: an early version used
    # `wp:anchor` + `wrapTopAndBottom` because the very first attempt (using
    # `wps:cxnSp` for arrows) failed to render as inline. Using `wps:wsp` for
    # every child makes `wp:inline` work, and unlike floating anchors it keeps
    # multiple diagrams in strict document order — floating anchors on
    # adjacent near-empty host paragraphs render their vertical order
    # unpredictably (a caption could end up below its own diagram).
    #
    # Only shapes that actually carry text get a `wps:txbx`. A shape with an
    # *empty* `w:txbxContent` shifts Word's text-to-shape assignment by one
    # for the rest of the document — arrow labels land inside node boxes and
    # the last node's text disappears. LibreOffice renders it correctly, so
    # this is invisible unless the check is done in Word itself.
    xml = f'''<w:drawing xmlns:w="{_NS_W}" xmlns:wp="{_NS_WP}" xmlns:a="{_NS_A}" xmlns:wps="{_NS_WPS}" xmlns:wpg="{_NS_WPG}">
  <wp:inline distT="0" distB="0" distL="0" distR="0">
    <wp:extent cx="{cx}" cy="{cy}"/>
    <wp:effectExtent l="0" t="0" r="0" b="0"/>
    <wp:docPr id="{drawing_id}" name="Diagram {drawing_id}"/>
    <wp:cNvGraphicFramePr/>
    <a:graphic>
      <a:graphicData uri="{_NS_WPG}">
        <wpg:wgp>
          <wpg:cNvGrpSpPr/>
          <wpg:grpSpPr>
            <a:xfrm>
              <a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/>
              <a:chOff x="0" y="0"/><a:chExt cx="{cx}" cy="{cy}"/>
            </a:xfrm>
          </wpg:grpSpPr>
          {children_xml}
        </wpg:wgp>
      </a:graphicData>
    </a:graphic>
  </wp:inline>
</w:drawing>'''
    return etree.fromstring(xml)




def render_diagram_bullet(doc: Document, bullet: dict, is_last: bool = False) -> None:
    """Renders `"kind": "diagram"` as native, editable Word shapes (see
    build_diagram_drawing). `caption` renders above it as `< 제목 >`, same
    convention as table/image captions. Any explanatory note belongs in a
    separate bullet (with a normal 이동글틀 annotation) placed right after
    this one — not inside the diagram spec."""
    caption = bullet.get('caption')
    if caption:
        cap_p = body_paragraph(f"< {caption} >", alignment='center',
                               after=AFTER['body'], size=SIZE_BODY, bold=True)
        _apply_keep_next(cap_p)
        _append_block(doc, cap_p)


    spec = bullet.get('spec') or bullet
    drawing = build_diagram_drawing(spec)


    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run()
    r._r.append(drawing)
    after_val = AFTER['last_in_section'] if is_last else AFTER['body']
    _apply_p_properties(p._p, line=240, line_rule='auto', after=after_val)




# ---------- Image paragraph ------------------------------------
def _emu_from_px(px: int) -> int:
    # 1 inch = 96 px = 914400 EMU
    return int(round(px * 914400 / 96))




def render_image_bullet(doc: Document, bullet: dict, is_last: bool = False):
    """Appends an optional caption and an image paragraph to the document body.


    `caption` renders ABOVE the image as `< \uC81C\uBAA9 >` (centered, bold) \u2014 the
    same convention `render_table_element`'s caption uses above a table.
    Any explanatory note or source for the image belongs in a separate
    bullet (with a normal \uC774\uB3D9\uAE00\uD2C0 annotation) placed right after this one
    in the content JSON \u2014 it is not baked into the image bullet itself.


    Note: this uses python-docx add_picture() which creates a paragraph in the
    current body position with an inline shape, then we tweak the paragraph.
    """
    if bullet.get('float'):
        # render_section 이 미리 걷어내지 못한 경로(섹션 밖) — 직전 단락에 붙이되 줄폭 예약은 없다.
        print("[WARN] float 이미지가 섹션 불릿 밖에서 나와 줄폭 예약 없이 직전 단락에 붙였습니다.",
              file=sys.stderr)
        attach_floating_image(doc, _float_image_spec_from_bullet(bullet),
                              json_dir=CONTENT_JSON_DIR[0],
                              default_width_cm=SECTION_PHOTO_DEFAULT_WIDTH_CM,
                              default_y_dxa=SECTION_PHOTO_Y_DXA, name='Section photo')
        return


    caption = bullet.get('caption')
    if caption:
        cap_p = body_paragraph(f"< {caption} >", alignment='center',
                               after=AFTER['body'], size=SIZE_BODY, bold=True)
        _apply_keep_next(cap_p)
        _append_block(doc, cap_p)


    file_path = resolve_image_path(bullet.get('path', ''))
    with open(file_path, 'rb') as f:
        data = f.read()
    width_px, height_px = image_dimensions(bullet, file_path, data)


    # Use add_picture helper: it appends a paragraph with an inline drawing.
    p_runcarrier = doc.add_paragraph()
    run = p_runcarrier.add_run()
    run.add_picture(io.BytesIO(data), width=Emu(_emu_from_px(width_px)),
                    height=Emu(_emu_from_px(height_px)))
    # Alignment
    p_runcarrier.alignment = (WD_ALIGN_PARAGRAPH.LEFT
                              if bullet.get('alignment') == 'left'
                              else WD_ALIGN_PARAGRAPH.CENTER)
    # Spacing
    after_val = AFTER['last_in_section'] if is_last else AFTER['body']
    _apply_p_properties(p_runcarrier._p, line=240, line_rule='auto', after=after_val)




# ---------- CEO/인물 프로필 이미지 (floating, 우상단) ----------
# 인물 프로필(ceoinfo) 문서의 얼굴 사진은 본문을 밀어내지 않는 **떠 있는 그림**
# 으로 넣는다. Word 줄바꿈 옵션은 항상 "텍스트 앞"(In Front of Text) —
# OOXML 상 `wp:anchor` + `behindDoc="0"` + `wp:wrapNone` 조합이며, 자식 순서는
# extent → effectExtent → wrapNone → docPr → cNvGraphicFramePr → graphic 이어야
# Word 가 정상 인식한다.
PROFILE_IMAGE_DEFAULT_WIDTH_CM = 3.8
PROFILE_IMAGE_DEFAULT_Y_DXA = 300   # 앵커 단락 상단에서 아래로 약 0.53cm


# ---------- □ 헤딩 우측 사진 (섹션 사진, 260923 손수정본 Jev 계측) ----------
# 여러 인물이 한 별첨에 들어가는 프로필(예: 창업진 3명)은 사진을 각 인물의 □ 헤딩
# 단락에 "텍스트 앞"(wrapNone) 이동 그림으로 붙인다 — 인라인 사진 단락 + `※ 사진 :`
# 캡션 단락이 차지하던 세로 공간(1인당 약 9줄)이 사라져 3명이 한 쪽에 들어간다.
# 손수정본 계측: 폭 1619250 EMU(=4.5cm), 본문 폭 우측 정렬, 세로 = □ 헤딩 단락 상단.
# 글자와 겹치지 않도록 사진 세로 범위에 드는 줄의 wrap 폭을 `RIGHT_RESERVE_DXA` 만큼
# 줄인다(plan_photo_reserve). 사진 뒤로 글자가 들어가는 일은 생성 단계에서 막는다.
SECTION_PHOTO_DEFAULT_WIDTH_CM = 4.5
SECTION_PHOTO_Y_DXA = 0              # □ 헤딩 단락 상단에 맞춤
SECTION_PHOTO_TEXT_GAP_DXA = 170     # 글자 오른쓴 끝 ↔ 사진 왼쓴 끝 최소 여백 (≈0.3cm)
SECTION_PHOTO_BOTTOM_MARGIN_DXA = 120  # 사진 아래 6pt 안에서 시작하는 줄도 예약(추정 오차 흡수)
BODY_LINE_HEIGHT_FACTOR = 1.3        # 바탕 14pt · 자동 줄간격(240) 실측 18.2pt = 364dxa


# 사진 옆 줄폭 예약(dxa) — render_section 이 설정·해제한다. 0 이면 본문 폭 전체를 쓴다.
RIGHT_RESERVE_DXA = [0]




def _wrap_width_dxa() -> int:
    """불릿·□ 헤딩 pre-wrap 에 쓰는 가용 폭. 사진 옆 줄은 RIGHT_RESERVE_DXA 만큼 좁아진다."""
    return max(PAGE_CONTENT_WIDTH - RIGHT_RESERVE_DXA[0], 1200)




def _dxa_from_emu(emu: int) -> int:
    return int(round(int(emu) / EMU_PER_DXA))
_IMAGE_CONTENT_TYPE_EXT = {
    'image/jpeg': '.jpg', 'image/jpg': '.jpg', 'image/png': '.png',
    'image/gif': '.gif', 'image/webp': '.webp', 'image/bmp': '.bmp',
    'image/tiff': '.tif',
}
_DOCX_SAFE_IMAGE_SUFFIXES = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tif', '.tiff'}




def _cm_to_dxa(cm) -> int:
    return int(round(float(cm) / 2.54 * TWIPS_PER_INCH))




def _is_http_url(value) -> bool:
    text = str(value or '').strip().lower()
    return text.startswith('http://') or text.startswith('https://')




def _download_image_url(url: str) -> str:
    """Download an image URL into a temp file and return its local path."""
    import hashlib
    import tempfile
    from urllib.request import Request, urlopen


    req = Request(url, headers={'User-Agent': 'Mozilla/5.0 (samsung-word-writer-pro)'})
    with urlopen(req, timeout=30) as resp:
        content_type = (resp.headers.get('Content-Type') or '').split(';')[0].strip().lower()
        data = resp.read()
    if not data:
        raise ValueError(f'Downloaded image is empty: {url}')
    suffix = os.path.splitext(url.split('?')[0])[1].lower()
    if suffix not in _DOCX_SAFE_IMAGE_SUFFIXES and suffix != '.webp':
        suffix = _IMAGE_CONTENT_TYPE_EXT.get(content_type, '.img')
    digest = hashlib.sha1(url.encode('utf-8')).hexdigest()[:16]
    out = os.path.join(tempfile.gettempdir(), f'profile_image_{digest}{suffix}')
    with open(out, 'wb') as f:
        f.write(data)
    return out




def _prepare_image_for_docx(path: str) -> str:
    """python-docx 가 읽을 수 있는 포맷으로 보정 (WebP 등은 PNG 로 변환)."""
    suffix = os.path.splitext(path)[1].lower()
    if suffix in _DOCX_SAFE_IMAGE_SUFFIXES:
        return path
    try:
        from PIL import Image
    except Exception as exc:
        raise ValueError(
            f'지원하지 않는 이미지 포맷이며 Pillow 가 없어 변환할 수 없습니다: {path}'
        ) from exc
    out = os.path.splitext(path)[0] + '.png'
    with Image.open(path) as im:
        if im.mode not in {'RGB', 'RGBA'}:
            im = im.convert('RGBA')
        im.save(out, 'PNG')
    return os.path.abspath(out)




def _resolve_profile_image_path(raw, json_dir=None) -> str:
    """로컬 경로 또는 HTTP(S) URL 을 실제 파일 경로로 해석한다."""
    value = str(raw or '').strip()
    if not value:
        raise ValueError('profileImage 에 path 또는 url 이 필요합니다.')
    if _is_http_url(value):
        return _download_image_url(value)
    candidates = []
    if os.path.isabs(value):
        candidates.append(value)
    else:
        if json_dir:
            candidates.append(os.path.join(json_dir, value))
        candidates.append(os.path.join(os.getcwd(), value))
        candidates.append(str(SKILL_ROOT / value))
    for cand in candidates:
        if os.path.isfile(cand):
            return os.path.abspath(cand)
    raise FileNotFoundError(f'프로필 이미지를 찾을 수 없습니다: {raw}')




def normalize_profile_image(data: dict):
    """문서(또는 별첨) 딕셔너리에서 프로필 이미지 spec 을 정규화해 돌려준다.


    허용 형태:
      "profileImage": {"path": "..."} / {"url": "https://..."}
      "profileImage": "/mnt/data/headshot.jpg" | "https://.../a.jpg"
      "profileImagePath" / "profileImageUrl" (top-level alias)
      레거시 CEO JSON: "image" / "image_path" / "image_url" / "ceo_image"
    """
    if not isinstance(data, dict):
        return None
    spec = {}
    raw = data.get('profileImage')
    if raw is None:
        # 레거시 CEO JSON 호환 — bullet 의 "kind": "image" 와는 다른 레벨이다.
        raw = data.get('image')
    if isinstance(raw, dict):
        spec.update(raw)
    elif isinstance(raw, str) and raw.strip():
        spec['url' if _is_http_url(raw) else 'path'] = raw.strip()
    elif raw is not None and not isinstance(raw, (dict, str)):
        raise ValueError('profileImage 는 객체 또는 경로/URL 문자열이어야 합니다.')


    for key, target in (('profileImagePath', 'path'), ('image_path', 'path'),
                        ('profileImageUrl', 'url'), ('image_url', 'url')):
        if data.get(key) and not spec.get(target):
            spec[target] = str(data[key]).strip()
    if data.get('ceo_image') and not (spec.get('path') or spec.get('url')):
        value = str(data['ceo_image']).strip()
        spec['url' if _is_http_url(value) else 'path'] = value


    source = spec.get('path') or spec.get('url') or spec.get('src') or spec.get('file')
    if not source:
        return None
    spec['source'] = source
    return spec



def _convert_inline_to_anchor(r_element, *, x_emu: int, y_emu: int, alt: str,
                              name: str = 'Profile image') -> None:
    """`wp:inline` 그림을 "텍스트 앞" floating `wp:anchor` 로 바꾼다."""
    inline_list = r_element.findall('.//' + qn('wp:inline'))
    if not inline_list:
        return
    inline = inline_list[0]
    extent = inline.find(qn('wp:extent'))
    doc_pr = inline.find(qn('wp:docPr'))
    cnv_pr = inline.find(qn('wp:cNvGraphicFramePr'))
    graphic = inline.find(qn('a:graphic'))


    parent = inline.getparent()
    index = list(parent).index(inline)
    parent.remove(inline)


    anchor = OxmlElement('wp:anchor')
    for k, v in (('distT', '0'), ('distB', '0'), ('distL', '114300'), ('distR', '114300'),
                 ('simplePos', '0'),
                 ('relativeHeight', str(252637184 + _next_drawing_id())),
                 ('behindDoc', '0'), ('locked', '0'), ('layoutInCell', '1'),
                 ('allowOverlap', '1')):
        anchor.set(k, v)


    simple_pos = OxmlElement('wp:simplePos')
    simple_pos.set('x', '0')
    simple_pos.set('y', '0')
    anchor.append(simple_pos)


    pos_h = OxmlElement('wp:positionH')
    pos_h.set('relativeFrom', 'column')
    pos_h_offset = OxmlElement('wp:posOffset')
    pos_h_offset.text = str(int(x_emu))
    pos_h.append(pos_h_offset)
    anchor.append(pos_h)


    pos_v = OxmlElement('wp:positionV')
    pos_v.set('relativeFrom', 'paragraph')
    pos_v_offset = OxmlElement('wp:posOffset')
    pos_v_offset.text = str(int(y_emu))
    pos_v.append(pos_v_offset)
    anchor.append(pos_v)


    if extent is not None:
        anchor.append(extent)
    effect = OxmlElement('wp:effectExtent')
    for key in ('l', 't', 'r', 'b'):
        effect.set(key, '0')
    anchor.append(effect)
    # "텍스트 앞" — wrapNone 은 effectExtent 뒤, docPr 앞이어야 한다.
    anchor.append(OxmlElement('wp:wrapNone'))
    if doc_pr is not None:
        doc_pr.set('name', name)
        doc_pr.set('descr', alt or 'profile image')
        anchor.append(doc_pr)
    if cnv_pr is not None:
        anchor.append(cnv_pr)
    if graphic is not None:
        anchor.append(graphic)
    parent.insert(index, anchor)




def attach_floating_image(doc: Document, spec: dict, *, json_dir=None,
                          default_width_cm: float = PROFILE_IMAGE_DEFAULT_WIDTH_CM,
                          default_y_dxa: int = PROFILE_IMAGE_DEFAULT_Y_DXA,
                          name: str = 'Profile image'):
    """그림을 **직전 단락**에 "텍스트 앞"(wrapNone) 이동 그림으로 부착한다.


    별도 host 단락을 남기지 않으므로 본문 높이를 **전혀** 차지하지 않는다
    (이동글틀 주석과 동일한 방식). 기본 위치는 본문 폭 기준 우측 정렬.
    부착한 그림의 기하(dxa, 앵커 단락 상단·본문 왼쓴 끝 기준)를 돌려준다 —
    render_section 이 사진 옆 줄폭 예약(plan_photo_reserve)에 쓴다.
    """
    if not spec:
        return None
    img_path = _prepare_image_for_docx(
        _resolve_profile_image_path(spec['source'], json_dir=json_dir))
    width_cm = float(spec.get('width_cm') or spec.get('widthCm') or default_width_cm)
    width_dxa = _cm_to_dxa(width_cm)
    alt = str(spec.get('alt') or 'profile image')


    if spec.get('x_emu') is not None:
        x_emu = int(spec['x_emu'])
    elif spec.get('x_cm') is not None:
        x_emu = _emu_from_dxa(_cm_to_dxa(spec['x_cm']))
    else:
        x_emu = _emu_from_dxa(max(PAGE_CONTENT_WIDTH - width_dxa, 0))
    if spec.get('y_emu') is not None:
        y_emu = int(spec['y_emu'])
    elif spec.get('y_cm') is not None:
        y_emu = _emu_from_dxa(_cm_to_dxa(spec['y_cm']))
    else:
        y_emu = _emu_from_dxa(default_y_dxa)


    carrier = doc.add_paragraph()
    run = carrier.add_run()
    with open(img_path, 'rb') as f:
        shape = run.add_picture(io.BytesIO(f.read()), width=Emu(_emu_from_dxa(width_dxa)))
    height_dxa = _dxa_from_emu(int(shape.height))
    _convert_inline_to_anchor(run._r, x_emu=x_emu, y_emu=y_emu, alt=alt, name=name)


    carrier_p = carrier._p
    body = doc.element.body
    target = None
    for el in reversed(list(body)):
        if el is carrier_p:
            continue
        if el.tag == qn('w:p'):
            target = el
            break
        if el.tag == qn('w:tbl'):
            break
    if target is not None:
        target.append(run._r)
        body.remove(carrier_p)
    else:
        # 앞선 단락이 없으면(문서 첫 블록) 캐리어를 0높이에 가깝게 눌러 둔다.
        _apply_p_properties(carrier_p, line=20, line_rule='exact', after=0, before=0)
    return {'x_dxa': _dxa_from_emu(x_emu), 'y_dxa': _dxa_from_emu(y_emu),
            'width_dxa': width_dxa, 'height_dxa': height_dxa}




def render_profile_image(doc: Document, spec: dict, *, json_dir=None) -> None:
    """인물 프로필 사진(최상위·별첨 `profileImage`)을 직전 단락(제목/별첨 라벨)에 부착한다."""
    attach_floating_image(doc, spec, json_dir=json_dir)




# ---------- □ 헤딩 우측 사진 — spec 추출·줄폭 예약 계획 ----------
def _float_image_spec_from_bullet(bullet):
    """`kind: "image"` 불릿의 `float` 옵션(`"right"`/true) → 이동 그림 spec. 없으면 None.


    직전에 렌더된 단락(첫 불릿이면 □ 헤딩)에 "텍스트 앞" 으로 붙는다. 캡션 단락은
    만들지 않는다 — 사진 출처는 섹션 `headingAnnotation`(이동글틀)으로 적는다.
    """
    if not isinstance(bullet, dict) or bullet.get('kind') != 'image' or not bullet.get('float'):
        return None
    src = bullet.get('path') or bullet.get('url')
    if not src:
        raise ValueError('float 이미지 bullet 에는 "path" 또는 "url" 이 필요합니다.')
    spec = {'source': str(src).strip()}
    if bullet.get('width_cm') or bullet.get('widthCm'):
        spec['width_cm'] = float(bullet.get('width_cm') or bullet.get('widthCm'))
    elif bullet.get('width') or bullet.get('widthPx'):
        spec['width_cm'] = round(float(bullet.get('width') or bullet.get('widthPx'))
                                 / PX_PER_INCH * 2.54, 2)
    for key in ('alt', 'x_cm', 'y_cm', 'x_emu', 'y_emu'):
        if bullet.get(key) is not None:
            spec[key] = bullet[key]
    if bullet.get('caption'):
        print("[WARN] 이동 그림(float) 이미지는 캡션 단락을 만들지 않아 caption 을 무시했습니다. "
              "사진 출처는 섹션 headingAnnotation(이동글틀)으로 적으세요.", file=sys.stderr)
    return spec




def _section_photo_spec(section: dict):
    """`sections[].profileImage`(별칭 `photo`) → 이동 그림 spec."""
    raw = section.get('profileImage')
    if raw is None:
        raw = section.get('photo')
    if raw is None:
        return None
    return normalize_profile_image({'profileImage': raw})




def _photo_reserve_dxa(spec: dict) -> int:
    """사진 옆 줄에서 빼야 하는 폭(dxa) = 본문 우측 끝 − 사진 왼쓴 끝 + 여백."""
    width_dxa = _cm_to_dxa(float(spec.get('width_cm') or spec.get('widthCm')
                                 or SECTION_PHOTO_DEFAULT_WIDTH_CM))
    if spec.get('x_emu') is not None:
        x_dxa = _dxa_from_emu(int(spec['x_emu']))
    elif spec.get('x_cm') is not None:
        x_dxa = _cm_to_dxa(spec['x_cm'])
    else:
        x_dxa = max(PAGE_CONTENT_WIDTH - width_dxa, 0)
    return max(PAGE_CONTENT_WIDTH - x_dxa + SECTION_PHOTO_TEXT_GAP_DXA, 0)




def _body_line_height_dxa() -> int:
    return round(BODY_PT * 20 * BODY_LINE_HEIGHT_FACTOR * BODY_LINE[0] / 240)




def _bullet_prefix(bullet: dict) -> str:
    kind = bullet.get('kind') or 'dash'
    if kind == 'circled':
        idx = (bullet.get('index') or 1) - 1
        return f' {CIRCLED[idx] if 0 <= idx < len(CIRCLED) else CIRCLED[0]} '
    if kind == 'ordered':
        return f" {bullet.get('index') or 1}) "
    return PREFIX.get(kind, PREFIX['dash'])




def _estimate_bullet_lines(bullet: dict, reserve_dxa: int) -> int:
    """불릿이 몇 줄로 pre-wrap 될지 추정 (사진 옆 줄폭 예약 계획용)."""
    prefix = _bullet_prefix(bullet)
    text = strip_inline_emphasis(str(bullet.get('text') or ''))
    hang = hanging_indent_for(prefix, text)
    cont_indent = hang['left'] if hang else measure_dxa(prefix)
    width = max(PAGE_CONTENT_WIDTH - reserve_dxa, 1200)
    lines = split_bullet_text(prefix, text,
                              first_line_capacity=round(width * WRAP_SAFETY_MARGIN),
                              continuation_capacity=round((width - cont_indent) * WRAP_SAFETY_MARGIN))
    return max(1, len(lines))




def plan_photo_reserve(bullets, *, photo_bottom_dxa: int, start_y_dxa: int,
                       reserve_dxa: int) -> int:
    """사진(□ 헤딩 우측 "텍스트 앞") 세로 범위 안에서 **시작하는** 선행 불릿 수를 돌려준다.


    이 불릿들은 wrap 폭을 `reserve_dxa` 만큼 줄여 글자가 사진 뒤로 들어가지 않게 한다.
    좌표는 앵커 단락 상단 기준 dxa. 표·도식·이미지처럼 높이를 추정할 수 없는 블록을
    만나면 그 앞에서 멈춘다(그 아래 불릿은 예약하지 않음).
    """
    line_h = _body_line_height_dxa()
    y = start_y_dxa
    n = 0
    for i, b in enumerate(bullets):
        kind = b.get('kind') or 'dash'
        if kind in {'table', 'image', 'diagram'}:
            break
        if y >= photo_bottom_dxa + SECTION_PHOTO_BOTTOM_MARGIN_DXA:
            break
        n += 1
        nxt = bullets[i + 1].get('kind') if (i + 1) < len(bullets) else None
        if kind == 'subhead':
            lines, after = 1, AFTER['body']
        else:
            lines = _estimate_bullet_lines(b, reserve_dxa)
            after = _bullet_after_spacing(kind, nxt)
        y += lines * line_h + (lines - 1) * AFTER['body_wrap'] + after
    return n




def _attach_section_photo(doc: Document, spec: dict, bullets, *, start_index: int,
                          reserve_dxa: int, label: str) -> int:
    """직전 단락(□ 헤딩 또는 불릿 마지막 줄)에 사진을 붙이고, 줄폭 예약이 끝나는
    불릿 인덱스(exclusive)를 돌려준다."""
    geo = attach_floating_image(doc, spec, json_dir=CONTENT_JSON_DIR[0],
                                default_width_cm=SECTION_PHOTO_DEFAULT_WIDTH_CM,
                                default_y_dxa=SECTION_PHOTO_Y_DXA, name='Section photo')
    if not geo:
        return start_index
    line_h = _body_line_height_dxa()
    if start_index == 0:
        start_y = line_h + AFTER['section_heading']
    else:
        prev_kind = bullets[start_index - 1].get('kind') or 'dash'
        next_kind = bullets[start_index].get('kind') if start_index < len(bullets) else None
        start_y = line_h + _bullet_after_spacing(prev_kind, next_kind)
    n = plan_photo_reserve(bullets[start_index:],
                           photo_bottom_dxa=geo['y_dxa'] + geo['height_dxa'],
                           start_y_dxa=start_y, reserve_dxa=reserve_dxa)
    print(f"[INFO] □ '{label}' 사진을 헤딩 우측 텍스트 앞 이동 그림으로 부착 "
          f"(폭 {geo['width_dxa'] / 567:.1f}cm) — 사진 옆 {n}개 항목의 줄폭을 "
          f"{reserve_dxa}dxa 줄여 글자 겹침을 막았습니다.", file=sys.stderr)
    return start_index + n




# ---------- ceoinfo 입력 정규화 (레거시 CEO JSON + 용어집) ----------
# CEO Profile(문서유형 08)은 더 이상 별도 엔진을 쓰지 않는다. 기업개요(07)와
# 똑같이 `sections` 기반 표준 JSON 을 이 파일이 렌더한다. 아래 두 함수는
#   ① 예전 generate_ceo.py 용 JSON(name/education/career/notes)을 표준
#      `sections` 구조로 펼치고,
#   ② term_annotations(용어집)를 첫 등장 지점의 이동글틀로 배분한다.
CEO_LABELS = {
    'name': '이    름',
    'nationality': '국    적',
    'birthplace': '출    생',
    'education': '학    력',
    'career': '주요 이력',
    'notes': '참고사항',
}
_CEO_LEGACY_KEYS = ('name', 'nationality', 'birthplace', 'education', 'career', 'notes')




def _ceo_bullet_from_item(item, kind='dash'):
    """레거시 CEO 항목(문자열 / {period,organization,role} / {text,annotation})을
    표준 bullet 딕셔너리로 바꾼다."""
    if isinstance(item, str):
        return {'kind': kind, 'text': item}
    if not isinstance(item, dict):
        return {'kind': kind, 'text': str(item)}
    text = str(item.get('text') or '').strip()
    if not text:
        period = str(item.get('period') or '').strip()
        organization = str(item.get('organization') or '').strip()
        role = str(item.get('role') or item.get('position') or '').strip()
        parts = [x for x in (period, organization, role) if x]
        if period and (organization or role):
            text = f"{period}, {organization} {role}".strip()
        else:
            text = ' '.join(parts)
    bullet = {'kind': item.get('kind') or kind, 'text': text}
    if item.get('annotation'):
        bullet['annotation'] = item['annotation']
    for flag in ('bold', 'underline', 'highlight'):
        if item.get(flag) is True:
            bullet[flag] = True
    return bullet




def _ceo_label_heading(label, value):
    label_text = CEO_LABELS[label]
    value = str(value or '').strip()
    return f"{label_text} : {value}" if value else label_text




def expand_ceo_profile(node):
    """레거시 CEO Profile JSON 을 표준 `sections` 구조로 펼친다.


    `sections` 가 이미 있으면 아무것도 하지 않는다(신규 표준 입력).
    문서 최상위와 각 별첨(appendix) 모두에 적용된다.
    """
    if not isinstance(node, dict):
        return node
    if node.get('sections'):
        return node
    if not any(node.get(k) for k in _CEO_LEGACY_KEYS):
        return node


    sections = []
    if node.get('name'):
        sec = {'heading': _ceo_label_heading('name', node['name']), 'bullets': []}
        if node.get('name_annotation'):
            sec['headingAnnotation'] = node['name_annotation']
        sections.append(sec)
    for key in ('nationality', 'birthplace'):
        if node.get(key):
            sec = {'heading': _ceo_label_heading(key, node[key]), 'bullets': []}
            if node.get(f'{key}_annotation'):
                sec['headingAnnotation'] = node[f'{key}_annotation']
            sections.append(sec)
    for key in ('education', 'career'):
        items = node.get(key) or []
        if items:
            sections.append({
                'heading': CEO_LABELS[key],
                'bullets': [_ceo_bullet_from_item(it, 'dash') for it in items],
            })
    notes = node.get('notes') or []
    if notes:
        bullets = []
        for entry in notes:
            if not isinstance(entry, dict):
                bullets.append(_ceo_bullet_from_item(entry, 'dash'))
                continue
            if entry.get('text'):
                bullets.append(_ceo_bullet_from_item(entry, 'dash'))
            for child in entry.get('children') or []:
                bullets.append(_ceo_bullet_from_item(child, 'dot'))
            if entry.get('note'):
                note_bullet = {'kind': 'note', 'text': str(entry['note'])}
                if entry.get('note_annotation'):
                    note_bullet['annotation'] = entry['note_annotation']
                bullets.append(note_bullet)
        sections.append({'heading': CEO_LABELS['notes'], 'bullets': bullets})


    node['sections'] = sections
    for k in _CEO_LEGACY_KEYS:
        node.pop(k, None)
    return node




def _normalize_term_glossary(raw):
    """term_annotations 를 [(term, definition), ...] 순서 리스트로 정규화."""
    pairs = []
    if isinstance(raw, dict):
        for term, definition in raw.items():
            term = str(term or '').strip()
            definition = str(definition or '').strip()
            if term and definition:
                pairs.append((term, definition))
    elif isinstance(raw, list):
        for entry in raw:
            if isinstance(entry, dict):
                term = str(entry.get('anchor') or entry.get('term') or '').strip()
                definition = str(entry.get('text') or entry.get('description') or '').strip()
                if term and definition:
                    pairs.append((term, definition))
    # 긴 용어를 먼저 매칭해 부분 문자열 오탐(예: "AI" vs "AI Agent")을 줄인다.
    pairs.sort(key=lambda kv: len(kv[0]), reverse=True)
    return pairs




def _iter_annotation_slots(doc_data):
    """이동글틀을 붙일 수 있는 위치를 문서 순서대로 훑는다.


    각 슬롯은 (텍스트, 딕셔너리, 주석키) 튜플. 표/이미지/도식은 제외.
    """
    def walk(container):
        for section in container.get('sections') or []:
            if not isinstance(section, dict):
                continue
            heading = str(section.get('heading') or '')
            if heading:
                yield heading, section, 'headingAnnotation'
            for bullet in section.get('bullets') or []:
                if not isinstance(bullet, dict):
                    continue
                if bullet.get('kind') in {'table', 'image', 'diagram', 'subhead'}:
                    continue
                text = str(bullet.get('text') or '')
                if text:
                    yield text, bullet, 'annotation'


    yield from walk(doc_data)
    for app in doc_data.get('appendices') or []:
        if isinstance(app, dict):
            yield from walk(app)




def apply_term_annotations(doc_data):
    """용어집(term_annotations)을 각 용어의 **첫 등장 지점** 이동글틀로 배분한다.


    - 이미 주석이 달린 라인은 건드리지 않는다 (명시 주석 우선).
    - 한 라인에는 이동글틀 1개만 붙인다 (엔진 제약과 동일).
    - 같은 용어는 문서 전체에서 한 번만 (`references/tone.md` §7 동일 출처
      반복 금지 원칙).
    """
    raw = doc_data.get('termAnnotations')
    if raw is None:
        raw = doc_data.get('term_annotations')
    pairs = _normalize_term_glossary(raw)
    if not pairs:
        return doc_data
    remaining = list(pairs)
    for text, holder, key in _iter_annotation_slots(doc_data):
        if not remaining:
            break
        if holder.get(key):
            continue
        for i, (term, definition) in enumerate(remaining):
            if term in text:
                holder[key] = {'anchor': term, 'text': definition}
                remaining.pop(i)
                break
    doc_data.pop('termAnnotations', None)
    doc_data.pop('term_annotations', None)
    return doc_data




# ---------- Body insertion helper -----------------------------
def _append_block(doc: Document, element: OxmlElement) -> None:
    """Append a block element (w:p or w:tbl) to the document body, before sectPr."""
    body = doc.element.body
    sect_pr = body.find(qn('w:sectPr'))
    if sect_pr is not None:
        sect_pr.addprevious(element)
    else:
        body.append(element)




def _append_blocks(doc: Document, elements) -> None:
    for el in elements:
        _append_block(doc, el)




def _set_last_para_after(doc: Document, after_dxa: int) -> None:
    """직전에 추가된 마지막 w:p 단락의 단락뒤(after) 간격을 after_dxa 로 재지정한다.


    □ 섹션 사이 20pt 간격을 "□ 단락의 before" 대신 "앞 단락의 after" 로
    반영하기 위해 사용. w:tbl 이 마지막일 경우는 처리하지 않는다 (표 뒤
    간격은 trailing spacer 단락으로 이미 처리됨).
    """
    body = doc.element.body
    # 뒤에서부터 w:p 탐색 (sectPr, tbl 제외)
    children = list(body)
    sect_pr = body.find(qn('w:sectPr'))
    # sectPr 이전의 단락들 역방향 탐색
    for el in reversed(children):
        if sect_pr is not None and el is sect_pr:
            continue
        if el.tag == qn('w:p'):
            # pPr 내 spacing 요소의 after 속성을 갱신
            pPr = el.find(qn('w:pPr'))
            if pPr is None:
                pPr = _make('pPr')
                el.insert(0, pPr)
            spacing = pPr.find(qn('w:spacing'))
            if spacing is None:
                spacing = _make('spacing')
                pPr.append(spacing)
            spacing.set(_qn('after'), str(after_dxa))
            return
        # w:tbl 만나면 중단 (표 뒤는 건드리지 않음)
        if el.tag == qn('w:tbl'):
            return




# ---------- Table rendering -----------------------------------
NUMERIC_CELL_REGEX = re.compile(
    r'^[()\-+]?[\d,]+(\.\d+)?\s*(%p?|%|원|₩|달러|\$|B\$|M\$|억|만|천|조|pp|p|배|명|건|시간|분|일|개|kg|g|\s)*\)?$'
)
LONG_NUMERIC_MARKER = re.compile(r'[,.]|\$|₩|달러|B\$|M\$|억|만|천|조|원')
# Columns whose header names this pattern are money/scale quantities — the
# SDS convention is right-align even when the sampled values happen to be
# all short (no thousands-separator) so a column with mixed "820" and "1,200"
# reads consistently. Applied before the short-comparable/center fallback.
MONEY_HEADER_RE = re.compile(
    r'금액|매출|영업이익|순이익|당기순이익|영업손실|손실|비용|수익|세액|'
    r'원$|억원|만원|백만원|천만원|달러|amount|price|revenue|cost|profit|sales',
    re.IGNORECASE,
)




def _is_money_header(text) -> bool:
    if text is None:
        return False
    s = str(text).strip()
    if not s:
        return False
    return bool(MONEY_HEADER_RE.search(s))


CELL_H_PADDING_DXA = 200
MIN_COL_WIDTH_DXA = 900
# 표 셀 좌우 안쪽 여백. 상하는 0 을 유지한다 — 세로 여백은 행 최소 높이
# 0.8cm(`TABLE_MIN_ROW_HEIGHT_TWIPS`)가 이미 만들어 주고, 여기에 값을 주면
# 행이 규정보다 높아진다. 좌우는 보정이 없어 0 이면 글자가 테두리에 붙는다.
# 50 DXA(≈0.09cm)는 `column_content_dxa` 가 열 너비에 이미 얹어 두는
# CELL_H_PADDING_DXA(200) 안쪽이므로 기존 표의 줄바꿈을 바꾸지 않는다.
TABLE_CELL_SIDE_MARGIN_DXA = 50




def is_numeric_cell(v) -> bool:
    if v is None:
        return False
    s = str(v).strip()
    if s == '' or s == '-':
        return False
    return bool(NUMERIC_CELL_REGEX.match(s))




# ---- 260909 정렬 규칙 보강 (손수정본 기준) ----------------------------------
# ④ 첫 열은 `구분`·제목 성격의 소개 항목이므로 짧으면 가운데 정렬.
# ⑤ 시점·기간(`'26.10∼11월`, `'19.12월`, `6/1일`, `2026년`)을 담은 열은 가운데 정렬.
# ⑥ 비교표(구분 열 + 비교 대상 열)처럼 값이 짧은 라벨 열은 가운데 정렬. 단, 헤더가
#    `비고·내용·설명·기업…` 같은 서술/명칭 열이면 그대로 왼쪽.
PERIOD_VALUE_RE = re.compile(
    r"^(?:'\d{2}|\d{4}\s*년?|\d{4}\.\d{1,2}|\d{1,2}/\d{1,2}|Q[1-4]|[1-4]Q|[12]H|FY\s*\d{2}|\d{1,2}월)"
)
PERIOD_TOKEN_RE = re.compile(
    r"(년|월|일|분기|주차|반기|상반기|하반기|Q[1-4]|[1-4]Q|[12]H|FY|CY|\d{4}\.\d{1,2}|\d{1,2}/\d{1,2}|'\d{2})"
)
PERIOD_HEADER_RE = re.compile(
    r'시점|일자|일정|기간|시기|날짜|연도|년도|년월|출시|설립|마감|기한|시행|발표|체결|공개|기준일|'
    r'date|when|period|timeline|year|month', re.IGNORECASE)
DESCRIPTIVE_HEADER_RE = re.compile(
    r'비고|내용|설명|특징|개요|상세|사유|근거|의미|시사점|영향|대응|과제|목적|정의|현황|계획|전략|방안|'
    r'이슈|리스크|참고|출처|역할|기능|용도|담당|기업|회사|업체|사업자|명칭|이름|성명|제품|서비스|모델|'
    r'제목|사업|분야|고객|파트너|경쟁사|투자자|주체|기관|조직|부서|'
    r'note|remark|desc|name|company|vendor|product|item|detail|comment', re.IGNORECASE)
NEUTRAL_CELL_RE = re.compile(r'^(-|–|—|미정|미공개|미확정|비공개|해당\s*없음|N/A|n/a|TBD|미상|없음)$')
LABEL_MAX_WEIGHTED_CHARS = 22   # 전각 1 · 반각 0.5 로 센 길이 상한 (라벨로 볼 수 있는 길이)




def _weighted_len(s) -> float:
    """전각(한글·한자·기호) 1, 반각(영문·숫자·공백) 0.5 로 센 글자 수."""
    return sum(1.0 if is_fullwidth(ord(ch)) else 0.5 for ch in str(s or '').strip())




def _is_period_value(v):
    """True = 시점/기간 값, None = 중립(`-`, `미정` 등), False = 그 외."""
    s = str(v or '').strip()
    if not s:
        return None
    if NEUTRAL_CELL_RE.match(s):
        return None
    if _weighted_len(s) > LABEL_MAX_WEIGHTED_CHARS:
        return False
    if PERIOD_VALUE_RE.match(s):
        return True
    return bool(PERIOD_TOKEN_RE.search(s) and any(ch.isdigit() for ch in s)
                and _weighted_len(s) <= 14)




def _is_period_column(values, header=None) -> bool:
    non_empty = [v for v in values if v is not None and str(v).strip() != '']
    if not non_empty:
        return False
    flags = [_is_period_value(v) for v in non_empty]
    real = [f for f in flags if f is not None]
    if real and sum(1 for f in real if f) / len(real) >= 0.8:
        return True
    if header and PERIOD_HEADER_RE.search(str(header)) and \
            max(_weighted_len(v) for v in non_empty) <= LABEL_MAX_WEIGHTED_CHARS:
        return True
    return False




def _is_short_label_column(values, header=None, col_idx=None) -> bool:
    """짧은 라벨 열 — 첫 열(구분/제목 항목)이거나, 서술형 헤더가 아닌 열의 값이
    전부 라벨 길이(≤22 전각 기준)일 때. 비교표(구분 | Anthropic | OpenAI)의 값 열이
    여기에 해당한다. `기업`·`비고`처럼 명칭/서술 헤더는 왼쪽을 유지한다."""
    non_empty = [v for v in values if v is not None and str(v).strip() != '']
    if not non_empty:
        return False
    if max(_weighted_len(v) for v in non_empty) > LABEL_MAX_WEIGHTED_CHARS:
        return False
    if col_idx == 0:
        return True
    if header and DESCRIPTIVE_HEADER_RE.search(str(header)):
        return False
    return True




def _refine_text_alignment(values, header=None, col_idx=None) -> str:
    """숫자 규칙에 걸리지 않은(=글) 열의 최종 정렬: 시점 열·짧은 라벨 열은 가운데."""
    if _is_period_column(values, header):
        return 'center'
    if _is_short_label_column(values, header, col_idx):
        return 'center'
    return 'left'




def _normalize_explicit_alignments(cols, rows, alignments, *, strict=False):
    """JSON 이 준 `alignments` 중 `left` 를 정책에 맞게 보정한다 — 첫 열의 짧은 라벨과
    시점 열은 어떤 LLM 이 작성했든 가운데로 통일한다(④·⑤). `alignmentsStrict: true`
    면 그대로 둔다."""
    if strict or not isinstance(alignments, list):
        return alignments
    out = list(alignments)
    changed = []
    for idx, header in enumerate(cols):
        if idx >= len(out) or str(out[idx]).strip().lower() != 'left':
            continue
        vals = [r[idx] if idx < len(r) else None for r in rows]
        if _is_period_column(vals, header) or (idx == 0 and _is_short_label_column(vals, header, 0)):
            out[idx] = 'center'
            changed.append(str(header))
    if changed:
        print(f"[INFO] 표 열 {changed} 의 정렬을 left → center 로 보정했습니다 "
              f"(첫 열 라벨·시점 열은 가운데 정렬 정책). 유지하려면 \"alignmentsStrict\": true.",
              file=sys.stderr)
    return out




def is_fixed_length_column(values) -> bool:
    non_empty = [v for v in values if v is not None and str(v).strip() != '']
    if len(non_empty) < 2:
        return False
    length = len(str(non_empty[0]).strip())
    if length == 0 or length > 8:
        return False
    return all(len(str(v).strip()) == length for v in non_empty)




def is_short_comparable_numeric_column(values) -> bool:
    non_empty = [v for v in values if v is not None and str(v).strip() != '']
    if len(non_empty) < 2:
        return False
    if not all(is_numeric_cell(v) for v in non_empty):
        return False
    for v in non_empty:
        s = str(v).strip()
        if len(s) > 5 or LONG_NUMERIC_MARKER.search(s):
            return False
    return True




def infer_column_alignments(cols, rows):
    result = []
    for col_idx, header in enumerate(cols):
        col_vals = [r[col_idx] if col_idx < len(r) else None for r in rows]
        non_empty = [v for v in col_vals if v is not None and str(v).strip() != '']
        if not non_empty:
            result.append('left')
            continue
        all_num = all(is_numeric_cell(v) for v in non_empty)
        # Money/scale header with numeric body → right, even when values are
        # short digits without thousands separators.
        if all_num and _is_money_header(header):
            result.append('right')
            continue
        if all_num and any(LONG_NUMERIC_MARKER.search(str(v).strip()) for v in non_empty):
            result.append('right')
            continue
        if is_fixed_length_column(col_vals):
            result.append('center')
            continue
        if is_short_comparable_numeric_column(col_vals):
            result.append('center')
            continue
        if all_num:
            result.append('right')
            continue
        result.append(_refine_text_alignment(col_vals, header, col_idx))
    return result




def column_content_dxa(header, body_values, font_pt):
    scale = font_pt / 14
    cells = [str(header or '')] + [str(v or '') for v in body_values]
    max_dxa = max((measure_dxa(c) for c in cells), default=0)
    return round(max_dxa * scale) + CELL_H_PADDING_DXA




def is_compressible_column(body_values) -> bool:
    non_empty = [v for v in body_values if v is not None and str(v).strip() != '']
    if not non_empty:
        return True
    if all(is_numeric_cell(v) for v in non_empty):
        return False
    if all(len(str(v).strip()) <= 6 for v in non_empty):
        return False
    return True




def compute_auto_column_widths(cols, rows, total_width, font_pt):
    n = len(cols)
    if n == 0:
        return []
    naturals = [
        max(column_content_dxa(h, [r[i] if i < len(r) else None for r in rows], font_pt),
            MIN_COL_WIDTH_DXA)
        for i, h in enumerate(cols)
    ]
    total = sum(naturals)
    if total >= total_width:
        return [int(w * total_width / total) for w in naturals]
    extra = total_width - total
    compressible = [is_compressible_column([r[i] if i < len(r) else None for r in rows])
                    for i in range(n)]
    flex_weight_total = sum(naturals[i] for i in range(n) if compressible[i])
    if flex_weight_total == 0:
        per = extra // n
        return [w + per for w in naturals]
    return [
        w + int(extra * w / flex_weight_total) if compressible[i] else w
        for i, w in enumerate(naturals)
    ]




def resolve_column_widths(b, cols, rows, total_width, font_pt):
    cw = b.get('columnWidths')
    if isinstance(cw, list) and len(cw) == len(cols):
        try:
            weights = [float(w) if (w is not None and float(w) > 0) else 1.0 for w in cw]
        except (TypeError, ValueError):
            weights = [1.0] * len(cols)
        s = sum(weights)
        return [int(total_width * w / s) for w in weights]
    return compute_auto_column_widths(cols, rows, total_width, font_pt)




def _alignment_from_string(s):
    if s == 'right':
        return 'right'
    if s == 'center':
        return 'center'
    return 'left'




def _clamp_table_font_pt(pt):
    try:
        n = float(pt)
    except (TypeError, ValueError):
        return 12
    if n <= 0:
        return 12
    return max(9, min(14, n))




def _border_el(name: str):
    return _make(name, val='single', sz=4, color='000000', space=0)




def _table_cell_mar(*, top: int, bottom: int, left: int, right: int) -> OxmlElement:
    """Build a w:tblCellMar element to set table-level default cell margins.


    Setting margins on the table (tblCellMar in tblPr) instead of on each cell
    (tcMar in tcPr) lets users adjust cell margins through Word's
    "Table Properties → Table/Cell → Options" dialog. Per-cell tcMar would
    override the table default and silently swallow the user's edits.
    """
    mar = _make('tblCellMar')
    mar.append(_make('top', w=top, type='dxa'))
    mar.append(_make('left', w=left, type='dxa'))
    mar.append(_make('bottom', w=bottom, type='dxa'))
    mar.append(_make('right', w=right, type='dxa'))
    return mar




def _apply_table_row_min_height(tr: OxmlElement, height_twips: int = TABLE_MIN_ROW_HEIGHT_TWIPS) -> None:
    """Set a minimum row height for a Word table row.


    Samsung report tables should keep visually consistent row spacing. Use
    hRule="atLeast" instead of "exact" so multi-line cells can expand without
    clipping while one-line rows never collapse below 0.8cm.
    """
    trPr = tr.find(_qn('trPr'))
    if trPr is None:
        trPr = _make('trPr')
        tr.insert(0, trPr)
    existing = trPr.find(_qn('trHeight'))
    if existing is None:
        trPr.append(_make('trHeight', val=height_twips, hRule='atLeast'))
    else:
        existing.set(_qn('val'), str(height_twips))
        existing.set(_qn('hRule'), 'atLeast')



def _make_cell(text, *, is_header: bool, col_width: int, font_size_half_pt: int,
               alignment: str, bottom_sz: int = 4, accent_sides=()) -> OxmlElement:
    tc = _make('tc')
    tcPr = _make('tcPr')
    tcPr.append(_make('tcW', w=col_width, type='dxa'))
    borders = _make('tcBorders')
    for b in ('top', 'left', 'bottom', 'right'):
        # 전체 테두리 0.5pt(sz=4). 헤더 행 아래줄만 1.5pt(sz=12)로 강조.
        sz = bottom_sz if b == 'bottom' else 4
        color = '000000'
        if b in accent_sides:
            # 설명 대상 열 강조 — 1.5pt 파랑 (260923 손수정본: 비교표의 Meta Muse 열)
            sz, color = TABLE_ACCENT_BORDER_SZ, TABLE_ACCENT_BORDER_COLOR
        borders.append(_make(b, val='single', sz=sz, color=color, space=0))
    tcPr.append(borders)
    tcPr.append(_make('vAlign', val='center'))
    # NOTE: Cell margins are set at the TABLE level via w:tblCellMar on the
    # parent <w:tbl>, not here per-cell with w:tcMar. Per-cell tcMar would
    # override the table default and prevent the user from editing margins via
    # Word's "Table Properties → Cell/Table → Options" dialog.
    tc.append(tcPr)
    run = make_run(str(text or ''), size=font_size_half_pt, bold=is_header)
    p = make_paragraph([run],
                       alignment=('center' if is_header else _alignment_from_string(alignment)),
                       line=240, line_rule='auto', after=0)
    tc.append(p)
    return tc




# ---------- Table merge (cells-mode) helpers ------------------
def _apply_keep_next(p_element) -> None:
    """Add w:keepNext to a paragraph so it stays on the same page as the next block."""
    pPr = p_element.find(_qn('pPr'))
    if pPr is None:
        pPr = _make('pPr')
        p_element.insert(0, pPr)
    if pPr.find(_qn('keepNext')) is None:
        pPr.insert(0, _make('keepNext'))




def _apply_table_keep_together(tbl) -> None:
    """Keep an entire table on one page when possible.


    Two-layer strategy:
      1. `w:cantSplit` on every row — prevents a single row from splitting
         mid-cell across a page boundary.
      2. `w:keepNext` on every paragraph inside every row EXCEPT the last
         row — forces Word to keep each row attached to the next one, so
         the whole table moves to the next page together when it doesn't
         fit. cantSplit alone is not enough; without keepNext Word will
         happily break between rows.


    We skip the final row so Word allows the block AFTER the table (the
    trailing spacer paragraph) to flow normally, and so we add one fewer
    ■ indicator per table in the editing view.
    """
    rows = tbl.findall(_qn('tr'))
    for idx, tr in enumerate(rows):
        trPr = tr.find(_qn('trPr'))
        if trPr is None:
            trPr = _make('trPr')
            tr.insert(0, trPr)
        if trPr.find(_qn('cantSplit')) is None:
            trPr.append(_make('cantSplit'))
        if idx == len(rows) - 1:
            continue
        for tc in tr.findall(_qn('tc')):
            for p in tc.findall(_qn('p')):
                _apply_keep_next(p)




def _infer_one_column_alignment(values, header_texts=(), col_idx=None) -> str:
    """Per-column alignment for a single body column (cells-mode).


    Mirrors the logic of `infer_column_alignments` but runs against one column
    at a time. Uses aggregate signals across the column so every cell in the
    column ends up with the same alignment — e.g. a 금액 column with both
    `820` and `1,200` is classified as right-aligned for all rows, instead of
    mixing center/right per-cell.


    `header_texts` are any header-row origin texts that cover this column. If
    any of them matches a money/scale keyword (`금액`, `매출`, …) we force
    right alignment even when the sampled body values are all short digits.
    """
    non_empty = [v for v in values if v is not None and str(v).strip() != '']
    if not non_empty:
        return 'left'
    all_num = all(is_numeric_cell(v) for v in non_empty)
    if all_num and any(_is_money_header(h) for h in header_texts):
        return 'right'
    if all_num and any(LONG_NUMERIC_MARKER.search(str(v).strip()) for v in non_empty):
        return 'right'
    if is_fixed_length_column(values):
        return 'center'
    if is_short_comparable_numeric_column(values):
        return 'center'
    if all_num:
        return 'right'
    return _refine_text_alignment(values, ' '.join(str(h) for h in header_texts), col_idx)




def _make_merged_cell(text, *, col_widths, colspan, is_header, bold,
                      alignment, font_size_half_pt, vmerge=None):
    """Build a w:tc with optional gridSpan / vMerge."""
    tc = _make('tc')
    tcPr = _make('tcPr')
    total_w = sum(col_widths) if col_widths else 900
    tcPr.append(_make('tcW', w=total_w, type='dxa'))
    if colspan > 1:
        tcPr.append(_make('gridSpan', val=colspan))
    if vmerge == 'restart':
        tcPr.append(_make('vMerge', val='restart'))
    elif vmerge == 'continue':
        tcPr.append(_make('vMerge'))  # no val = continue
    borders = _make('tcBorders')
    for bn in ('top', 'left', 'bottom', 'right'):
        borders.append(_border_el(bn))
    tcPr.append(borders)
    tcPr.append(_make('vAlign', val='center'))
    # Cell margins are set on the parent <w:tbl> via w:tblCellMar so users can
    # edit them from Word's Table Properties dialog (see _table_cell_mar).
    tc.append(tcPr)
    run = make_run(str(text or ''), size=font_size_half_pt, bold=bold)
    p = make_paragraph([run], alignment=_alignment_from_string(alignment),
                       line=240, line_rule='auto', after=0)
    tc.append(p)
    return tc




def _render_cells_table(b: dict) -> OxmlElement:
    """Render a table from a 2-D `cells` array with rowspan/colspan support.


    cells item forms:
      - str                       → single cell, text only
      - {"text", "rowspan",       → explicit cell descriptor
         "colspan", "align", "bold"}
      - None                      → position covered by a prior merge
    """
    cells = b.get('cells') or []
    header_row_count = max(int(b.get('headerRowCount') or 1), 0)
    font_pt = _clamp_table_font_pt(b.get('fontSize', 12))
    font_size_half_pt = round(font_pt * 2)


    # Determine total logical column count: max over all rows of (sum of
    # colspans for dict cells + 1 for each string/None item).
    n_cols = 0
    for row in cells:
        width = 0
        for item in row or []:
            if isinstance(item, dict):
                width += max(int(item.get('colspan', 1)), 1)
            else:
                width += 1
        if width > n_cols:
            n_cols = width
    if n_cols == 0:
        return _make('tbl')  # empty shell


    # Column widths — always sum exactly to total_width so the table's outer
    # right edge aligns precisely with the page content right margin (which is
    # where a right-aligned caption/unit paragraph above the table ends up).
    table_indent = measure_dxa(PREFIX['dash'])
    total_width = PAGE_CONTENT_WIDTH - table_indent
    cw_in = b.get('columnWidths')
    if isinstance(cw_in, list) and len(cw_in) == n_cols:
        try:
            weights = [max(float(w), 0.01) for w in cw_in]
        except (TypeError, ValueError):
            weights = [1.0] * n_cols
        s = sum(weights) or 1.0
        column_widths = [int(total_width * w / s) for w in weights]
    else:
        base = total_width // n_cols
        column_widths = [base] * n_cols
    # Distribute rounding remainder across first N columns so the sum equals
    # total_width exactly.
    remainder = total_width - sum(column_widths)
    for i in range(max(remainder, 0)):
        column_widths[i % n_cols] += 1


    # Build an origin map + coverage status grid
    n_rows = len(cells)
    status = [[None] * n_cols for _ in range(n_rows)]
    origin_data = {}  # (r, c) -> dict
    # Grid contract: each row is a full 2-D grid — exactly one item per
    # logical column. `null` marks a slot covered by a prior merge;
    # strings/dicts emit origin cells (a dict's colspan consumes N columns).
    for r in range(n_rows):
        row = cells[r] or []
        c = 0
        for item in row:
            if c >= n_cols:
                break
            if item is None:
                c += 1
                continue
            if isinstance(item, dict):
                rs = max(int(item.get('rowspan', 1)), 1)
                cs = max(int(item.get('colspan', 1)), 1)
                text = item.get('text', '')
                align_ov = item.get('align')
                bold_ov = item.get('bold')
            else:
                rs, cs = 1, 1
                text = str(item)
                align_ov = None
                bold_ov = None
            rs = min(rs, n_rows - r)
            cs = min(cs, n_cols - c)
            # If this slot is already covered by an earlier merge, the user's
            # item is in conflict — skip it (advance by cs) and keep going.
            if status[r][c] is not None:
                c += cs
                continue
            status[r][c] = ('ORIGIN', rs, cs)
            origin_data[(r, c)] = {
                'text': text, 'rowspan': rs, 'colspan': cs,
                'align': align_ov, 'bold': bold_ov,
            }
            for cc in range(c + 1, c + cs):
                status[r][cc] = ('HCOVER',)
            for rr in range(r + 1, r + rs):
                status[rr][c] = ('VCOVER_LEFT', cs)
                for cc in range(c + 1, c + cs):
                    status[rr][cc] = ('VCOVER_MID',)
            c += cs


    # Column-level alignment inference for body leaf cells (colspan=1,
    # rowspan=1 only). Matches the simple-mode behavior: a column with any
    # thousands-separated / money-marker value aligns all its cells right, so
    # `820` and `1,200` in the same 금액 column don't split across center/right.
    col_alignments = []
    # Pre-collect header-row origin texts per logical column so the money-
    # header heuristic works across spanned headers too (e.g. a column whose
    # innermost header is "금액" under a "'25.상반기" group header).
    header_texts_by_col = [[] for _ in range(n_cols)]
    for (orig_r, orig_c), oo in origin_data.items():
        if orig_r >= header_row_count:
            continue
        for cc in range(orig_c, orig_c + oo['colspan']):
            if 0 <= cc < n_cols:
                header_texts_by_col[cc].append(oo['text'])
    for c in range(n_cols):
        col_values = []
        for r in range(header_row_count, n_rows):
            o = origin_data.get((r, c))
            if o is not None and o['rowspan'] == 1 and o['colspan'] == 1:
                col_values.append(o['text'])
        col_alignments.append(
            _infer_one_column_alignment(col_values, header_texts_by_col[c], c)
        )


    # Build tbl
    tbl = _make('tbl')
    tblPr = _make('tblPr')
    tblPr.append(_make('tblW', w=total_width, type='dxa'))
    tblPr.append(_make('tblInd', w=table_indent, type='dxa'))
    borders = _make('tblBorders')
    for bn in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        borders.append(_border_el(bn))
    tblPr.append(borders)
    tblPr.append(_make('tblLayout', type='fixed'))
    tblPr.append(_table_cell_mar(top=0, bottom=0,
                                 left=TABLE_CELL_SIDE_MARGIN_DXA,
                                 right=TABLE_CELL_SIDE_MARGIN_DXA))
    tbl.append(tblPr)


    tblGrid = _make('tblGrid')
    for w in column_widths:
        tblGrid.append(_make('gridCol', w=w))
    tbl.append(tblGrid)


    # Emit rows
    for r in range(n_rows):
        tr = _make('tr')
        c = 0
        while c < n_cols:
            st = status[r][c]
            in_header = (r < header_row_count)
            if st is None:
                # No origin, no cover — render a blank single cell
                tr.append(_make_merged_cell(
                    '', col_widths=[column_widths[c]], colspan=1,
                    is_header=in_header, bold=in_header,
                    alignment='center' if in_header else 'left',
                    font_size_half_pt=font_size_half_pt, vmerge=None))
                c += 1
            elif st[0] == 'ORIGIN':
                _, rs, cs = st
                o = origin_data[(r, c)]
                bold = o['bold'] if o['bold'] is not None else in_header
                if o['align']:
                    align = o['align']
                elif in_header:
                    align = 'center'
                elif rs > 1 or cs > 1:
                    # Merged body cells: center for readability (a spanned
                    # label looks cramped left-aligned in a wide cell).
                    align = 'center'
                else:
                    align = col_alignments[c]
                tr.append(_make_merged_cell(
                    o['text'],
                    col_widths=column_widths[c:c + cs],
                    colspan=cs, is_header=in_header, bold=bold,
                    alignment=align,
                    font_size_half_pt=font_size_half_pt,
                    vmerge='restart' if rs > 1 else None))
                c += cs
            elif st[0] == 'HCOVER':
                # Already covered by same-row origin's gridSpan
                c += 1
            elif st[0] == 'VCOVER_LEFT':
                _, cs = st
                tr.append(_make_merged_cell(
                    '', col_widths=column_widths[c:c + cs],
                    colspan=cs, is_header=in_header, bold=False,
                    alignment='center',
                    font_size_half_pt=font_size_half_pt,
                    vmerge='continue'))
                c += cs
            else:  # VCOVER_MID — covered by the VCOVER_LEFT cell's gridSpan
                c += 1
        _apply_table_row_min_height(tr)
        tbl.append(tr)


    return tbl




def resolve_accent_column(b: dict, cols) -> int | None:
    """표에서 파란 1.5pt 테두리로 감쌀 열(0-based)을 정한다 (260923).


    - `highlightColumn`: 열 머리글 문자열 또는 0-based 정수. `false`/`null` 이면 자동 판정도 끈다.
    - 생략 시 자동: 첫 열(구분)을 제외한 머리글(3자 이상)이 **문서 제목**에 들어 있으면 그 열 —
      비교표에서 문서가 설명하는 서비스(`Meta Muse`)를 강조한다. 여러 개면 첫 번째, [INFO] 출력.
    """
    if not cols:
        return None
    spec = b.get('highlightColumn', b.get('accentColumn', 'auto'))
    if spec is None or spec is False:
        return None
    if isinstance(spec, bool):          # True → 자동 판정
        spec = 'auto'
    if isinstance(spec, int):
        return spec if 0 <= spec < len(cols) else None
    if isinstance(spec, str) and spec.strip().lower() != 'auto':
        want = spec.strip().lower()
        for i, c in enumerate(cols):
            if str(c or '').strip().lower() == want:
                return i
        for i, c in enumerate(cols):
            if want and want in str(c or '').strip().lower():
                return i
        print(f"[WARN] 표 highlightColumn {spec!r} 에 맞는 열 머리글이 없습니다: {cols}", file=sys.stderr)
        return None
    title = (DOC_TITLE[0] or '').strip().lower()
    if not title:
        return None
    for i, c in enumerate(cols):
        if i == 0:
            continue
        head = str(c or '').strip()
        if len(head) >= 3 and head.lower() in title:
            print(f"[INFO] 표의 '{head}' 열이 문서 제목에 포함돼 파란 1.5pt 테두리로 강조합니다 "
                  f"(끄려면 \"highlightColumn\": false).", file=sys.stderr)
            return i
    return None




def _accent_sides_for(idx: int, accent: int | None, *, first_row: bool, last_row: bool):
    """열 `idx` 의 셀이 강조 열(`accent`)과 관련해 파랗게 칠할 변. 이웃 열의 맞닿은 변도
    같이 칠해 Word 의 인접 셀 테두리 충돌에서 파란 선이 이기게 한다."""
    if accent is None:
        return ()
    sides = []
    if idx == accent:
        sides += ['left', 'right']
        if first_row:
            sides.append('top')
        if last_row:
            sides.append('bottom')
    elif idx == accent - 1:
        sides.append('right')
    elif idx == accent + 1:
        sides.append('left')
    return tuple(sides)




def render_table_element(b: dict) -> OxmlElement:
    if isinstance(b.get('cells'), list) and len(b['cells']) > 0:
        if b.get('highlightColumn') not in (None, False, 'auto'):
            print("[WARN] highlightColumn 은 columns+rows 단순 표에서만 지원합니다 (cells 병합표 무시).",
                  file=sys.stderr)
        return _render_cells_table(b)
    cols = b.get('columns') or []
    rows = b.get('rows') or []
    accent = resolve_accent_column(b, cols)
    font_pt = _clamp_table_font_pt(b.get('fontSize', 12))
    font_size_half_pt = round(font_pt * 2)
    alignments_in = b.get('alignments')
    if isinstance(alignments_in, list) and len(alignments_in) == len(cols):
        alignments = _normalize_explicit_alignments(
            cols, rows, alignments_in,
            strict=bool(b.get('alignmentsStrict') or b.get('alignments_strict')))
    else:
        alignments = infer_column_alignments(cols, rows)
    table_indent = measure_dxa(PREFIX['dash'])
    total_width = PAGE_CONTENT_WIDTH - table_indent
    column_widths = (resolve_column_widths(b, cols, rows, total_width, font_pt)
                     if cols else [])


    tbl = _make('tbl')
    tblPr = _make('tblPr')
    tblPr.append(_make('tblW', w=total_width, type='dxa'))
    tblPr.append(_make('tblInd', w=table_indent, type='dxa'))
    borders = _make('tblBorders')
    for b_name in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        borders.append(_border_el(b_name))
    tblPr.append(borders)
    tblPr.append(_make('tblLayout', type='fixed'))
    tblPr.append(_table_cell_mar(top=0, bottom=0,
                                 left=TABLE_CELL_SIDE_MARGIN_DXA,
                                 right=TABLE_CELL_SIDE_MARGIN_DXA))
    tbl.append(tblPr)


    # tblGrid
    tblGrid = _make('tblGrid')
    for w in column_widths:
        tblGrid.append(_make('gridCol', w=w))
    tbl.append(tblGrid)


    # Header row
    tr = _make('tr')
    for idx, h in enumerate(cols):
        tr.append(_make_cell(h, is_header=True, col_width=column_widths[idx],
                             font_size_half_pt=font_size_half_pt,
                             alignment=alignments[idx] if idx < len(alignments) else 'left',
                             bottom_sz=12,
                             accent_sides=_accent_sides_for(idx, accent, first_row=True,
                                                            last_row=not rows)))
    _apply_table_row_min_height(tr)
    tbl.append(tr)
    # Body rows
    for r_i, row in enumerate(rows):
        tr = _make('tr')
        for idx, _ in enumerate(cols):
            cell_val = row[idx] if idx < len(row) else ''
            tr.append(_make_cell(cell_val, is_header=False, col_width=column_widths[idx],
                                 font_size_half_pt=font_size_half_pt,
                                 alignment=alignments[idx] if idx < len(alignments) else 'left',
                                 accent_sides=_accent_sides_for(idx, accent, first_row=False,
                                                                last_row=(r_i == len(rows) - 1))))
        _apply_table_row_min_height(tr)
        tbl.append(tr)
    return tbl




# ---------- Bullet rendering ----------------------------------
def _clean_subhead_text(value):
    """소제목의 중복 장식과 잘못 들어간 □ 계층 마커를 정리한다."""
    text = normalize_body(value or '', autocap=False).strip()
    stripped_angles = False
    while len(text) >= 2 and text.startswith('<') and text.endswith('>'):
        text = text[1:-1].strip()
        stripped_angles = True
    promoted = bool(re.match(r'^□\s*', text))
    if promoted:
        text = re.sub(r'^□\s*', '', text, count=1).strip()
    return text, promoted, stripped_angles




def render_bullet(doc: Document, bullet: dict, is_last: bool = False, next_kind: str | None = None):
    kind = bullet.get('kind')


    if kind == 'image':
        render_image_bullet(doc, bullet, is_last=is_last)
        return


    if kind == 'diagram':
        render_diagram_bullet(doc, bullet, is_last=is_last)
        return


    if kind == 'table':
        caption = bullet.get('caption')
        unit = bullet.get('unit')
        if caption:
            # 표 제목 `< >` 단락 아래 12pt 간격을 항상 둔다. 단위(`unit`) 라인이
            # 뒤따르더라도 12pt는 제목 바로 아래에 적용한다.
            cap_p = body_paragraph(f"< {caption} >", alignment='center',
                                   after=AFTER['body'], size=SIZE_BODY, bold=True)
            _apply_keep_next(cap_p)
            _append_block(doc, cap_p)
        if unit:
            unit_p = body_paragraph(f"({unit})", alignment='right',
                                    after=0, size=20)  # 10pt
            _apply_keep_next(unit_p)
            _append_block(doc, unit_p)
        tbl = render_table_element(bullet)
        _apply_table_keep_together(tbl)
        _append_block(doc, tbl)
        # Trailing spacer paragraph (matches JS: tiny line=40 exact, carries after-spacing)
        sp_after = (AFTER['last_in_section'] if is_last
                    else _bullet_after_spacing('table', next_kind))
        sp = make_paragraph([make_run('')], line=40, line_rule='exact', before=0,
                            after=sp_after)
        _append_block(doc, sp)
        return


    if kind == 'subhead':
        text, promoted, stripped_angles = _clean_subhead_text(bullet.get('text', ''))
        if stripped_angles:
            print("[WARN] subhead text의 중복 < >를 제거했습니다. "
                  "괄호는 생성기가 자동으로 붙입니다.", file=sys.stderr)
        if promoted:
            print("[WARN] subhead text에서 선행 '□'를 발견했습니다. "
                  "'< □ ... >' 중앙 소제목 대신 좌측 정렬 □ 헤딩으로 복구했습니다. "
                  "정식 입력은 sections[].heading을 사용하세요.", file=sys.stderr)
            p = body_paragraph(f"□ {text}", after=AFTER['section_heading'],
                               alignment=None, bold=True)
            _apply_keep_next(p)
        else:
            p = body_paragraph(f"< {text} >",
                               after=AFTER['body'], alignment='center', bold=True)
        _append_block(doc, p)
        return


    # Compute prefix
    if kind == 'circled':
        idx = (bullet.get('index') or 1) - 1
        circle = CIRCLED[idx] if 0 <= idx < len(CIRCLED) else CIRCLED[0]
        prefix = f' {circle} '
    elif kind == 'ordered':
        prefix = f" {bullet.get('index') or 1}) "
    else:
        prefix = PREFIX.get(kind, PREFIX['dash'])


    ann = normalize_annotation(bullet.get('annotation'))
    is_bold = bullet.get('bold') is True
    is_underline = bullet.get('underline') is True
    is_highlight = bullet.get('highlight') is True
    user_scale = bullet.get('scale')
    manual_scale = user_scale is not None
    prefix_scale = user_scale if manual_scale else WIDTH_PCT
    text_scale = user_scale if manual_scale else WIDTH_PCT
    text = normalize_body(strip_duplicate_marker(kind, bullet.get('text') or ''),
                          where=f"'{kind or 'dash'}' 불릿",
                          autocap=(kind != 'subhead'))
    # `예시 :` → `예)` (260923). 부분 강조 마크업(`**…**`/`__…__`)은 폭 계산 전에 벗긴다.
    text = normalize_example_label(text)
    text, em_spans = parse_inline_emphasis(text)


    # 이동글틀에는 설명 대상 용어명을 반복하지 않는다(정의만). 작성 단계에서
    # "용어 : 정의" 형태가 들어와도 선행 "anchor :" 라벨을 자동 제거한다.
    if ann:
        if ann.get('anchor'):
            ann['anchor'] = strip_inline_emphasis(normalize_hanja(ann['anchor']))
        ann['text'] = normalize_example_label(
            _strip_anchor_label(normalize_hanja(ann.get('text') or ''), ann.get('anchor')))


    last_normal_after = (AFTER['last_in_section'] if is_last
                         else _bullet_after_spacing(kind or 'dash', next_kind))


    hang_indent = hanging_indent_for(prefix, text)
    continuation_indent = hang_indent['left'] if hang_indent else measure_dxa(prefix)
    wrap_width = _wrap_width_dxa()   # 사진 옆 줄이면 RIGHT_RESERVE_DXA 만큼 좁다
    first_line_capacity = round(wrap_width * WRAP_SAFETY_MARGIN)
    continuation_capacity = round((wrap_width - continuation_indent) * WRAP_SAFETY_MARGIN)
    lines = split_bullet_text(prefix, text,
                              first_line_capacity=first_line_capacity,
                              continuation_capacity=continuation_capacity,
                              prefix_scale=prefix_scale,
                              text_scale=text_scale)


    # Auto widow fix: only when user didn't set `scale` manually.
    # Single-word widow (1개 단어만 밀림): character spacing -0.2pt → -0.3pt 우선 시도.
    # Multi-word widow (2단어): scale 조정(94→90) 시도.
    char_spacing = 0  # 1/20pt units; negative = tighter
    if not manual_scale and _last_line_is_widow(lines):
        if _last_line_is_single_word_widow(lines):
            # Pass A: single-word widow → try character spacing first (요청: 0.2pt, max 0.3pt)
            # -0.2pt = -4 twips, -0.3pt = -6 twips
            char_resolved = False
            for cs in (-4, -6):
                cand_lines = split_bullet_text(
                    prefix, text,
                    first_line_capacity=first_line_capacity,
                    continuation_capacity=continuation_capacity,
                    prefix_scale=prefix_scale,
                    text_scale=text_scale,
                    char_spacing_twips=cs,
                )
                if not _last_line_is_single_word_widow(cand_lines):
                    lines = cand_lines
                    char_spacing = cs
                    char_resolved = True
                    break
            # Pass B: if character spacing didn't resolve, fall back to scale
            if not char_resolved:
                for candidate in (94, 93, 92, 91, 90):
                    cand_lines = split_bullet_text(
                        prefix, text,
                        first_line_capacity=first_line_capacity,
                        continuation_capacity=continuation_capacity,
                        prefix_scale=WIDTH_PCT,
                        text_scale=candidate,
                    )
                    if not _last_line_is_widow(cand_lines):
                        lines = cand_lines
                        text_scale = candidate
                        break
        else:
            # Multi-word widow: scale adjustment only
            for candidate in (94, 93, 92, 91, 90):
                cand_lines = split_bullet_text(
                    prefix, text,
                    first_line_capacity=first_line_capacity,
                    continuation_capacity=continuation_capacity,
                    prefix_scale=WIDTH_PCT,
                    text_scale=candidate,
                )
                if not _last_line_is_widow(cand_lines):
                    lines = cand_lines
                    text_scale = candidate
                    break


    anchor_line_idx = -1
    anchor_pos_in_line = None
    if ann and ann['anchor']:
        for i, ln in enumerate(lines):
            if ann['anchor'] in ln:
                anchor_line_idx = i
                break
        if anchor_line_idx < 0:
            # 앵커가 줄바꿈으로 갈라진 경우 — 앵커가 시작되는 줄에 붙인다 (260923).
            located = _locate_anchor_across_lines(lines, text, ann['anchor'])
            if located:
                anchor_line_idx, anchor_pos_in_line = located


    use_anchor_placement = ann is not None and anchor_line_idx >= 0
    ann_insert_after = (anchor_line_idx if use_anchor_placement
                        else (len(lines) - 1 if ann else -1))


    # Umbrella (no-anchor) annotations default to the bullet's own text start
    # (after the `- `/`· ` prefix), not the raw column edge (dxa 0) — anchoring
    # at 0 makes the box appear to start slightly ahead of/before the actual
    # bullet text instead of under it.
    ann_indent_dxa = measure_dxa(prefix, prefix_scale)
    # 앵커가 놓인 본문 줄의 글자 끝 x — `┘` 전환 판정(과다 돌출)에 쓴다.
    ann_line_end_dxa = None
    if ann and 0 <= ann_insert_after < len(lines):
        _lt = lines[ann_insert_after]
        ann_line_end_dxa = ((measure_dxa(prefix, prefix_scale) + measure_dxa(_lt, text_scale))
                            if ann_insert_after == 0
                            else continuation_indent + measure_dxa(_lt, text_scale))
    # 앵커 줄의 글자 시작 x — ┘ 박스가 이보다 왼쪽으로 나가지 않게 하는 하한 (260923).
    ann_line_start_dxa = None
    if ann and 0 <= ann_insert_after < len(lines):
        ann_line_start_dxa = (measure_dxa(prefix, prefix_scale) if ann_insert_after == 0
                              else continuation_indent)
    if ann and ann['anchor']:
        if anchor_line_idx >= 0:
            lt = lines[anchor_line_idx]
            pos = lt.find(ann['anchor'])
            if pos < 0 and anchor_pos_in_line is not None:
                pos = anchor_pos_in_line
            if anchor_line_idx == 0:
                ann_indent_dxa = (measure_dxa(prefix, prefix_scale)
                                  + measure_dxa(lt[:pos], text_scale))
            else:
                ann_indent_dxa = continuation_indent + measure_dxa(lt[:pos], text_scale)
        else:
            ann_indent_dxa = anchor_indent_or_warn(
                prefix, text, ann['anchor'],
                where=f"'{kind or 'dash'}' 불릿 본문",
                fallback_dxa=measure_dxa(prefix, prefix_scale))


    # Continuation-line leading spaces: match the first-line prefix width using
    # repeated half-width spaces so the continuation's x-start is reached purely
    # by literal whitespace (no paragraph w:ind). All default prefixes are an
    # exact multiple of half-width space width; under widow-fix (text_scale <
    # prefix_scale) the alignment may drift by ≤1 space, which is acceptable
    # per spec.
    cont_space_dxa = round(BODY_PT * 20 * 0.50 * (text_scale / 100))
    cont_spaces = (round(continuation_indent / cont_space_dxa)
                   if cont_space_dxa > 0 else 0)
    cont_pad = ' ' * max(cont_spaces, 0)
    line_offsets = _line_offsets(text, lines) if em_spans else [0] * len(lines)


    for i, line_text in enumerate(lines):
        is_last_line = (i == len(lines) - 1)
        indent = hang_indent if i == 0 else None


        if is_last_line:
            after = last_normal_after
        else:
            after = AFTER['body_wrap']


        # First line carries the prefix at prefix_scale, body text at text_scale
        # (two runs); continuation lines pad with half-width spaces to align
        # under the first-line text start, without using paragraph indent.
        # Underline applies only to the actual sentence text, never to the
        # prefix mark or to the continuation alignment pad — otherwise a
        # wrapped underlined bullet shows an underline over the leading blanks.
        body_runs = _emphasis_runs(line_text, line_offsets[i], em_spans,
                                   bold=is_bold, underline=is_underline, scale=text_scale,
                                   character_spacing=char_spacing if char_spacing else None,
                                   highlight=is_highlight)
        if i == 0:
            runs = [make_run(prefix, size=SIZE_BODY, bold=is_bold, scale=prefix_scale)] + body_runs
        else:
            runs = [make_run(cont_pad, size=SIZE_BODY, bold=is_bold, underline=False,
                             scale=text_scale,
                             character_spacing=char_spacing if char_spacing else None)] + body_runs
        p = make_paragraph(runs, alignment=None, line=BODY_LINE[0], line_rule='auto',
                           after=after, indent=indent)
        _append_block(doc, p)


        if ann and i == ann_insert_after:
            # 이동글틀(주석)을 anchor 라인 단락에 직접 부착 — 별도 host 단락(1pt)을
            # 만들지 않아 불릿 사이 1pt 빈 줄이 생기지 않는다. 텍스트 앞 wrap 으로
            # 떠 있어 본문 세로 공간을 차지하지 않는다.
            attach_annotation(
                p,
                ann['text'],
                indent_dxa=ann_indent_dxa,
                long_mode=_annotation_is_long(ann['text'], ann_indent_dxa, ann_line_end_dxa),
                line_start_dxa=ann_line_start_dxa,
                line_end_dxa=ann_line_end_dxa,
                highlight=ann.get('highlight', False),
            )




# ---------- Section heading & section -------------------------
def render_section_heading(doc: Document, section: dict, is_first: bool = True):
    # 페이지 나누기: 섹션이 페이지 하단에 1줄만 남아 잘릴 것 같으면 JSON에서
    # "pageBreakBefore": true 를 지정한다.
    # ── 구현: □ 헤딩 단락 자체가 아닌 **직전 단락의 끝**에 w:br(page) run을
    # 삽입해, □ 가 다음 페이지 첫째 줄에 오도록 한다. 빈 단락 없이
    # 앞 페이지에서 자연스럽게 끊기는 방식.
    # (첫 섹션엔 적용 안 함 — 본문 첫 페이지가 비지 않도록.)
    if bool(section.get('pageBreakBefore')) and not is_first:
        _add_page_break_after_last_para(doc)


    has_numeral = section.get('numeral') is not None and str(section.get('numeral')).strip() != ''
    has_number = (not has_numeral
                  and section.get('number') is not None
                  and str(section.get('number')).strip() != '')
    if has_numeral:
        prefix = f"{str(section['numeral']).strip()}. "
        heading_size = 32
    elif has_number:
        prefix = f"{str(section['number']).strip()}. "
        heading_size = 28
    else:
        prefix = '\u25A1 '
        heading_size = SIZE_BODY


    body_text = normalize_body(section.get('heading', '') or '', autocap=False).strip()
    if re.match(r'^□\s*', body_text):
        body_text = re.sub(r'^□\s*', '', body_text, count=1).strip()
        print("[WARN] sections[].heading의 선행 '□'를 제거했습니다. "
              "섹션 마커는 생성기가 자동으로 붙입니다.", file=sys.stderr)
    heading_text = f"{prefix}{body_text}"
    ann = normalize_annotation(section.get('headingAnnotation'))
    if ann:
        if ann.get('anchor'):
            ann['anchor'] = normalize_hanja(ann['anchor'])
        ann['text'] = _strip_anchor_label(normalize_hanja(ann.get('text') or ''),
                                          ann.get('anchor'))


    # Pre-wrap long headings into multiple paragraphs (same approach as
    # render_bullet) so wrapped lines carry body_wrap (9pt) after-spacing
    # between them \u2014 matches the visual gap users see on wrapped bullets.
    # The colon-based hanging indent still aligns continuation lines under
    # the value column.
    hang_indent = hanging_indent_for(prefix, body_text)
    continuation_indent = hang_indent['left'] if hang_indent else measure_dxa(prefix)
    wrap_width = _wrap_width_dxa()   # □ 헤딩 우측 사진이 있으면 그만큼 좁다
    first_capacity = round(wrap_width * WRAP_SAFETY_MARGIN)
    cont_capacity = round((wrap_width - continuation_indent) * WRAP_SAFETY_MARGIN)
    lines = split_bullet_text(prefix, body_text,
                              first_line_capacity=first_capacity,
                              continuation_capacity=cont_capacity)

    last_idx = len(lines) - 1
    for i, line_text in enumerate(lines):
        is_first_line = (i == 0)
        is_last_line = (i == last_idx)
        # □ 헤딩 단락의 before 간격은 사용하지 않는다 — 대신 이전 섹션의
        # 마지막 단락 after 를 400으로 재지정하는 방식으로 처리한다.
        # (render_body / render_appendix 에서 _set_last_para_after 호출)
        before = None
        after = (AFTER['section_heading'] if is_last_line
                 else AFTER['body_wrap'])
        text = f"{prefix}{line_text}" if is_first_line else line_text
        p = body_paragraph(text, before=before, after=after,
                           indent=(hang_indent if is_first_line else None),
                           bold=True, size=heading_size)
        if not is_first_line and continuation_indent > 0:
            # Continuation lines start under the value column (post-colon).
            pPr = p.find(_qn('pPr'))
            if pPr is None:
                pPr = _make('pPr')
                p.insert(0, pPr)
            for existing in list(pPr.findall(_qn('ind'))):
                pPr.remove(existing)
            pPr.append(_make('ind', left=continuation_indent))
        _append_block(doc, p)
        if section.get('bullets'):
            _apply_keep_next(p)
        last_heading_p = p


    if ann:
        # No-anchor (umbrella) heading annotation: default to the heading's
        # own text start (after the `□ `/`1. ` prefix), not dxa 0 — see the
        # matching fix in render_bullet for why 0 makes the box look like it
        # starts ahead of the heading text.
        indent_dxa = (anchor_indent_or_warn('', heading_text, ann['anchor'],
                                            where='소제목', fallback_dxa=measure_dxa(prefix))
                      if ann.get('anchor') else measure_dxa(prefix))
        # 헤딩 라인 단락에 직접 부착 (별도 host 단락 없음 → 1pt 빈 줄 제거).
        heading_line_end_dxa = ((continuation_indent + measure_dxa(lines[-1]))
                                if len(lines) > 1 else measure_dxa(heading_text))
        attach_annotation(last_heading_p, ann['text'],
                          indent_dxa=indent_dxa,
                          long_mode=_annotation_is_long(ann['text'], indent_dxa,
                                                        heading_line_end_dxa),
                          line_start_dxa=(continuation_indent if len(lines) > 1
                                          else measure_dxa(prefix)),
                          line_end_dxa=heading_line_end_dxa,
                          highlight=ann.get('highlight', False))




# □ 제목과 바로 아래 `< 캡션 >`이 "같은 것"을 가리키는지 판정할 때 쓰는 끝말(중심 명사)
# 동의어 묶음. 손수정본: `□ 주요 지표 대비` + `< 상장 추진 현황 비교 >` → 둘 다 '비교'가
# 중심이라 중복으로 보고 캡션을 지우고 □ 제목을 더 구체적인 캡션 문구로 바꿨다.
_CAPTION_HEAD_SYNONYMS = [
    {'비교', '대비', '비교표', '대조'},
    {'현황', '추이', '이력', '동향', '실적'},
    {'구조', '체계', '구성', '구성도', '구조도'},
    {'일정', '계획', '로드맵', '타임라인'},
    {'개요', '요약', '정리'},
]




def _head_noun_key(text: str) -> str:
    t = normalize_body(text or '', autocap=False).strip()
    t = re.sub(r'[<>\[\]()]', ' ', t)
    tokens = [tok for tok in re.split(r'[\s·,/]+', t) if tok]
    if not tokens:
        return ''
    last = tokens[-1]
    for group in _CAPTION_HEAD_SYNONYMS:
        if last in group:
            return min(group)
    return last




def _heading_caption_duplicate(heading: str, caption: str) -> bool:
    """□ 제목과 캡션이 같은 대상을 가리키면 True — 문자열 일치, 포함 관계, 또는
    중심 명사(끝말) 일치(동의어 포함)."""
    hk = re.sub(r'\s+', '', normalize_body(heading or '', autocap=False).strip())
    ck = re.sub(r'\s+', '', normalize_body(caption or '', autocap=False).strip())
    if not hk or not ck:
        return False
    if hk == ck or hk in ck or ck in hk:
        return True
    hn, cn = _head_noun_key(heading), _head_noun_key(caption)
    return bool(hn) and hn == cn




def render_section(doc: Document, section: dict, is_last: bool = False, is_first: bool = True):
    # 줄간격 압축: 해당 섹션(또는 그 섹션이 놓인 페이지)이 1~2줄 정도만 넘칠 때,
    # 작성 단계에서 section 에 "compact": true (→ line 223) 또는 "line": <값> 을
    # 지정하면 그 섹션의 본문 줄간격을 줄여 한 페이지에 맞춘다.
    prev_line = BODY_LINE[0]
    if section.get('line') is not None:
        BODY_LINE[0] = int(section['line'])
    elif section.get('compact'):
        BODY_LINE[0] = LINE_COMPRESSED
    try:
        section = dict(section)
        bullets = list(section.get('bullets') or [])
        # 같은 섹션 제목을 바로 아래의 `< >` 소제목/캡션으로 반복하지 않는다(⑦).
        # 문자열이 같을 때뿐 아니라 뜻이 같을 때(포함 관계·중심 명사 일치)도 중복으로
        # 본다. subhead는 제거하고, 표·이미지·도식은 콘텐츠는 유지하되 caption만 제거.
        # 캡션이 □ 제목보다 구체적(길면)이면 □ 제목을 캡션 문구로 바꾼다 — 손수정본과
        # 같은 결과(`□ 주요 지표 대비` → `□ 상장 추진 현황 비교`).
        heading_raw = section.get('heading') or ''
        while bullets and heading_raw.strip():
            first = bullets[0]
            first_kind = first.get('kind')
            if first_kind == 'subhead':
                repeated_text = _clean_subhead_text(first.get('text'))[0]
            elif first_kind in {'table', 'image', 'diagram'}:
                repeated_text = first.get('caption')
            else:
                repeated_text = None
            if not repeated_text or not _heading_caption_duplicate(heading_raw, repeated_text):
                break
            if first_kind == 'subhead':
                bullets = bullets[1:]
                print(f"[INFO] □ 제목과 같은 뜻의 소제목 '< {repeated_text} >' 을 생략했습니다.",
                      file=sys.stderr)
                continue
            first = dict(first)
            first.pop('caption', None)
            bullets[0] = first
            if _weighted_len(repeated_text) > _weighted_len(heading_raw):
                print(f"[INFO] □ 제목 '{heading_raw}' 과 바로 아래 {first_kind} 캡션 "
                      f"'< {repeated_text} >' 이 같은 뜻이라 캡션을 생략하고 □ 제목을 캡션 문구로 "
                      f"바꿨습니다.", file=sys.stderr)
                section['heading'] = repeated_text
            else:
                print(f"[INFO] □ 제목 '{heading_raw}' 과 같은 뜻의 {first_kind} 캡션 "
                      f"'< {repeated_text} >' 을 생략했습니다.", file=sys.stderr)
            break
        # □ 헤딩 우측 "텍스트 앞" 사진 (260923 손수정본 Jev) — `sections[].profileImage`
        # 또는 `kind:"image", "float":"right"` 불릿. float 불릿은 목록에서 빼고 직전 단락에
        # 붙인다(첫 불릿이면 □ 헤딩). 사진 세로 범위의 줄은 wrap 폭을 줄여 겹침을 막는다.
        photo_spec = _section_photo_spec(section)
        floats: dict[int, dict] = {}
        kept: list[dict] = []
        for b in bullets:
            fspec = _float_image_spec_from_bullet(b)
            if fspec is None:
                kept.append(b)
            elif len(kept) in floats:
                print("[WARN] 같은 단락에 float 이미지가 2개 이상 붙어 두 번째 이후를 무시했습니다.",
                      file=sys.stderr)
            else:
                floats[len(kept)] = fspec
        if 0 in floats:
            if photo_spec:
                print("[WARN] sections[].profileImage 와 첫 불릿 float 이미지가 함께 있어 "
                      "profileImage 만 사용합니다.", file=sys.stderr)
            else:
                photo_spec = floats[0]
            floats.pop(0)
        bullets = kept
        prev_reserve = RIGHT_RESERVE_DXA[0]
        reserve_dxa = 0
        reserved_until = 0
        try:
            if photo_spec:
                reserve_dxa = _photo_reserve_dxa(photo_spec)
                RIGHT_RESERVE_DXA[0] = reserve_dxa
            render_section_heading(doc, section, is_first=is_first)
            if photo_spec:
                reserved_until = _attach_section_photo(
                    doc, photo_spec, bullets, start_index=0, reserve_dxa=reserve_dxa,
                    label=section.get('heading') or '')
            for i, b in enumerate(bullets):
                if i in floats:
                    reserve_dxa = _photo_reserve_dxa(floats[i])
                    reserved_until = _attach_section_photo(
                        doc, floats[i], bullets, start_index=i, reserve_dxa=reserve_dxa,
                        label=section.get('heading') or '')
                RIGHT_RESERVE_DXA[0] = reserve_dxa if i < reserved_until else 0
                nxt = bullets[i + 1].get('kind') if (i + 1) < len(bullets) else None
                render_bullet(doc, b, is_last=(i == len(bullets) - 1), next_kind=nxt)
        finally:
            RIGHT_RESERVE_DXA[0] = prev_reserve
    finally:
        BODY_LINE[0] = prev_line
    # Section separator paragraph removed \u2014 section heading's `before=20pt`
    # carries the inter-section gap instead (matches new SC template).




# ---------- Title block, cover, TOC ---------------------------
def render_title_block(doc: Document, doc_data: dict):
    title = normalize_body(doc_data.get('title') or '(제목 없음)')
    title_width_dxa = measure_title_dxa(title)
    if title_width_dxa > PAGE_CONTENT_WIDTH:
        print(f"[WARN] 제목이 한 줄 폭을 초과해 Word에서 2줄로 줄바꿈됩니다 "
              f"({title_width_dxa}dxa > {PAGE_CONTENT_WIDTH}dxa) — 축약 권장: {title!r}",
              file=sys.stderr)
    p = make_paragraph([make_run(title, size=SIZE_TITLE, bold=True, underline=True)],
                       alignment='center', line=240, line_rule='auto', after=AFTER['title'])
    # 기사/1차 소스 인용 URL — 제목 단락에 이동글틀(floating DrawingML textbox)로
    # 직접 부착해 제목 바로 아래에 표시. 별도 host 단락 없이 y_dxa 만큼 아래에 떠 있음.
    src = doc_data.get('sourceUrl') or doc_data.get('titleSource')
    if src:
        src = str(src).strip()
        if src.startswith('*'):
            src = src.lstrip('* ').strip()
        # Align the source URL textbox to the title text's left edge, not the page left edge.
        source_x_dxa = max(0, min((PAGE_CONTENT_WIDTH - title_width_dxa) // 2, PAGE_CONTENT_WIDTH - 1200))
        source_w_dxa = PAGE_CONTENT_WIDTH - source_x_dxa
        drawing = _build_source_url_drawing(src, x_dxa=source_x_dxa, width_dxa=source_w_dxa)
        r = _make('r')
        r.append(drawing)
        p.append(r)
    _append_block(doc, p)
    if doc_data.get('date'):
        p2 = make_paragraph([make_run(normalize_body(doc_data['date']))],
                            alignment='right', line=240, line_rule='auto', after=AFTER['date'])
        _append_block(doc, p2)




def _spacer_paragraph(size_half_pt: int = 24, after: int = 120) -> OxmlElement:
    return make_paragraph([make_run('', size=size_half_pt)],
                          line=240, line_rule='auto', after=after)




def _page_break_paragraph() -> OxmlElement:
    """A paragraph containing a single w:br (page break), matching JS PageBreak."""
    r = _make('r')
    r.append(_make('br', type='page'))
    return make_paragraph([r], line=240, line_rule='auto', after=0)




def _set_page_break_before(p_element) -> None:
    """Add <w:pageBreakBefore/> to a paragraph's pPr so it starts a new page
    without inserting a separate empty break paragraph (which would push a
    blank line onto the next page)."""
    pPr = p_element.find(_qn('pPr'))
    if pPr is None:
        pPr = _make('pPr')
        p_element.insert(0, pPr)
    if pPr.find(_qn('pageBreakBefore')) is None:
        pPr.insert(0, _make('pageBreakBefore'))




def _add_page_break_after_last_para(doc: Document) -> None:
    """직전에 추가된 마지막 w:p 단락의 끝에 w:br (page break) run 을 삽입한다.


    □ 섹션 헤딩이 페이지 하단에 1줄만 남을 때, 그 앞 단락에 페이지 나누기를
    걸어 □ 가 다음 페이지 첫째 줄에 나오도록 한다.
    — "□ 단락의 pageBreakBefore" 대신 "앞 단락의 단락 끝 pageBreak" 방식으로
    처리해, □ 앞에 빈 줄이 생기지 않고 자연스럽게 페이지가 나뉜다.
    """
    body = doc.element.body
    for el in reversed(list(body)):
        if el.tag == qn('w:p'):
            br_r = _make('r')
            br_r.append(_make('br', type='page'))
            el.append(br_r)
            return




def _boxed_table(inner_children, *, width: int, alignment: str = 'center',
                 border_sz: int = 8, margins=(480, 480, 300, 300)) -> OxmlElement:
    """Single-cell bordered table used for TOC title and TOC content boxes."""
    tbl = _make('tbl')
    tblPr = _make('tblPr')
    tblPr.append(_make('tblW', w=width, type='dxa'))
    if alignment == 'center':
        tblPr.append(_make('jc', val='center'))
    elif alignment == 'right':
        tblPr.append(_make('jc', val='right'))
    borders = _make('tblBorders')
    for b_name in ('top', 'left', 'bottom', 'right'):
        borders.append(_make(b_name, val='single', sz=border_sz, color='000000', space=0))
    tblPr.append(borders)
    tblPr.append(_make('tblLayout', type='fixed'))
    top_m, bottom_m, left_m, right_m = margins
    tblPr.append(_table_cell_mar(top=top_m, bottom=bottom_m,
                                 left=left_m, right=right_m))
    tbl.append(tblPr)
    grid = _make('tblGrid')
    grid.append(_make('gridCol', w=width))
    tbl.append(grid)
    tr = _make('tr')
    tc = _make('tc')
    tcPr = _make('tcPr')
    tcPr.append(_make('tcW', w=width, type='dxa'))
    tc_borders = _make('tcBorders')
    for b_name in ('top', 'left', 'bottom', 'right'):
        tc_borders.append(_make(b_name, val='single', sz=border_sz, color='000000', space=0))
    tcPr.append(tc_borders)
    # Margins are inherited from w:tblCellMar on the parent <w:tbl>.
    tc.append(tcPr)
    for child in inner_children:
        tc.append(child)
    tr.append(tc)
    _apply_table_row_min_height(tr)
    tbl.append(tr)
    return tbl




def render_toc_page(doc: Document, toc: dict):
    toc = toc or {}


    # 1) Small top spacer
    _append_block(doc, _spacer_paragraph(24, 120))


    # 2) Title box
    if toc.get('reportTitle'):
        box_width = 7600
        title_p = make_paragraph(
            [make_run(toc['reportTitle'], size=44, bold=True, scale=100)],
            alignment='center', line=240, line_rule='auto', after=0,
        )
        _append_block(doc, _boxed_table([title_p], width=box_width,
                                        alignment='center', border_sz=8,
                                        margins=(480, 480, 300, 300)))


    # 3) 2 empty spacers
    _append_block(doc, _spacer_paragraph(24, 120))
    _append_block(doc, _spacer_paragraph(24, 120))


    # 4) "- 목    차 -" center 18pt bold
    _append_block(doc, make_paragraph(
        [make_run('- 목    차 -', size=36, bold=True, scale=100)],
        alignment='center', line=240, line_rule='auto', after=300,
    ))


    # 5) TOC body box
    toc_children = []
    main_items = toc.get('items') or []
    for idx, item in enumerate(main_items):
        text = item if isinstance(item, str) else (item.get('text') or '')
        num = (item.get('number') if isinstance(item, dict) and item.get('number') is not None
               else (idx + 1))
        item_text = f"{num}. {text}"
        toc_children.append(make_paragraph(
            [make_run(item_text, size=32, bold=True, scale=100)],
            alignment='left', line=360, line_rule='auto', after=280,
            indent={'left': 600, 'hanging': 280},
        ))


    if toc.get('appendix'):
        label = toc['appendix'].get('label') or '[별첨]'
        app_items = toc['appendix'].get('items') or []
        for idx, item in enumerate(app_items):
            text = item if isinstance(item, str) else (item.get('text') or '')
            prefix = f"{label} " if idx == 0 else ''
            left_indent = 900 if idx == 0 else 1900
            toc_children.append(make_paragraph(
                [make_run(f"{prefix}{text}", size=28, scale=100)],
                alignment='left', line=300, line_rule='auto', after=200,
                indent={'left': left_indent},
            ))


    if toc_children:
        box_width = 8800
        _append_block(doc, _boxed_table(toc_children, width=box_width,
                                        alignment='center', border_sz=4,
                                        margins=(500, 500, 500, 500)))


    # Spacer
    _append_block(doc, _spacer_paragraph(24, 240))


    # 6) Date
    if toc.get('date'):
        _append_block(doc, make_paragraph(
            [make_run(toc['date'], size=36, scale=100)],
            alignment='center', line=240, line_rule='auto', after=160,
        ))


    # Small gap
    _append_block(doc, _spacer_paragraph(16, 80))


    # 7) Author
    if toc.get('author'):
        _append_block(doc, make_paragraph(
            [make_run(toc['author'], size=40, bold=True, scale=100,
                      character_spacing=58)],
            alignment='center', line=240, line_rule='auto', after=0,
        ))


    # 8) Page break
    _append_block(doc, _page_break_paragraph())




def render_cover(doc: Document, cover: dict):
    cover = cover or {}
    render_title_block(doc, {'title': cover.get('title') or '',
                             'date': cover.get('date') or ''})


    if cover.get('subtitle'):
        _append_block(doc, body_paragraph(cover['subtitle'],
                                          alignment='center', after=AFTER['body']))


    meta = cover.get('metaLines') or []
    for idx, line in enumerate(meta):
        last = (idx == len(meta) - 1)
        p = make_paragraph([make_run(line)], alignment='right',
                           line=240, line_rule='auto',
                           after=(AFTER['section_separator'] if last else 120))
        _append_block(doc, p)


    if cover.get('tocHeading'):
        render_section_heading(doc, {'heading': cover['tocHeading']})


    toc_items = cover.get('tocItems') or []
    notes = cover.get('notes') or []
    has_trailing_notes = len(notes) > 0
    for idx, item in enumerate(toc_items):
        render_bullet(doc, {'kind': 'dash', 'text': item},
                      is_last=(idx == len(toc_items) - 1 and not has_trailing_notes))


    for idx, note in enumerate(notes):
        render_bullet(doc, {'kind': 'note', 'text': note},
                      is_last=(idx == len(notes) - 1))


    _append_block(doc, _page_break_paragraph())




def render_closing(doc: Document):
    p = make_paragraph([make_run('- 이  상 -')], alignment='right',
                       line=240, line_rule='auto', after=AFTER['closing'])
    _append_block(doc, p)




# 별첨 라벨(`#별첨1. `)은 생성기가 붙인다. 작성 단계에서 title 에 `별첨 1.` 을
# 또 쓰면 `#별첨1. 별첨 1. …` 로 겹쳐 나오므로 선행 라벨을 제거한다.
# 번호가 있는 형태만 제거해 `별첨 자료 목록` 같은 정상 제목은 보존한다.
_APPENDIX_LABEL_RE = re.compile(r'^\s*[#\[]?\s*별첨\s*\d+\s*[\].)·:\-]*\s*')




def strip_appendix_label(title):
    if not title:
        return title
    stripped = _APPENDIX_LABEL_RE.sub('', title).strip()
    if stripped and stripped != title.strip():
        print(f"[WARN] 별첨 제목에 '별첨 N' 라벨이 중복돼 제거했습니다 "
              f"(라벨은 생성기가 자동으로 붙입니다): {title!r} → {stripped!r}",
              file=sys.stderr)
        return stripped
    return title




def render_appendix_label(doc: Document, n: int, title: str | None):
    title = strip_appendix_label(title)
    text = f"#별첨{n}. {title}" if title else f"#별첨{n}."
    # Paragraph combines a page break followed by the label run (matches JS layout).
    br_r = _make('r')
    br_r.append(_make('br', type='page'))
    label_r = make_run(text, size=SIZE_APPEND, bold=True)
    p = make_paragraph([br_r, label_r], line=240, line_rule='auto',
                       after=AFTER['append_label'])
    _append_block(doc, p)




def render_body(doc: Document, doc_data: dict):
    DOC_TITLE[0] = normalize_body(doc_data.get('title') or '', autocap=False)
    default_skip = bool(doc_data.get('toc'))
    skip_explicit = doc_data.get('skipTitleBlock')
    skip = default_skip if skip_explicit is None else bool(skip_explicit)
    if not skip:
        render_title_block(doc, doc_data)
    # 인물 프로필 사진(ceoinfo) — 제목/날짜 단락에 떠 있는 그림으로 부착.
    render_profile_image(doc, normalize_profile_image(doc_data),
                         json_dir=CONTENT_JSON_DIR[0])
    sections = doc_data.get('sections') or []
    for i, s in enumerate(sections):
        # 두 번째 섹션부터: 직전 단락의 after 를 400(20pt)으로 재지정해
        # "□ 단락의 before=20pt" 대신 "앞 단락의 after=20pt"으로 간격을 표현한다.
        if i > 0:
            _set_last_para_after(doc, SPACING_BEFORE_NEXT_SECTION)
        render_section(doc, s,
                       is_last=(i == len(sections) - 1),
                       is_first=(i == 0))
    render_closing(doc)




def render_appendix(doc: Document, app: dict, n: int):
    render_appendix_label(doc, n, app.get('title'))
    # 별첨으로 붙는 CEO Profile 도 본문과 같은 방식으로 사진을 부착한다.
    render_profile_image(doc, normalize_profile_image(app),
                         json_dir=CONTENT_JSON_DIR[0])
    sections = app.get('sections') or []
    for i, s in enumerate(sections):
        if i > 0:
            _set_last_para_after(doc, SPACING_BEFORE_NEXT_SECTION)
        render_section(doc, s,
                       is_last=(i == len(sections) - 1),
                       is_first=(i == 0))




# ---------- Post-processing: autoSpaceDE/DN -------------------
_AUTO_SPACE_SNIPPET = '<w:autoSpaceDE w:val="0"/><w:autoSpaceDN w:val="0"/>'
_PPR_OPEN_RE = re.compile(r'<w:pPr>')




def post_process_autospace(buf: bytes) -> bytes:
    """Inject <w:autoSpaceDE/> + <w:autoSpaceDN/> at the start of every <w:pPr>.


    Matches the JS postProcessAutoSpace(). We also need to handle paragraphs
    that don't yet have a pPr — python-docx omits pPr when no properties are
    set. To keep parity we ensure every paragraph has at least autoSpace
    entries by inserting pPr into paragraph marks without one.
    """
    with io.BytesIO(buf) as src_stream:
        with zipfile.ZipFile(src_stream, 'r') as zin:
            out_bytes = io.BytesIO()
            with zipfile.ZipFile(out_bytes, 'w', zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    data = zin.read(item.filename)
                    if item.filename == 'word/document.xml':
                        xml = data.decode('utf-8')
                        # 1) Prepend autoSpace into every existing <w:pPr>
                        xml = _PPR_OPEN_RE.sub('<w:pPr>' + _AUTO_SPACE_SNIPPET, xml)
                        # 2) Insert a pPr (with autoSpace only) into paragraphs
                        #    that don't already have one.  <w:p> → <w:p><w:pPr>…</w:pPr>
                        xml = re.sub(
                            r'<w:p(\s[^>]*)?>(?!<w:pPr>)',
                            lambda m: f'<w:p{m.group(1) or ""}><w:pPr>{_AUTO_SPACE_SNIPPET}</w:pPr>',
                            xml,
                        )
                        data = xml.encode('utf-8')
                    zout.writestr(item, data)
            return out_bytes.getvalue()




# ---------- Document setup & main -----------------------------
def _setup_page_numbers(doc: Document):
    """Center-aligned '- N -' page number in the footer at 12pt 바탕체.


    Footer distance itself is set in _setup_document_defaults via PAGE['footer']
    (510 twips ≈ 0.9cm).
    """
    section = doc.sections[0]
    footer = section.footer
    footer.is_linked_to_previous = False


    ftr_element = footer._element
    for p in ftr_element.findall(qn('w:p')):
        ftr_element.remove(p)


    p = _make('p')
    pPr = _make('pPr')
    pPr.append(_make('jc', val='center'))
    p.append(pPr)


    p.append(make_run('- ', size=SIZE_TABLE))


    fld = _make('fldSimple', instr='PAGE')
    fld.append(make_run('1', size=SIZE_TABLE))
    p.append(fld)


    p.append(make_run(' -', size=SIZE_TABLE))


    ftr_element.append(p)




def _setup_document_defaults(doc: Document):
    section = doc.sections[0]
    section.page_width = Twips(PAGE['width'])
    section.page_height = Twips(PAGE['height'])
    section.top_margin = Twips(PAGE['top'])
    section.right_margin = Twips(PAGE['right'])
    section.bottom_margin = Twips(PAGE['bottom'])
    section.left_margin = Twips(PAGE['left'])
    section.header_distance = Twips(PAGE['header'])
    section.footer_distance = Twips(PAGE['footer'])
    _setup_page_numbers(doc)


    # Set default run font on styles.xml → docDefaults/rPrDefault/rPr/rFonts
    styles_el = doc.styles.element
    rpr_defaults = styles_el.find(qn('w:docDefaults'))
    if rpr_defaults is not None:
        rpr_default = rpr_defaults.find(qn('w:rPrDefault'))
        if rpr_default is not None:
            rpr = rpr_default.find(qn('w:rPr'))
            if rpr is None:
                rpr = _make('rPr')
                rpr_default.append(rpr)
            # Clear any existing rFonts / sz to replace with our defaults
            for tag in ('rFonts', 'sz', 'szCs'):
                for el in rpr.findall(qn('w:' + tag)):
                    rpr.remove(el)
            _set_run_font(rpr)
            rpr.append(_make('sz', val=SIZE_BODY))
            rpr.append(_make('szCs', val=SIZE_BODY))


    # Remove the default empty paragraph that python-docx inserts.
    body = doc.element.body
    for p in body.findall(qn('w:p')):
        # Only remove the leading empty paragraph (no runs)
        if len(p.findall(qn('w:r'))) == 0:
            body.remove(p)
            break




# 로컬(Claude Code·Codex·AI Pro) 작업 시 Word 기본 저장 폴더.
SECURE_FOLDER = r"D:\Secure Folder"
KST = timezone(timedelta(hours=9))
_INVALID_FILENAME_CHARS_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_GENERATED_SUFFIX_RE = re.compile(r'\([^()]+,\s*[^()]+\)_\d{6}_\d{4}$')




def _safe_filename_part(value):
    """Windows에서도 안전한 파일명 조각으로 정규화한다."""
    text = _INVALID_FILENAME_CHARS_RE.sub('_', str(value or '').strip())
    text = re.sub(r'\s+', ' ', text)
    return text.strip(' ._')




def apply_output_naming(raw_out, doc_data, now=None):
    """표준 Word 파일명으로 변환한다.


    <보고서 제목>(<Tool>, <짧은 LLM 버전>)_YYMMDD_HHMM.docx


    toolName/llmVersion이 없는 레거시 JSON은 기존 파일명을 유지한다. 호출자는
    SWW_TOOL_NAME/SWW_LLM_VERSION 환경변수로도 실행 정보를 넘길 수 있다.
    """
    tool_name = (doc_data.get('toolName') or doc_data.get('tool_name')
                 or os.environ.get('SWW_TOOL_NAME'))
    llm_version = (doc_data.get('llmVersion') or doc_data.get('llm_version')
                   or os.environ.get('SWW_LLM_VERSION'))
    if not tool_name or not llm_version:
        sys.stderr.write(
            '[WARN] 표준 파일명에 필요한 toolName/llmVersion이 없어 '
            '요청한 출력 파일명을 유지합니다.\n'
        )
        return str(raw_out)


    raw = str(raw_out)
    parent = os.path.dirname(raw)
    requested_stem = os.path.splitext(os.path.basename(raw))[0]
    requested_stem = _GENERATED_SUFFIX_RE.sub('', requested_stem)
    title = requested_stem if requested_stem.lower() != 'output' else doc_data.get('title')
    title = _safe_filename_part(title or doc_data.get('title') or '보고서')
    tool = _safe_filename_part(tool_name)
    # Tool/LLM 식별자는 호출 환경에서 확인된 값을 그대로 사용한다.
    # 확인되지 않은 버전·변형을 추정하거나 상향 보정하지 않는다.
    model = _safe_filename_part(llm_version)
    stamp = (now or datetime.now(KST)).astimezone(KST).strftime('%y%m%d_%H%M')
    filename = f'{title}({tool}, {model})_{stamp}.docx'
    return os.path.join(parent, filename) if parent else filename




def resolve_output_path(raw_out):
    """Word(.docx) 저장 경로 결정 (로컬 환경 공통 규칙):
      ① 호출 시 디렉터리를 포함한 경로를 주면 → 그 경로 그대로 (사용자 지정 최우선)
      ② 파일명만 주면 → D:\\Secure Folder 가 있으면 거기에 저장
      ③ 둘 다 아니면 → 현재 작업 디렉터리(기본값)
    파일명(basename)은 항상 유지한다."""
    raw = str(raw_out)
    fname = os.path.basename(raw) or 'output.docx'
    if os.path.dirname(raw):
        return os.path.abspath(raw)
    if os.path.isdir(SECURE_FOLDER):
        return os.path.join(SECURE_FOLDER, fname)
    return os.path.abspath(raw)




def main():
    # `--verify [옵션...]`: 생성 직후 scripts/verify_docx.py 를 같은 프로세스 턴에서 실행해
    # 변환→페이지수→줄바꿈→충돌 판정 요약을 함께 돌려준다. `--verify` 뒤의 인수는 모두
    # verify_docx.py 로 그대로 전달된다 (예: --verify --png --max-pages 3).
    verify_args = None
    if '--verify' in sys.argv:
        i = sys.argv.index('--verify')
        verify_args = sys.argv[i + 1:]
        del sys.argv[i:]
    if len(sys.argv) < 3:
        sys.stderr.write('Usage: python generate.py <content.json> <output.docx> [--verify [verify 옵션]]\n')
        sys.exit(1)
    content_path = sys.argv[1]
    with open(content_path, 'r', encoding='utf-8') as f:
        doc_data = json.load(f)


    named_out = apply_output_naming(sys.argv[2], doc_data)
    out_path = resolve_output_path(named_out)


    CONTENT_JSON_DIR[0] = os.path.dirname(os.path.abspath(content_path))


    # 문서별 자동 대문자화 예외(회사명·고유명사) 추가 등록.
    for w in (doc_data.get('noAutoCap') or doc_data.get('no_auto_cap') or []):
        NO_AUTOCAP_EXTRA.add(str(w).replace('-', '').lower())


    # 레거시 CEO Profile JSON(name/education/career/notes)도 표준 sections 로
    # 펼쳐서 **보고서와 완전히 동일한 렌더 경로**를 타게 한다.
    expand_ceo_profile(doc_data)
    for app in doc_data.get('appendices') or []:
        expand_ceo_profile(app)
    apply_term_annotations(doc_data)


    # ceoinfo(08) 단독 문서는 인물 사진이 필수다. 본문/별첨 어디에도 사진이
    # 없으면 산출을 막는다(별첨으로만 들어가는 CEO Profile 은 권장 사항).
    if str(doc_data.get('mode') or '').lower() in {'ceo', 'ceoinfo', 'ceo_profile'}:
        if not normalize_profile_image(doc_data):
            sys.stderr.write(
                '[ERROR] ceoinfo 모드는 인물 사진이 필수입니다. '
                'profileImage.path 또는 profileImage.url 을 지정하세요.\n')
            sys.exit(2)


    doc = Document()
    _setup_document_defaults(doc)


    # Document-level 줄간격 default (per-section overrides still apply).
    if doc_data.get('line') is not None:
        BODY_LINE[0] = int(doc_data['line'])
    elif doc_data.get('compact'):
        BODY_LINE[0] = LINE_COMPRESSED


    if doc_data.get('toc'):
        render_toc_page(doc, doc_data['toc'])
    if doc_data.get('cover'):
        render_cover(doc, doc_data['cover'])
    render_body(doc, doc_data)
    for i, app in enumerate(doc_data.get('appendices') or []):
        render_appendix(doc, app, i + 1)


    # Serialize to bytes, then post-process autoSpaceDE/DN
    buffer = io.BytesIO()
    doc.save(buffer)
    buf = buffer.getvalue()
    buf = post_process_autospace(buf)
    with open(out_path, 'wb') as f:
        f.write(buf)
    # Normalize path to forward slashes for readability.
    print(f"Wrote {out_path.replace(os.sep, '/')} ({len(buf)} bytes)", flush=True)


    if verify_args is not None:
        verifier = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'verify_docx.py')
        cmd = [sys.executable, verifier, out_path, '--content', content_path] + verify_args
        rc = subprocess.call(cmd)
        sys.exit(rc)




if __name__ == '__main__':
    main()
