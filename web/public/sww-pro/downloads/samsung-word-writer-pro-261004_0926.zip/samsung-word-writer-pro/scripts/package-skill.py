#!/usr/bin/env python3
"""스킬 배포용 zip 패키징.


Windows PowerShell 5.1 의 Compress-Archive 는 zip 엔트리 경로를 백슬래시(`\\`)로
기록하는 버그가 있다. ZIP 규격(APPNOTE 4.4.17.1)은 슬래시(`/`)만 허용하므로
Claude 스킬 업로더가 아래 오류로 거부한다:


    Zip file contains path with invalid characters


이 스크립트는 파이썬 zipfile 로 규격에 맞는 zip 을 만든다.
업로드 전 SKILL.md front matter 검증(check-skill.py)도 먼저 수행한다.


사용법:
    python scripts/package-skill.py                  # assets/downloads/<repo>-<YYMMDD_HHMM>.zip
    python scripts/package-skill.py <output.zip>
"""
from __future__ import annotations


import os
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path


# Windows 콘솔(cp949)에서 한글·기호 출력이 UnicodeEncodeError 로 죽는 것을 막는다.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


# docs/ 는 저장소 문서(변경 이력 등)이지 스킬 실행 리소스가 아니다. 배포 ZIP 에
# 넣으면 크기만 키우고, 문제 조사 중 열리면 컨텍스트 비용도 크다.
EXCLUDE_DIRS = {".git", ".qa", ".claude", "dist", "docs", "qa_render", "__pycache__",
                ".pytest_cache", ".idea", ".vscode"}
EXCLUDE_FILES = {".gitignore", ".DS_Store", "Thumbs.db"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo"}
EXCLUDE_ROOT_ARTIFACT_SUFFIXES = {".docx", ".pdf", ".png", ".json"}
DOWNLOAD_DIR = Path("assets") / "downloads"
KST = timezone(timedelta(hours=9))




def main(argv: list[str]) -> int:
    root = Path(__file__).resolve().parent.parent
    skill_name = root.name


    # 1) front matter 검증 - 업로드가 거부될 zip 은 애초에 만들지 않는다
    checker = root / "scripts" / "check-skill.py"
    if checker.is_file():
        env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
        r = subprocess.run([sys.executable, str(checker), str(root / "SKILL.md")], env=env)
        if r.returncode != 0:
            print("[package] SKILL.md 검증 실패 - 패키징을 중단합니다.", file=sys.stderr)
            return 1


    release_now = datetime.now(KST)
    release_stamp = release_now.strftime("%y%m%d_%H%M")
    release_label = release_now.strftime("%y-%m-%d %H:%M")
    publishing = len(argv) == 1
    out = Path(argv[1]).resolve() if not publishing else (
        root / DOWNLOAD_DIR / f"{skill_name}-{release_stamp}.zip"
    )


    # 기본 배포 실행은 Prompt Builder 링크를 이번 ZIP 이름으로 함께 갱신한다.
    if publishing:
        # 저장소와 gh-pages가 매 커밋마다 ZIP을 누적하지 않도록 최신본만 유지한다.
        download_dir = root / DOWNLOAD_DIR
        if download_dir.is_dir():
            for old in download_dir.glob(f"{skill_name}-??????_????.zip"):
                if old.resolve() != out.resolve():
                    old.unlink()
        builder = root / "assets" / "prompt-builder.html"
        text = builder.read_text(encoding="utf-8")
        link = f"downloads/{out.name}"
        updated, count = re.subn(
            r'(<a class="button ghost" id="skillZipLink" href=")[^"]+(" download>)',
            rf'\g<1>{link}\g<2>', text, count=1,
        )
        if count != 1:
            print("[package] Prompt Builder ZIP 링크를 찾지 못했습니다.", file=sys.stderr)
            return 1
        updated, date_count = re.subn(
            r'(<span class="last-modified" id="lastModified">)\(최종수정일 [^)]+\)(</span>)',
            rf'\g<1>(최종수정일 {release_label})\g<2>', updated, count=1,
        )
        if date_count != 1:
            print("[package] Prompt Builder 최종수정일 표시를 찾지 못했습니다.", file=sys.stderr)
            return 1
        builder.write_text(updated, encoding="utf-8", newline="\n")


    # 2) 수집 — Git 저장소에서는 추적 파일만 패키징해 작업 중인 개인 자료가
    # 섞이지 않게 한다. 설치본처럼 .git이 없는 경우에만 기존 전체 탐색을 쓴다.
    try:
        tracked = subprocess.run(
            ["git", "-C", str(root), "ls-files", "-z"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
    except OSError:
        tracked = None
    if tracked is not None and tracked.returncode == 0:
        candidates = [root / rel for rel in tracked.stdout.decode("utf-8").split("\0") if rel]
    else:
        candidates = root.rglob("*")


    files: list[tuple[Path, str]] = []
    for p in sorted(candidates):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        if any(part in EXCLUDE_DIRS for part in rel.parts):
            continue
        if rel.parts[:2] == DOWNLOAD_DIR.parts:
            continue
        if p.name in EXCLUDE_FILES or p.suffix in EXCLUDE_SUFFIXES:
            continue
        # Root-level report inputs/outputs are working artifacts, not skill
        # resources. Bundled examples/templates live under assets/ and remain.
        if len(rel.parts) == 1 and p.suffix.lower() in EXCLUDE_ROOT_ARTIFACT_SUFFIXES:
            continue
        if p.resolve() == out:
            continue
        # zip 내부 경로는 항상 슬래시로 (as_posix)
        files.append((p, f"{skill_name}/{rel.as_posix()}"))


    if not files:
        print("[package] 포함할 파일이 없습니다.", file=sys.stderr)
        return 1


    # 3) 작성
    if out.exists():
        out.unlink()
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for src, arc in files:
            zf.write(src, arc)


    # 4) 검증 - 백슬래시가 하나라도 있으면 실패로 처리
    bad: list[str] = []
    with zipfile.ZipFile(out) as zf:
        names = zf.namelist()
        bad = [n for n in names if "\\" in n]
        broken = zf.testzip()


    if bad:
        print(f"[package] 백슬래시 경로 {len(bad)}건 - zip 이 규격에 맞지 않습니다.", file=sys.stderr)
        for n in bad[:5]:
            print(f"  {n}", file=sys.stderr)
        return 1
    if broken:
        print(f"[package] 손상된 엔트리: {broken}", file=sys.stderr)
        return 1


    size_kb = out.stat().st_size / 1024
    print(f"[package] OK - {out}")
    print(f"[package] {len(names)}개 파일, {size_kb:.1f} KB, 경로 구분자 '/' 확인")
    return 0




if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
