#!/usr/bin/env python3
"""scripts/verify_docx.py 회귀 검사 — 판정 규칙(순수 함수)과 파이프라인(생성→검증) 양쪽.


    python scripts/test-verify-regressions.py


변환기(Word COM / LibreOffice)가 없는 환경에서는 PDF 파이프라인 부분만 SKIP 으로 건너뛴다.
"""
from __future__ import annotations


import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path


for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass




def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)




def load(root: Path):
    spec = importlib.util.spec_from_file_location("sww_verify", root / "scripts" / "verify_docx.py")
    require(spec is not None and spec.loader is not None, "verify_docx.py 로드 실패")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod




# --- 페이지 모델 생성 도우미 ---------------------------------------------------
def _line(v, text, y, kind=None, x0=None, x1=None, size=14.0, blue=False):
    x0 = v.CONTENT_LEFT if x0 is None else x0
    x1 = (v.CONTENT_LEFT + 380) if x1 is None else x1
    ln = {"x0": x0, "y0": y, "x1": x1, "y1": y + 14, "size": size, "blue": blue, "bold": False,
          "text": text}
    ln["kind"] = kind or v._classify_line(ln)
    return ln




def _page(v, number, lines, images=(), drawings=()):
    lines = list(lines) + [_line(v, f"- {number} -", v.CONTENT_BOTTOM + 8, x0=283, x1=320)]
    return {"number": number, "lines": lines, "images": list(images), "drawings": list(drawings),
            "width": 595.3, "height": 841.9}




def _fill(v, texts, start=None, pitch=30.0, annots=0):
    """본문 줄 목록을 위에서부터 pitch 간격으로 배치."""
    y = v.CONTENT_TOP if start is None else start
    out = []
    for t in texts:
        out.append(_line(v, t, y))
        y += pitch
    for i in range(annots):
        out.append(_line(v, f"* 출처 {i}", v.CONTENT_TOP + 20 + i * pitch, x0=200, x1=300, size=8.8,
                         blue=True))
    return out




def issues_of(report, level=None, contains=""):
    return [i for i in report.issues if (level is None or i["level"] == level)
            and contains in i["message"]]




def test_rules(v) -> None:
    body = [f"- 본문 {i}" for i in range(30)]
    top = v.CONTENT_TOP


    # 1) □ 헤딩이 하단에 2줄만 남고 다음 페이지로 이어짐 → pageBreakBefore 권고
    p1 = _fill(v, body[:22], pitch=30) + [_line(v, "□ 고립 헤딩", top + 22 * 30),
                                          _line(v, "- 이어지는 첫 줄", top + 23 * 30)]
    p2 = _fill(v, ["- 이어지는 둘째 줄", "- 셋째 줄", "□ 다음 섹션", "- 내용", "- 이 상 -"], pitch=30)
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p2)], r, ["앞 섹션", "고립 헤딩", "다음 섹션"])
    hits = issues_of(r, "WARN", "헤딩이 p1 하단에 1줄만 남고")
    require(len(hits) == 1, f"고립 헤딩 미탐지: {r.issues}")
    require("sections[1]" in hits[0]["hint"] and "pageBreakBefore" in hits[0]["hint"],
            f"고립 헤딩 힌트 오류: {hits[0]['hint']}")


    # 2) 헤딩만 홀로 남음 → ERROR
    p1 = _fill(v, body[:23], pitch=30) + [_line(v, "□ 홀로 헤딩", top + 23 * 30)]
    p2 = _fill(v, ["- 내용 1", "- 내용 2", "- 내용 3", "- 이 상 -"], pitch=30)
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p2)], r)
    require(issues_of(r, "ERROR", "헤딩만 페이지 하단에 홀로"), f"홀로 헤딩 미탐지: {r.issues}")


    # 3) 섹션 1줄이 다음 페이지로 넘침 → compact 권고 (sections 인덱스 매칭)
    p1 = [_line(v, "□ 넘치는 섹션", top)] + _fill(v, body[:23], start=top + 30, pitch=30)
    p2 = _fill(v, ["- 마지막 한 줄", "□ 다음 섹션", "- 내용", "- 내용", "- 이 상 -"], pitch=30)
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p2)], r, ["넘치는 섹션", "다음 섹션"])
    hits = issues_of(r, "WARN", "1줄이 p2 로 넘침")
    require(len(hits) == 1 and "sections[0]" in hits[0]["hint"] and "compact" in hits[0]["hint"],
            f"넘침 미탐지/힌트 오류: {r.issues}")


    # 4) 마지막 페이지에 `- 이 상 -` 만 → WARN
    p1 = [_line(v, "□ 섹션", top)] + _fill(v, body[:23], start=top + 30, pitch=30)
    p2 = [_line(v, "- 이 상 -", top, x0=470, x1=538)]
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p2)], r)
    require(issues_of(r, "WARN", "`- 이 상 -` 만 남음"), f"종결표기 단독 페이지 미탐지: {r.issues}")


    # 5) 앞 페이지 공백 30% + 다음 페이지가 □ 로 시작 → pageBreakBefore 취소 검토
    p1 = [_line(v, "□ 짧은 섹션", top)] + _fill(v, body[:14], start=top + 30, pitch=30)
    p2 = [_line(v, "□ 강제 이동 섹션", top)] + _fill(v, body[:5], start=top + 30, pitch=30) + \
         [_line(v, "- 이 상 -", top + 200, x0=470, x1=538)]
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p2)], r, ["짧은 섹션", "강제 이동 섹션"])
    hits = issues_of(r, "WARN", "1/4 초과) 뒤에 □")
    require(len(hits) == 1 and "sections[1]" in hits[0]["hint"], f"1/4 규칙 미탐지: {r.issues}")


    # 6) 1~2단어 widow → INFO
    p1 = [_line(v, "□ 섹션", top), _line(v, "- 긴 문장이 이어져서 줄바꿈이 발생하는 경우", top + 30),
          _line(v, "전망", top + 47, x1=v.CONTENT_LEFT + 30), _line(v, "- 다음 항목", top + 80),
          _line(v, "- 이 상 -", top + 120, x0=470, x1=538)]
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1)], r)
    require(issues_of(r, "INFO", "widow"), f"widow 미탐지: {r.issues}")


    # 7) 이동글틀-본문 겹침 → WARN / 우측 초과 → WARN
    p1 = [_line(v, "□ 섹션", top), _line(v, "- 본문 줄", top + 30),
          _line(v, "* 겹치는 주석", top + 33, x0=100, x1=200, size=8.8, blue=True),
          _line(v, "* 우측 초과 주석", top + 60, x0=400, x1=v.CONTENT_RIGHT + 20, size=8.8, blue=True),
          _line(v, "- 이 상 -", top + 120, x0=470, x1=538)]
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1)], r)
    require(issues_of(r, "WARN", "본문 '- 본문 줄' 과 겹침"), f"주석 겹침 미탐지: {r.issues}")
    require(issues_of(r, "WARN", "우측 여백 초과"), f"주석 우측 초과 미탐지: {r.issues}")


    # 8) 이미지 과점 → WARN, 도형 영역 이탈 → ERROR, 페이지 상한 → ERROR
    big = (v.CONTENT_LEFT, top + 40, v.CONTENT_RIGHT, top + 40 + v.CONTENT_HEIGHT_PT * 0.6)
    p1 = [_line(v, "□ 도표", top), _line(v, "- 이 상 -", v.CONTENT_BOTTOM - 20, x0=470, x1=538)]
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1, images=[{"bbox": big}],
                           drawings=[(v.CONTENT_LEFT - 40, top + 100, v.CONTENT_LEFT + 100, top + 130)])],
                    r, max_pages=0)
    require(issues_of(r, "WARN", "확대 렌더 의심"), f"이미지 과점 미탐지: {r.issues}")
    require(issues_of(r, "ERROR", "본문 영역 밖"), f"도형 이탈 미탐지: {r.issues}")
    require(not issues_of(r, "ERROR", "상한"), "max_pages=0 은 무시돼야 함")
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p1)], r, max_pages=1)
    require(issues_of(r, "ERROR", "상한 1쪽 초과"), f"페이지 상한 미탐지: {r.issues}")


    # 8b) □ 헤딩 우측 "텍스트 앞" 사진과 글자 겹침 → WARN (사진 1장당 1건), 사진 아래 긴 줄은 무관 (260923)
    photo = (v.CONTENT_RIGHT - 128, top, v.CONTENT_RIGHT, top + 128)
    p1 = [_line(v, "□ 인물 A", top, x1=v.CONTENT_LEFT + 200),
          _line(v, "- 학력 : 사진 뒤로 들어가는 긴 줄", top + 34, x1=v.CONTENT_RIGHT - 60),
          _line(v, "- 국적 : 사진 뒤로 들어가는 또 다른 줄", top + 68, x1=v.CONTENT_RIGHT - 30),
          _line(v, "- 주요 이력 : 사진 아래라서 길어도 되는 줄", top + 140, x1=v.CONTENT_RIGHT - 5),
          _line(v, "- 이 상 -", v.CONTENT_BOTTOM - 20, x0=470, x1=538)]
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1, images=[{"bbox": photo}])], r)
    require(len(issues_of(r, "WARN", "사진과 겹침")) == 1, f"사진·글자 겹침 미탐지(또는 중복): {r.issues}")
    p1[1]["x1"] = v.CONTENT_RIGHT - 200
    p1[2]["x1"] = v.CONTENT_RIGHT - 200
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1, images=[{"bbox": photo}])], r)
    require(not issues_of(r, "WARN", "사진과 겹침"), f"사진 옆 짧은 줄을 겹침으로 오탐: {r.issues}")


    # 9) 별첨 새 페이지 시작 앞의 공백은 경고하지 않음 / 별첨 페이지 표기
    p1 = [_line(v, "□ 본문", top)] + _fill(v, body[:8], start=top + 30, pitch=30) + \
         [_line(v, "- 이 상 -", top + 300, x0=470, x1=538)]
    p2 = [_line(v, "#별첨1. 상세", top), _line(v, "□ 별첨 섹션", top + 30)] + \
         _fill(v, body[:5], start=top + 60, pitch=30)
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p2)], r)
    require(not issues_of(r, "WARN", "하단 공백"), f"별첨 앞 공백을 경고함: {r.issues}")
    require(r.pages[1]["appendix"] is True, "별첨 페이지 표기 누락")


    # 10) 정상 문서 → WARN/ERROR 없음, 이동글틀 부족 INFO 만
    p1 = [_line(v, "□ 섹션 A", top)] + _fill(v, body[:22], start=top + 30, pitch=30, annots=3)
    p2 = [_line(v, "□ 섹션 B", top)] + _fill(v, body[:10], start=top + 30, pitch=30, annots=1) + \
         [_line(v, "- 이 상 -", top + 400, x0=470, x1=538)]
    r = v.Report()
    v.analyze_pages([_page(v, 1, p1), _page(v, 2, p2)], r)
    require(r.count("ERROR") == 0 and r.count("WARN") == 0, f"정상 문서에 경고: {r.issues}")
    require(issues_of(r, "INFO", "이동글틀 1개"), f"이동글틀 부족 INFO 누락: {r.issues}")
    require(r.pages[0]["sections"] == ["섹션 A"], f"섹션→페이지 표 오류: {r.pages}")


    # 11) 영문 기능어 대문자화 정규식
    require(v.AUTOCAP_RE.search("The State Of AI In 2026"), "Of/In 대문자화 미탐지")
    require(v.AUTOCAP_RE.search("OpenAI And Microsoft"), "And 대문자화 미탐지")
    require(not v.AUTOCAP_RE.search("The state of AI in 2026"), "정상 소문자 기능어를 오탐")
    require(not v.AUTOCAP_RE.search("Bank of America"), "정상 고유명사 오탐")


    # 12) 줄 병합 — 같은 기준선의 기호·굵은 조각을 한 줄로
    raw = [dict(x0=56.6, y0=133.1, x1=136.4, y1=147.1, size=13.6, blue=False, bold=True, text="□ 기사"),
           dict(x0=140.5, y0=133.1, x1=200.0, y1=147.1, size=14.0, blue=False, bold=True, text="개요")]
    merged = v._merge_visual_lines(raw)
    require(len(merged) == 1 and merged[0]["text"] == "□ 기사 개요", f"줄 병합 오류: {merged}")
    require(v._classify_line(merged[0]) == "heading", "□ 헤딩 분류 오류")
    print("[verify-test] 판정 규칙 12건 OK")




def test_pipeline(root: Path, v) -> None:
    env = v.check_env(auto_install=False)
    generator = root / "scripts" / "generate.py"
    verifier = root / "scripts" / "verify_docx.py"
    with tempfile.TemporaryDirectory(prefix="sww-verify-test-") as td:
        tdir = Path(td)
        out = tdir / "example.docx"
        subprocess.run([sys.executable, str(generator), str(root / "assets" / "example.json"), str(out)],
                       check=True, capture_output=True)


        # docx 구조 검사만 (변환기 불필요)
        r = v.Report()
        v.inspect_docx(out, r)
        require(r.count("ERROR") == 0, f"예시 문서 docx 검사 ERROR: {r.issues}")
        require(r.docx["hanja"] == 0, "예시 문서(원문에 中/有 포함)에 한자가 남음 — 정규화 회귀")
        require(r.docx["sections"] == 5 and r.docx["annotations"] == 4,
                f"예시 문서 구조 집계 오류: {r.docx}")


        # 이미지 높이 상한 — 세로로 긴 그림은 본문 높이의 55% 이하로 축소돼야 한다
        gspec = importlib.util.spec_from_file_location("sww_generate", generator)
        gen = importlib.util.module_from_spec(gspec)
        gspec.loader.exec_module(gen)
        try:
            from PIL import Image
        except Exception:  # noqa: BLE001
            Image = None
        if Image is not None:
            tall = tdir / "tall.png"
            Image.new("RGB", (600, 1800), (200, 220, 240)).save(tall)
            w, h = gen.image_dimensions({"path": str(tall)}, str(tall), tall.read_bytes())
            limit = gen.twips_to_px(gen.PAGE_CONTENT_HEIGHT) * gen.IMAGE_MAX_HEIGHT_PCT
            require(h <= limit + 1, f"세로 이미지 높이 상한 미적용: {h}px > {limit:.0f}px")
            require(abs(w / h - 600 / 1800) < 0.01, f"이미지 비율이 깨짐: {w}x{h}")
            w2, h2 = gen.image_dimensions({"path": str(tall), "maxHeightPct": 0.3}, str(tall),
                                          tall.read_bytes())
            require(h2 < h, "maxHeightPct 로 더 작게 조정되지 않음")
            tall_doc = tdir / "tall.docx"
            tall_json = tdir / "tall.json"
            tall_json.write_text(json.dumps({
                "title": "세로 이미지", "date": "'26. 9. 7 (월)",
                "sections": [{"heading": "도표", "bullets": [
                    {"kind": "dash", "text": "세로로 긴 도표"},
                    {"kind": "image", "path": str(tall), "caption": "긴 도표"}]}],
                "appendices": []}, ensure_ascii=False), encoding="utf-8")
            subprocess.run([sys.executable, str(generator), str(tall_json), str(tall_doc)],
                           check=True, capture_output=True)
            r = v.Report()
            v.inspect_docx(tall_doc, r)
            require(r.docx["images"] == 1 and not issues_of(r, "ERROR", "폭"),
                    f"세로 이미지 docx 검사 오류: {r.issues}")


        # --engine none 은 변환 없이 종료 코드 0
        p = subprocess.run([sys.executable, str(verifier), str(out), "--engine", "none"],
                           capture_output=True, text=True, encoding="utf-8")
        require(p.returncode == 0 and "[result]" in p.stdout, f"--engine none 실패: {p.stdout} {p.stderr}")


        if not (env.get("word_com") or env.get("soffice")):
            print("[verify-test] 변환기 없음 — PDF 파이프라인 SKIP")
            return
        if not env.get("PyMuPDF"):
            print("[verify-test] PyMuPDF 없음 — PDF 파이프라인 SKIP")
            return


        # 생성 + 검증 1턴 (--verify 통과 인수)
        js = tdir / "verify.json"
        qa = tdir / "qa"
        p = subprocess.run([sys.executable, str(generator), str(root / "assets" / "example.json"),
                            str(tdir / "example2.docx"), "--verify", "--png", "--sheet",
                            "--out", str(qa), "--json", str(js), "--max-pages", "3"],
                           capture_output=True, text=True, encoding="utf-8", timeout=300)
        require(p.returncode == 0, f"generate --verify 실패 rc={p.returncode}\n{p.stdout}\n{p.stderr}")
        require("Wrote " in p.stdout and "[verify]" in p.stdout and "[pages]" in p.stdout,
                f"생성+검증 출력 형식 오류:\n{p.stdout}")
        data = json.loads(js.read_text(encoding="utf-8"))
        require(data["meta"]["pdf_pages"] == 2, f"예시 문서 페이지 수 2 아님: {data['meta']}")
        require(data["summary"]["ERROR"] == 0, f"예시 문서 검증 ERROR: {data['issues']}")
        require(len(data["pages"]) == 2 and data["pages"][0]["annotations"] == 4,
                f"페이지별 이동글틀 집계 오류: {data['pages']}")
        require((qa / "page-1.png").is_file() and (qa / "page-2.png").is_file(),
                "페이지 PNG 미생성")
        require((qa / "contact-sheet-1.png").is_file(), "contact sheet 미생성")
        # 출력이 요약 수준인지 (페이지당 1줄 + 이슈) — 장문 덤프 방지
        require(len(p.stdout.splitlines()) < 40, f"요약 출력이 너무 김 ({len(p.stdout.splitlines())}줄)")
        print(f"[verify-test] 파이프라인 OK — {data['meta']['engine']}, 2쪽, "
              f"WARN {data['summary']['WARN']} INFO {data['summary']['INFO']}")




def main() -> int:
    root = Path(__file__).resolve().parent.parent
    v = load(root)
    test_rules(v)
    test_pipeline(root, v)
    print("[verify-test] OK")
    return 0




if __name__ == "__main__":
    raise SystemExit(main())
