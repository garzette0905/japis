#!/usr/bin/env python3
"""CEO Profile(ceoinfo) 통합 회귀 검사.


CEO Profile 은 더 이상 전용 엔진을 쓰지 않고 `scripts/generate.py` 가 기업개요·
일반 보고서와 **같은 경로**로 렌더한다. 이 스크립트는 그 통합이 깨지지 않았는지
확인한다.


  1. 표준 JSON(sections + profileImage) → 이동글틀이 보고서 엔진 규격
     (파랑 3333FF 9pt, `* ` prefix, wrapNone floating)으로 렌더되는가
  2. 프로필 사진이 "텍스트 앞"(wp:anchor + behindDoc=0 + wp:wrapNone) 으로
     본문 높이를 차지하지 않고 붙는가
  3. 레거시 CEO JSON(name/education/career/notes/image)이 표준 sections 로
     펼쳐져 동일 결과를 내는가
  4. term_annotations 용어집이 첫 등장 지점 이동글틀로 배분되는가
  5. 별첨(appendix) 안의 CEO Profile 에도 사진이 붙는가
  6. `mode: "ceoinfo"` 인데 사진이 없으면 생성이 실패하는가
  7. 여러 인물 별첨 — `sections[].profileImage` / `kind:"image", "float":"right"` 가
     □ 헤딩 우측 "텍스트 앞" 사진으로 붙고, 사진 옆 긴 줄의 wrap 폭이 줄어드는가 (260923)


사용법: python scripts/test-ceo-regressions.py
"""
from __future__ import annotations


import json
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path




def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)




def _run(generator: Path, data: dict, directory: Path, name: str,
         expect_failure: bool = False):
    directory.mkdir(parents=True, exist_ok=True)
    src = directory / f"{name}.json"
    out = directory / f"{name}.docx"
    src.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    proc = subprocess.run([sys.executable, str(generator), str(src), str(out)],
                          capture_output=True, text=True, encoding="utf-8",
                          errors="replace")
    if expect_failure:
        require(proc.returncode != 0,
                f"{name}: 실패해야 하는데 성공했습니다 ({proc.stdout})")
        return proc, ""
    require(proc.returncode == 0, f"{name}: 생성 실패 — {proc.stderr}")
    require(out.is_file() and out.stat().st_size > 0, f"{name}: DOCX 미생성")
    with zipfile.ZipFile(out) as zf:
        return proc, zf.read("word/document.xml").decode("utf-8")




CEO_STANDARD = {
    "mode": "ceoinfo",
    "title": "Testcorp사 CEO Profile",
    "profileImage": {"path": "assets/example_ceo_image.jpeg",
                     "alt": "profile image for Test Person", "width_cm": 3.8},
    "sections": [
        {"heading": "이    름 : Test Person ('83년생)", "bullets": []},
        {"heading": "국    적 : 미국", "bullets": []},
        {"heading": "학    력",
         "bullets": [{"kind": "dash", "text": "'04 ~ '08년, Testville University 학사"}]},
        {"heading": "주요 이력",
         "bullets": [
             {"kind": "dash", "text": "'21년 ~ 현재, Testcorp 공동 창업자 겸 CEO"},
             {"kind": "dash", "text": "'19년, 사내 MoE 모델 상용화 주도",
              "annotation": {"anchor": "MoE", "text": "Mixture of Experts (전문가 혼합 구조)"}},
         ]},
        {"heading": "참고사항",
         "bullets": [
             {"kind": "dash", "text": "형제 : Second Person(Testcorp President)"},
             {"kind": "dot", "text": "'18년 ~ 현재, Testcorp 경영 총괄"},
         ]},
    ],
}


CEO_LEGACY = {
    "title": "Testcorp사 CEO Profile",
    "name": "Test Person ('83년생)",
    "nationality": "미국",
    "education": ["'04 ~ '08년, Testville University 학사"],
    "career": [
        {"period": "'21년 ~ 현재", "organization": "Testcorp", "role": "공동 창업자 겸 CEO"},
        {"text": "'19년, 사내 MoE 모델 상용화 주도",
         "annotation": {"anchor": "MoE", "text": "Mixture of Experts (전문가 혼합 구조)"}},
    ],
    "notes": [
        {"text": "형제 : Second Person(Testcorp President)",
         "children": ["'18년 ~ 현재, Testcorp 경영 총괄"]},
    ],
    "image": {"path": "assets/example_ceo_image.jpeg", "width_cm": 3.8},
}


CEO_GLOSSARY = {
    "title": "Testcorp사 CEO Profile",
    "term_annotations": {"RAG": "Retrieval-Augmented Generation (검색 증강 생성)"},
    "sections": [
        {"heading": "주요 이력",
         "bullets": [
             {"kind": "dash", "text": "'24년, RAG 파이프라인 사내 표준화 주도"},
             {"kind": "dash", "text": "'25년, RAG 확산 프로젝트 총괄"},
         ]},
    ],
}


REPORT_WITH_CEO_APPENDIX = {
    "title": "Testcorp 인수 현황",
    "date": "'26. 8. 21 (금)",
    "sections": [{"heading": "거래 개요", "bullets": [{"kind": "dash", "text": "인수 합의 체결"}]}],
    "appendices": [
        {
            "title": "Testcorp사 CEO Profile",
            "profileImage": {"path": "assets/example_ceo_image.jpeg"},
            "sections": [
                {"heading": "이    름 : Test Person ('83년생)", "bullets": []},
                {"heading": "주요 이력",
                 "bullets": [{"kind": "dash", "text": "'21년 ~ 현재, Testcorp CEO"}]},
            ],
        }
    ],
}


CEO_NO_IMAGE = {
    "mode": "ceoinfo",
    "title": "Testcorp사 CEO Profile",
    "sections": [{"heading": "이    름 : Test Person", "bullets": []}],
}


# 여러 인물이 한 별첨에 들어가는 프로필 (260923 Jev 손수정본) — 사진은 각 □ 헤딩 우측
# "텍스트 앞" 이동 그림, 사진 옆 줄은 wrap 폭을 줄여 글자가 사진 뒤로 들어가지 않는다.
LONG_EDU = "스탠퍼드대 컴퓨터공학 박사, 리스본공대 전기공학 학사, 서울대 경영학 석사 (사진 옆 긴 줄)"
MULTI_PERSON_APPENDIX = {
    "title": "Testcorp 창업진 현황",
    "date": "'26. 9. 23 (수)",
    "sections": [{"heading": "핵심 개요", "bullets": [{"kind": "dash", "text": "창업진 3명 프로필은 별첨"}]}],
    "appendices": [
        {
            "title": "Testcorp 주요 인물 프로필",
            "sections": [
                {"heading": "Test Person A (공동 창업자·CEO)",
                 "profileImage": {"path": "assets/example_ceo_image.jpeg", "alt": "profile image for A"},
                 "headingAnnotation": {"anchor": "Test Person A", "text": "사진 : Testcorp 공식 Team 페이지"},
                 "bullets": [
                     {"kind": "dash", "text": "이름 : Test Person A"},
                     {"kind": "dash", "text": "국적·출생 : 공개자료에서 확인되지 않음"},
                     {"kind": "dash", "text": f"학력 : {LONG_EDU}"},
                     {"kind": "dash", "text": "주요 이력 : Google Brain 연구원 → OpenAI 연구원 → Testcorp 공동 창업자·CEO"},
                     {"kind": "dash", "text": "참고사항 : 없음"},
                 ]},
                {"heading": "Test Person B (공동 창업자·COO)",
                 "bullets": [
                     {"kind": "image", "path": "assets/example_ceo_image.jpeg", "float": "right"},
                     {"kind": "dash", "text": "이름 : Test Person B"},
                     {"kind": "dash", "text": "국적·출생 : 공개자료에서 확인되지 않음"},
                     {"kind": "dash", "text": "학력 : 공개자료에서 확인되지 않음"},
                     {"kind": "dash", "text": "주요 이력 : Meta·FAIR 연구 엔지니어 → Testcorp 공동 창업자·COO"},
                 ]},
            ],
        }
    ],
}




def main() -> int:
    root = Path(__file__).resolve().parent.parent
    generator = root / "scripts" / "generate.py"
    require(generator.is_file(), "scripts/generate.py 가 없습니다")


    with tempfile.TemporaryDirectory(prefix="sww-ceo-test-") as tmp:
        tmpdir = Path(tmp)


        # 1) 표준 JSON — 이동글틀이 보고서 엔진 규격으로 렌더되는가
        _, xml = _run(generator, CEO_STANDARD, tmpdir, "ceo-standard")
        require('<w:color w:val="3333FF"/>' in xml,
                "이동글틀 색상이 보고서 엔진 기준(3333FF)이 아닙니다")
        require("Mixture Of Experts" in xml or "Mixture of Experts" in xml,
                "MoE 이동글틀 본문이 없습니다")
        require(xml.count("<wp:anchor") >= 2,
                "floating 개체(주석 + 사진)가 부족합니다")
        require("<wp:wrapNone/>" in xml, "wrapNone(텍스트 앞) 설정이 없습니다")
        require('name="Profile image"' in xml, "프로필 사진이 삽입되지 않았습니다")
        require('behindDoc="0"' in xml, '사진/주석이 behindDoc="0" 이 아닙니다')
        # 사진은 별도 host 단락 없이 부착 — 그림 run 은 제목 단락 안에 있어야 한다.
        first_p_end = xml.find("</w:p>")
        require(0 < xml.find('name="Profile image"') < first_p_end,
                "프로필 사진이 첫 단락(제목)에 부착되지 않았습니다 — 빈 단락이 생겼을 수 있습니다")


        # 2) 레거시 CEO JSON → 표준 sections 로 펼쳐지는가
        _, legacy_xml = _run(generator, CEO_LEGACY, tmpdir, "ceo-legacy")
        for label in ("이    름", "국    적", "학    력", "주요 이력", "참고사항"):
            require(label in legacy_xml, f"레거시 변환 결과에 '{label}' 섹션이 없습니다")
        require("Testcorp 공동 창업자 겸 CEO" in legacy_xml,
                "period/organization/role 조합이 한 줄로 합쳐지지 않았습니다")
        require('name="Profile image"' in legacy_xml,
                "레거시 image 필드로 사진이 삽입되지 않았습니다")


        # 3) 용어집(term_annotations) — 첫 등장 1회만
        _, gloss_xml = _run(generator, CEO_GLOSSARY, tmpdir, "ceo-glossary")
        require(gloss_xml.count("Retrieval-Augmented Generation") == 1,
                "용어집 주석이 첫 등장 1회로 배분되지 않았습니다")


        # 4) 별첨 CEO Profile 에도 사진이 붙는가
        _, app_xml = _run(generator, REPORT_WITH_CEO_APPENDIX, tmpdir, "ceo-appendix")
        require('name="Profile image"' in app_xml,
                "별첨 CEO Profile 에 사진이 삽입되지 않았습니다")
        require("#별첨1. Testcorp사 CEO Profile" in app_xml,
                "별첨 라벨이 렌더되지 않았습니다")


        # 5) ceoinfo 단독 문서인데 사진이 없으면 실패해야 한다
        proc, _ = _run(generator, CEO_NO_IMAGE, tmpdir, "ceo-no-image",
                       expect_failure=True)
        require("인물 사진이 필수" in (proc.stderr or ""),
                f"사진 누락 에러 메시지가 명확하지 않습니다: {proc.stderr!r}")


        # 6) 여러 인물 별첨 — □ 헤딩 우측 "텍스트 앞" 사진 + 사진 옆 줄폭 예약 (260923)
        proc, multi_xml = _run(generator, MULTI_PERSON_APPENDIX, tmpdir, "ceo-multi-photo")
        require(multi_xml.count('name="Section photo"') == 2,
                "□ 헤딩 사진이 2장(sections[].profileImage + float 불릿) 붙지 않았습니다")
        require(not any("pic:pic" in m for m in re.findall(r"<wp:inline.*?</wp:inline>", multi_xml, re.S)),
                "float 사진이 인라인 그림 단락으로 남아 있습니다 (본문 높이를 차지)")
        for anchor in re.findall(r"<wp:anchor.*?</wp:anchor>", multi_xml, re.S):
            if 'name="Section photo"' not in anchor:
                continue
            require('behindDoc="0"' in anchor and "<wp:wrapNone/>" in anchor,
                    "□ 헤딩 사진이 '텍스트 앞'(wrapNone, behindDoc=0) 이 아닙니다")
            require("<wp:posOffset>0</wp:posOffset></wp:positionV>" in anchor,
                    "□ 헤딩 사진 세로 위치가 헤딩 단락 상단(0) 이 아닙니다")
        # 사진 run 은 □ 헤딩 단락 안에 있어야 한다 — 첫 불릿보다 앞에 나와야 함
        require(0 < multi_xml.find('name="Section photo"') < multi_xml.find("이름 : Test Person A"),
                "□ 헤딩 사진이 헤딩 단락이 아닌 곳에 붙었습니다")
        # 사진 옆 긴 학력 줄은 사진 왼쓴 끝 앞에서 잘려 2줄이 되어야 한다 (줄폭 예약)
        require("스탠퍼드대" in multi_xml and LONG_EDU not in multi_xml,
                "사진 옆 긴 줄이 줄폭 예약 없이 한 줄로 렌더됐습니다 — 글자가 사진 뒤로 들어갑니다")
        require("줄폭을" in (proc.stderr or ""), "사진 부착 [INFO] 로그(줄폭 예약)가 없습니다")


    print("[ceo-regression] OK")
    return 0




if __name__ == "__main__":
    raise SystemExit(main())
