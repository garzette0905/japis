#!/bin/sh
#
# git 훅 설치 (.git/hooks 는 버전 관리가 안 되므로 clone 마다 한 번 실행)
#
#   sh scripts/install-hooks.sh
#
# 설치되는 훅:
#   pre-commit  이름규칙 ZIP 생성 + Prompt Builder 링크 갱신 + 자동 스테이징
#   pre-push  ① scripts/check-skill.py 로 SKILL.md front matter 를 검증한다
#               (description 1024자 초과 등 = 스킬 업로드 거부 사유). 위반 시 push 중단.
#             ② main 이면 scripts/sync-gh-pages.sh 를 호출해
#               호스팅 페이지(gh-pages)를 자동으로 갱신한다.


set -u


root=$(git rev-parse --show-toplevel) || exit 1
hookdir=$(git rev-parse --git-path hooks)
mkdir -p "$hookdir"


precommit="$hookdir/pre-commit"
target="$hookdir/pre-push"


if [ -e "$precommit" ] && ! grep -q "package-skill.py" "$precommit" 2>/dev/null; then
    cp "$precommit" "$precommit.bak"
    echo "기존 pre-commit 훅을 $precommit.bak 로 백업했습니다."
fi


cat > "$precommit" <<'HOOK'
#!/bin/sh
# 자동 생성됨 - scripts/install-hooks.sh


set -u
root=$(git rev-parse --show-toplevel) || exit 1


# ZIP은 working tree가 아니라 이번 커밋과 동일한 내용을 담아야 한다.
# 추적 파일에 unstaged 변경이 있으면 의도치 않은 내용 포함을 막기 위해 중단한다.
if ! git diff --quiet --; then
    echo "[pre-commit] 스테이징되지 않은 추적 파일 수정이 있습니다." >&2
    echo "변경을 먼저 git add 하거나 별도로 보관한 뒤 다시 커밋하세요." >&2
    exit 1
fi


# 빈 커밋에는 배포 ZIP을 새로 만들지 않는다.
if git diff --cached --quiet --; then
    exit 0
fi


sh "$root/scripts/run-python.sh" "$root/scripts/package-skill.py" || {
    echo "[pre-commit] 스킬 ZIP 생성 실패로 커밋을 중단했습니다." >&2
    exit 1
}


# 패키징 스크립트가 만든 링크와 최신 ZIP(이전 ZIP 삭제 포함)만 자동 스테이징.
git add -- "$root/assets/prompt-builder.html" || exit 1
git add -A -- "$root/assets/downloads" || exit 1
echo "[pre-commit] 최신 스킬 ZIP과 Prompt Builder 링크를 커밋에 포함했습니다."
HOOK


if [ -e "$target" ] && ! grep -q "sync-gh-pages.sh" "$target" 2>/dev/null; then
    cp "$target" "$target.bak"
    echo "기존 pre-push 훅을 $target.bak 로 백업했습니다."
fi


cat > "$target" <<'HOOK'
#!/bin/sh
# 자동 생성됨 - scripts/install-hooks.sh
#
# ① SKILL.md front matter 검증 (위반 시 push 중단)
#    description 1024자 초과 등은 ChatGPT 스킬 업로드가 거부되는 사유라
#    push 전에 막는다. 급할 때는 git push --no-verify 로 우회 가능.
# ② main 을 push 할 때 assets/prompt-builder.html · assets/user-manual.html 변경분을
#    gh-pages(index.html · user-manual.html)로 자동 반영한다.
#    동기화 실패는 push 를 막지 않고 경고만 출력한다. 그때는 수동 실행:
#      sh scripts/sync-gh-pages.sh


remote="$1"
ZERO=0000000000000000000000000000000000000000
root=$(git rev-parse --show-toplevel) || exit 0


# --- ① SKILL.md front matter 검증 ---------------------------------------
if [ -f "$root/scripts/check-skill.py" ]; then
    PYTHONIOENCODING=utf-8 sh "$root/scripts/run-python.sh" \
        "$root/scripts/check-skill.py" "$root/SKILL.md" || {
        echo "" >&2
        echo "push 를 중단했습니다. SKILL.md 를 고친 뒤 다시 push 하세요." >&2
        echo "(검증을 건너뛰려면: git push --no-verify)" >&2
        exit 1
    }
fi


# --- ② gh-pages 동기화 ---------------------------------------------------
while read -r local_ref local_sha remote_ref remote_sha; do
    [ "$remote_ref" = "refs/heads/main" ] || continue
    [ "$local_sha" = "$ZERO" ] && continue        # 브랜치 삭제


    # gh-pages 자체를 push 하는 중이면 재진입 방지
    [ "${SYNC_GH_PAGES_RUNNING:-}" = "1" ] && continue


    SYNC_GH_PAGES_RUNNING=1 sh "$root/scripts/sync-gh-pages.sh" "$remote" "$local_sha" \
        || echo "[gh-pages sync] 동기화에 실패했지만 main push 는 그대로 진행합니다." >&2
done


exit 0
HOOK


chmod +x "$target"
chmod +x "$precommit"
chmod +x "$root/scripts/run-python.sh" 2>/dev/null || true
chmod +x "$root/scripts/sync-gh-pages.sh" 2>/dev/null || true


echo "설치 완료: $precommit"
echo "설치 완료: $target"
echo "이제 commit 시 ZIP이 자동 생성되고, main push 시 gh-pages가 자동 갱신됩니다."
