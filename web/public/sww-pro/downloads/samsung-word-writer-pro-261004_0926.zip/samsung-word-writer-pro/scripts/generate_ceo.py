#!/usr/bin/env python3
"""[DEPRECATED] CEO Profile 전용 엔진 → `scripts/generate.py` 로 통합됨.


CEO Profile(문서유형 08)은 기업개요(07)·일반 보고서와 **완전히 동일한 렌더
경로**를 쓴다. 이동글틀(주석)·줄간격·표·페이지 맞춤 로직이 하나의 엔진에만
존재하도록 통합했기 때문에, 예전처럼 CEO 전용 엔진을 따로 유지하지 않는다.


이 파일은 기존 호출(`python scripts/generate_ceo.py content.json out.docx`)이
깨지지 않도록 남겨둔 **얇은 호환 레이어**다. 실제 렌더는 `generate.py` 가 하며,
레거시 CEO JSON(`name` / `education` / `career` / `notes` / `image`)은
`generate.py` 의 `expand_ceo_profile()` 이 표준 `sections` 구조로 펼친다.


새로 작성할 때는 아래를 직접 쓸 것:


    python scripts/generate.py <ceo_content.json> <output.docx>


`--template` 옵션은 더 이상 의미가 없다(무시됨). 상세: `references/ceoinfo.md`.
"""
from __future__ import annotations


import runpy
import sys
from pathlib import Path


# Windows 콘솔(cp949)에서 한글 안내 문구가 깨지지 않도록.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


SKILL_ROOT = Path(__file__).resolve().parent.parent
GENERATOR = SKILL_ROOT / "scripts" / "generate.py"




def main(argv: list[str]) -> int:
    # `--template <path>` 는 더 이상 의미가 없으므로 값 인자까지 함께 걷어낸다.
    cleaned: list[str] = []
    skip_next = False
    for a in argv[1:]:
        if skip_next:
            skip_next = False
            continue
        if a == "--template":
            skip_next = True
            continue
        if a.startswith("--template="):
            continue
        cleaned.append(a)
    args = cleaned


    if len(args) < 2:
        sys.stderr.write(
            "Usage: python scripts/generate_ceo.py <content.json> <output.docx>\n"
            "       (deprecated - use: python scripts/generate.py <content.json> <output.docx>)\n"
        )
        return 1


    sys.stderr.write(
        "[deprecated] generate_ceo.py 는 generate.py 로 통합됐습니다. "
        "다음부터는 `python scripts/generate.py <content.json> <output.docx>` 를 사용하세요.\n"
    )
    sys.argv = [str(GENERATOR), *args]
    runpy.run_path(str(GENERATOR), run_name="__main__")
    return 0




if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
