#!/usr/bin/env python3
"""표준 도식 템플릿 (Python 전용, Word 파일 불필요).


`scripts/generate.py` 의 `kind: "diagram"` 렌더러가 이 모듈의 레이아웃을 호출한다.
목표는 **어떤 LLM 이 JSON 을 써도 균질하게** — 글자가 도형 밖으로 나가거나 잘리지 않고,
같은 입력이면 항상 같은 모양이 나오는 것. 그래서 모든 좌표는 본문 폭(DXA) 기준으로
결정론적으로 계산하고, 글자 크기는 안전 사각형(도형 안에서 글자가 확실히 보이는 영역)
안에 들어갈 때까지 자동으로 줄인다(제목 11→9pt, 항목 10→8pt).


지원 레이아웃 13종 (`LAYOUTS` 표 참조):


    horizontal_flow  좌→우 단계 흐름            2~5   ┌─┐→┌─┐→┌─┐
    vertical_flow    위→아래 단계 흐름           2~5
    chevron_flow     화살표형 밸류체인            3~6   ▶▶▶
    2x2_cycle        4단계 순환(PDCA)             4
    cycle            원형 순환                    3~6
    comparison       좌우 비교(As-Is/To-Be)       2
    hub_spoke        중심-주변(플랫폼·생태계)     1+3~6  (nodes[0] 이 중심)
    hierarchy        조직도·분류 트리             1+2~5  (nodes[0] 이 최상위)
    layers           계층 구조(아키텍처 스택)     2~6    (items 는 계층 안의 구성요소 상자)
    matrix_2x2       2×2 매트릭스                 4      (좌상→우상→좌하→우하, xAxis/yAxis 라벨)
    timeline         일정·마일스톤                3~6    (title=시점, items=내용)
    funnel           퍼널(단계별 축소)            3~5
    pyramid          피라미드(계층·비중)          3~5


이 모듈은 **기하만** 계산한다 — 결과(`LayoutResult`)를 generate.py 가 DrawingML 로
그린다. generate.py 쪽 상수·측정 함수는 `g`(generate 모듈)로 주입받는다.
"""
from __future__ import annotations


import math


# 레이아웃명 → (최소 노드 수, 최대 노드 수, 설명). 새 레이아웃은 여기와 `layout()` 에
# 함께 등록한다. 앞의 4개는 generate.py 안의 기존 구현을 그대로 쓴다(LEGACY).
LAYOUTS = {
    'horizontal_flow': (2, 5, '좌→우 단계 흐름(절차·프로세스)'),
    'vertical_flow':   (2, 5, '위→아래 단계 흐름'),
    'chevron_flow':    (3, 6, '화살표형 밸류체인'),
    '2x2_cycle':       (4, 4, '4단계 순환(PDCA 등)'),
    'cycle':           (3, 6, '원형 순환(3~6단계)'),
    'comparison':      (2, 2, '좌우 비교(As-Is/To-Be)'),
    'hub_spoke':       (4, 7, '중심-주변 구조(플랫폼·생태계) — nodes[0]=중심'),
    'hierarchy':       (3, 6, '조직도·분류 트리 — nodes[0]=최상위, 나머지=하위'),
    'layers':          (2, 6, '계층 구조(아키텍처 스택)'),
    'matrix_2x2':      (4, 4, '2×2 매트릭스(우선순위·포지셔닝)'),
    'timeline':        (3, 6, '일정·마일스톤 타임라인 — title=시점, items=내용'),
    'funnel':          (3, 5, '퍼널(단계별 축소)'),
    'pyramid':         (3, 5, '피라미드(계층·비중)'),
}
LEGACY_LAYOUTS = ('horizontal_flow', 'chevron_flow', '2x2_cycle', 'comparison')


# 글자 수 권고 — 넘으면 생성기가 자동 축소하지만 [WARN] 을 낸다.
TITLE_MAX_CHARS = 8
ITEM_MAX_CHARS = 14




class LayoutResult:
    """레이아웃 계산 결과. 좌표는 모두 DXA, 도식 좌상단 (0,0) 기준."""


    def __init__(self):
        self.width = 0
        self.height = 0
        self.rects = []          # 노드 i 의 바운딩 박스 (x0, y0, x1, y1) — nodes 순서
        self.auto_arrows = []    # rects 기반 자동 화살표 [{'from','to','label'}] (legacy 방식)
        self.arrows_xy = []      # 좌표 확정 화살표 [(start, end, label, orientation)]
        self.lines = []          # 화살촉 없는 선 [(start, end)]
        self.labels = []         # 자유 텍스트 [{'x0','y0','w','h','text','pt','jc','bold','color'}]
        self.extra_nodes = []    # 추가 상자 [(rect, node_dict, theme_index)] — layers 의 구성요소 등
        self.dots = []           # 작은 원 [(cx, cy, diameter, theme_index)] — timeline 마일스톤
        self.text_rects = {}     # 노드 i 의 글자 영역 강제 지정 {i: (x0,y0,x1,y1)}
        self.node_shapes = {}    # 노드 i 의 도형 강제 지정 {i: 'rect'|'ellipse'|...}
        self.suppress_items = set()  # items 를 노드 안에 그리지 않을 노드 번호
        self.hide_shape = set()      # 외곽 도형을 그리지 않을 노드 번호 (timeline: 점으로 대체)
        self.title_pt = 11
        self.item_pt = 10




# ---------------------------------------------------------------- helpers
def _center(rect):
    x0, y0, x1, y1 = rect
    return (x0 + x1) // 2, (y0 + y1) // 2




def _exit_point(center, toward, rect, gap=40):
    """`center`(rect 안) 에서 `toward` 방향으로 나갈 때 rect 경계와 만나는 점.
    경계에서 `gap` 만큼 바깥으로 띄운다 — 화살촉이 테두리 선과 겹치지 않게."""
    cx, cy = center
    tx, ty = toward
    dx, dy = tx - cx, ty - cy
    x0, y0, x1, y1 = rect
    ts = []
    if dx > 0:
        ts.append((x1 - cx) / dx)
    elif dx < 0:
        ts.append((x0 - cx) / dx)
    if dy > 0:
        ts.append((y1 - cy) / dy)
    elif dy < 0:
        ts.append((y0 - cy) / dy)
    if not ts:
        return center
    t = min(ts)
    length = math.hypot(dx, dy) or 1.0
    ex = cx + dx * t + dx / length * gap
    ey = cy + dy * t + dy / length * gap
    return int(round(ex)), int(round(ey))




def connect(rect_a, rect_b):
    """두 상자 중심을 잇는 직선을 상자 경계에서 잘라 (start, end) 로 돌려준다."""
    ca, cb = _center(rect_a), _center(rect_b)
    return _exit_point(ca, cb, rect_a), _exit_point(cb, ca, rect_b)




def _orientation(start, end):
    return 'horizontal' if abs(start[0] - end[0]) >= abs(start[1] - end[1]) else 'vertical'




def _label_box(text, pt, w, g, *, x_center=None, y_top=None, x0=None, jc='center', bold=False,
               color='0F172A'):
    lines = g._diagram_wrap(text, pt, max(w - 100, 300))
    h = len(lines) * g._diagram_line_height_dxa(pt) + 60
    if x0 is None:
        x0 = x_center - w // 2
    return {'x0': int(x0), 'y0': int(y_top), 'w': int(w), 'h': int(h), 'text': text,
            'pt': pt, 'jc': jc, 'bold': bold, 'color': color, 'lines': lines}




def _fit(nodes, box_w, g, *, exclude_items=False):
    """상자 폭에 맞는 (title_pt, item_pt, box_h). 모든 노드가 같은 높이를 쓴다."""
    title_pt = g._diagram_fit_title_pt(nodes, box_w)
    item_pt = g._diagram_fit_item_pt(nodes, box_w, title_pt) if not exclude_items else g.DIAGRAM_ITEM_PT
    box_h = max(g._diagram_node_height_dxa(
        (dict(node, items=[]) if exclude_items else node), box_w,
        g._diagram_node_geometry(node), title_pt, item_pt) for node in nodes)
    return title_pt, item_pt, box_h




def _ring_positions(n, cx, cy, rx, ry, start_deg=-90.0):
    """타원 위 n 개 점(시계 방향, 12시 시작)."""
    pts = []
    for i in range(n):
        ang = math.radians(start_deg + 360.0 * i / n)
        pts.append((int(round(cx + rx * math.cos(ang))), int(round(cy + ry * math.sin(ang)))))
    return pts




def _rect_at(center, w, h):
    cx, cy = center
    return (cx - w // 2, cy - h // 2, cx - w // 2 + w, cy - h // 2 + h)




def validate(layout_name: str, nodes: list) -> None:
    """레이아웃별 노드 수·필수 필드 검사. 문제가 있으면 원인이 분명한 ValueError."""
    if layout_name not in LAYOUTS:
        allowed = ', '.join(LAYOUTS)
        raise ValueError(f"Unknown diagram layout {layout_name!r}. Use one of: {allowed}")
    lo, hi, desc = LAYOUTS[layout_name]
    n = len(nodes)
    if not (lo <= n <= hi):
        raise ValueError(f"{layout_name} layout requires {lo}~{hi} nodes ({desc}); got {n}")
    for i, node in enumerate(nodes):
        if not isinstance(node, dict):
            raise ValueError(f"nodes[{i}] must be an object with a 'title'")
        if not str(node.get('title') or '').strip():
            raise ValueError(f"nodes[{i}] is missing 'title' ({layout_name})")
        items = node.get('items') or []
        if not isinstance(items, list):
            raise ValueError(f"nodes[{i}].items must be a list of short strings")




# ---------------------------------------------------------------- layouts
def layout(layout_name: str, nodes: list, arrows, spec: dict, g) -> LayoutResult:
    """새 레이아웃(LEGACY 외) 기하 계산. `g` = generate 모듈."""
    W = g.PAGE_CONTENT_WIDTH
    n = len(nodes)
    res = LayoutResult()
    fn = _LAYOUT_FNS.get(layout_name)
    if fn is None:
        raise ValueError(f"Layout {layout_name!r} is not implemented in diagram_templates")
    fn(res, nodes, arrows, spec, g, W, n)
    res.height += g.DIAGRAM_BOTTOM_MARGIN_DXA
    return res




def _vertical_flow(res, nodes, arrows, spec, g, W, n):
    box_w = min(int(spec.get('boxWidth') or 5400), W)
    title_pt, item_pt, box_h = _fit(nodes, box_w, g)
    gap = g._diagram_row_gap_dxa(nodes, arrows, box_w, 520)
    x0 = (W - box_w) // 2
    y = 0
    for _ in range(n):
        res.rects.append((x0, y, x0 + box_w, y + box_h))
        y += box_h + gap
    res.auto_arrows = [{'from': i, 'to': i + 1, 'label': ''} for i in range(n - 1)]
    res.width, res.height = W, y - gap
    res.title_pt, res.item_pt = title_pt, item_pt




def _cycle(res, nodes, arrows, spec, g, W, n):
    box_w = 2700 if n <= 4 else 2300
    title_pt, item_pt, box_h = _fit(nodes, box_w, g)
    rx = W // 2 - box_w // 2
    ry = max(box_h + 520, 1500) if n > 3 else max(int(box_h * 0.9) + 420, 1300)
    cx, cy = W // 2, ry + box_h // 2
    for pt in _ring_positions(n, cx, cy, rx, ry):
        res.rects.append(_rect_at(pt, box_w, box_h))
    user_arrows = arrows or [{'from': i, 'to': (i + 1) % n, 'label': ''} for i in range(n)]
    for a in user_arrows:
        i, j = g._diagram_resolve_index(nodes, a['from']), g._diagram_resolve_index(nodes, a['to'])
        start, end = connect(res.rects[i], res.rects[j])
        res.arrows_xy.append((start, end, a.get('label') or '', _orientation(start, end)))
    res.width, res.height = W, 2 * ry + box_h
    res.title_pt, res.item_pt = title_pt, item_pt




def _hub_spoke(res, nodes, arrows, spec, g, W, n):
    hub, sats = nodes[0], nodes[1:]
    k = len(sats)
    hub_w = min(int(spec.get('hubWidth') or 2800), W // 2)
    sat_w = 2500 if k <= 4 else 2200
    hub_shape = spec.get('hubShape') or 'ellipse'
    res.node_shapes[0] = hub_shape
    hub_node = dict(hub, _shape=g._diagram_shape_geometry(hub_shape))
    t1, i1, hub_h = _fit([hub_node], hub_w, g)
    t2, i2, sat_h = _fit(sats, sat_w, g)
    title_pt, item_pt = min(t1, t2), min(i1, i2)
    rx = W // 2 - sat_w // 2
    ry = hub_h // 2 + sat_h // 2 + 620
    cx, cy = W // 2, ry + sat_h // 2
    res.rects.append(_rect_at((cx, cy), hub_w, hub_h))
    for pt in _ring_positions(k, cx, cy, rx, ry):
        res.rects.append(_rect_at(pt, sat_w, sat_h))
    direction = (spec.get('direction') or 'out').lower()
    if arrows:
        for a in arrows:
            i, j = g._diagram_resolve_index(nodes, a['from']), g._diagram_resolve_index(nodes, a['to'])
            start, end = connect(res.rects[i], res.rects[j])
            res.arrows_xy.append((start, end, a.get('label') or '', _orientation(start, end)))
    else:
        for j in range(1, k + 1):
            if direction == 'in':
                start, end = connect(res.rects[j], res.rects[0])
            elif direction == 'none':
                start, end = connect(res.rects[0], res.rects[j])
                res.lines.append((start, end))
                continue
            else:
                start, end = connect(res.rects[0], res.rects[j])
            res.arrows_xy.append((start, end, '', _orientation(start, end)))
    res.width, res.height = W, 2 * ry + sat_h
    res.title_pt, res.item_pt = title_pt, item_pt




def _hierarchy(res, nodes, arrows, spec, g, W, n):
    root, kids = nodes[0], nodes[1:]
    k = len(kids)
    gap_x = 300
    kid_w = (W - gap_x * (k - 1)) // k
    root_w = min(max(3200, kid_w), W // 2)
    t1, i1, root_h = _fit([root], root_w, g)
    t2, i2, kid_h = _fit(kids, kid_w, g)
    title_pt, item_pt = min(t1, t2), min(i1, i2)
    gap_y = 700
    rx0 = (W - root_w) // 2
    res.rects.append((rx0, 0, rx0 + root_w, root_h))
    y_kid = root_h + gap_y
    x = 0
    for _ in range(k):
        res.rects.append((x, y_kid, x + kid_w, y_kid + kid_h))
        x += kid_w + gap_x
    # 꺾인 연결선(조직도): 루트 아래 세로 → 가로 버스 → 각 자식 위 세로
    bus_y = root_h + gap_y // 2
    root_cx = W // 2
    res.lines.append(((root_cx, root_h), (root_cx, bus_y)))
    first_cx, last_cx = _center(res.rects[1])[0], _center(res.rects[-1])[0]
    if k > 1:
        res.lines.append(((first_cx, bus_y), (last_cx, bus_y)))
    for r in res.rects[1:]:
        cxk = _center(r)[0]
        res.lines.append(((cxk, bus_y), (cxk, y_kid)))
    res.width, res.height = W, y_kid + kid_h
    res.title_pt, res.item_pt = title_pt, item_pt




def _layers(res, nodes, arrows, spec, g, W, n):
    label_w = min(int(spec.get('labelWidth') or 2200), W // 3)
    gap_y = 120
    pad = g.DIAGRAM_BOX_PAD_DXA
    title_pt = g._diagram_fit_title_pt(nodes, label_w)
    # 구성요소 상자의 글자 크기는 항목 수가 가장 많은 계층 기준으로 맞춘다.
    comp_nodes, comp_w_min = [], W
    for node in nodes:
        items = [str(it) for it in (node.get('items') or []) if str(it).strip()]
        if items:
            comp_w = (W - label_w - pad * 2 - 120 * (len(items) - 1)) // len(items)
            comp_w_min = min(comp_w_min, comp_w)
            comp_nodes.extend({'title': it, 'items': []} for it in items)
    comp_pt = g._diagram_fit_title_pt(comp_nodes, comp_w_min) if comp_nodes else title_pt
    comp_pt = min(comp_pt, g.DIAGRAM_ITEM_PT)
    y = 0
    for i, node in enumerate(nodes):
        items = [str(it) for it in (node.get('items') or []) if str(it).strip()]
        title_lines = g._diagram_wrap(node.get('title', ''), title_pt, label_w - 2 * pad)
        h_title = 2 * pad + len(title_lines) * g._diagram_line_height_dxa(title_pt)
        if items:
            comp_w = (W - label_w - pad * 2 - 120 * (len(items) - 1)) // len(items)
            h_comp = max(2 * pad + len(g._diagram_wrap(it, comp_pt, comp_w - 2 * pad))
                         * g._diagram_line_height_dxa(comp_pt) for it in items)
            box_h = max(h_title, h_comp + 2 * pad, 700)
        else:
            box_h = max(h_title, 700)
        res.rects.append((0, y, W, y + box_h))
        res.suppress_items.add(i)
        if items:
            res.text_rects[i] = (0, y, label_w, y + box_h)
            x = label_w + pad
            for it in items:
                r = (x, y + pad, x + comp_w, y + box_h - pad)
                res.extra_nodes.append((r, {'title': it, 'items': [], 'color': 'white'}, i))
                x += comp_w + 120
        y += box_h + gap_y
    res.width, res.height = W, y - gap_y
    res.title_pt, res.item_pt = title_pt, comp_pt




def _matrix_2x2(res, nodes, arrows, spec, g, W, n):
    y_axis = spec.get('yAxis') or ''
    x_axis = spec.get('xAxis') or ''
    y_labels = spec.get('yLabels') or (['높음', '낮음'] if y_axis else [])
    x_labels = spec.get('xLabels') or (['낮음', '높음'] if x_axis else [])
    left_w = 1000 if (y_axis or y_labels) else 0
    bottom_h = 0
    gap = 160
    box_w = (W - left_w - gap) // 2
    title_pt, item_pt, box_h = _fit(nodes, box_w, g)
    box_h = max(box_h, 1300)
    top_h = 0
    if y_axis:
        top_h = g._diagram_line_height_dxa(9) + 120
        res.labels.append(_label_box(y_axis, 9, left_w + box_w, g, x0=0, y_top=0,
                                     jc='left', bold=True))
    xs = [left_w, left_w + box_w + gap]
    ys = [top_h, top_h + box_h + gap]
    order = [(0, 0), (1, 0), (0, 1), (1, 1)]   # 좌상, 우상, 좌하, 우하
    for (cx, cy) in order:
        x0, y0 = xs[cx], ys[cy]
        res.rects.append((x0, y0, x0 + box_w, y0 + box_h))
    if y_labels:
        for lab, y0 in zip(y_labels[:2], ys):
            res.labels.append(_label_box(str(lab), 9, left_w - 100, g, x0=0,
                                         y_top=y0 + box_h // 2 - g._diagram_line_height_dxa(9) // 2,
                                         jc='center'))
    y_bottom = ys[1] + box_h
    if x_labels:
        for lab, x0 in zip(x_labels[:2], xs):
            res.labels.append(_label_box(str(lab), 9, box_w, g, x0=x0, y_top=y_bottom + 60,
                                         jc='center'))
        bottom_h = g._diagram_line_height_dxa(9) + 120
    if x_axis:
        res.labels.append(_label_box(x_axis, 9, W - left_w, g, x0=left_w,
                                     y_top=y_bottom + bottom_h + 40, jc='right', bold=True))
        bottom_h += g._diagram_line_height_dxa(9) + 100
    res.width, res.height = W, y_bottom + bottom_h
    res.title_pt, res.item_pt = title_pt, item_pt




def _timeline(res, nodes, arrows, spec, g, W, n):
    slot = W // n
    text_w = slot - 160
    title_pt = g._diagram_fit_title_pt(nodes, text_w)
    item_pt = g._diagram_fit_item_pt(nodes, text_w, title_pt)
    lh_t, lh_i = g._diagram_line_height_dxa(title_pt), g._diagram_line_height_dxa(item_pt)
    top_h = max(len(g._diagram_wrap(nd.get('title', ''), title_pt, text_w - 100)) for nd in nodes) * lh_t + 60
    dot = 260
    y_line = top_h + 140 + dot // 2
    res.lines.append(((0, y_line), (W - 200, y_line)))
    res.arrows_xy.append(((W - 200, y_line), (W, y_line), '', 'horizontal'))
    max_items_h = 0
    for i, node in enumerate(nodes):
        cx = slot * i + slot // 2
        res.dots.append((cx, y_line, dot, i))
        # rects 는 화살표 참조용 자리표시(글자 없는 노드) — 그리지 않도록 suppress
        res.rects.append((cx - dot // 2, y_line - dot // 2, cx + dot // 2, y_line + dot // 2))
        res.suppress_items.add(i)
        res.hide_shape.add(i)
        res.text_rects[i] = (cx - text_w // 2, 0, cx + text_w // 2, top_h)
        items = [str(it) for it in (node.get('items') or []) if str(it).strip()]
        if items:
            text = '\n'.join(items)
            lines = []
            for it in items:
                lines.extend(g._diagram_wrap(it, item_pt, text_w - 100))
            h = len(lines) * lh_i + 60
            max_items_h = max(max_items_h, h)
            res.labels.append({'x0': cx - text_w // 2, 'y0': y_line + dot // 2 + 120, 'w': text_w,
                               'h': h, 'text': text, 'pt': item_pt, 'jc': 'center', 'bold': False,
                               'color': '334155', 'lines': lines})
    res.width, res.height = W, y_line + dot // 2 + 120 + max_items_h
    res.title_pt, res.item_pt = title_pt, item_pt




def _funnel(res, nodes, arrows, spec, g, W, n):
    min_ratio = 0.42
    widths = [int(W * (1 - (1 - min_ratio) * i / max(n - 1, 1))) for i in range(n)]
    title_pt, item_pt, box_h = _fit(nodes, widths[-1], g)
    gap = 80
    y = 0
    for w in widths:
        x0 = (W - w) // 2
        res.rects.append((x0, y, x0 + w, y + box_h))
        y += box_h + gap
    res.width, res.height = W, y - gap
    res.title_pt, res.item_pt = title_pt, item_pt




def _pyramid(res, nodes, arrows, spec, g, W, n):
    min_ratio = 0.38
    widths = [int(W * (min_ratio + (1 - min_ratio) * i / max(n - 1, 1))) for i in range(n)]
    title_pt, item_pt, box_h = _fit(nodes, widths[0], g)
    gap = 80
    y = 0
    for w in widths:
        x0 = (W - w) // 2
        res.rects.append((x0, y, x0 + w, y + box_h))
        y += box_h + gap
    res.width, res.height = W, y - gap
    res.title_pt, res.item_pt = title_pt, item_pt




_LAYOUT_FNS = {
    'vertical_flow': _vertical_flow,
    'cycle': _cycle,
    'hub_spoke': _hub_spoke,
    'hierarchy': _hierarchy,
    'layers': _layers,
    'matrix_2x2': _matrix_2x2,
    'timeline': _timeline,
    'funnel': _funnel,
    'pyramid': _pyramid,
}
