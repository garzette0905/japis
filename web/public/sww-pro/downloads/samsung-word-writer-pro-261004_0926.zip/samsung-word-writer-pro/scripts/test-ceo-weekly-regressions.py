#!/usr/bin/env python3
"""CEO 현안보고(scripts/generate_ceo_weekly.py) 회귀 검사.


- 기준 문서(박광현 팀장 「[8월 4주차 현안보고] 경영지원담당 AX팀PI팀.docx」) 본문을 같은 입력으로 다시 만들었을 때
  단락(줄바꿈 위치)·after 간격이 계측값과 1:1 로 일치하는지
- 서식 계측값(여백·글꼴·크기·Bold·밑줄·박스 표)이 유지되는지
- 빈 항목의 `To Be Determined` 대체, 표준 파일명, `**부분 Bold**`, 표/※ 렌더
- Prompt Builder(assets/prompt-builder.html)·SKILL.md·references 배선


사용법: python scripts/test-ceo-weekly-regressions.py
"""
from __future__ import annotations


import importlib.util
import io
import json
import re
import sys
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path


from lxml import etree


for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


ROOT = Path(__file__).resolve().parent.parent
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"




def require(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)




def load_module():
    spec = importlib.util.spec_from_file_location("sww_ceo_weekly", ROOT / "scripts" / "generate_ceo_weekly.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod




def paragraphs(buf: bytes):
    root = etree.fromstring(zipfile.ZipFile(io.BytesIO(buf)).read("word/document.xml"))
    out = []
    for p in root.iter(W + "p"):
        text = "".join(p.itertext())
        sp = p.find(f"{W}pPr/{W}spacing")
        runs = p.findall(W + "r")
        rprs = [r.find(W + "rPr") for r in runs]
        sizes = {int(r.find(W + "sz").get(W + "val")) for r in rprs if r is not None and r.find(W + "sz") is not None}
        bold = [r.find(W + "b") is not None for r in rprs if r is not None]
        underline = any(r.find(W + "u") is not None for r in rprs if r is not None)
        jc = p.find(f"{W}pPr/{W}jc")
        out.append({
            "text": text, "after": int(sp.get(W + "after")) if sp is not None else None,
            "sizes": sizes, "bold": bold, "underline": underline,
            "jc": jc.get(W + "val") if jc is not None else None, "el": p,
        })
    return root, out




# 기준 문서 계측값 — (텍스트, after twips). NBSP 는 공백으로 정규화해 비교한다.
STANDARD = [
    ("안녕하십니까", 240),
    ("8월 4주차 경영지원담당 AX팀/PI팀 업무현안 내용을 보고드립니다.", 240),
    ("", 240),
    ("AX팀/PI팀 현안 보고", 320),
    ("경영지원담당 AX팀/PI팀 박광현 팀장", 180),
    (" [연간 주요 업무]", 120),
    ("  1. 차세대 시스템 구축 및 정보화 과제를 기반으로 데이터 중심의 E2E 업무시스템을 확보", 120),
    ("  2. SDS 업무 생산성 혁신을 위해 데이터와 AI를 활용한 핵심 Use Case를 지속적으로 확보", 120),
    ("  3. SDS 신 기술과 솔루션을 검증/고도화하는 Test-bed 역할을 수행하여 사업화 성공 지원", 120),
    ("", 180),
    ("□ 차세대 '26-2차 통합테스트 결과 (8/3 ~ 8/28)", 180),
    (" - 2주전 보고드린 2차 통합테스트는 SDSK 84명과 법인 41명 출장자와 함께 완료하였으며,", 180),
    ("   E2E시나리오 성공률 SDSK 98.4%(431/438), 해외법인 99.1%(347/350)로 목표 95%를 모두", 180),
    ("   상회하였습니다.", 240),
    (" - 9/2(수)에는 차세대 전체 PI/IT 140명과 반나절 워크샵을 통해 2차 통합테스트 결과를", 180),
    ("   공유하고, 마지막 3차 통합테스트 보완점 및 오픈후 고도화 내용을 점검할 예정입니다.", 240),
    (" - 9월 3차 통합테스트·10월 이행 준비를 거쳐, 11월 초 오픈을 반드시 완수하겠습니다.", 180),
    ("", 180),
    ("□ 주간 AI 활용 현황", 180),
    (" - 8/17(월) 광복절 대체 휴무 영향으로 WAU는 △118 감소한 10,996명, 토큰 사용량은", 180),
    ("   △827억 감소한 5,512억을 기록했습니다. 토큰 사용량 감소폭은 사외 AI(△16%)가 사내", 180),
    ("   AI(△4%)보다 컸으며, ▲사외 AI 월말 토큰 한도 제한 ▲법인 사용자 중심의 사내 AI", 180),
    ("   활용(AI Pro 사용 토큰의 73% 차지) 영향으로 판단됩니다.", 180),
    ("", 160),
    ("- 이  상 -", 160),
]


STANDARD_INPUT = {
    "week": "8월 4주차",
    "org": "경영지원담당 AX팀/PI팀",
    "reporter": "박광현 팀장",
    "annualTasks": [
        "차세대 시스템 구축 및 정보화 과제를 기반으로 데이터 중심의 E2E 업무시스템을 확보",
        "SDS 업무 생산성 혁신을 위해 데이터와 AI를 활용한 핵심 Use Case를 지속적으로 확보",
        "SDS 신 기술과 솔루션을 검증/고도화하는 Test-bed 역할을 수행하여 사업화 성공 지원",
    ],
    "sections": [
        {"heading": "차세대 '26-2차 통합테스트 결과 (8/3 ~ 8/28)", "items": [
            "2주전 보고드린 2차 통합테스트는 SDSK 84명과 법인 41명 출장자와 함께 완료하였으며, E2E시나리오 성공률 SDSK 98.4%(431/438), 해외법인 99.1%(347/350)로 목표 95%를 모두 상회하였습니다.",
            "9/2(수)에는 차세대 전체 PI/IT 140명과 반나절 워크샵을 통해 2차 통합테스트 결과를 공유하고, 마지막 3차 통합테스트 보완점 및 오픈후 고도화 내용을 점검할 예정입니다.",
            "9월 3차 통합테스트·10월 이행 준비를 거쳐, 11월 초 오픈을 반드시 완수하겠습니다.",
        ]},
        {"heading": "주간 AI 활용 현황", "items": [
            "8/17(월) 광복절 대체 휴무 영향으로 WAU는 △118 감소한 10,996명, 토큰 사용량은 △827억 감소한 5,512억을 기록했습니다. 토큰 사용량 감소폭은 사외 AI(△16%)가 사내 AI(△4%)보다 컸으며, ▲사외 AI 월말 토큰 한도 제한 ▲법인 사용자 중심의 사내 AI 활용(AI Pro 사용 토큰의 73% 차지) 영향으로 판단됩니다.",
        ]},
    ],
}




def norm(s: str) -> str:
    return s.replace("\u00a0", " ").rstrip()




def test_standard_reproduction(mod):
    buf, meta = mod.build_document(STANDARD_INPUT)
    root, paras = paragraphs(buf)
    require(len(paras) == len(STANDARD), f"단락 수 불일치: {len(paras)} != {len(STANDARD)}")
    for i, ((exp_text, exp_after), got) in enumerate(zip(STANDARD, paras)):
        require(norm(got["text"]) == norm(exp_text), f"[{i}] 줄바꿈/텍스트 불일치:\n  기대 {exp_text!r}\n  실제 {got['text']!r}")
        require(got["after"] == exp_after, f"[{i}] after 간격 불일치 {got['after']} != {exp_after}: {exp_text[:30]!r}")


    # 서식 계측값
    title = paras[3]
    require(title["sizes"] == {40} and all(title["bold"]) and title["underline"] and title["jc"] == "center",
            "제목은 20pt Bold 밑줄 가운데")
    require(paras[0]["sizes"] == {24} and paras[4]["jc"] == "right" and paras[4]["sizes"] == {24},
            "인사말 12pt / 보고자 12pt 오른쪽")
    heading = paras[10]
    require(heading["sizes"] == {22} and all(heading["bold"]) and heading["jc"] == "both", "□ 헤딩은 11pt Bold 양쪽 맞춤")
    dash = paras[11]
    require(dash["sizes"] == {22} and not any(dash["bold"]) and dash["jc"] == "both", "- 항목은 11pt 일반 양콽 맞춤")
    closing = paras[-1]
    require(closing["sizes"] == {24} and closing["jc"] == "right", "- 이  상 - 는 12pt 오른콽")
    for p in paras:
        for rf in p["el"].iter(W + "rFonts"):
            for attr in ("ascii", "eastAsia", "hAnsi", "cs"):
                require(rf.get(W + attr) == "바탕체", f"글꼴이 바탕체가 아님: {rf.attrib}")
        ppr = p["el"].find(W + "pPr")
        require(ppr is not None and ppr.find(W + "autoSpaceDE") is not None, "autoSpaceDE 누락")
        sp = ppr.find(W + "spacing")
        require(sp.get(W + "lineRule") == "auto" and sp.get(W + "line") in ("240", "259"), f"줄간격 {sp.attrib}")


    # 연간 주요 업무 박스
    tbl = root.find(f".//{W}tbl")
    require(tbl is not None, "박스 표 없음")
    require(tbl.find(f"{W}tblPr/{W}tblW").get(W + "w") == "9954", "박스 폭 9954")
    require(tbl.find(f".//{W}trHeight").get(W + "val") == "1362", "박스 행 높이 1362")
    borders = tbl.find(f".//{W}tcBorders")
    require(borders is not None and all(borders.find(W + s).get(W + "sz") == "4" for s in ("top", "left", "bottom", "right")),
            "박스 테두리 sz 4")
    require(tbl.find(f".//{W}vAlign").get(W + "val") == "center", "박스 세로 가운데")


    # 페이지 설정
    pg = root.find(f".//{W}sectPr/{W}pgMar")
    require(pg.get(W + "top") == "1418" and pg.get(W + "left") == "1134" and pg.get(W + "footer") == "992",
            f"여백 불일치 {pg.attrib}")
    require(meta["title"] == "AX팀/PI팀 현안 보고", meta["title"])




def test_tbd_and_filename(mod):
    mod._WARNINGS.clear()
    buf, meta = mod.build_document({"sections": []})
    _, paras = paragraphs(buf)
    text = "\n".join(p["text"] for p in paras)
    require(text.count("To Be Determined") >= 5, f"TBD 대체 부족: {text.count('To Be Determined')}")
    require("To Be Determined To Be Determined 업무현안 내용을 보고드립니다." in text, "인사말 TBD")
    require("□ To Be Determined" in text, "섹션 TBD")
    require(len(mod._WARNINGS) >= 4, "빈 항목 경고가 나야 함")


    fixed = datetime(2026, 9, 11, 10, 22, tzinfo=timezone(timedelta(hours=9)))
    name = mod.standard_filename({"week": "8월 4주차", "org": "경영지원담당 AX팀/PI팀"}, fixed)
    require(name == "[8월 4주차 현안보고] 경영지원담당 AX팀PI팀_260911_1022.docx", name)
    require(":" not in name, "파일명에 콜론 금지")




def test_inline_bold_and_extras(mod):
    data = json.loads(json.dumps(STANDARD_INPUT))
    data["sections"][0]["items"][2] = "9월 3차 통합테스트·10월 이행 준비를 거쳐, **11월 초 오픈을 반드시 완수**하겠습니다."
    data["sections"][1]["items"].append({"kind": "dot", "text": "세부 : 사내 AI 73%"})
    data["sections"][1]["items"].append({"kind": "note", "text": "출처 : 사내 AI 대시보드"})
    data["sections"][1]["items"].append({"kind": "table", "columns": ["구분", "값"], "rows": [["WAU", "10,996"]], "note": "기준 설명"})
    data["sections"][0]["items"][1] = {"kind": "dash", "text": data["sections"][0]["items"][1],
                                       "annotation": "PI/IT : 프로세스 혁신 및 IT 담당 인력"}
    buf, _ = mod.build_document(data)
    root, paras = paragraphs(buf)
    # 주석 — 문장 아래 파란 9pt 줄, 앞 문장 after 0
    ai = next(i for i, p in enumerate(paras) if "PI/IT : 프로세스" in p["text"])
    annot = paras[ai]
    require(annot["sizes"] == {18} and annot["text"].lstrip().startswith("* "), "주석 줄은 9pt `* ` 접두")
    require(any(c.get(W + "val") == "3333FF" for c in annot["el"].iter(W + "color")), "주석 줄은 파란색 3333FF")
    require(paras[ai - 1]["after"] == 0, "주석 앞 문장 간격은 0pt")
    require(annot["after"] == 240, "주석 줄이 항목 간격(12pt)을 이어받음")
    bold_line = next(p for p in paras if "11월 초 오픈" in p["text"])
    require(any(bold_line["bold"]) and not all(bold_line["bold"]), "부분 Bold 런이 섞여야 함")
    require("**" not in bold_line["text"], "** 마커가 본문에 남음")
    dot = next(p for p in paras if p["text"].startswith("  · "))
    require(dot["sizes"] == {22}, "· 하위 항목 11pt")
    note = next(p for p in paras if p["text"].strip().startswith("※"))
    require(note["sizes"] == {20}, "※ 주석 10pt")
    tbls = root.findall(f".//{W}tbl")
    require(len(tbls) == 2, "박스 + 데이터 표 = 2개")
    data_tbl = tbls[1]
    require(data_tbl.find(f".//{W}trHeight").get(W + "hRule") == "atLeast", "데이터 표 행 최소 높이 atLeast")
    require(data_tbl.find(f".//{W}sz").get(W + "val") == "20", "데이터 표 10pt")




def test_wrap_capacity(mod):
    long = "가" * 120
    lines = mod.wrap_segments(mod.parse_inline("가가 " * 60), mod.WRAP_CAPACITY - 330, mod.WRAP_CAPACITY - 330)
    for ln in lines:
        require(mod.measure_dxa("".join(t for t, _ in ln)) <= mod.WRAP_CAPACITY - 330, "줄 폭 초과")
    require(len(lines) >= 3, "긴 문장은 3줄 이상으로 나뉘어야 함")
    require(mod.wrap_segments(mod.parse_inline(long), 100, 100) == [[(long, False)]], "공백 없는 긴 단어는 한 줄 유지")




def test_wiring():
    builder = (ROOT / "assets" / "prompt-builder.html").read_text(encoding="utf-8")
    for needle in ('id="ceoWeekly"', "CEO 현안보고", "EXTRA_DEFAULT_CEO", "* 보고 주차(예, 8월 4주차) : ",
                   "* 주간 업무 스토리 (첨부 파일 가능) : ", "'To Be Determined'", "ceo_weekly_report",
                   "scripts/generate_ceo_weekly.py", "references/ceo-weekly-report.md",
                   "lockAudienceToExecutive", "[X월 X주차 현안보고] 조직명_YYMMDD_HHMM.docx",
                   "문장 바로 아래 줄에 파란색 9pt 주석"):
        require(needle in builder, f"Prompt Builder 에 '{needle}' 없음")
    require(builder.index('id="ceoWeekly"') > builder.index('const DOC_TYPES'), "ceoWeekly 는 JS 에서 03 옆에 생성")
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8-sig")
    for needle in ("ceo_weekly", "references/ceo-weekly-report.md", "scripts/generate_ceo_weekly.py", "CEO 현안보고"):
        require(needle in skill, f"SKILL.md 에 '{needle}' 없음")
    require((ROOT / "references" / "ceo-weekly-report.md").is_file(), "references/ceo-weekly-report.md 없음")
    example = json.loads((ROOT / "assets" / "example_ceo_weekly.json").read_text(encoding="utf-8"))
    require(example.get("week") and example.get("sections"), "예시 JSON 형식")
    pb_ref = (ROOT / "references" / "prompt-builder.md").read_text(encoding="utf-8")
    require("CEO 현안보고" in pb_ref and "ceo_weekly_report" in pb_ref, "prompt-builder.md 배선 누락")




def main() -> int:
    mod = load_module()
    test_standard_reproduction(mod)
    test_tbd_and_filename(mod)
    test_inline_bold_and_extras(mod)
    test_wrap_capacity(mod)
    test_wiring()
    print("[ceo-weekly-test] OK — 기준 문서 25단락 1:1 재현 · 서식 계측값 · TBD/파일명 · 부분 Bold/표/※ · 배선")
    return 0




if __name__ == "__main__":
    raise SystemExit(main())
