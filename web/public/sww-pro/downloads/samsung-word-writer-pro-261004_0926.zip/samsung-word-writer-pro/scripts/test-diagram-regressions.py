#!/usr/bin/env python3
"""Focused regression checks for native diagrams and Prompt Builder wiring."""
from __future__ import annotations


import json
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path




def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)




def _generate_and_read_xml(generator: Path, data: dict, directory: Path, output: Path) -> str:
    directory.mkdir(parents=True, exist_ok=True)
    src = directory / "diagram-regression-input.json"
    src.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    subprocess.run([sys.executable, str(generator), str(src), str(output)], check=True)
    require(output.is_file() and output.stat().st_size > 0, "DOCX was not generated")
    with zipfile.ZipFile(output) as zf:
        return zf.read("word/document.xml").decode("utf-8")




def main() -> int:
    root = Path(__file__).resolve().parent.parent
    generator = root / "scripts" / "generate.py"
    builder = (root / "assets" / "prompt-builder.html").read_text(encoding="utf-8")
    require('id="includeDiagram"' in builder, "Prompt Builder checkbox is missing")
    require("json.include_diagrams = true" in builder, "checkbox is not wired to JSON")
    require("간단한 도식을 반드시 1~2개" in builder, "mandatory 1~2 diagram instruction is missing")
    require("06_기존 문서 수정 (업데이트, 오탈자, 문서비교)" in builder,
            "Prompt Builder 06 label is outdated")
    require('value="template_reformat"' not in builder,
            "removed template_reformat option remains in Prompt Builder")
    require('id="lastModified"' in builder and "(최종수정일 " in builder,
            "Prompt Builder release timestamp is missing")


    data = {
        "title": "도식 회귀 테스트",
        "date": "'26. 8. 20 (목)",
        "sections": [
            {
                "heading": "추진 구조",
                "bullets": [
                    {"kind": "subhead", "text": "추진 구조"},
                    {
                        "kind": "diagram",
                        "caption": "추진 구조",
                        "layout": "horizontal_flow",
                        "nodes": [
                            {"title": "기획", "items": ["요건 정의"]},
                            {"title": "구현", "items": ["개발 및 검증"]},
                            {"title": "확산", "items": ["현장 적용"]},
                        ],
                    },
                    {"kind": "subhead", "text": "별도 소제목"},
                    {
                        "kind": "diagram",
                        "caption": "순환 구조",
                        "layout": "2x2_cycle",
                        "nodes": [
                            {"title": "계획"}, {"title": "실행"},
                            {"title": "점검"}, {"title": "개선"},
                        ],
                    },
                ],
            }
        ],
        "appendices": [],
    }


    if len(sys.argv) > 1:
        out = Path(sys.argv[1]).resolve()
        xml = _generate_and_read_xml(generator, data, out.parent, out)
        shape_dir = out.parent
    else:
        temp = tempfile.TemporaryDirectory(prefix="sww-diagram-test-")
        shape_dir = Path(temp.name)
        xml = _generate_and_read_xml(generator, data, shape_dir, shape_dir / "output.docx")


    require('prst="line"' in xml, "native line geometry is missing")
    require(xml.count('prst="line"') == 6, "unexpected connector count")
    require(xml.count('<a:tailEnd type="triangle"') == 6, "each connector must have one arrowhead")
    require('<a:tailEnd type="triangle"' in xml, "arrowhead is missing from line")
    require('prst="triangle"' not in xml, "legacy separate triangle arrowhead remains")
    require('w="12700"' in xml, "1.0pt line width is missing")
    require('flipH="1"' in xml and 'flipV="1"' in xml, "reverse/upward arrow directions are missing")
    require(xml.count("추진 구조") == 1, "duplicate section/subhead/caption was not suppressed")
    require("별도 소제목" in xml and "순환 구조" in xml, "non-duplicate captions were removed")


    shape_data = {
        "title": "기본 도형 회귀 테스트",
        "date": "'26. 8. 20 (목)",
        "sections": [{
            "heading": "도형",
            "bullets": [
                {
                    "kind": "diagram", "layout": "chevron_flow",
                    "nodes": [{"title": "A"}, {"title": "B"}, {"title": "C"}],
                    "arrows": [{"from": 0, "to": 1, "label": "ignored"}],
                },
                {
                    "kind": "diagram", "layout": "horizontal_flow", "defaultShape": "hexagon",
                    "nodes": [{"title": "D"}, {"title": "E"}],
                },
                {
                    "kind": "diagram", "layout": "horizontal_flow",
                    "nodes": [
                        {"title": "F", "shape": "circle"},
                        {"title": "G", "shape": "cylinder"},
                        {"title": "H", "shape": "rect"},
                    ],
                },
            ],
        }],
        "appendices": [],
    }
    shape_xml = _generate_and_read_xml(
        generator, shape_data, shape_dir, shape_dir / "shape-output.docx"
    )
    require(shape_xml.count('prst="chevron"') == 3, "chevron_flow nodes are not chevrons")
    require(shape_xml.count('prst="hexagon"') == 2, "hexagon defaultShape was not applied")
    require('prst="ellipse"' in shape_xml, "circle/ellipse geometry is missing")
    require('prst="can"' in shape_xml, "cylinder geometry is missing")
    require('prst="rect"' in shape_xml, "rectangle geometry is missing")
    require(shape_xml.count('prst="line"') == 3, "chevron_flow must not add connectors")


    invalid_data = json.loads(json.dumps(shape_data, ensure_ascii=False))
    invalid_data["sections"][0]["bullets"][1]["defaultShape"] = "star"
    invalid_src = shape_dir / "invalid-shape.json"
    invalid_out = shape_dir / "invalid-shape.docx"
    invalid_src.write_text(json.dumps(invalid_data, ensure_ascii=False), encoding="utf-8")
    invalid_run = subprocess.run(
        [sys.executable, str(generator), str(invalid_src), str(invalid_out)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    require(invalid_run.returncode != 0, "unknown shape must fail generation")
    require("Unknown diagram node shape" in invalid_run.stderr, "unknown shape error is unclear")


    # --- 도형 안에 글자가 실제로 들어가는지 (문자열 존재만으로는 못 잡는 것들) ---
    # (a) 빈 텍스트박스 금지: 내용 없는 w:txbxContent 가 하나라도 있으면 Word 는
    #     그 뒤 모든 텍스트를 한 도형씩 밀어서 그린다(LibreOffice 는 정상 렌더).
    for name, doc_xml in (("flow", xml), ("shape", shape_xml)):
        require("<w:txbxContent><w:p/></w:txbxContent>" not in doc_xml,
                f"{name}: empty textbox shifts Word's text-to-shape mapping")


    # (b) 노드 배경색이 실제로 칠해지는지 — nodes[].color 가 죽은 코드가 되지 않게
    require(xml.count("<a:solidFill><a:srgbClr val=\"EFF6FF\"/></a:solidFill>") >= 1,
            "node theme background fill is missing")
    require("<a:noFill/><a:ln><a:noFill/></a:ln>" in xml,
            "node text overlay must be borderless and unfilled")


    # (c) hexagon 은 adj 만 덮어쓰면 Word 가 문서를 열지 못한다 (vf 가 함께 필요)
    require('<a:gd name="vf" fmla="val 115470"/>' in shape_xml,
            "hexagon needs its vf guide alongside adj")


    # (d) 추정 텍스트 높이가 도형의 안전 사각형을 넘지 않는지 (넘치면 조용히 잘림)
    sys.path.insert(0, str(root / "scripts"))
    import importlib.util
    spec = importlib.util.spec_from_file_location("sww_generate", generator)
    gen = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gen)


    cases = [
        ("chevron_flow", [{"title": "반도체", "items": ["GPU·HBM 공급"]},
                          {"title": "서버·스토리지", "items": ["랙·네트워크 구성"]},
                          {"title": "데이터센터", "items": ["전력·냉각 인프라"]},
                          {"title": "클라우드", "items": ["GPUaaS 제공"]},
                          {"title": "AI 서비스", "items": ["학습·추론 운영"]}], None),
        ("horizontal_flow", [{"title": "현황 진단", "items": ["시장·경쟁 환경 분석"]},
                             {"title": "전략 수립", "items": ["핵심 과제 도출"]},
                             {"title": "실행 계획", "items": ["단계별 로드맵"]}], None),
        ("horizontal_flow", [{"title": "원본", "items": ["수집 로그"]},
                             {"title": "가공", "items": ["전처리"]},
                             {"title": "적재", "items": ["DW 저장"]}], "cylinder"),
        ("2x2_cycle", [{"title": "계획", "items": ["목표 설정"]},
                       {"title": "실행", "items": ["과제 수행"]},
                       {"title": "점검", "items": ["성과 측정"]},
                       {"title": "개선", "items": ["보완 조치"]}], None),
        ("comparison", [{"title": "As-Is", "items": ["수작업 취합", "주 1회 갱신"]},
                        {"title": "To-Be", "items": ["자동 수집", "실시간 갱신"]}], None),
    ]
    for layout, nodes, default_shape in cases:
        spec_dict = {"layout": layout, "nodes": nodes}
        if default_shape:
            spec_dict["defaultShape"] = default_shape
        gen.build_diagram_drawing(spec_dict)   # 값 검증은 아래에서 다시 계산
        natural = "chevron" if layout == "chevron_flow" else "rect"
        resolved = [dict(nd, _shape=(nd.get("shape") or default_shape or natural))
                    for nd in nodes]
        _, _, rects, _, title_pt = gen._diagram_layout(layout, resolved, None)
        for node, rect in zip(resolved, rects):
            geom = gen._diagram_node_geometry(node)
            ix0, iy0, ix1, iy1 = gen._diagram_safe_rect(geom, *rect)
            inner_w = ix1 - ix0 - 2 * gen.DIAGRAM_BOX_PAD_DXA
            need = (len(gen._diagram_wrap(node.get("title", ""), title_pt, inner_w))
                    * gen._diagram_line_height_dxa(title_pt) + gen.DIAGRAM_TITLE_GAP_DXA)
            for item in (node.get("items") or []):
                need += (len(gen._diagram_wrap(item, gen.DIAGRAM_ITEM_PT, inner_w))
                         * gen._diagram_line_height_dxa(gen.DIAGRAM_ITEM_PT))
            require(need <= iy1 - iy0,
                    f"{layout}/{geom} {node['title']!r}: 텍스트 {need}dxa 가 "
                    f"안전 사각형 {iy1 - iy0}dxa 를 넘어 잘립니다")
            require(len(gen._diagram_wrap(node.get("title", ""), title_pt, inner_w)) == 1,
                    f"{layout}/{geom} {node['title']!r}: 제목이 1줄에 들어가지 않습니다")


    # --- 본문 렌더링 공통 회귀 (표 셀 여백 / 제목 자동 대문자화) ---
    body_data = {
        "title": "본문 렌더링 회귀",
        "date": "'26. 8. 31 (월)",
        "sections": [{
            "heading": "horizontal_flow 4단계",
            "bullets": [
                {"kind": "subhead", "text": "openai_api 연동"},
                {"kind": "dash", "text": "본문의 scale-up 은 그대로 대문자화한다"},
                {"kind": "dash", "text": "매킨지 「The State of AI in 2026」, Bank of America 발표"},
                {"kind": "dot", "text": "단독 frontier 모델과 openai and Microsoft 협력"},
                {"kind": "table", "columns": ["구분", "값"],
                 "rows": [["셀 여백", "좌우 50 DXA"]]},
            ],
        }],
        "appendices": [],
    }
    body_xml = _generate_and_read_xml(
        generator, body_data, shape_dir, shape_dir / "body-output.docx"
    )
    # 표 셀 좌우 여백 — 0 이면 글자가 테두리에 붙는다. 상하는 행 최소 높이가
    # 담당하므로 0 을 유지해야 한다 (값을 주면 행이 규정보다 높아진다).
    require('<w:left w:w="50" w:type="dxa"/>' in body_xml
            and '<w:right w:w="50" w:type="dxa"/>' in body_xml,
            "table cells need a left/right margin")
    require('<w:top w:w="0" w:type="dxa"/>' in body_xml
            and '<w:bottom w:w="0" w:type="dxa"/>' in body_xml,
            "table cell top/bottom margin must stay 0")
    require('w:val="454" ' in body_xml or 'w:val="454"/' in body_xml
            or '454' in body_xml, "0.8cm minimum row height is missing")
    # 제목·소제목은 영문 자동 대문자화 대상이 아니다 (코드·API 이름이 오는 자리)
    require("horizontal_flow 4단계" in body_xml,
            "section heading must not be auto-capitalized")
    require("openai_api 연동" in body_xml,
            "subhead must not be auto-capitalized")
    require("Horizontal_flow" not in body_xml and "Openai_api" not in body_xml,
            "snake_case identifiers were auto-capitalized")
    # 본문의 단독 소문자 단어 대문자화 규칙은 그대로 유지
    require("Scale-up" in body_xml, "body auto-capitalization regressed")
    # 영어 구 안의 기능어(of/in/and)는 대문자화하지 않는다 — 앞 토큰이 영어일 때만
    require("The State of AI in 2026" in body_xml and "Bank of America" in body_xml,
            "English function words inside a phrase were auto-capitalized")
    require("openai and Microsoft" in body_xml,
            "'and' after a NO_AUTOCAP proper noun was capitalized")
    require("단독 Frontier 모델" in body_xml,
            "standalone lowercase English word must still be capitalized")


    # 잘못된 subhead + □ 입력은 `< □ ... >` 중앙 소제목으로 만들지 않고
    # 좌측 정렬 □ 헤딩으로 안전 복구한다. 중복 < >도 생성기가 한 번만 붙인다.
    malformed_data = {
        "title": "소제목 계층 회귀",
        "date": "'26. 9. 2 (수)",
        "sections": [{
            "number": 1,
            "heading": "주요 내용",
            "bullets": [
                {"kind": "subhead", "text": "□ AX PI 추진 배경 및 목표"},
                {"kind": "dash", "text": "본문"},
                {"kind": "subhead", "text": "< 정상 소제목 >"},
            ],
        }],
        "appendices": [],
    }
    malformed_xml = _generate_and_read_xml(
        generator, malformed_data, shape_dir, shape_dir / "malformed-subhead.docx"
    )
    require("□ AX PI 추진 배경 및 목표" in malformed_xml,
            "subhead + □ input was not recovered as a square heading")
    require("&lt; □ AX PI 추진 배경 및 목표 &gt;" not in malformed_xml,
            "malformed centered < □ ... > heading regressed")
    require(malformed_xml.count("정상 소제목") == 1,
            "subhead angle-marker normalization duplicated the label")


    if 'temp' in locals():
        temp.cleanup()


    # --- 표준 도식 템플릿 13종 (scripts/diagram_templates.py) ---
    tpl_json = json.loads((root / "assets" / "example_diagram_templates.json").read_text(encoding="utf-8"))
    tpl_json.pop("toolName", None); tpl_json.pop("llmVersion", None)   # 표준 파일명 변환 없이 지정 경로에 저장
    tpl_layouts = [b["layout"] for sec in tpl_json["sections"] for b in sec["bullets"] if b.get("kind") == "diagram"]
    require(len(tpl_layouts) == 13 and len(set(tpl_layouts)) == 13,
            f"example_diagram_templates.json must show all 13 layouts once: {tpl_layouts}")
    tpl_xml = _generate_and_read_xml(generator, tpl_json, shape_dir, shape_dir / "templates-output.docx")
    require(tpl_xml.count("<wpg:wgp>") == 13, "13 diagram groups expected")
    require("<w:txbxContent><w:p/></w:txbxContent>" not in tpl_xml, "templates: empty textbox")
    for label in ("↑ 사업 효과", "실행 용이성 →", "1영업일", "'26.10월 중순", "오케스트레이션", "단장: CTO"):
        require(label in tpl_xml, f"template text missing from docx: {label!r}")
    # hierarchy 꺾인 선(화살촉 없음) 과 timeline 점(ellipse, 글자 없음)
    require('<a:tailEnd type="none"/>' in tpl_xml, "plain connector lines (hierarchy/timeline) are missing")
    require(tpl_xml.count('name="Dot ') == 4, "timeline should draw 4 milestone dots")


    tpl = gen.diagram_templates()
    require(set(tpl.LAYOUTS) == {
        "horizontal_flow", "vertical_flow", "chevron_flow", "2x2_cycle", "cycle", "comparison",
        "hub_spoke", "hierarchy", "layers", "matrix_2x2", "timeline", "funnel", "pyramid"},
        "LAYOUTS registry drifted")
    # 노드 수 검증 메시지가 분명해야 한다 (LLM 이 고칠 수 있게)
    for bad_layout, bad_n in (("matrix_2x2", 3), ("hub_spoke", 2), ("timeline", 7), ("pyramid", 2)):
        try:
            tpl.validate(bad_layout, [{"title": f"n{i}"} for i in range(bad_n)])
        except ValueError as exc:
            require("requires" in str(exc) and bad_layout in str(exc), f"unclear node-count error: {exc}")
        else:
            raise AssertionError(f"{bad_layout} with {bad_n} nodes must be rejected")
    try:
        tpl.validate("star_burst", [{"title": "a"}, {"title": "b"}])
    except ValueError as exc:
        require("Use one of" in str(exc) and "timeline" in str(exc), "unknown layout error must list layouts")
    else:
        raise AssertionError("unknown layout must be rejected")


    # 모든 템플릿에서 추정 글자 높이가 안전 사각형 안에 들어가야 한다 (Word 는 넘치면 조용히 잘라낸다)
    for sec in tpl_json["sections"]:
        for b in sec["bullets"]:
            if b.get("kind") != "diagram":
                continue
            layout_name = b["layout"]
            natural = "chevron" if layout_name == "chevron_flow" else "rect"
            nodes = [dict(nd, _shape=(nd.get("shape") or b.get("defaultShape") or natural)) for nd in b["nodes"]]
            if layout_name in tpl.LEGACY_LAYOUTS:
                _, _, rects, _, title_pt = gen._diagram_layout(layout_name, nodes, b.get("arrows"))
                item_pt = gen._DIAGRAM_LAST_ITEM_PT[0]
                text_rects, suppress = {}, set()
            else:
                res = tpl.layout(layout_name, nodes, b.get("arrows"), b, gen)
                for i, geom in res.node_shapes.items():
                    nodes[i]["_shape"] = geom
                rects, title_pt, item_pt = res.rects, res.title_pt, res.item_pt
                text_rects, suppress = res.text_rects, res.suppress_items
                require(res.width == gen.PAGE_CONTENT_WIDTH, f"{layout_name}: width must be the content width")
                for (x0, y0, x1, y1) in rects:
                    require(0 <= x0 < x1 <= gen.PAGE_CONTENT_WIDTH and 0 <= y0 < y1 <= res.height,
                            f"{layout_name}: node rect {x0, y0, x1, y1} leaves the diagram box")
            for i, (node, rect) in enumerate(zip(nodes, rects)):
                geom = gen._diagram_node_geometry(node)
                ix0, iy0, ix1, iy1 = text_rects.get(i) or gen._diagram_safe_rect(geom, *rect)
                inner_w = ix1 - ix0 - 2 * gen.DIAGRAM_BOX_PAD_DXA
                need = (len(gen._diagram_wrap(node.get("title", ""), title_pt, inner_w))
                        * gen._diagram_line_height_dxa(title_pt))
                if i not in suppress:
                    need += gen.DIAGRAM_TITLE_GAP_DXA
                    for item in (node.get("items") or []):
                        need += (len(gen._diagram_wrap(item, item_pt, inner_w))
                                 * gen._diagram_line_height_dxa(item_pt) + gen.DIAGRAM_ITEM_GAP_DXA)
                require(need <= iy1 - iy0,
                        f"{layout_name} {node['title']!r}: 텍스트 {need}dxa 가 안전 사각형 {iy1 - iy0}dxa 를 넘습니다")


    # 항목 3개 comparison — 종전 높이 추정이 단락 간격을 빼고 계산해 3번째 항목이 잘렸다
    three = [{"title": "As-Is", "items": ["수작업 취합", "주 1회 갱신", "엑셀 배포"], "_shape": "rect"},
             {"title": "To-Be", "items": ["자동 수집", "실시간 갱신", "대시보드 공유"], "_shape": "rect"}]
    _, _, rects3, _, tp3 = gen._diagram_layout("comparison", three, None)
    box_h3 = rects3[0][3] - rects3[0][1]
    need3 = (gen.DIAGRAM_BOX_PAD_DXA * 2 + gen._diagram_line_height_dxa(tp3) + gen.DIAGRAM_TITLE_GAP_DXA
             + 3 * (gen._diagram_line_height_dxa(gen.DIAGRAM_ITEM_PT) + gen.DIAGRAM_ITEM_GAP_DXA))
    require(box_h3 >= need3, f"comparison with 3 items: box {box_h3} < needed {need3}")


    # 항목 자동 축소: 긴 항목은 10pt → 8pt 까지 줄어든다
    long_items = [{"title": "A", "items": ["아주 길게 쓴 항목 설명 문장이 들어가는 경우입니다"], "_shape": "rect"},
                  {"title": "B", "items": ["짧음"], "_shape": "rect"}]
    require(gen._diagram_fit_item_pt(long_items, 1800, 11) < gen.DIAGRAM_ITEM_PT,
            "long items must shrink the item font")
    require(gen._diagram_fit_item_pt(three, 4500, 11) == gen.DIAGRAM_ITEM_PT,
            "short items must keep 10pt")


    # --- 표 정렬 정책 (260909, 손수정본 기준) ---
    require(gen.infer_column_alignments(
        ["구분", "기업", "조달액", "시점"],
        [["추진(전망)", "Anthropic", "1,000억 달러", "'26.10∼11월"],
         ["기록 1위", "SpaceX", "857억 달러", "'26.6월"]]) == ["center", "left", "right", "center"],
        "첫 열 라벨·시점 열은 가운데, 기업명은 왼쪽, 금액은 오른쪽")
    require(gen.infer_column_alignments(
        ["투자사", "투자금액", "투자시점", "비고"],
        [["Google", "3억 달러", "'23.2월", "초기 지분 약 10% 확보"],
         ["Spark Capital 등", "4.5억 달러", "'23.5월", "Salesforce Ventures 공동 참여"]]) == ["center", "right", "center", "left"],
        "비고(서술) 열은 왼쪽 유지")
    require(gen.infer_column_alignments(
        ["구분", "Anthropic", "OpenAI"],
        [["조달 목표액", "1,000억 달러", "미공개"], ["예상 공모 시점", "'26.10∼11월 (중간선거 직전)", "'27년 (CFO 공식 언급)"],
         ["주요 리스크", "AI 사회적 반발·컴퓨팅 약정·정부 소송", "밸류에이션 논란·손실 지속"]]) == ["center", "center", "center"],
        "비교표(짧은 값 열)는 전부 가운데")
    require(gen._normalize_explicit_alignments(
        ["구분", "기업", "시점"], [["기록 1위", "SpaceX", "'26.6월"]], ["left", "left", "left"]) == ["center", "left", "center"],
        "explicit left on label/period columns is normalised to center")
    require(gen._normalize_explicit_alignments(
        ["구분", "기업", "시점"], [["기록 1위", "SpaceX", "'26.6월"]], ["left", "left", "left"], strict=True) == ["left", "left", "left"],
        "alignmentsStrict keeps explicit alignments")


    # --- □ 제목 / 캡션 의미 중복 (260909) ---
    require(gen._heading_caption_duplicate("주요 지표 대비", "상장 추진 현황 비교"), "대비≈비교 must be a duplicate")
    require(not gen._heading_caption_duplicate("주요 투자사·투자금액·투자시점", "Anthropic 주요 투자 유치 이력"),
            "different head nouns must not merge")
    dup_data = {
        "title": "캡션 중복 회귀", "date": "'26. 9. 9 (수)",
        "sections": [{"heading": "주요 지표 대비",
                      "bullets": [{"kind": "table", "caption": "상장 추진 현황 비교",
                                   "columns": ["구분", "A"], "rows": [["x", "1"]]}]}],
        "appendices": [],
    }
    dup_xml = _generate_and_read_xml(generator, dup_data, shape_dir, shape_dir / "dup-output.docx")
    require("□ 상장 추진 현황 비교" in dup_xml and "&lt; 상장 추진 현황 비교 &gt;" not in dup_xml
            and "주요 지표 대비" not in dup_xml,
            "heading must take the caption text and the caption line must be dropped")


    # --- 이동글틀 위치 (260909) ---
    require(gen.ANNOT_DROP_DXA == 324 and gen.ANNOT_X_NUDGE_DXA == 24, "annotation offsets drifted")
    require(gen._annotation_is_long("확정 전 비밀유지 심사 절차, 제출 직후 침묵기간 진입", 5719, 7182),
            "annotation overhanging the anchor line end by >120pt must switch to ┘ mode")
    require(not gen._annotation_is_long("8/21일 뉴욕타임스 보도", 532, 8378), "short annotation stays * mode")


    # --- 이동글틀 배치 계획 (260923 손수정본: Meta Muse 서비스 개요) ---
    dash_start = gen.measure_dxa(gen.PREFIX["dash"])
    def _geom(text, anchor):
        a = dash_start + gen.measure_dxa(text[:text.find(anchor)])
        return a, dash_start, dash_start + gen.measure_dxa(text)
    # ① ┘ 박스는 윗줄 글자 시작점보다 왼쪽으로 나가지 않는다 — ┘ 를 오른쪽으로 옮겨 맞춘다
    a, s0, e0 = _geom("출시 12일 만에 누적 설치 280만, 미국 App Store 1위로 ChatGPT 추월", "280만")
    pl = gen.plan_annotation_layout("출처 : Apptopia 집계, TechCrunch (9/21일). 같은 12일 기준 iOS 미국·캐나다 설치 Muse 180만 vs. ChatGPT 130만", a, s0, e0)
    require(pl["long_mode"] and pl["x_dxa"] == s0 and pl["shifted"] and pl["fallback"] is None
            and gen.ANNOT_MIN_SCALE_PCT <= pl["scale_pct"] <= gen.WIDTH_PCT,
            f"┘ box must be flush with the line text start (shifted, scaled if needed): {pl}")
    require(pl["x_dxa"] + gen.measure_annot_dxa(pl["display_text"], pl["scale_pct"]) <= e0 + gen.ANNOT_TAIL_TOLERANCE_DXA,
            "shifted ┘ must still end under the anchor line")
    # ② 출처 이동글틀을 줄 끝 날짜에 앵커하면 ┘ 가 그 아래에 그대로 온다
    a, s0, e0 = _geom("Meta, 사용자 대신 작업을 실행하는 개인 AI Agent 'Muse' 미국 출시 (9/8)", "(9/8)")
    pl = gen.plan_annotation_layout("출처 : Meta Newsroom (about.fb.com/news/2026/09/introducing-muse-personal-ai-agent)", a, s0, e0)
    require(pl["long_mode"] and not pl["shifted"] and pl["x_dxa"] >= s0
            and abs(pl["x_dxa"] + gen.measure_annot_dxa(pl["display_text"], pl["scale_pct"]) - (a + gen.ANNOT_FULLWIDTH_DXA)) <= 40,
            f"┘ must sit under the trailing date anchor: {pl}")
    # ③ 모델명 소개 — 우측 여백만 살짝 넘치면 ┘ 대신 `*` 유지 + 장평 축소
    a, s0, e0 = _geom("모델 : Muse Spark (Superintelligence Labs 첫 자체 모델, 비공개 가중치)", "Muse Spark")
    pl = gen.plan_annotation_layout("'26.4월 공개, Llama 대체. Artificial Analysis 지능지수 52 (Llama 4 Maverick 18), 1.3 버전 9/2일 배포", a, s0, e0,
                                    long_hint=True)
    require(not pl["long_mode"] and pl["x_dxa"] == a + gen.ANNOT_X_NUDGE_DXA and pl["scale_pct"] < gen.WIDTH_PCT
            and pl["x_dxa"] + gen.measure_annot_dxa(pl["display_text"], pl["scale_pct"]) <= gen.PAGE_CONTENT_WIDTH,
            f"model-name annotation must stay in `*` mode with reduced 장평: {pl}")
    # ④ 짧은 주석은 종전과 같이 `*` 95%
    pl = gen.plan_annotation_layout("8/21일 뉴욕타임스 보도", 532, 532, 8378)
    require(not pl["long_mode"] and pl["scale_pct"] == gen.WIDTH_PCT and pl["x_dxa"] == 532 + gen.ANNOT_X_NUDGE_DXA,
            "short annotation must be unchanged")
    # ⑤ 어떤 경우에도 박스가 윗줄 글자 시작점 왼쪽(x=0)으로 밀리지 않는다
    pl = gen.plan_annotation_layout("MIT 라이선스 오픈소스 Agent 프레임워크, 비영리 OpenClaw 재단(OpenAI·Amazon·Red Hat 후원) 관리, 노출 인스턴스 3만+ 사고",
                                    dash_start, dash_start, dash_start + 8700)
    require(pl["x_dxa"] >= dash_start and pl["fallback"] == "overflow", f"over-wide annotation must not fall back to x=0: {pl}")
    # ⑥ 줄바꿈으로 갈라진 앵커는 앵커가 시작되는 줄에 붙는다 (Claude 비용 보고서 3p 사고)
    note_text = "위 수치는 Anthropic이 공개한 평가 결과이며, 실제 업무 적용 전 자체 평가 필요"
    note_lines = gen.split_bullet_text(gen.PREFIX["note"], note_text, round(gen.PAGE_CONTENT_WIDTH * 0.99),
                                       round((gen.PAGE_CONTENT_WIDTH - gen.measure_dxa(gen.PREFIX["note"])) * 0.99))
    require(len(note_lines) == 2 and gen._locate_anchor_across_lines(note_lines, note_text, "자체 평가") == (0, note_lines[0].find("자체")),
            f"split anchor must resolve to the first line: {note_lines}")
    # ⑦ 부분 강조 마크업 + `예시 :` → `예)`
    clean, spans = gen.parse_inline_emphasis("정의 : 목표를 __앱 종료 후에도 일하는 상시 Agent__ + **핵심**")
    require(clean == "정의 : 목표를 앱 종료 후에도 일하는 상시 Agent + 핵심" and spans == [(9, 30, "underline"), (33, 35, "bold")],
            f"inline emphasis parse: {clean!r} {spans}")
    require(gen.normalize_example_label("예시 : 이메일 발송·여행 예약") == "예) 이메일 발송·여행 예약"
            and gen.normalize_example_label("예정 : 9월") == "예정 : 9월", "예시 : → 예) normalization")
    emph_data = {
        "title": "Meta Muse 서비스 개요", "date": "'26. 9. 23 (수)",
        "sections": [{"heading": "개요",
                      "bullets": [{"kind": "dash", "text": "정의 : 목표를 실행 계획으로 바꿔 __앱 종료 후에도 일하는 상시 Agent__"},
                                  {"kind": "dot", "text": "예시 : 이메일 발송·여행 예약"},
                                  {"kind": "note", "text": note_text,
                                   "annotation": {"anchor": "자체 평가", "text": "방향성 자료이며 업무별 재검증이 필요"}},
                                  {"kind": "table", "columns": ["구분", "Meta Muse", "OpenClaw"],
                                   "rows": [["형태", "전용 VM", "자체 호스팅"], ["가격", "무료∼100$", "무료"]]}]}],
        "appendices": [],
    }
    emph_xml = _generate_and_read_xml(generator, emph_data, shape_dir, shape_dir / "emph-output.docx")
    require("__" not in emph_xml and "**" not in emph_xml, "emphasis markers leaked into the document")
    require(re.search(r'<w:u w:val="single"/>.{0,400}?<w:t xml:space="preserve">앱 종료 후에도 일하는 상시 Agent</w:t>', emph_xml, re.S)
            and "<w:t xml:space=\"preserve\">정의 : 목표를 실행 계획으로 바꿔 </w:t>" in emph_xml,
            "partial underline must split the line into runs")
    require("·</w:t>" in emph_xml and "예) 이메일 발송·여행 예약" in emph_xml and "예시 :" not in emph_xml, "예시 : must render as 예)")
    # 표 강조 열 — 제목에 있는 'Meta Muse' 열이 자동으로 파란 1.5pt 테두리
    tc_blocks = re.findall(r"<w:tc>.*?</w:tc>", emph_xml, re.S)
    muse_cells = [c for c in tc_blocks if ">Meta Muse<" in c or ">전용 VM<" in c or ">무료∼100$<" in c]
    require(len(muse_cells) == 3 and all('w:left w:val="single" w:sz="12" w:color="0000FF"' in c
                                         and 'w:right w:val="single" w:sz="12" w:color="0000FF"' in c for c in muse_cells),
            "accent column cells must have blue 1.5pt left/right borders")
    require('w:top w:val="single" w:sz="12" w:color="0000FF"' in muse_cells[0]
            and 'w:bottom w:val="single" w:sz="12" w:color="0000FF"' in muse_cells[-1]
            and 'w:bottom w:val="single" w:sz="12" w:color="000000"' in muse_cells[0],
            "accent column must be boxed (header top / last-row bottom blue, header underline stays black)")
    other_cells = [c for c in tc_blocks if ">OpenClaw<" in c or ">자체 호스팅<" in c]
    require(all('w:left w:val="single" w:sz="12" w:color="0000FF"' in c and 'w:right w:val="single" w:sz="4" w:color="000000"' in c
                for c in other_cells), "neighbour column must share the blue edge only on the facing side")
    off_data = dict(emph_data); off_data["sections"] = [dict(emph_data["sections"][0])]
    off_data["sections"][0]["bullets"] = [dict(emph_data["sections"][0]["bullets"][3], highlightColumn=False)]
    off_xml = _generate_and_read_xml(generator, off_data, shape_dir, shape_dir / "emph-off-output.docx")
    require('w:color="0000FF"' not in off_xml, "highlightColumn:false must disable the accent")
    # 세 번째 불릿(2줄 ※)의 이동글틀은 첫 줄 단락에 붙고 ┘ 가 '자체' 아래 — x 는 본문 시작점 이상
    ann_blocks = re.findall(r'<wp:anchor.*?</wp:anchor>', emph_xml, re.S)
    ann_blocks = [b for b in ann_blocks if "재검증이 필요" in b]
    require(len(ann_blocks) == 1, "split-anchor annotation missing")
    x_emu = int(re.search(r'positionH relativeFrom="column"><wp:posOffset>(-?\d+)', ann_blocks[0]).group(1))
    require(x_emu >= gen._emu_from_dxa(gen.measure_dxa(gen.PREFIX["note"])) and "\u2518" in ann_blocks[0],
            "┘ annotation must not start left of the note text")
    first_line_p = emph_xml.find("실제 업무 적용 전 자체</w:t>")
    require(first_line_p != -1 and emph_xml.find("재검증이 필요", first_line_p) < emph_xml.find("<w:t xml:space=\"preserve\">평가 필요</w:t>"),
            "annotation must be attached to the first wrapped line where the anchor starts")
    url_data = {
        "title": "Anthropic 상장 추진 현황 및 SDS 영향",
        "sourceUrl": "https://www.cnbc.com/2026/09/05/anthropic-ipo-launch-shifts-toward-mid-october-reuters.html",
        "date": "'26. 9. 9 (수)", "sections": [{"heading": "a", "bullets": [{"kind": "dash", "text": "b"}]}], "appendices": [],
    }
    url_xml = _generate_and_read_xml(generator, url_data, shape_dir, shape_dir / "url-output.docx")
    m = re.search(r'name="SourceUrl \d+"', url_xml)
    require(m is not None, "source url textbox missing")
    src_block = url_xml[url_xml.rfind("<wp:anchor", 0, m.start()):url_xml.find("</wp:anchor>", m.start())]
    x_emu = int(re.search(r'positionH relativeFrom="column"><wp:posOffset>(-?\d+)', src_block).group(1))
    cx_emu = int(re.search(r'<wp:extent cx="(\d+)"', src_block).group(1))
    require(x_emu + cx_emu <= gen._emu_from_dxa(gen.PAGE_CONTENT_WIDTH),
            "source URL box must stay inside the content width")
    require(cx_emu >= gen._emu_from_dxa(gen.measure_annot_dxa("* 출처 : " + url_data["sourceUrl"])),
            "source URL box must be wide enough for the whole URL")


    builder = (root / "assets" / "prompt-builder.html").read_text(encoding="utf-8")
    require('id="repositoryLink"' in builder and "https://github.com/garzette0905/samsung-word-writer-pro" in builder,
            "GitHub 저장소 버튼 없음")
    require('divider.className = "doc-divider"' in builder, "01~06 | 07~10 점선 구분 없음")
    require("__…__" in builder and "예)" in builder and "highlightColumn" in builder and "(9/8)" in builder,
            "표준 작업 지시에 강조·예)·강조 열·앵커 규칙 누락")


    print("[diagram-regression] OK")
    return 0




if __name__ == "__main__":
    raise SystemExit(main())
