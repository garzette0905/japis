#!/bin/sh
#
# gh-pages 호스팅 페이지 동기화
# https://github.com/garzette0905/samsung-word-writer-pro
#
# main 의 에셋을 gh-pages 브랜치로 복사한다.
#
#   assets/prompt-builder.html  ->  index.html
#   assets/user-manual.html     ->  user-manual.html
#   assets/downloads/*.zip      ->  downloads/*.zip
#
# main 이 단일 원본(single source of truth)이다. gh-pages 에서 직접 파일을
# 고치면 다음 동기화 때 덮어써지므로, 수정은 항상 main 의 assets/ 에서 한다.
#
# 사용법:
#   scripts/sync-gh-pages.sh [<remote>] [<commit>]
#     remote  기본값 origin
#     commit  게시할 main 커밋. 기본값 HEAD
#
# 보통은 pre-push 훅이 자동 호출한다 (scripts/install-hooks.sh 로 설치).
# 훅 없이 수동으로 돌릴 때는 인자 없이 실행하면 된다.
#
# 동작 방식: worktree 나 checkout 없이 git plumbing 으로 gh-pages 커밋을
# 만들어 push 한다. 작업 트리를 전혀 건드리지 않고, blob 을 그대로 재사용하므로
# 줄바꿈(CRLF)도 원본 그대로 보존된다.


set -u


REMOTE="${1:-origin}"
SRC_COMMIT="${2:-HEAD}"


# main 경로 -> gh-pages 경로 (공백 구분 쌍)
MAPPINGS="assets/prompt-builder.html:index.html assets/user-manual.html:user-manual.html"


# main에 추적된 배포 ZIP은 동일한 파일명으로 downloads/에 게시한다.
for src in $(git ls-tree -r --name-only "$SRC_COMMIT" -- assets/downloads 2>/dev/null); do
    case "$src" in
        assets/downloads/*.zip) MAPPINGS="$MAPPINGS $src:downloads/${src##*/}" ;;
    esac
done


log() { echo "[gh-pages sync] $*"; }
err() { echo "[gh-pages sync] $*" >&2; }


src_sha=$(git rev-parse -q --verify "$SRC_COMMIT^{commit}" 2>/dev/null) || {
    err "커밋을 찾을 수 없습니다: $SRC_COMMIT"
    exit 1
}


# gh-pages 최신 상태 확보
if ! git fetch -q "$REMOTE" gh-pages 2>/dev/null; then
    err "'$REMOTE' 에서 gh-pages 를 fetch 하지 못했습니다. 동기화를 건너뜁니다."
    exit 1
fi
base=$(git rev-parse -q --verify FETCH_HEAD) || {
    err "gh-pages 브랜치를 찾을 수 없습니다. 동기화를 건너뜁니다."
    exit 1
}


# 바뀐 파일이 있는지 먼저 확인 (없으면 빈 커밋을 만들지 않는다)
changed=""
for pair in $MAPPINGS; do
    src=${pair%%:*}
    dst=${pair##*:}
    new=$(git rev-parse -q --verify "$src_sha:$src" 2>/dev/null) || {
        err "main 에 $src 가 없습니다. 건너뜁니다."
        continue
    }
    old=$(git rev-parse -q --verify "$base:$dst" 2>/dev/null || true)
    [ "$new" = "$old" ] || changed="$changed $dst"
done


if [ -z "$changed" ]; then
    log "변경 없음 - 호스팅 페이지는 이미 최신입니다."
    exit 0
fi


# 임시 인덱스에 gh-pages 트리를 읽고 바뀐 blob 만 갈아끼운다
idx=$(mktemp -u "${TMPDIR:-/tmp}/ghpages-idx.XXXXXX")
export GIT_INDEX_FILE="$idx"
trap 'rm -f "$idx"' EXIT INT TERM


if ! git read-tree "$base"; then
    err "gh-pages 트리를 읽지 못했습니다."
    exit 1
fi


# gh-pages에는 최신 배포 ZIP만 유지한다. main에서 사라진 이전 timestamp ZIP 제거.
for old in $(git ls-tree -r --name-only "$base" -- downloads 2>/dev/null); do
    case "$old" in
        downloads/samsung-word-writer-pro-??????_????.zip)
            keep=""
            for pair in $MAPPINGS; do
                [ "${pair##*:}" = "$old" ] && keep="yes"
            done
            [ "$keep" = "yes" ] || git update-index --force-remove "$old"
            ;;
    esac
done


for pair in $MAPPINGS; do
    src=${pair%%:*}
    dst=${pair##*:}
    new=$(git rev-parse -q --verify "$src_sha:$src" 2>/dev/null) || continue
    git update-index --add --cacheinfo "100644,$new,$dst" || {
        err "$dst 갱신 실패"
        exit 1
    }
done


tree=$(git write-tree) || { err "트리 생성 실패"; exit 1; }
unset GIT_INDEX_FILE


short=$(git rev-parse --short "$src_sha")
subject=$(git log -1 --format=%s "$src_sha")
commit=$(git commit-tree "$tree" -p "$base" -m "docs: 호스팅 페이지 자동 동기화 (main ${short})


main ${short} 의 에셋을 gh-pages 로 반영합니다.
  ${subject}


갱신 대상:${changed}


scripts/sync-gh-pages.sh 가 자동 생성한 커밋입니다.") || {
    err "커밋 생성 실패"
    exit 1
}


if git push -q "$REMOTE" "$commit:refs/heads/gh-pages"; then
    log "호스팅 페이지 갱신 완료:${changed}  ->  $(git rev-parse --short "$commit")"
    exit 0
else
    err "gh-pages push 실패. 아래 명령으로 수동 재시도하세요:"
    err "  git push $REMOTE $commit:refs/heads/gh-pages"
    exit 1
fi
