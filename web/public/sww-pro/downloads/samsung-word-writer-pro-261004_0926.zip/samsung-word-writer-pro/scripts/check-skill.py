#!/usr/bin/env python3
"""SKILL.md front matter 검증.


ChatGPT·Codex 등에 스킬을 업로드할 때 적용되는 제약을 미리 잡는다.
제약을 어기면 업로드 자체가 거부된다:


    Invalid SKILL.md front matter in samsung-word-writer-pro:
    SKILL.md front matter 'description' must be 1-1024 characters long


추가로 assets/ 를 검증한다 (260917):
  - NASCA DRM 헤더(`<## NASC`)가 붙은 파일 → 오류. 사내 PC 에서 DRM 이 걸린 docx 가
    패키지에 섞이면 Claude Desktop 이 스킬 설치 임시 폴더를 삭제하지 못해(ENOTEMPTY)
    동기화가 무한 재시도되고 새 대화가 응답하지 않는 사고가 났다.
  - docx/xlsx/pptx 가 ZIP(`PK`)으로 열리지 않거나 CRC 가 깨진 경우 → 오류.
  - 정상 Office 바이너리도 경고 — 배포 패키지에는 바이너리 문서를 넣지 않는 것이 기본.


사용법:
    python scripts/check-skill.py          # 작업 트리 검사 (SKILL.md + assets/)
    python scripts/check-skill.py <path>   # 특정 SKILL.md 검사 (assets 는 그 옆 폴더)


정상이면 exit 0, 위반이 있으면 exit 1.
"""
from __future__ import annotations


import io
import re
import sys
import zipfile
from pathlib import Path


# Windows 콘솔(cp949)에서 한글·기호 출력이 UnicodeEncodeError 로 죽는 것을 막는다.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):  # 파이프로 리다이렉트된 경우 등
        pass


# 업로더가 강제하는 값
LIMITS = {
    "name": (1, 64),
    "description": (1, 1024),
}
NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


# assets 검증 기준
NASCA_MAGIC = b"<## NASC"          # NASCA DRM 파일 헤더 (일반 docx 는 b"PK")
ZIP_MAGIC = b"PK"
OFFICE_SUFFIXES = {".docx", ".dotx", ".docm", ".xlsx", ".xlsm", ".pptx", ".potx"}
ASSET_SKIP_DIRS = {"downloads"}    # 배포 ZIP 자체는 검사 대상이 아니다




def check_assets(assets_dir: Path) -> tuple[list[str], list[str]]:
    """assets/ 아래 파일을 검사해 (errors, warnings) 를 돌려준다."""
    errors: list[str] = []
    warnings: list[str] = []
    if not assets_dir.is_dir():
        return errors, warnings
    for f in sorted(assets_dir.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(assets_dir.parent).as_posix()
        if any(part in ASSET_SKIP_DIRS for part in f.relative_to(assets_dir).parts[:-1]):
            continue
        with open(f, "rb") as fh:
            head = fh.read(8)
        if head.startswith(NASCA_MAGIC):
            errors.append(f"{rel}: NASCA DRM 파일 (헤더 '<## NASC') - 패키지에 넣을 수 없습니다. "
                          "DRM 을 해제하거나 파일을 제거하세요.")
            continue
        if f.suffix.lower() in OFFICE_SUFFIXES:
            if not head.startswith(ZIP_MAGIC):
                errors.append(f"{rel}: Office 문서가 ZIP('PK')으로 시작하지 않습니다 - 손상 또는 암호화.")
                continue
            try:
                with zipfile.ZipFile(f) as zf:
                    broken = zf.testzip()
            except zipfile.BadZipFile as exc:
                errors.append(f"{rel}: ZIP 으로 열리지 않습니다 ({exc}).")
                continue
            if broken:
                errors.append(f"{rel}: ZIP 엔트리 손상 ({broken}).")
                continue
            warnings.append(f"{rel}: Office 바이너리가 assets 에 포함되어 있습니다 - 배포 패키지에는 "
                            "바이너리 문서를 넣지 않는 것이 기본입니다(DRM 재발 위험). 정말 필요한지 확인하세요.")
    return errors, warnings




def main(argv: list[str]) -> int:
    path = Path(argv[1]) if len(argv) > 1 else Path(__file__).resolve().parent.parent / "SKILL.md"
    if not path.is_file():
        print(f"[check-skill] SKILL.md 를 찾을 수 없습니다: {path}", file=sys.stderr)
        return 1


    # utf-8-sig: BOM 이 붙은 파일도 front matter 를 정상 인식한다
    text = io.open(path, encoding="utf-8-sig").read()
    m = re.match(r"^---\r?\n(.*?)\r?\n---", text, re.S)
    if not m:
        print("[check-skill] YAML front matter(--- ... ---)가 없습니다.", file=sys.stderr)
        return 1


    front = m.group(1)
    errors: list[str] = []
    warnings: list[str] = []


    fields = {}
    for key in LIMITS:
        fm = re.search(rf"^{key}:\s*(.*)$", front, re.M)
        if not fm:
            errors.append(f"'{key}' 필드가 없습니다.")
            continue
        fields[key] = fm.group(1).strip()


    for key, value in fields.items():
        lo, hi = LIMITS[key]
        n = len(value)
        if not (lo <= n <= hi):
            errors.append(f"'{key}' 길이 {n}자 - 허용 범위 {lo}-{hi}자 (초과분 {n - hi}자)")
        elif n > hi * 0.95:
            warnings.append(f"'{key}' 길이 {n}자 - 한도 {hi}자에 근접 (여유 {hi - n}자)")


    name = fields.get("name", "")
    if name and not NAME_RE.match(name):
        errors.append(f"'name' 은 소문자·숫자·하이픈만 사용해야 합니다: {name!r}")


    asset_errors, asset_warnings = check_assets(path.parent / "assets")
    errors += asset_errors
    warnings += asset_warnings


    for w in warnings:
        print(f"[check-skill] 경고: {w}")


    if errors:
        print(f"[check-skill] {path} 검증 실패:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        print("  스킬 업로드/설치가 거부되거나 사용자 환경을 망가뜨릴 수 있습니다. 위 항목을 수정하세요.",
              file=sys.stderr)
        return 1


    print(
        "[check-skill] OK - name {}자, description {}자 (한도 1024), assets DRM/Office 바이너리 없음".format(
            len(fields.get("name", "")), len(fields.get("description", ""))
        )
    )
    return 0




if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
