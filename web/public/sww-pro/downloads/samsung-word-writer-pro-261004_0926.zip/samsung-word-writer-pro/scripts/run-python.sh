#!/bin/sh
# Git hook에서 사용할 정상 Python 실행기를 찾고 전달받은 스크립트를 실행한다.


set -u


if [ -n "${SWW_PYTHON:-}" ] && "$SWW_PYTHON" -c "import sys" >/dev/null 2>&1; then
    exec "$SWW_PYTHON" "$@"
fi


for cmd in python python3; do
    if command -v "$cmd" >/dev/null 2>&1 && "$cmd" -c "import sys" >/dev/null 2>&1; then
        exec "$cmd" "$@"
    fi
done


if command -v py >/dev/null 2>&1 && py -3 -c "import sys" >/dev/null 2>&1; then
    exec py -3 "$@"
fi


if [ -n "${USERPROFILE:-}" ]; then
    user_root="$USERPROFILE"
    if command -v cygpath >/dev/null 2>&1; then
        user_root=$(cygpath -u "$USERPROFILE")
    fi
    bundled="$user_root/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe"
    if [ -f "$bundled" ] && "$bundled" -c "import sys" >/dev/null 2>&1; then
        exec "$bundled" "$@"
    fi
fi


echo "[git hook] 실행 가능한 Python을 찾지 못했습니다." >&2
echo "Python 3을 설치하거나 SWW_PYTHON 환경변수에 실행 파일 경로를 지정하세요." >&2
exit 127
