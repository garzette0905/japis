#!/usr/bin/env python3
"""Word 문서 2개 비교 → 최신 버전 복사본에 변경부분 노란 하이라이트 (06 문서비교 모드).


    python scripts/compare_docx.py <이전.docx> <최신.docx> [--out 경로] [--limit 0.20]
                                   [--json 경로] [--force] [--quiet]


동작
  1. 두 문서의 단락(본문·표 셀·이동글틀 텍스트박스)을 순서대로 뽑아 단락 단위로 정렬(diff)한다.
  2. 짝이 지어진 단락은 글자 단위로 다시 비교해 **최신본에서 추가·수정된 글자 범위**만 찾는다.
     새로 들어온 단락은 단락 전체가 변경 범위다. 이전본에서 삭제된 단락은 최신본에 표시할 곳이 없어
     요약에만 적는다.
  3. 변경 비율 = (최신본 변경 글자 수 + 이전본 삭제 글자 수) / (이전본 글자 수 + 최신본 글자 수).
     기본 상한 20% 이상이면 "많이 바뀌어 비교가 어렵다"고 알리고 **파일을 만들지 않고** exit 2.
  4. 상한 미만이면 최신본의 복사본을 만들어 변경 범위에 `w:highlight yellow`(Word COM 은
     HighlightColorIndex 7)를 칠하고 저장한다. 원본은 절대 덮어쓰지 않는다.


입력 형식
  - 일반 docx(`PK` 헤더): python-docx 로 읽고 run 을 쪼개 하이라이트 (서식·표·이미지 불변).
  - NASCA DRM docx(`<## NASC` 헤더) 등 ZIP 이 아닌 파일: Windows Word COM 으로 열어 읽고
    Range.HighlightColorIndex 로 칠한 뒤 SaveAs2 로 복사본 저장. DRM 사본은 원본과 같은 폴더에만
    저장 가능하므로 기본 출력 위치도 최신본 옆이다. Windows/pywin32 가 없으면 exit 3.


종료 코드  0 성공 / 2 변경 비율 상한 초과(비교 중지) / 3 입력 오류(파일 2개 아님·형식·DRM 처리 불가)
"""
from __future__ import annotations


import argparse
import copy
import difflib
import json
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


ZIP_MAGIC = b"PK"
NASCA_MAGIC = b"<## NASC"
WORD_SUFFIXES = {".docx", ".docm", ".dotx", ".dotm", ".doc"}
DEFAULT_LIMIT = 0.20
PAIR_MIN_RATIO = 0.5          # 이 이상 닮은 단락만 "수정된 같은 단락" 으로 짝짓는다
EXIT_OK, EXIT_TOO_MANY, EXIT_INPUT = 0, 2, 3




# --------------------------------------------------------------------------- 공통 diff
@dataclass
class Unit:
    """비교 단위 = 단락 하나. `ref` 는 하이라이트를 되돌려 칠할 때 쓰는 백엔드별 핸들."""
    text: str
    ref: object = None
    spans: list[tuple[int, int]] = field(default_factory=list)   # 최신본에서 칠할 [start, end)




@dataclass
class DiffResult:
    old_chars: int
    new_chars: int
    changed_new: int
    deleted_old: int
    changed_units: int
    added_units: int
    deleted_units: int
    changes: list[dict]            # {"kind": "modified|added|deleted", "old": str, "new": str}


    @property
    def total_chars(self) -> int:
        return self.old_chars + self.new_chars


    @property
    def ratio(self) -> float:
        return 0.0 if self.total_chars == 0 else (self.changed_new + self.deleted_old) / self.total_chars




def _norm(s: str) -> str:
    return " ".join(s.split())




def _expand_to_words(text: str, spans: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """글자 범위를 단어(공백 구분) 경계까지 넓히고 겹치는 범위를 합친다 — '128건'→'121건' 에서
    '1' 한 글자만 칠하면 읽기 어려우므로 '121건' 전체를 칠한다."""
    out: list[tuple[int, int]] = []
    for s, e in sorted(spans):
        # 범위 양끝의 공백은 먼저 떼어낸다 — " (수정)" 삽입 때 앞 단어까지 번지지 않도록
        while s < e and text[s].isspace():
            s += 1
        while e > s and text[e - 1].isspace():
            e -= 1
        if s >= e:
            continue
        while s > 0 and not text[s - 1].isspace():
            s -= 1
        while e < len(text) and not text[e].isspace():
            e += 1
        if out and s <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out




def _char_spans(old: str, new: str) -> tuple[list[tuple[int, int]], int, int]:
    """단락 안 글자 diff → (칠할 범위[단어 경계로 확장], 최신본 변경 글자 수[최소 diff 기준],
    이전본에서 사라진 글자 수). 변경 비율은 확장 전의 최소 diff 로 센다."""
    sm = difflib.SequenceMatcher(None, old, new, autojunk=False)
    raw: list[tuple[int, int]] = []
    deleted = 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ("replace", "insert") and j2 > j1:
            raw.append((j1, j2))
        if tag in ("replace", "delete"):
            deleted += max(0, (i2 - i1) - (j2 - j1)) if tag == "replace" else (i2 - i1)
    changed = sum(e - s for s, e in raw)
    return _expand_to_words(new, raw), changed, deleted




def diff_units(old_units: list[Unit], new_units: list[Unit]) -> DiffResult:
    old_keys = [_norm(u.text) for u in old_units]
    new_keys = [_norm(u.text) for u in new_units]
    sm = difflib.SequenceMatcher(None, old_keys, new_keys, autojunk=False)
    changed_new = deleted_old = 0
    changed_units = added_units = deleted_units = 0
    changes: list[dict] = []


    def mark_added(u: Unit) -> None:
        nonlocal changed_new, added_units
        if u.text.strip():
            u.spans = [(0, len(u.text))]
            changed_new += len(u.text)
            added_units += 1
            changes.append({"kind": "added", "old": "", "new": u.text})


    def mark_deleted(u: Unit) -> None:
        nonlocal deleted_old, deleted_units
        if u.text.strip():
            deleted_old += len(u.text)
            deleted_units += 1
            changes.append({"kind": "deleted", "old": u.text, "new": ""})


    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "insert":
            for u in new_units[j1:j2]:
                mark_added(u)
            continue
        if tag == "delete":
            for u in old_units[i1:i2]:
                mark_deleted(u)
            continue
        # replace: 블록 안에서 가장 닮은 이전 단락과 짝짓기
        olds = list(range(i1, i2))
        for j in range(j1, j2):
            nu = new_units[j]
            best, best_r = None, 0.0
            for i in olds:
                r = difflib.SequenceMatcher(None, old_units[i].text, nu.text, autojunk=False).ratio()
                if r > best_r:
                    best, best_r = i, r
            if best is not None and best_r >= PAIR_MIN_RATIO:
                olds.remove(best)
                ou = old_units[best]
                spans, changed, deleted = _char_spans(ou.text, nu.text)
                if spans or deleted:
                    nu.spans = spans
                    changed_new += changed
                    deleted_old += deleted
                    changed_units += 1
                    changes.append({"kind": "modified", "old": ou.text, "new": nu.text})
            else:
                mark_added(nu)
        for i in olds:
            mark_deleted(old_units[i])


    return DiffResult(
        old_chars=sum(len(u.text) for u in old_units),
        new_chars=sum(len(u.text) for u in new_units),
        changed_new=changed_new, deleted_old=deleted_old,
        changed_units=changed_units, added_units=added_units, deleted_units=deleted_units,
        changes=changes,
    )




# --------------------------------------------------------------------------- 입력 판별
def sniff(path: Path) -> str:
    """'zip' | 'nasca' | 'other'"""
    with open(path, "rb") as fh:
        head = fh.read(8)
    if head.startswith(ZIP_MAGIC):
        return "zip"
    if head.startswith(NASCA_MAGIC):
        return "nasca"
    return "other"




# --------------------------------------------------------------------------- python-docx 백엔드
def _qn(tag: str) -> str:
    from docx.oxml.ns import qn  # type: ignore
    return qn(tag)




def _nearest_p(el, W_P):
    parent = el.getparent()
    while parent is not None and parent.tag != W_P:
        parent = parent.getparent()
    return parent




def _own_text_nodes(p, W_P, W_T):
    """이 단락에 직접 속한 w:t (텍스트박스 안 중첩 단락의 w:t 는 제외)."""
    return [t for t in p.iter(W_T) if _nearest_p(t, W_P) is p]




def docx_units(doc) -> list[Unit]:
    W_P, W_T = _qn("w:p"), _qn("w:t")
    units: list[Unit] = []
    for p in doc.element.body.iter(W_P):
        nodes = _own_text_nodes(p, W_P, W_T)
        text = "".join(n.text or "" for n in nodes)
        units.append(Unit(text=text, ref=p))
    return units




def _split_run_per_child(run, W_R, W_RPR):
    """w:r 안에 w:t 가 여럿이거나 w:tab/w:br 와 섞여 있으면 자식 하나당 run 하나로 쪼갠다."""
    children = [c for c in run if c.tag != W_RPR]
    if len(children) <= 1:
        return [run]
    rpr = run.find(W_RPR)
    new_runs = []
    for child in children:
        r = copy.deepcopy(run)
        for c in [c for c in r if c.tag != W_RPR]:
            r.remove(c)
        r.append(copy.deepcopy(child))
        run.addprevious(r)
        new_runs.append(r)
    run.getparent().remove(run)
    return new_runs




def _set_highlight(run, W_RPR):
    from docx.oxml import OxmlElement  # type: ignore
    rpr = run.find(W_RPR)
    if rpr is None:
        rpr = OxmlElement("w:rPr")
        run.insert(0, rpr)
    for old in rpr.findall(_qn("w:highlight")):
        rpr.remove(old)
    hl = OxmlElement("w:highlight")
    hl.set(_qn("w:val"), "yellow")
    # rPr 자식 순서 규약: highlight 는 shd/u 앞·color/sz 뒤 정도가 관례지만 Word 는 순서에 관대하다.
    rpr.append(hl)




def docx_apply_highlights(units: list[Unit]) -> int:
    W_P, W_T, W_R, W_RPR = _qn("w:p"), _qn("w:t"), _qn("w:r"), _qn("w:rPr")
    XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
    painted = 0
    for u in units:
        if not u.spans:
            continue
        p = u.ref
        # 1) 이 단락의 run 을 "w:t 하나짜리" 로 정규화
        for run in [r for r in p.findall(W_R)]:
            _split_run_per_child(run, W_R, W_RPR)
        # 2) 글자 오프셋 → w:t 매핑
        pos = 0
        pieces = []   # (start, end, t_element)
        for t in _own_text_nodes(p, W_P, W_T):
            txt = t.text or ""
            pieces.append((pos, pos + len(txt), t))
            pos += len(txt)
        # 3) w:t 하나마다 겹치는 범위를 모아 한 번에 조각내고(하이라이트/비하이라이트 교대) run 을 교체한다
        for ps, pe, t in pieces:
            local = sorted((max(s, ps) - ps, min(e, pe) - ps) for s, e in u.spans if not (pe <= s or ps >= e))
            if not local:
                continue
            run = t.getparent()
            if run is None or run.tag != W_R:
                continue
            txt = t.text or ""
            if local == [(0, len(txt))]:
                _set_highlight(run, W_RPR)
                painted += len(txt)
                continue
            segments: list[tuple[str, bool]] = []
            cursor = 0
            for ls, le in local:
                if ls > cursor:
                    segments.append((txt[cursor:ls], False))
                if le > ls:
                    segments.append((txt[ls:le], True))
                cursor = max(cursor, le)
            if cursor < len(txt):
                segments.append((txt[cursor:], False))
            for seg, hi in segments:
                r = copy.deepcopy(run)
                tt = r.find(W_T)
                tt.text = seg
                tt.set(XML_SPACE, "preserve")
                if hi:
                    _set_highlight(r, W_RPR)
                    painted += len(seg)
                run.addprevious(r)
            run.getparent().remove(run)
    return painted




def compare_plain(old_path: Path, new_path: Path, out_path: Path, limit: float, force: bool):
    try:
        import docx  # type: ignore
    except ImportError:
        _pip_install("python-docx")
        import docx  # type: ignore
    old_doc = docx.Document(str(old_path))
    new_doc = docx.Document(str(new_path))
    old_units, new_units = docx_units(old_doc), docx_units(new_doc)
    result = diff_units(old_units, new_units)
    if result.ratio >= limit and not force:
        return result, None
    painted = docx_apply_highlights(new_units)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    new_doc.save(str(out_path))
    return result, painted




# --------------------------------------------------------------------------- Word COM 백엔드 (DRM)
def _com_units(doc) -> list[Unit]:
    units: list[Unit] = []
    for para in doc.Paragraphs:
        rng = para.Range
        text = rng.Text or ""
        if text.endswith("\r"):
            text = text[:-1]
        units.append(Unit(text=text, ref=("body", rng.Start)))
    # 이동글틀(텍스트박스) — 본문 Range 에는 포함되지 않으므로 별도 수집
    try:
        for shape in doc.Shapes:
            try:
                tf = shape.TextFrame
                if not tf.HasText:
                    continue
                tr = tf.TextRange
            except Exception:
                continue
            base = tr.Start
            text = tr.Text or ""
            pos = 0
            for line in text.split("\r"):
                units.append(Unit(text=line, ref=("shape", shape, base + pos)))
                pos += len(line) + 1
    except Exception:
        pass
    return units




def _com_apply(doc, units: list[Unit]) -> int:
    painted = 0
    for u in units:
        if not u.spans:
            continue
        kind = u.ref[0]
        for s, e in u.spans:
            try:
                if kind == "body":
                    start = u.ref[1]
                    doc.Range(start + s, start + e).HighlightColorIndex = 7   # wdYellow
                else:
                    _, shape, base = u.ref
                    sub = shape.TextFrame.TextRange.Duplicate
                    sub.SetRange(base + s, base + e)
                    sub.HighlightColorIndex = 7
                painted += e - s
            except Exception as exc:  # 필드·숨김 문자로 오프셋이 어긋난 경우 — 단락 전체를 칠한다
                try:
                    if kind == "body":
                        start = u.ref[1]
                        doc.Range(start, start + len(u.text)).HighlightColorIndex = 7
                        painted += len(u.text)
                except Exception:
                    print(f"[compare] 경고: 하이라이트 실패 ({exc})", file=sys.stderr)
    return painted




def compare_com(old_path: Path, new_path: Path, out_path: Path, limit: float, force: bool):
    if os.name != "nt":
        raise RuntimeError("DRM 문서는 Windows Word COM 으로만 처리할 수 있습니다.")
    try:
        import win32com.client  # type: ignore
        import pythoncom  # type: ignore
    except ImportError:
        _pip_install("pywin32")
        import win32com.client  # type: ignore
        import pythoncom  # type: ignore
    pythoncom.CoInitialize()
    word = win32com.client.DispatchEx("Word.Application")
    word.Visible = False
    word.DisplayAlerts = 0
    old_doc = new_doc = None
    try:
        old_doc = word.Documents.Open(str(old_path), ReadOnly=True, AddToRecentFiles=False)
        new_doc = word.Documents.Open(str(new_path), ReadOnly=False, AddToRecentFiles=False)
        old_units, new_units = _com_units(old_doc), _com_units(new_doc)
        result = diff_units(old_units, new_units)
        if result.ratio >= limit and not force:
            return result, None
        painted = _com_apply(new_doc, new_units)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        new_doc.SaveAs2(str(out_path), 16)    # wdFormatDocumentDefault (.docx)
        return result, painted
    finally:
        for d in (new_doc, old_doc):
            try:
                if d is not None:
                    d.Close(0)   # wdDoNotSaveChanges — 원본은 절대 저장하지 않는다
            except Exception:
                pass
        try:
            word.Quit()
        except Exception:
            pass
        pythoncom.CoUninitialize()




# --------------------------------------------------------------------------- 유틸
def _pip_install(pkg: str) -> None:
    import subprocess
    print(f"[compare] {pkg} 설치 중...", file=sys.stderr)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", pkg], check=False)




def default_out(new_path: Path) -> Path:
    stamp = datetime.now().strftime("%y%m%d_%H%M")
    return new_path.with_name(f"{new_path.stem}_비교표시_{stamp}.docx")




def _fmt_pct(r: float) -> str:
    return f"{r * 100:.1f}%"




def print_summary(result: DiffResult, out: Path | None, painted: int | None, limit: float, quiet: bool) -> None:
    print(f"[compare] 이전본 {result.old_chars:,}자 · 최신본 {result.new_chars:,}자 · "
          f"수정 단락 {result.changed_units} · 추가 단락 {result.added_units} · 삭제 단락 {result.deleted_units}")
    print(f"[compare] 변경 비율 {_fmt_pct(result.ratio)} (상한 {_fmt_pct(limit)})")
    if out is not None:
        print(f"[compare] 하이라이트 {painted:,}자 → {out}")
    if quiet:
        return
    shown = 0
    for c in result.changes:
        if shown >= 40:
            print(f"  … 외 {len(result.changes) - shown}건")
            break
        o = c["old"].strip().replace("\n", " ")
        n = c["new"].strip().replace("\n", " ")
        o = (o[:70] + "…") if len(o) > 70 else o
        n = (n[:70] + "…") if len(n) > 70 else n
        label = {"modified": "수정", "added": "추가", "deleted": "삭제"}[c["kind"]]
        print(f"  [{label}] {o or '(없음)'} → {n or '(삭제)'}")
        shown += 1




def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description="Word 문서 2개 비교 → 최신본 변경부분 노란 하이라이트")
    ap.add_argument("docs", nargs="*", help="<이전.docx> <최신.docx> — 정확히 2개")
    ap.add_argument("--out", help="출력 경로 (기본: 최신본 옆 <이름>_비교표시_YYMMDD_HHMM.docx)")
    ap.add_argument("--limit", type=float, default=DEFAULT_LIMIT, help="변경 비율 상한 (기본 0.20)")
    ap.add_argument("--json", help="결과 요약을 JSON 으로 저장")
    ap.add_argument("--force", action="store_true", help="상한을 넘어도 하이라이트 파일을 만든다")
    ap.add_argument("--quiet", action="store_true", help="변경 목록을 출력하지 않는다")
    ap.add_argument("--engine", choices=["auto", "docx", "com"], default="auto",
                    help="auto(기본): PK 헤더면 python-docx, 아니면 Word COM / docx·com 강제 지정")
    args = ap.parse_args(argv[1:])


    if len(args.docs) != 2:
        print(f"[compare] 비교할 Word 파일 2개(이전 버전·최신 버전)가 필요합니다 — 받은 파일 {len(args.docs)}개. "
              "문서비교 작업을 진행할 수 없습니다.", file=sys.stderr)
        return EXIT_INPUT
    old_path, new_path = (Path(d).expanduser().resolve() for d in args.docs)
    for p in (old_path, new_path):
        if not p.is_file():
            print(f"[compare] 파일을 찾을 수 없습니다: {p}", file=sys.stderr)
            return EXIT_INPUT
        if p.suffix.lower() not in WORD_SUFFIXES:
            print(f"[compare] Word 파일(.docx)만 비교할 수 있습니다: {p.name}", file=sys.stderr)
            return EXIT_INPUT
    if old_path == new_path:
        print("[compare] 같은 파일 2개는 비교할 수 없습니다.", file=sys.stderr)
        return EXIT_INPUT


    kinds = {sniff(old_path), sniff(new_path)}
    out_path = Path(args.out).expanduser().resolve() if args.out else default_out(new_path)
    use_com = args.engine == "com" or (args.engine == "auto" and kinds != {"zip"})
    if args.engine == "docx" and kinds != {"zip"}:
        print("[compare] ZIP 이 아닌(DRM/암호화) 문서는 --engine docx 로 처리할 수 없습니다.", file=sys.stderr)
        return EXIT_INPUT
    try:
        if not use_com:
            result, painted = compare_plain(old_path, new_path, out_path, args.limit, args.force)
        else:
            if kinds != {"zip"}:
                print("[compare] ZIP 이 아닌(DRM/암호화) 문서가 있어 Word COM 으로 처리합니다.", file=sys.stderr)
            result, painted = compare_com(old_path, new_path, out_path, args.limit, args.force)
    except Exception as exc:
        print(f"[compare] 처리 실패: {exc}", file=sys.stderr)
        return EXIT_INPUT


    stopped = painted is None
    print_summary(result, None if stopped else out_path, painted, args.limit, args.quiet)
    if args.json:
        Path(args.json).write_text(json.dumps({
            "old": str(old_path), "new": str(new_path),
            "out": None if stopped else str(out_path),
            "ratio": round(result.ratio, 4), "limit": args.limit, "stopped": stopped,
            "old_chars": result.old_chars, "new_chars": result.new_chars,
            "changed_new_chars": result.changed_new, "deleted_old_chars": result.deleted_old,
            "changed_units": result.changed_units, "added_units": result.added_units,
            "deleted_units": result.deleted_units, "changes": result.changes,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    if stopped:
        print(f"[compare] 두 문서의 차이가 전체의 {_fmt_pct(result.ratio)}로 {_fmt_pct(args.limit)} 이상입니다 — "
              "많이 바뀌어 문서비교가 어렵습니다. 하이라이트 파일을 만들지 않고 중지합니다.", file=sys.stderr)
        return EXIT_TOO_MANY
    return EXIT_OK




if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
