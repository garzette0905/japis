#!/usr/bin/env python3
"""Word(.docx) 산출물 통합 검증 — 변환 → 페이지 수 → 줄바꿈/페이지 경계 → 충돌 판정을
**스크립트 1회**로 끝내고 텍스트 요약만 돌려준다.


목적: 렌더 검증 루프(PNG 생성 → 페이지마다 Read → 판단 → 수정)가 세션 비용의 50~70%를
차지하던 것을, 결정론적 검사 + 요약 1회로 대체한다. 육안 확인은 마지막 1회만 한다.


사용법:
    python scripts/verify_docx.py <file.docx> [옵션]
    python scripts/generate.py <content.json> <out.docx> --verify [옵션]   # 생성+검증 1턴


옵션:
    --content <json>   생성에 쓴 content JSON. 헤딩 → sections[i] 인덱스를 힌트에 붙인다.
    --png              페이지 PNG를 --out 디렉터리에 저장 (page-N.png). 마지막 육안 확인용.
    --sheet            여러 페이지를 한 장으로 합친 contact-sheet-N.png 도 저장 (6쪽/장).
    --dpi <n>          PNG 해상도 (기본 80 ≈ A4 661×935px ≈ 이미지 1장 800토큰 수준).
    --out <dir>        PNG/PDF 저장 위치 (기본 ./qa_render/<docx 파일명>/). DRM 폴더를 피한다.
    --keep-pdf         변환한 고정 레이아웃 파일(XPS 또는 PDF)을 --out 에 남긴다.
    --json <path>      전체 결과를 JSON으로 저장.
    --max-pages <n>    페이지 수 상한. 초과 시 ERROR.
    --engine <auto|word|soffice|none>  변환 엔진 강제. none = docx 구조 검사만.
    --env              환경(변환기·라이브러리) 점검만 하고 종료.


종료 코드: 0 = ERROR 없음 / 1 = ERROR 있음 / 2 = 변환·도구 실패로 판정 불가.


검사 항목(결정론적):
  [docx]  Heading 스타일 미사용 · □ 헤딩 Bold · 폰트(바탕체) · 한자 잔존 · 영문 기능어 대문자화(Of/And)
          · ASCII 물결표 · 이미지/도식 폭 초과 · `- 이 상 -` 1회 · 표 셀 여백/행 높이
  [pages] 페이지 수 · □ 헤딩 고립(하단 1~2줄) · 섹션 1~2줄 넘침 · `- 이 상 -` 단독 페이지
          · 하단 공백 1/4 초과 · 빈 페이지 · 1~2단어 widow · 이동글틀-본문 겹침 · 이동글틀 우측 초과
          · 이미지 페이지 과점(확대 렌더) · 도형 본문 영역 이탈 · 페이지 번호 연속성 · 제목 2줄
          · 페이지당 이동글틀 수(목표 3+) · 섹션 → 페이지 배치표
각 이슈에는 수정 knob(`pageBreakBefore` / `compact` / `scale` …)을 힌트로 붙인다.
"""
from __future__ import annotations


import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


SKILL_ROOT = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------------
# 생성기(scripts/generate.py)와 같은 페이지 기하 — twips 기준. 1pt = 20 twips.
# ---------------------------------------------------------------------------
PAGE_W_TW, PAGE_H_TW = 11906, 16838
MARGIN_TW = 1134
PT = 1 / 20.0
CONTENT_LEFT = MARGIN_TW * PT            # 56.7pt
CONTENT_RIGHT = (PAGE_W_TW - MARGIN_TW) * PT
CONTENT_TOP = MARGIN_TW * PT
CONTENT_BOTTOM = (PAGE_H_TW - MARGIN_TW) * PT
CONTENT_WIDTH_PT = CONTENT_RIGHT - CONTENT_LEFT
CONTENT_HEIGHT_PT = CONTENT_BOTTOM - CONTENT_TOP
CONTENT_WIDTH_EMU = (PAGE_W_TW - 2 * MARGIN_TW) * 635


BODY_LINE_PITCH_PT = 20.0   # 14pt 본문 1줄 ≈ 17pt + after 여백 → 이동 예측용 근사


EXPECTED_FONT = "바탕체"
ANNOT_MAX_PT = 10.5          # 이동글틀 9pt
TITLE_MIN_PT = 18.0          # 제목 20pt
TABLE_MAX_PT = 12.6          # 표 12pt (widow 검사 제외)
BLANK_LIMIT = 0.25           # SKILL.md: 앞 페이지 1/4 이상 공백이면 pageBreakBefore 취소
IMAGE_PAGE_DOMINANCE = 0.55  # 이미지가 본문 높이의 55% 초과 → 확대 렌더 의심
ANNOT_MIN_PER_PAGE = 3       # 이동글틀 5원칙 ⑤


NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "wpg": "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
    "wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
}
W = "{%s}" % NS["w"]


MARKER_RE = re.compile(
    r"^\s*(□|[-–—]|·|•|※|→|➔|[①-⑳]|\d{1,2}\.\s|[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ]+\.\s|<|\[|#별첨|\*)"
)
HEADING_RE = re.compile(r"^\s*(□|[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ]+\.\s|\d{1,2}\.\s)")
FOOTER_RE = re.compile(r"^\s*-\s*\d+\s*-\s*$")
END_MARK_RE = re.compile(r"^\s*-\s*이\s*상\s*-\s*$")
APPENDIX_RE = re.compile(r"^\s*#\s*별첨")
TOC_RE = re.compile(r"^\s*-\s*목\s*차\s*-\s*$")
HANJA_RE = re.compile(r"[一-鿿㐀-䶿]")
# "State Of AI", "OpenAI And Microsoft" — 영문 구 중간의 기능어가 대문자면 자동 대문자화 의심.
AUTOCAP_RE = re.compile(
    r"\b[A-Za-z][A-Za-z\-]+\s+(Of|And|The|In|On|For|To|With|At|By|From|Or|Is|Are|An|A)\s+[A-Za-z]"
)
ASCII_TILDE_RE = re.compile(r"(?<=[\d%])\s*~\s*(?=\d)")




# ---------------------------------------------------------------------------
# 결과 모델
# ---------------------------------------------------------------------------
class Report:
    def __init__(self) -> None:
        self.issues: list[dict] = []
        self.docx: dict = {}
        self.pages: list[dict] = []
        self.env: dict = {}
        self.meta: dict = {}


    def add(self, level: str, where: str, message: str, hint: str = "") -> None:
        self.issues.append({"level": level, "where": where, "message": message, "hint": hint})


    def count(self, level: str) -> int:
        return sum(1 for i in self.issues if i["level"] == level)


    def to_dict(self) -> dict:
        return {"meta": self.meta, "env": self.env, "docx": self.docx,
                "pages": self.pages, "issues": self.issues,
                "summary": {"ERROR": self.count("ERROR"), "WARN": self.count("WARN"),
                            "INFO": self.count("INFO")}}




# ---------------------------------------------------------------------------
# 환경 점검
# ---------------------------------------------------------------------------
def _try_import(name: str) -> tuple[bool, str]:
    try:
        mod = __import__(name)
        return True, str(getattr(mod, "__version__", getattr(mod, "VersionBind", "ok")))
    except Exception as exc:  # noqa: BLE001
        return False, exc.__class__.__name__




def _pip_install(pkg: str) -> bool:
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet",
                               "--disable-pip-version-check", pkg])
        return True
    except Exception:  # noqa: BLE001
        return False




def check_env(auto_install: bool = True) -> dict:
    env: dict = {"python": sys.version.split()[0], "platform": sys.platform}
    ok, ver = _try_import("docx")
    env["python-docx"] = ver if ok else None
    ok, ver = _try_import("PIL")
    env["Pillow"] = ver if ok else None
    ok, ver = _try_import("fitz")
    if not ok and auto_install:
        sys.stderr.write("[verify] PyMuPDF 설치 중 (pip install pymupdf)...\n")
        if _pip_install("pymupdf"):
            ok, ver = _try_import("fitz")
    env["PyMuPDF"] = ver if ok else None
    if sys.platform == "win32":
        ok, _ = _try_import("win32com")
        if not ok and auto_install:
            sys.stderr.write("[verify] pywin32 설치 중 (pip install pywin32)...\n")
            if _pip_install("pywin32"):
                ok, _ = _try_import("win32com")
        env["word_com"] = bool(ok)
    else:
        env["word_com"] = False
    env["soffice"] = shutil.which("soffice") or shutil.which("libreoffice") or None
    return env




def env_line(env: dict) -> str:
    parts = [f"python {env.get('python')}"]
    parts.append("python-docx " + (env.get("python-docx") or "없음"))
    parts.append("PyMuPDF " + (env.get("PyMuPDF") or "없음"))
    parts.append("Word COM " + ("가능" if env.get("word_com") else "불가"))
    parts.append("soffice " + ("있음" if env.get("soffice") else "없음"))
    return " · ".join(parts)




# ---------------------------------------------------------------------------
# [docx] 구조 검사 — python-docx 없이 XML 직접 판독 (빠르고 의존성 적음)
# ---------------------------------------------------------------------------
_TXBX_TAG = W + "txbxContent"
# ElementTree 는 parent 링크가 없어, 텍스트박스(이동글틀·도식) 안의 w:t 를 사전 계산해 둔다.
_TXBX_T_SET: set = set()




def _para_text(p: ET.Element) -> str:
    """단락 본문 텍스트 — 이동글틀(텍스트박스) 안의 글자는 제외."""
    return "".join((el.text or "") for el in p.iter(W + "t") if el not in _TXBX_T_SET)




def inspect_docx(path: Path, report: Report) -> None:
    global _TXBX_T_SET
    with zipfile.ZipFile(path) as zf:
        xml = zf.read("word/document.xml")
        styles_xml = zf.read("word/styles.xml") if "word/styles.xml" in zf.namelist() else b""
    root = ET.fromstring(xml)
    body = root.find(W + "body")
    if body is None:
        report.add("ERROR", "docx", "word/document.xml 에 w:body 가 없음")
        return


    _TXBX_T_SET = {t for tb in root.iter(_TXBX_TAG) for t in tb.iter(W + "t")}


    paragraphs = list(body.iter(W + "p"))
    texts = [_para_text(p) for p in paragraphs]


    # 1) Heading 스타일 사용 여부
    heading_styles: set[str] = set()
    for p in paragraphs:
        ps = p.find(f"{W}pPr/{W}pStyle")
        if ps is not None:
            val = ps.get(W + "val", "")
            if re.match(r"(?i)^(heading|제목|title)", val) or re.match(r"^\d$", val):
                heading_styles.add(val)
    if heading_styles:
        report.add("ERROR", "docx",
                   f"Word Heading 스타일 사용: {sorted(heading_styles)} — 엔진 규칙은 직접 서식만",
                   "원본 스타일이 남은 문서면 엔진으로 재생성")


    # 2) □ 헤딩 Bold
    not_bold: list[str] = []
    headings: list[str] = []
    for p, text in zip(paragraphs, texts):
        if not text.strip().startswith("□"):
            continue
        headings.append(text.strip())
        runs = [r for r in p.iter(W + "r") if (r.find(W + "t") is not None
                                                and r.find(W + "t") not in _TXBX_T_SET
                                                and (r.find(W + "t").text or "").strip())]
        if not runs:
            continue
        if not all(r.find(f"{W}rPr/{W}b") is not None for r in runs):
            not_bold.append(text.strip()[:30])
    if not_bold:
        report.add("ERROR", "docx", f"□ 헤딩이 Bold 가 아님: {not_bold[:3]}")


    # 3) 폰트 — 바탕체 이외 폰트가 run 에 명시되면 경고
    fonts: dict[str, int] = {}
    for rf in root.iter(W + "rFonts"):
        for attr in ("ascii", "eastAsia", "hAnsi"):
            v = rf.get(W + attr)
            if v and v != EXPECTED_FONT and not v.startswith("Symbol"):
                fonts[v] = fonts.get(v, 0) + 1
    if fonts:
        report.add("WARN", "docx", f"{EXPECTED_FONT} 이외 폰트 지정: {fonts}",
                   "표·도식 내부가 아니면 엔진 기본 폰트 사용")


    # 4) 한자 잔존 (본문 + 이동글틀 + 표 모두)
    all_text = "".join((t.text or "") for t in root.iter(W + "t"))
    hanja = sorted(set(HANJA_RE.findall(all_text)))
    if hanja:
        report.add("ERROR", "docx", f"한자 {len(hanja)}종 잔존: {''.join(hanja[:12])}",
                   "tone.md §6 — 전면 한글. content JSON 원문 수정")


    # 5) 영문 기능어 대문자화 의심 (Of/And/The …)
    suspicious: list[str] = []
    for text in texts:
        for m in AUTOCAP_RE.finditer(text):
            snippet = text[max(0, m.start() - 12): m.end() + 12].strip()
            suspicious.append(snippet)
    if suspicious:
        report.add("WARN", "docx", f"영문 기능어 대문자화 의심 {len(suspicious)}건: "
                   f"{suspicious[:3]}", "고유명사면 무시. 문장이면 noAutoCap 또는 원문 소문자 확인")


    # 6) ASCII 물결표 (범위는 ∼)
    tilde_hits = [t for t in texts if ASCII_TILDE_RE.search(t)]
    if tilde_hits:
        report.add("INFO", "docx", f"범위 표기에 ASCII '~' {len(tilde_hits)}건 (규칙: 2byte ∼)",
                   f"예: {tilde_hits[0].strip()[:40]}")


    # 7) 이미지/도식 폭
    images = 0
    oversize: list[str] = []
    for ext in root.iter("{%s}extent" % NS["wp"]):
        images += 1
        cx = int(ext.get("cx", "0"))
        if cx > CONTENT_WIDTH_EMU * 1.005:
            oversize.append(f"{cx / CONTENT_WIDTH_EMU:.0%}")
    if oversize:
        report.add("ERROR", "docx", f"이미지/도식 폭이 본문 폭 초과: {oversize}",
                   "image bullet 의 width/maxWidthPct 축소")
    diagrams = sum(1 for _ in root.iter("{%s}wgp" % NS["wpg"]))
    # 이미지 = 도식 그룹(wgp)·텍스트박스(이동글틀)가 아닌 inline/anchor 그림만 센다.
    inline_images = 0
    for tag in ("inline", "anchor"):
        for el in root.iter("{%s}%s" % (NS["wp"], tag)):
            if list(el.iter("{%s}wgp" % NS["wpg"])) or list(el.iter("{%s}txbx" % NS["wps"])):
                continue
            inline_images += 1


    # 8) `- 이 상 -` 횟수
    end_marks = sum(1 for t in texts if END_MARK_RE.match(t))
    if end_marks == 0:
        report.add("WARN", "docx", "`- 이 상 -` 종결 표기가 없음")
    elif end_marks > 1:
        report.add("WARN", "docx", f"`- 이 상 -` 가 {end_marks}회 (본문 1회만)")


    # 9) 표 — 셀 상하 여백 0, 행 최소 높이 0.8cm(454twips)
    tables = list(body.iter(W + "tbl"))
    bad_margin = bad_height = 0
    for tbl in tables:
        mar = tbl.find(f"{W}tblPr/{W}tblCellMar")
        if mar is not None:
            for side in ("top", "bottom"):
                el = mar.find(W + side)
                if el is not None and int(el.get(W + "w", "0")) != 0:
                    bad_margin += 1
        for tr in tbl.iter(W + "tr"):
            trh = tr.find(f"{W}trPr/{W}trHeight")
            if trh is None or int(trh.get(W + "val", "0")) < 454:
                bad_height += 1
    if bad_margin:
        report.add("WARN", "docx", f"표 셀 상하 여백이 0이 아닌 표 {bad_margin}개")
    if bad_height:
        report.add("WARN", "docx", f"행 최소 높이 0.8cm 미설정 행 {bad_height}개")


    # 10) 이동글틀 수 (3333FF 색 텍스트박스)
    annots = 0
    for tb in root.iter(_TXBX_TAG):
        if any(c.get(W + "val", "").upper() == "3333FF" for c in tb.iter(W + "color")):
            annots += 1


    title = next((t.strip() for t in texts if t.strip()), "")
    report.docx = {
        "paragraphs": len(paragraphs), "sections": len(headings), "tables": len(tables),
        "images": inline_images, "diagrams": diagrams, "annotations": annots,
        "end_marks": end_marks, "hanja": len(hanja), "heading_styles": sorted(heading_styles),
        "title": title[:60], "headings": [h[:40] for h in headings],
    }




# ---------------------------------------------------------------------------
# 변환 (docx → pdf)
# ---------------------------------------------------------------------------
def convert_word(src: Path, out_stem: Path) -> tuple[Path | None, int | None, str]:
    """Word COM 으로 고정 레이아웃 파일을 만든다. 성공 시 (경로, Word 페이지 수, 엔진명).


    XPS(18) 를 먼저, 실패하면 PDF(17) 를 시도한다. 사내 DRM/DLP 에이전트가 Word 의 PDF
    생성을 가로채 "읽기 전용이므로 저장할 수 없습니다" 로 실패시키는 환경이 있는데, XPS 는
    같은 레이아웃을 담고 PyMuPDF 가 그대로 읽을 수 있어 가장 안정적이다.
    """
    try:
        import pythoncom  # type: ignore
        import win32com.client  # type: ignore
    except Exception as exc:  # noqa: BLE001
        return None, None, f"pywin32 없음 ({exc.__class__.__name__})"


    # 원본이 DRM 폴더(D:\Secure Folder)나 잠긴 위치에 있어도 열리도록 임시 사본을 연다.
    work = out_stem.parent / ("_src_" + src.name)
    shutil.copy2(src, work)
    pythoncom.CoInitialize()
    errors: list[str] = []
    word = None
    try:
        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0
        try:
            word.NormalTemplate.Saved = True
        except Exception:  # noqa: BLE001
            pass
        doc = word.Documents.Open(str(work), False, True, False)   # ConfirmConversions, ReadOnly, AddToRecent
        try:
            pages = int(doc.ComputeStatistics(2))   # wdStatisticPages
            for fmt, suffix, label in ((18, ".xps", "Word COM (XPS)"), (17, ".pdf", "Word COM (PDF)")):
                target = out_stem.with_suffix(suffix)
                try:
                    doc.ExportAsFixedFormat(str(target), fmt)
                    if target.exists() and target.stat().st_size > 0:
                        return target, pages, label
                    errors.append(f"{suffix} 결과 파일 없음")
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"{suffix}: {str(exc)[:120]}")
        finally:
            doc.Close(False)
        return None, None, "Word COM 실패: " + " / ".join(errors)
    except Exception as exc:  # noqa: BLE001
        return None, None, f"Word COM 실패: {exc}"
    finally:
        if word is not None:
            try:
                word.Quit()
            except Exception:  # noqa: BLE001
                pass
        pythoncom.CoUninitialize()
        try:
            work.unlink()
        except OSError:
            pass




def convert_soffice(src: Path, out_stem: Path, soffice: str) -> tuple[Path | None, int | None, str]:
    outdir = out_stem.parent
    pdf = out_stem.with_suffix(".pdf")
    try:
        subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", str(outdir),
                        str(src)], check=True, capture_output=True, timeout=180)
    except Exception as exc:  # noqa: BLE001
        return None, None, f"soffice 실패: {exc}"
    produced = outdir / (src.stem + ".pdf")
    if produced != pdf and produced.exists():
        produced.replace(pdf)
    if not pdf.exists():
        return None, None, "soffice 결과 파일 없음"
    return pdf, None, "LibreOffice (Word 와 줄바꿈이 다를 수 있음)"




def convert_fixed(src: Path, out_stem: Path, engine: str, env: dict) -> tuple[Path | None, int | None, str]:
    """docx → 고정 레이아웃(XPS/PDF). 성공 시 (파일, Word 페이지 수 또는 None, 엔진명)."""
    order = []
    if engine in ("auto", "word") and env.get("word_com"):
        order.append("word")
    if engine in ("auto", "soffice") and env.get("soffice"):
        order.append("soffice")
    if not order:
        return None, None, "사용 가능한 변환기 없음 (Word COM/pywin32 또는 LibreOffice 필요)"
    last = ""
    for eng in order:
        if eng == "word":
            path, pages, msg = convert_word(src, out_stem)
        else:
            path, pages, msg = convert_soffice(src, out_stem, env["soffice"])
        if path is not None:
            return path, pages, msg
        last = msg
    return None, None, last




# ---------------------------------------------------------------------------
# [pages] PDF 판독 → 페이지 모델
# ---------------------------------------------------------------------------
def _is_blue(color: int) -> bool:
    r, g, b = (color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF
    return b > 0xB0 and r < 0x90 and g < 0x90




def extract_pages(pdf: Path) -> list[dict]:
    import fitz  # type: ignore


    pages: list[dict] = []
    with fitz.open(pdf) as doc:
        for page in doc:
            raw_lines: list[dict] = []
            # 이미지 bbox 는 text-dict 의 이미지 블록(type=1)에서 얻는다 — XPS 에서는
            # get_image_info() 가 클리핑 전 원본 크기를 돌려줘 실제 배치 영역과 다르다.
            images: list[dict] = []
            for block in page.get_text("dict")["blocks"]:
                if block.get("type") == 1:
                    images.append({"bbox": tuple(block["bbox"])})
                    continue
                if block.get("type") != 0:
                    continue
                for line in block["lines"]:
                    spans = [s for s in line["spans"] if s["text"].strip()]
                    if not spans:
                        continue
                    x0 = min(s["bbox"][0] for s in spans)
                    y0 = min(s["bbox"][1] for s in spans)
                    x1 = max(s["bbox"][2] for s in spans)
                    y1 = max(s["bbox"][3] for s in spans)
                    size = max(s["size"] for s in spans)
                    blue = all(_is_blue(s["color"]) for s in spans)
                    bold = any(s["flags"] & 16 for s in spans)
                    text = "".join(s["text"] for s in sorted(spans, key=lambda s: s["bbox"][0]))
                    raw_lines.append({"x0": x0, "y0": y0, "x1": x1, "y1": y1, "size": size,
                                      "blue": blue, "bold": bold, "text": text})
            lines = _merge_visual_lines(raw_lines)
            for ln in lines:
                ln["kind"] = _classify_line(ln)
            draw_rects = []
            for d in page.get_drawings():
                r = d.get("rect")
                if r is not None and (r.width > 0.5 or r.height > 0.5):
                    draw_rects.append((r.x0, r.y0, r.x1, r.y1))
            pages.append({"number": page.number + 1, "lines": lines, "images": images,
                          "drawings": draw_rects,
                          "width": page.rect.width, "height": page.rect.height})
    return pages




def _merge_visual_lines(raw: list[dict]) -> list[dict]:
    """같은 기준선 위의 조각(굵은 run, 기호 폰트 등)을 한 줄로 합친다. 이동글틀(파랑 9pt)은
    본문과 합치지 않는다."""
    raw = sorted(raw, key=lambda l: (round(l["y0"]), l["x0"]))
    merged: list[dict] = []
    for ln in raw:
        cy = (ln["y0"] + ln["y1"]) / 2
        target = None
        for m in merged[-4:]:
            mcy = (m["y0"] + m["y1"]) / 2
            if abs(mcy - cy) < 3.0 and m["blue"] == ln["blue"] and ln["x0"] >= m["x1"] - 2.0:
                target = m
                break
        if target is None:
            merged.append(dict(ln))
        else:
            gap = ln["x0"] - target["x1"]
            target["text"] += (" " if gap > 2.5 else "") + ln["text"]
            target["x1"] = max(target["x1"], ln["x1"])
            target["y0"] = min(target["y0"], ln["y0"])
            target["y1"] = max(target["y1"], ln["y1"])
            target["size"] = max(target["size"], ln["size"])
            target["bold"] = target["bold"] or ln["bold"]
    for m in merged:
        m["text"] = re.sub(r"\s+", " ", m["text"]).strip()
    return [m for m in merged if m["text"]]




def _classify_line(ln: dict) -> str:
    t = ln["text"]
    if FOOTER_RE.match(t) and ln["y0"] > CONTENT_BOTTOM - 5:
        return "footer"
    if ln["blue"] and ln["size"] <= ANNOT_MAX_PT:
        return "annot"
    if END_MARK_RE.match(t):
        return "end"
    if APPENDIX_RE.match(t):
        return "appendix"
    if TOC_RE.match(t):
        return "toc"
    if ln["size"] >= TITLE_MIN_PT:
        return "title"
    if HEADING_RE.match(t) and ln["x0"] < CONTENT_LEFT + 30:
        return "heading"
    if ln["size"] <= TABLE_MAX_PT:
        return "table"
    return "body"




# ---------------------------------------------------------------------------
# [pages] 판정 — 페이지 모델만 입력으로 받아 순수 함수로 동작 (회귀 검사 가능)
# ---------------------------------------------------------------------------
def _heading_name(text: str) -> str:
    return HEADING_RE.sub("", text, count=1).strip()




def _section_hint(name: str, knob: str, sections: list[str] | None) -> str:
    idx = _match_section(name, sections)
    where = f'sections[{idx}]' if idx is not None else f'"{name[:24]}" 섹션'
    return f'{where} 에 {knob}'




def _norm(s: str) -> str:
    return re.sub(r"[\s□·\-:：,，.()\[\]<>「」'\"]", "", s)




def _match_section(name: str, sections: list[str] | None) -> int | None:
    if not sections:
        return None
    key = _norm(name)
    for i, h in enumerate(sections):
        if _norm(h) == key:
            return i
    for i, h in enumerate(sections):
        hk = _norm(h)
        if hk and (hk in key or key in hk):
            return i
    return None




def analyze_pages(pages: list[dict], report: Report, sections: list[str] | None = None,
                  max_pages: int | None = None) -> None:
    n = len(pages)
    report.meta["pdf_pages"] = n
    if max_pages and n > max_pages:
        report.add("ERROR", "pages", f"페이지 {n}쪽 — 상한 {max_pages}쪽 초과",
                   "섹션 통합·별첨 이동·compact 로 분량 축소")


    current_heading = ""
    page_summaries: list[dict] = []
    prev_tail_heading: str | None = None      # 직전 페이지가 헤딩(+≤2줄)으로 끝났으면 그 헤딩
    prev_tail_lines = 0
    prev_section_open = False                  # 직전 페이지가 섹션 본문 도중에 끝났는가
    prev_blank = 0.0


    for idx, pg in enumerate(pages):
        pno = pg["number"]
        lines = pg["lines"]
        content = [l for l in lines if l["kind"] not in ("footer", "annot")]
        body = [l for l in content if l["kind"] in ("body", "heading", "table", "title", "end")]
        annots = [l for l in lines if l["kind"] == "annot"]
        headings_here = [l for l in content if l["kind"] == "heading"]
        is_toc = any(l["kind"] == "toc" for l in content)
        is_appendix_start = any(l["kind"] == "appendix" for l in content[:2])
        last_page = idx == n - 1


        # 채움 비율: 본문 텍스트·이미지·도형 중 가장 아래
        bottoms = [l["y1"] for l in content if l["y1"] <= CONTENT_BOTTOM + 5]
        bottoms += [im["bbox"][3] for im in pg["images"] if im["bbox"][3] <= CONTENT_BOTTOM + 5]
        bottoms += [r[3] for r in pg["drawings"] if r[3] <= CONTENT_BOTTOM + 5 and r[1] >= CONTENT_TOP - 5]
        fill = max(0.0, min(1.0, ((max(bottoms) if bottoms else CONTENT_TOP) - CONTENT_TOP)
                            / CONTENT_HEIGHT_PT))
        blank = 1.0 - fill


        # 빈 페이지
        if not body and not pg["images"] and not pg["drawings"]:
            report.add("ERROR", f"p{pno}", "빈 페이지", "pageBreakBefore 중복 또는 표/이미지 강제 이동 확인")


        # 페이지 번호 연속성
        footers = [l for l in lines if l["kind"] == "footer"]
        if footers:
            m = re.search(r"\d+", footers[0]["text"])
            if m and int(m.group()) != pno:
                report.add("WARN", f"p{pno}", f"푸터 페이지 번호 '{footers[0]['text']}' 불일치")
        elif not is_toc:
            report.add("INFO", f"p{pno}", "푸터 페이지 번호 없음")


        # 제목 2줄
        if idx == 0:
            titles = [l for l in content if l["kind"] == "title"]
            if len(titles) >= 2:
                report.add("WARN", "p1", f"제목이 {len(titles)}줄로 렌더: '{titles[0]['text'][:30]}…'",
                           "제목 20pt 1줄 고정 — 축약(tone.md §6-11)")


        # 이 페이지 첫 본문 줄들: 직전 페이지에서 넘어온 꼬리(spill) 판정
        first_heading_pos = next((i for i, l in enumerate(body) if l["kind"] == "heading"), None)
        leading = body[:first_heading_pos] if first_heading_pos is not None else body
        leading_body = [l for l in leading if l["kind"] in ("body", "table")]
        leading_end_only = leading and all(l["kind"] == "end" for l in leading)
        starts_with_heading = bool(body) and body[0]["kind"] == "heading"


        if idx > 0 and not is_appendix_start and not is_toc:
            if leading_end_only and first_heading_pos is None and last_page:
                report.add("WARN", f"p{pno}",
                           f"마지막 페이지에 `- 이 상 -` 만 남음 (p{pno - 1} 채움 {1 - prev_blank:.0%})",
                           _section_hint(current_heading, '"compact": true (또는 앞 섹션 1~2줄 축약)', sections))
            elif prev_section_open and 1 <= len(leading_body) <= 2 and (
                    first_heading_pos is not None or (last_page and len(body) <= len(leading) + 1)):
                report.add("WARN", f"p{pno - 1}→p{pno}",
                           f"섹션 '{current_heading[:24]}' 내용 {len(leading_body)}줄이 p{pno} 로 넘침: "
                           f"'{leading_body[0]['text'][:28]}'",
                           _section_hint(current_heading, '"compact": true (1~2줄 끌어올림)', sections))
            if prev_tail_heading and not starts_with_heading and leading_body:
                # 직전 페이지 하단에 헤딩 + ≤2줄만 남고 내용이 이어짐 → 고립
                moved_blank = prev_blank + (prev_tail_lines + 1) * BODY_LINE_PITCH_PT / CONTENT_HEIGHT_PT
                if moved_blank <= BLANK_LIMIT:
                    knob = f'"pageBreakBefore": true (이동 후 p{pno - 1} 공백 약 {moved_blank:.0%}, 1/4 이내)'
                else:
                    knob = (f'"compact": true 또는 앞 섹션 축약 — pageBreakBefore 는 p{pno - 1} 공백이 '
                            f'약 {moved_blank:.0%} 로 1/4 초과라 부적합')
                report.add("WARN", f"p{pno - 1}→p{pno}",
                           f"□ '{prev_tail_heading[:24]}' 헤딩이 p{pno - 1} 하단에 {prev_tail_lines}줄만 남고 이어짐",
                           _section_hint(prev_tail_heading, knob, sections))
            if starts_with_heading and prev_blank > BLANK_LIMIT:
                report.add("WARN", f"p{pno - 1}",
                           f"p{pno - 1} 하단 공백 {prev_blank:.0%} (1/4 초과) 뒤에 □ '{_heading_name(body[0]['text'])[:24]}' 로 새 페이지 시작",
                           _section_hint(_heading_name(body[0]["text"]),
                                         '"pageBreakBefore" 취소 검토 (SKILL.md 페이지 맞춤 1/4 규칙)', sections))


        # 이 페이지의 섹션 목록 + current_heading 갱신
        section_names = [_heading_name(l["text"]) for l in headings_here]


        # 하단 고립 헤딩 판정 (다음 페이지에서 확정)
        prev_tail_heading = None
        prev_tail_lines = 0
        if not last_page:
            tail = [l for l in body if l["kind"] in ("heading", "body", "table")]
            for back in range(1, 4):
                if len(tail) >= back and tail[-back]["kind"] == "heading":
                    prev_tail_heading = _heading_name(tail[-back]["text"])
                    prev_tail_lines = back - 1
                    break
            if prev_tail_heading is not None and prev_tail_lines == 0:
                # 헤딩 아래에 글자 줄은 없지만 도식(wgp)·이미지가 이어지면 고립이 아니다 —
                # 도식만 담은 섹션(헤딩 + 도식)이 흔하므로 그림 사각형 위치로 확인한다.
                heading_y1 = tail[-1]["y1"]
                below = ([r for r in pg["drawings"] if r[1] >= heading_y1 - 2]
                         + [im["bbox"] for im in pg["images"] if im["bbox"][1] >= heading_y1 - 2])
                if not below:
                    report.add("ERROR", f"p{pno}", f"□ '{prev_tail_heading[:24]}' 헤딩만 페이지 하단에 홀로 남음",
                               _section_hint(prev_tail_heading, '"pageBreakBefore": true', sections))
                prev_tail_heading = None


        # widow: 본문 14pt 줄 중, 마커 없이 시작하고 폭이 좁으며 앞줄이 같은 문단인 경우
        for i, l in enumerate(body):
            if l["kind"] != "body" or MARKER_RE.match(l["text"]):
                continue
            words = l["text"].split()
            width = l["x1"] - l["x0"]
            if len(words) <= 2 and width < CONTENT_WIDTH_PT * 0.22 and i > 0:
                prev = body[i - 1]
                if prev["kind"] == "body" and abs(prev["x0"] - l["x0"]) < 30:
                    report.add("INFO", f"p{pno}", f"1~2단어 widow: '{l['text'][:20]}' (앞줄 '{prev['text'][:22]}…')",
                               '해당 bullet 문장 2~4자 축약 또는 "scale": 90')


        # 이동글틀 겹침 / 우측 초과 / 윗줄보다 왼쪽으로 나감 (260923)
        for a in annots:
            if a["x1"] > CONTENT_RIGHT + 3:
                report.add("WARN", f"p{pno}", f"이동글틀 우측 여백 초과: '{a['text'][:28]}'",
                           "주석 축약 또는 anchor 를 앞 단어로 이동")
            # 바로 윗줄(앵커 줄) — 주석 상단보다 위에서 끝나는 본문 줄 중 가장 아래 것
            above = [b for b in body if b["kind"] in ("body", "heading") and b["y1"] <= a["y0"] + 2]
            if above:
                ln = max(above, key=lambda b: b["y1"])
                if a["y0"] - ln["y1"] < 14 and a["x0"] < ln["x0"] - 3:
                    report.add("WARN", f"p{pno}",
                               f"이동글틀 '{a['text'][:22]}' 이 윗줄 글자 시작점보다 {ln['x0'] - a['x0']:.0f}pt 왼쪽에서 시작",
                               "anchor 를 줄 끝 날짜·괄호 토큰으로 이동, 또는 주석 축약")
            ah = a["y1"] - a["y0"]
            for b in body:
                if b["kind"] in ("end",):
                    continue
                ov_y = min(a["y1"], b["y1"]) - max(a["y0"], b["y0"])
                ov_x = min(a["x1"], b["x1"]) - max(a["x0"], b["x0"])
                if ov_y > ah * 0.45 and ov_x > 4:
                    report.add("WARN", f"p{pno}",
                               f"이동글틀 '{a['text'][:22]}' 이 본문 '{b['text'][:22]}' 과 겹침",
                               "anchor 위치 변경·주석 축약, 또는 해당 bullet 을 2줄로 분리")
                    break
            for a2 in annots:
                if a2 is a or a2["y0"] < a["y0"]:
                    continue
                ov_y = min(a["y1"], a2["y1"]) - max(a["y0"], a2["y0"])
                ov_x = min(a["x1"], a2["x1"]) - max(a["x0"], a2["x0"])
                if ov_y > ah * 0.45 and ov_x > 4:
                    report.add("WARN", f"p{pno}",
                               f"이동글틀 두 개가 겹침: '{a['text'][:18]}' / '{a2['text'][:18]}'",
                               "한 줄에 주석 1개, 또는 anchor 간격 확보")


        # 이미지 과점 / 영역 이탈 / 본문 글자와 겹침
        for im in pg["images"]:
            x0, y0, x1, y1 = im["bbox"]
            # "텍스트 앞" 사진(□ 헤딩 우측)은 본문을 밀어내지 않으므로, 옆 줄이 길면 글자가
            # 사진 뒤로 들어간다. 생성기가 줄폭을 예약하지만 렌더 결과로 한 번 더 확인한다.
            for ln in pg["lines"]:
                if ln.get("kind") == "footer":
                    continue
                lh = max(ln["y1"] - ln["y0"], 1.0)
                ov_y = min(y1, ln["y1"]) - max(y0, ln["y0"])
                ov_x = min(x1, ln["x1"]) - max(x0, ln["x0"])
                if ov_y > lh * 0.4 and ov_x > 2.0:
                    report.add("WARN", f"p{pno}",
                               f"글자가 사진과 겹침: '{ln['text'][:24]}' (사진 x≥{x0 - CONTENT_LEFT:.0f}pt)",
                               "사진 옆 문장을 짧게 나누거나 profileImage.width_cm 축소 — "
                               "생성기 줄폭 예약이 빗나간 경우 사진 아래 표·도식 위치 확인")
                    break
            if (y1 - y0) > CONTENT_HEIGHT_PT * IMAGE_PAGE_DOMINANCE:
                report.add("WARN", f"p{pno}", f"이미지가 본문 높이의 {(y1 - y0) / CONTENT_HEIGHT_PT:.0%} 차지 (확대 렌더 의심)",
                           'image bullet 에 "width" 또는 "maxWidthPct": 0.6 등 축소')
            if x0 < CONTENT_LEFT - 3 or x1 > CONTENT_RIGHT + 3:
                report.add("ERROR", f"p{pno}", "이미지가 본문 좌우 영역을 벗어남", "width 축소")
        def _full_width_table_border(r) -> bool:
            # 본문 폭 전체를 덮는 표 테두리가 오른쪽 여백을 조금(≤ 20pt) 넘는 경우는 도식 이탈이 아니다.
            # CEO 현안보고 양식의 [연간 주요 업무] 박스(기준 문서 계측 폭 9954dxa > 본문 9638dxa)가 여기에 해당한다.
            return (r[0] >= CONTENT_LEFT - 6 and r[2] <= CONTENT_RIGHT + 20
                    and (r[2] - r[0]) >= CONTENT_WIDTH_PT * 0.9)


        out_of_area = [r for r in pg["drawings"]
                       if (r[0] < CONTENT_LEFT - 6 or r[2] > CONTENT_RIGHT + 6)
                       and (r[2] - r[0]) > 5 and CONTENT_TOP - 5 < r[1] < CONTENT_BOTTOM
                       and not _full_width_table_border(r)]
        if out_of_area:
            report.add("ERROR", f"p{pno}", f"도형/선 {len(out_of_area)}개가 본문 영역 밖으로 나감",
                       "도식 노드 수·제목 길이 축소 (generator-defaults.md §Diagrams)")


        # 이동글틀 개수
        if not is_toc and body and len(annots) < ANNOT_MIN_PER_PAGE and not leading_end_only:
            report.add("INFO", f"p{pno}", f"이동글틀 {len(annots)}개 (페이지당 {ANNOT_MIN_PER_PAGE}개 이상 목표)",
                       "출처·시점·용어 풀이 중 근거 있는 것만 추가 (억지 주석 금지)")


        # 하단 공백 (마지막 페이지·별첨 직전 제외) — 다음 페이지 판정에서 쓰기 위해 보관
        if not last_page and blank > BLANK_LIMIT:
            nxt = pages[idx + 1]
            nxt_content = [l for l in nxt["lines"] if l["kind"] not in ("footer", "annot")]
            nxt_first = nxt_content[0]["kind"] if nxt_content else ""
            if nxt_first == "appendix":
                pass   # 별첨은 새 페이지 시작이 규칙
            elif nxt_first != "heading":
                report.add("WARN", f"p{pno}", f"p{pno} 하단 공백 {blank:.0%} (1/4 초과) — 표/이미지/도식이 통째로 다음 페이지로 밀린 결과일 가능성",
                           "표 분할·이미지 축소·앞 bullet 이동으로 공백 축소")


        if section_names:
            current_heading = section_names[-1]
        prev_section_open = bool(body) and body[-1]["kind"] in ("body", "table") and not any(
            l["kind"] == "end" for l in body)
        prev_blank = blank
        page_summaries.append({
            "page": pno, "body_lines": len([l for l in body if l["kind"] in ("body", "table")]),
            "annotations": len(annots), "fill": round(fill, 2), "images": len(pg["images"]),
            "sections": section_names, "starts_with_heading": starts_with_heading,
            "appendix": is_appendix_start, "toc": is_toc,
        })
    report.pages = page_summaries




# ---------------------------------------------------------------------------
# PNG / contact sheet
# ---------------------------------------------------------------------------
def render_pngs(pdf: Path, out_dir: Path, dpi: int, sheet: bool) -> list[Path]:
    import fitz  # type: ignore


    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("page-*.png"):
        old.unlink()
    for old in out_dir.glob("contact-sheet-*.png"):
        old.unlink()
    paths: list[Path] = []
    with fitz.open(pdf) as doc:
        for page in doc:
            pix = page.get_pixmap(dpi=dpi)
            p = out_dir / f"page-{page.number + 1}.png"
            pix.save(str(p))
            paths.append(p)
    if sheet and paths:
        paths += make_contact_sheets(paths, out_dir)
    return paths




def make_contact_sheets(pages: list[Path], out_dir: Path, cols: int = 3, rows: int = 2) -> list[Path]:
    try:
        from PIL import Image, ImageDraw
    except Exception:  # noqa: BLE001
        return []
    per = cols * rows
    sheets: list[Path] = []
    thumb_w = 520
    for si in range(0, len(pages), per):
        chunk = pages[si: si + per]
        ims = [Image.open(p) for p in chunk]
        ratio = ims[0].height / ims[0].width
        thumb_h = int(thumb_w * ratio)
        pad, label_h = 12, 22
        sheet = Image.new("RGB", (cols * (thumb_w + pad) + pad, rows * (thumb_h + label_h + pad) + pad),
                          (235, 235, 235))
        draw = ImageDraw.Draw(sheet)
        for i, im in enumerate(ims):
            r, c = divmod(i, cols)
            x = pad + c * (thumb_w + pad)
            y = pad + r * (thumb_h + label_h + pad)
            draw.text((x + 4, y + 3), f"p{si + i + 1}", fill=(30, 30, 30))
            sheet.paste(im.resize((thumb_w, thumb_h)), (x, y + label_h))
            draw.rectangle((x, y + label_h, x + thumb_w, y + label_h + thumb_h), outline=(150, 150, 150))
            im.close()
        p = out_dir / f"contact-sheet-{si // per + 1}.png"
        sheet.save(p)
        sheets.append(p)
    return sheets




# ---------------------------------------------------------------------------
# 출력
# ---------------------------------------------------------------------------
def format_report(report: Report, png_paths: list[Path]) -> str:
    m, d = report.meta, report.docx
    out: list[str] = []
    pages_txt = "변환 안 됨" if m.get("pdf_pages") is None else f"{m['pdf_pages']}쪽"
    if m.get("word_pages") and m.get("pdf_pages") and m["word_pages"] != m["pdf_pages"]:
        pages_txt += f" (Word 집계 {m['word_pages']}쪽)"
    out.append(f"[verify] {m.get('file')} · {m.get('engine', '-')} · {pages_txt} · {m.get('size_kb', 0):.0f}KB")
    out.append(f"[env] {env_line(report.env)}")
    if d:
        out.append(f"[docx] 제목 '{d.get('title', '')[:40]}' · □ {d.get('sections')} · 표 {d.get('tables')} · "
                   f"이미지 {d.get('images')} · 도식 {d.get('diagrams')} · 이동글틀 {d.get('annotations')} · "
                   f"한자 {d.get('hanja')} · Heading스타일 {'있음' if d.get('heading_styles') else '없음'}")
    if report.pages:
        out.append("[pages]")
        for p in report.pages:
            tag = " 별첨" if p["appendix"] else (" 목차" if p["toc"] else "")
            secs = ", ".join(s[:18] for s in p["sections"]) or ("(이어짐)" if not p["toc"] else "")
            out.append(f"  p{p['page']:<2} 본문 {p['body_lines']:>2}줄 · 주석 {p['annotations']} · "
                       f"채움 {p['fill']:.0%}{tag} · 섹션: {secs}")
    err, warn, info = report.count("ERROR"), report.count("WARN"), report.count("INFO")
    out.append(f"[issues] ERROR {err} · WARN {warn} · INFO {info}")
    order = {"ERROR": 0, "WARN": 1, "INFO": 2}
    for i in sorted(report.issues, key=lambda x: order[x["level"]]):
        line = f"  {i['level']:<5} {i['where']:<8} {i['message']}"
        if i["hint"]:
            line += f"\n        → {i['hint']}"
        out.append(line)
    if png_paths:
        pngs = [p for p in png_paths if p.name.startswith("page-")]
        sheets = [p for p in png_paths if p.name.startswith("contact-")]
        out.append(f"[png] {pngs[0].parent} · page-1..{len(pngs)}.png"
                   + (f" · contact-sheet ×{len(sheets)}" if sheets else ""))
    if err:
        verdict = f"ERROR {err} — 수정 후 재생성·재검증 필수"
    elif warn:
        verdict = f"WARN {warn} — 힌트대로 JSON 수정 후 재생성·재검증 1회 (최대 2라운드)"
    else:
        verdict = "PASS — 육안 확인은 전 페이지 PNG 를 한 턴에 병렬 Read 로 1회만"
    out.append(f"[result] {verdict}")
    return "\n".join(out)




# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def load_sections(content_path: Path | None) -> list[str] | None:
    if not content_path:
        return None
    try:
        data = json.loads(content_path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    names: list[str] = []
    for s in data.get("sections") or []:
        names.append(str(s.get("heading") or ""))
    for app in data.get("appendices") or []:
        for s in app.get("sections") or []:
            names.append(str(s.get("heading") or ""))
    return names




def run(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("docx", nargs="?")
    ap.add_argument("--content")
    ap.add_argument("--png", action="store_true")
    ap.add_argument("--sheet", action="store_true")
    ap.add_argument("--dpi", type=int, default=80)
    ap.add_argument("--out")
    ap.add_argument("--keep-pdf", action="store_true")
    ap.add_argument("--json")
    ap.add_argument("--max-pages", type=int)
    ap.add_argument("--engine", choices=["auto", "word", "soffice", "none"], default="auto")
    ap.add_argument("--env", action="store_true")
    args = ap.parse_args(argv)


    report = Report()
    report.env = check_env(auto_install=not args.env)
    if args.env:
        print("[env] " + env_line(report.env))
        return 0
    if not args.docx:
        ap.error("docx 경로가 필요합니다")
    src = Path(args.docx).resolve()
    if not src.is_file():
        print(f"[verify] 파일 없음: {src}", file=sys.stderr)
        return 2
    report.meta = {"file": src.name, "path": str(src), "size_kb": src.stat().st_size / 1024}


    inspect_docx(src, report)
    sections = load_sections(Path(args.content).resolve() if args.content else None)


    out_dir = Path(args.out).resolve() if args.out else (Path.cwd() / "qa_render" / src.stem)
    png_paths: list[Path] = []
    rc_conv = 0
    if args.engine != "none":
        tmp = Path(tempfile.mkdtemp(prefix="sww-verify-"))
        fixed, word_pages, msg = convert_fixed(src, tmp / src.stem, args.engine, report.env)
        report.meta["engine"] = msg
        report.meta["word_pages"] = word_pages
        if fixed is None:
            report.add("ERROR", "convert", f"고정 레이아웃 변환 실패 — 페이지 판정 불가: {msg}",
                       "Word(pywin32) 또는 LibreOffice 설치 후 재실행. docx 구조 검사 결과만 유효")
            rc_conv = 2
        else:
            if report.env.get("PyMuPDF"):
                pages = extract_pages(fixed)
                analyze_pages(pages, report, sections, args.max_pages)
                if args.png or args.sheet:
                    png_paths = render_pngs(fixed, out_dir, args.dpi, args.sheet)
            else:
                report.meta["pdf_pages"] = word_pages
                report.add("WARN", "pages", "PyMuPDF 없음 — 페이지 수만 확인, 경계·겹침 판정 생략",
                           "pip install pymupdf")
            if args.keep_pdf:
                out_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(fixed, out_dir / fixed.name)
                report.meta["fixed_layout_file"] = str(out_dir / fixed.name)
        shutil.rmtree(tmp, ignore_errors=True)
    else:
        report.meta["engine"] = "변환 생략 (--engine none)"


    text = format_report(report, png_paths)
    print(text)
    if args.json:
        Path(args.json).write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2),
                                   encoding="utf-8")
    if rc_conv:
        return 2
    return 1 if report.count("ERROR") else 0




if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
