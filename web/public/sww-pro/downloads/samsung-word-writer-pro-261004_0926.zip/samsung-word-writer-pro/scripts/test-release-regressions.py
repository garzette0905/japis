#!/usr/bin/env python3
"""파일명·Prompt Builder·배포 ZIP·gh-pages 연결 회귀 검사."""
from __future__ import annotations


import importlib.util
import re
import sys
import tempfile
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path




def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)




def main() -> int:
    root = Path(__file__).resolve().parent.parent
    spec = importlib.util.spec_from_file_location("sww_generate", root / "scripts" / "generate.py")
    require(spec is not None and spec.loader is not None, "generate.py를 로드할 수 없음")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)


    fixed = datetime(2026, 8, 28, 9, 0, tzinfo=timezone(timedelta(hours=9)))
    named = module.apply_output_naming(
        "AGI_Frontier_AI_보고서.docx",
        {"title": "무시", "toolName": "ChatGPT", "llmVersion": "Luna 5.6"},
        fixed,
    )
    require(
        named == "AGI_Frontier_AI_보고서(ChatGPT, Luna 5.6)_260828_0900.docx",
        f"표준 파일명 불일치: {named}",
    )
    generic = module.apply_output_naming(
        "Claude Code _eli5 스킬 개요 및 활용법.docx",
        {"toolName": "Codex", "llmVersion": "GPT-5"},
        fixed,
    )
    require("(Codex, GPT-5)_260828_0900.docx" in generic,
            f"확인된 GPT-5 이름 보존 실패: {generic}")
    detailed = module.apply_output_naming(
        "상세 모델 보고서.docx",
        {"toolName": "Codex", "llmVersion": "GPT-5.6 Sol"},
        fixed,
    )
    require("(Codex, GPT-5.6 Sol)_260828_0900.docx" in detailed,
            f"상세 모델명 보존 실패: {detailed}")
    chat = module.apply_output_naming(
        "채팅 보고서.docx",
        {"toolName": "ChatGPT chat", "llmVersion": "GPT-5"},
        fixed,
    )
    require("(ChatGPT chat, GPT-5)_260828_0900.docx" in chat,
            f"ChatGPT chat Tool 이름 보존 실패: {chat}")
    require(
        module.apply_output_naming("legacy.docx", {"title": "레거시"}, fixed) == "legacy.docx",
        "메타데이터 없는 레거시 출력명 호환 실패",
    )


    builder = (root / "assets" / "prompt-builder.html").read_text(encoding="utf-8")
    link_match = re.search(
        r'id="skillZipLink" href="downloads/(samsung-word-writer-pro-\d{6}_\d{4}\.zip)" download',
        builder,
    )
    require(link_match is not None, "Prompt Builder의 시간표시 ZIP 링크가 없거나 형식 오류")
    modified_match = re.search(
        r'id="lastModified">\(최종수정일 (\d{2}-\d{2}-\d{2} \d{2}:\d{2})\)</span>',
        builder,
    )
    require(modified_match is not None, "Prompt Builder 최종수정일 형식 오류")
    zip_stamp = re.search(r'(\d{6})_(\d{4})', link_match.group(1))
    require(zip_stamp is not None, "ZIP 파일명 timestamp 파싱 실패")
    expected_modified = datetime.strptime(
        zip_stamp.group(1) + zip_stamp.group(2), "%y%m%d%H%M"
    ).strftime("%y-%m-%d %H:%M")
    require(modified_match.group(1) == expected_modified,
            "Prompt Builder 최종수정일과 ZIP 생성시각이 다름")
    download_label = ("Skill Zip파일 다운로드" if "Skill Zip파일 다운로드" in builder
                      else "Skill 다운로드(zip)")
    require(builder.index("Claude 열기") < builder.index(download_label),
            "ZIP 다운로드 링크가 Claude 열기 링크 뒤에 있지 않음")


    archive = root / "assets" / "downloads" / link_match.group(1)
    require(archive.is_file(), f"Prompt Builder가 가리키는 ZIP이 없음: {archive}")
    with zipfile.ZipFile(archive) as zf:
        names = zf.namelist()
        require(zf.testzip() is None, "ZIP CRC 검사 실패")
        require(all("\\" not in name for name in names), "ZIP에 백슬래시 경로가 있음")
        require(f"{root.name}/SKILL.md" in names, "ZIP에 SKILL.md가 없음")
        require(not any("/assets/downloads/" in name for name in names),
                "배포 ZIP 안에 배포 ZIP이 재귀 포함됨")
        require(not any("/work_" in name or name.endswith("/article_raw.txt")
                        or name.endswith("/insert_native_diagram.py") for name in names),
                "Git 미추적 작업물이 배포 ZIP에 포함됨")
        # 260917: Office 바이너리는 배포 ZIP 에 넣지 않는다 — 사내 PC 에서 NASCA DRM 이 걸린 채 배포되면
        # Claude Desktop 스킬 설치 임시 폴더 삭제가 막혀(ENOTEMPTY) 응답 지연을 일으킨다.
        office = [n for n in names if n.lower().endswith((".docx", ".dotx", ".xlsx", ".pptx"))]
        require(not office, f"배포 ZIP 에 Office 바이너리가 포함됨: {office}")
        for name in names:
            require(not zf.read(name).startswith(b"<## NASC"), f"배포 ZIP 에 NASCA DRM 파일이 포함됨: {name}")


    sync = (root / "scripts" / "sync-gh-pages.sh").read_text(encoding="utf-8")
    require("assets/downloads/*.zip" in sync and "downloads/${src##*/}" in sync,
            "gh-pages ZIP 동기화 매핑이 없음")
    require("git update-index --force-remove" in sync,
            "gh-pages 이전 timestamp ZIP 정리 로직이 없음")


    installer = (root / "scripts" / "install-hooks.sh").read_text(encoding="utf-8")
    require('precommit="$hookdir/pre-commit"' in installer,
            "pre-commit 설치 로직이 없음")
    require('scripts/package-skill.py' in installer and
            'git add -A -- "$root/assets/downloads"' in installer,
            "pre-commit ZIP 생성·스테이징 로직이 없음")
    require('if ! git diff --quiet --' in installer,
            "unstaged 추적 파일 보호 로직이 없음")


    print(f"[release-test] OK - {archive.name}, {len(names)}개 엔트리")
    return 0




if __name__ == "__main__":
    raise SystemExit(main())
